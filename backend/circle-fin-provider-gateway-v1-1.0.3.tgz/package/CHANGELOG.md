# @circle-fin/provider-gateway-v1

## 1.0.3

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.0.2

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.0.1

### Patch Changes

- Improved README documentation with corrected code examples and updated architecture diagrams

## 1.0.0

### Major Changes

- Provider that powers the Unified Balance Kit, enabling instant cross-chain USDC transfers through Circle Gateway. Install alongside `@circle-fin/unified-balance-kit` or use standalone for lower-level control.
