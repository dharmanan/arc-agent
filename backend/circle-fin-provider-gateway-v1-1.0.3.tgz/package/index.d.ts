/**
 * Copyright (c) 2026, Circle Internet Group, Inc. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Abi } from 'abitype';
import { TransactionInstruction, Signer, AddressLookupTableAccount } from '@solana/web3.js';

/**
 * @packageDocumentation
 * @module ChainDefinitions
 *
 * This module provides a complete type system for blockchain chain definitions.
 * It supports both EVM and non‑EVM chains, token configurations, and multiple
 * versions of the Cross-Chain Transfer Protocol (CCTP). Additionally, utility types
 * are provided to extract subsets of chains (e.g. chains supporting USDC, EURC, or specific
 * CCTP versions) from a provided collection.
 *
 * All types are fully documented with TSDoc to maximize developer experience.
 */
/**
 * Represents basic information about a currency or token.
 * @category Types
 * @description Provides the essential properties of a cryptocurrency or token.
 * @example
 * ```typescript
 * const ethCurrency: Currency = {
 *   name: "Ether",
 *   symbol: "ETH",
 *   decimals: 18
 * };
 * ```
 */
interface Currency {
    /**
     * The full name of the currency.
     * @example "Ether", "USDC"
     */
    name: string;
    /**
     * The symbol or ticker of the currency.
     * @example "ETH", "USDC"
     */
    symbol: string;
    /**
     * The number of decimal places for the currency.
     * @description Defines the divisibility of the currency (e.g., 1 ETH = 10^18 wei).
     * @example 18 for ETH, 6 for USDC
     */
    decimals: number;
}
/**
 * Base information that all chain definitions must include.
 * @category Types
 * @description Provides the common properties shared by all blockchain definitions.
 * @example
 * ```typescript
 * const baseChain: BaseChainDefinition = {
 *   chain: Blockchain.Ethereum,
 *   name: "Ethereum",
 *   nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
 *   isTestnet: false
 * };
 * ```
 */
interface BaseChainDefinition {
    /**
     * The blockchain identifier from the {@link Blockchain} enum.
     */
    chain: Blockchain;
    /**
     * The display name of the blockchain.
     * @example "Ethereum", "Solana", "Avalanche"
     */
    name: string;
    /**
     * Optional title or alternative name for the blockchain.
     * @example "Ethereum Mainnet", "Solana Mainnet"
     */
    title?: string;
    /**
     * Information about the native currency of the blockchain.
     */
    nativeCurrency: Currency;
    /**
     * Indicates whether this is a testnet or mainnet.
     * @description Used to differentiate between production and testing environments.
     */
    isTestnet: boolean;
    /**
     * Template URL for the blockchain explorer to view transactions.
     * @description URL template with a `\{hash\}` placeholder for transaction hash.
     * @example "https://etherscan.io/tx/\{hash\}", "https://sepolia.etherscan.io/tx/\{hash\}"
     */
    explorerUrl: string;
    /**
     * Default RPC endpoints for connecting to the blockchain network.
     * @description Array of reliable public RPC endpoints that can be used for read and write operations.
     * The first endpoint in the array is considered the primary endpoint.
     * @example ["https://cloudflare-eth.com", "https://ethereum.publicnode.com"]
     */
    rpcEndpoints: readonly string[];
    /**
     * The contract address for EURC.
     * @description Its presence indicates that EURC is supported.
     */
    eurcAddress: string | null;
    /**
     * The contract address for USDC.
     * @description Its presence indicates that USDC is supported.
     */
    usdcAddress: string | null;
    /**
     * The contract address for USDT.
     * @description Its presence indicates that USDT is supported.
     */
    usdtAddress: string | null;
    /**
     * Optional CCTP configuration.
     * @description If provided, the chain supports CCTP.
     */
    cctp: CCTPConfig | null;
    /**
     * Optional kit-specific contract addresses for enhanced chain functionality.
     *
     * @description When provided, the chain supports additional kit-specific logic in addition
     * to standard CCTP. This enables hybrid flows where both standard approve/burn/mint
     * and enhanced custom features are available. When undefined, the chain uses only
     * the standard CCTP flow.
     *
     * The address format varies by blockchain:
     * - EVM chains: 40-character hexadecimal with 0x prefix (e.g., "0x1234...")
     * - Solana: Base58-encoded 32-byte address (e.g., "9WzDX...")
     * - Other chains: Platform-specific address formats
     *
     * @example
     * ```typescript
     * // EVM chain with bridge contract
     * const evmChain: ChainDefinition = {
     *   // ... other properties
     *   kitContracts: {
     *     bridge: "0x1234567890abcdef1234567890abcdef12345678"
     *   }
     * }
     *
     * // Solana chain with bridge contract
     * const solanaChain: ChainDefinition = {
     *   // ... other properties
     *   kitContracts: {
     *     bridge: "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM"
     *   }
     * }
     * ```
     */
    kitContracts?: KitContracts;
    /**
     * Optional Gateway contract configuration for Gateway protocol support.
     *
     * @description When provided, the chain supports the Gateway protocol for
     * cross-chain transfers. Gateway provides an alternative bridging mechanism
     * with its own set of smart contracts (GatewayWallet and GatewayMinter).
     *
     * Use the {@link isGatewayV1Supported} type guard to check if a chain
     * supports Gateway v1 before accessing these properties.
     *
     * @example
     * ```typescript
     * // Chain with Gateway v1 support
     * const chainWithGateway: ChainDefinition = {
     *   // ... other properties
     *   gateway: {
     *     domain: 6,
     *     forwarderSupported: { source: true, destination: true },
     *     contracts: {
     *       v1: {
     *         wallet: '0x1234567890abcdef1234567890abcdef12345678',
     *         minter: '0xabcdef1234567890abcdef1234567890abcdef12'
     *       }
     *     }
     *   }
     * }
     *
     * // Check Gateway support
     * if (isGatewayV1Supported(chainWithGateway)) {
     *   console.log('Gateway wallet:', chainWithGateway.gateway.contracts.v1.wallet)
     * }
     * ```
     *
     * @see {@link GatewayConfig} for the structure of Gateway configuration.
     * @see {@link isGatewayV1Supported} for checking Gateway v1 support.
     */
    gateway?: GatewayConfig;
}
/**
 * Represents chain definitions for Ethereum Virtual Machine (EVM) compatible blockchains.
 * @extends BaseChainDefinition
 * @category Types
 * @description Adds properties specific to EVM chains.
 * @example
 * ```typescript
 * const ethereum: EVMChainDefinition = {
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   name: 'Ethereum',
 *   title: 'Ethereum Mainnet',
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false
 * };
 * ```
 */
interface EVMChainDefinition extends BaseChainDefinition {
    /**
     * Discriminator for EVM chains.
     * @description Used for type narrowing when handling different chain types.
     */
    type: 'evm';
    /**
     * The unique identifier for the blockchain.
     * @description Standard EVM chain ID as defined in EIP-155.
     * @example 1 for Ethereum Mainnet, 137 for Polygon.
     */
    chainId: number;
}
/**
 * Represents chain definitions for non-EVM blockchains.
 * @extends BaseChainDefinition
 * @category Types
 * @description Contains properties for blockchains that do not use the EVM.
 * @example
 * ```typescript
 * const solana: NonEVMChainDefinition = {
 *   type: 'solana',
 *   chain: Blockchain.Solana,
 *   name: 'Solana',
 *   nativeCurrency: { name: 'Solana', symbol: 'SOL', decimals: 9 },
 *   isTestnet: false
 * };
 * ```
 */
interface NonEVMChainDefinition extends BaseChainDefinition {
    /**
     * Discriminator for non-EVM chains.
     * @description Identifies the specific blockchain platform.
     */
    type: 'algorand' | 'avalanche' | 'solana' | 'aptos' | 'near' | 'stellar' | 'sui' | 'hedera' | 'noble' | 'polkadot';
}
/**
 * The type of chain.
 * @alias ChainType
 * @category Types
 * @description Represents the type of chain.
 * @example
 * ```typescript
 * const chainType: ChainType = 'evm'
 * ```
 */
type ChainType = EVMChainDefinition['type'] | NonEVMChainDefinition['type'];
/**
 * Public chain definition type.
 * @alias ChainDefinition
 * @category Types
 * @description Represents either an EVM-based or non-EVM-based blockchain definition.
 * This type is used by developers to define chain configurations.
 * @example
 * ```typescript
 * // Standard chain with CCTP support only
 * const ethereumChain: ChainDefinition = {
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   name: 'Ethereum',
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   explorerUrl: 'https://etherscan.io/tx/{hash}',
 *   rpcEndpoints: ['https://eth.example.com'],
 *   eurcAddress: null,
 *   usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
 *   usdtAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       v2: {
 *         type: 'split',
 *         tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
 *         messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
 *         confirmations: 65,
 *         fastConfirmations: 2
 *       }
 *     }
 *   },
 *   kitContracts: undefined
 * };
 *
 * // Chain with custom contract support (hybrid flow)
 * const customChain: ChainDefinition = {
 *   ...ethereumChain,
 *   kitContracts: {
 *     bridge: '0x1234567890abcdef1234567890abcdef12345678'
 *   }
 * };
 * ```
 */
type ChainDefinition = EVMChainDefinition | NonEVMChainDefinition;
/**
 * Chain definition with CCTPv2 configuration.
 * @alias ChainDefinitionWithCCTPv2
 * @extends ChainDefinition
 * @category Types
 * @description Represents a chain definition that includes CCTPv2 configuration. This is useful for typescript consumers to narrow down the type of chain definition to a chain that supports CCTPv2.
 * @example
 * ```typescript
 * const ethereumWithCCTPv2: ChainDefinitionWithCCTPv2 = {
 *   ...ethereum,
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       v2: {
 *         type: 'merged',
 *         contract: '0x123...'
 *       }
 *     }
 *   }
 * };
 * ```
 */
type ChainDefinitionWithCCTPv2 = ChainDefinition & {
    cctp: CCTPConfig & {
        contracts: {
            v2: VersionConfig;
        };
    };
    usdcAddress: string;
};
/**
 * Chain identifier that can be used in transfer parameters and factory functions.
 * This can be either:
 * - A ChainDefinition object
 * - A Blockchain enum value (e.g., Blockchain.Ethereum)
 * - A string literal of the blockchain value (e.g., "Ethereum")
 */
type ChainIdentifier = ChainDefinition | Blockchain | `${Blockchain}`;
/**
 * Split CCTP contract configuration.
 *
 * Used by chains that deploy separate TokenMessenger and MessageTransmitter contracts.
 * This is the traditional CCTP architecture used by most EVM chains.
 *
 * @example
 * ```typescript
 * const splitConfig: CCTPSplitConfig = {
 *   type: 'split',
 *   tokenMessenger: '0x1234567890abcdef1234567890abcdef12345678',
 *   messageTransmitter: '0xabcdef1234567890abcdef1234567890abcdef12',
 *   confirmations: 12
 * }
 * ```
 */
interface CCTPSplitConfig {
    type: 'split';
    tokenMessenger: string;
    messageTransmitter: string;
    confirmations: number;
}
/**
 * Merged CCTP contract configuration.
 *
 * Used by chains that deploy a single unified CCTP contract.
 * This simplified architecture is used by newer chain integrations.
 *
 * @example
 * ```typescript
 * const mergedConfig: CCTPMergedConfig = {
 *   type: 'merged',
 *   contract: '0x9876543210fedcba9876543210fedcba98765432',
 *   confirmations: 1
 * }
 * ```
 */
interface CCTPMergedConfig {
    type: 'merged';
    contract: string;
    confirmations: number;
}
/**
 * Version configuration for CCTP contracts.
 *
 * Defines whether the chain uses split or merged CCTP contract architecture.
 * Split configuration uses separate TokenMessenger and MessageTransmitter contracts,
 * while merged configuration uses a single unified contract.
 *
 * @example Split configuration (most EVM chains)
 * ```typescript
 * const splitConfig: VersionConfig = {
 *   type: 'split',
 *   tokenMessenger: '0x1234567890abcdef1234567890abcdef12345678',
 *   messageTransmitter: '0xabcdef1234567890abcdef1234567890abcdef12',
 *   confirmations: 12
 * }
 * ```
 *
 * @example Merged configuration (newer chains)
 * ```typescript
 * const mergedConfig: VersionConfig = {
 *   type: 'merged',
 *   contract: '0x9876543210fedcba9876543210fedcba98765432',
 *   confirmations: 1
 * }
 * ```
 */
type VersionConfig = CCTPSplitConfig | CCTPMergedConfig;
type CCTPContracts = Partial<{
    v1: VersionConfig;
    v2: VersionConfig & {
        fastConfirmations: number;
    };
}>;
/**
 * Configuration for the Cross-Chain Transfer Protocol (CCTP).
 * @category Types
 * @description Contains the domain and required contract addresses for CCTP support.
 * @example
 * ```
 * const cctpConfig: CCTPConfig = {
 *   domain: 0,
 *   contracts: {
 *     TokenMessenger: '0xabc',
 *     MessageReceiver: '0xdef'
 *   }
 * };
 * ```
 */
interface CCTPConfig {
    /**
     * The CCTP domain identifier.
     */
    domain: number;
    /**
     * The contracts required for CCTP.
     */
    contracts: CCTPContracts;
    /**
     * Indicates whether the chain supports forwarder for source and destination.
     * @example
     * ```typescript
     * const chainWithForwarderSupported: ChainDefinition = {
     *   forwarderSupported: {
     *     source: true,
     *     destination: true,
     *   },
     * }
     * ```
     */
    forwarderSupported: {
        source: boolean;
        destination: boolean;
    };
}
/**
 * Available kit contract types for enhanced chain functionality.
 *
 * @description Defines the valid contract types that can be deployed on chains
 * to provide additional features beyond standard CCTP functionality.
 *
 * @example
 * ```typescript
 * import type { KitContractType } from '@core/chains'
 *
 * const contractType: KitContractType = 'bridge' // Valid
 * const invalidType: KitContractType = 'invalid' // TypeScript error
 * ```
 */
type KitContractType = 'bridge' | 'adapter';
/**
 * Configuration for Gateway v1 contracts.
 *
 * @description Contains the addresses for the GatewayWallet and GatewayMinter
 * smart contracts that enable Gateway functionality on a chain.
 *
 * @example
 * ```typescript
 * import type { GatewayV1Contracts } from '@core/chains'
 *
 * const v1Contracts: GatewayV1Contracts = {
 *   wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *   minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 * }
 * ```
 */
interface GatewayV1Contracts {
    /**
     * The address of the GatewayWallet smart contract.
     *
     * @description The GatewayWallet contract manages wallet operations
     * for Gateway transactions.
     *
     * Address format varies by blockchain:
     * - EVM chains: 40-character hexadecimal with 0x prefix (e.g., "0x1234...")
     * - Solana: Base58-encoded 32-byte address (e.g., "9WzDX...")
     *
     * @example "0x1234567890abcdef1234567890abcdef12345678"
     */
    wallet: string;
    /**
     * The address of the GatewayMinter smart contract.
     *
     * @description The GatewayMinter contract handles minting operations
     * for Gateway transactions.
     *
     * Address format varies by blockchain:
     * - EVM chains: 40-character hexadecimal with 0x prefix (e.g., "0x1234...")
     * - Solana: Base58-encoded 32-byte address (e.g., "9WzDX...")
     *
     * @example "0xabcdef1234567890abcdef1234567890abcdef12"
     */
    minter: string;
}
/**
 * Versioned map of Gateway contract configurations.
 *
 * @description Maps protocol versions to their contract addresses, following
 * the same pattern as {@link CCTPContracts}. Each version is optional so that
 * chains can support any combination of Gateway protocol versions.
 *
 * @example
 * ```typescript
 * import type { GatewayContracts } from '@core/chains'
 *
 * const contracts: GatewayContracts = {
 *   v1: {
 *     wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *     minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *   }
 * }
 * ```
 */
type GatewayContracts = Partial<{
    v1: GatewayV1Contracts;
}>;
/**
 * Configuration for the Gateway protocol on a blockchain.
 *
 * @description Contains the Gateway domain identifier and version-specific
 * contract configurations. Follows the same structure as {@link CCTPConfig}:
 * a domain number plus a versioned contracts map.
 *
 * @example
 * ```typescript
 * import type { GatewayConfig } from '@core/chains'
 *
 * const gatewayConfig: GatewayConfig = {
 *   domain: 0,
 *   forwarderSupported: { source: true, destination: true },
 *   contracts: {
 *     v1: {
 *       wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *       minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *     }
 *   }
 * }
 * ```
 */
interface GatewayConfig {
    /**
     * The Gateway domain identifier for this chain.
     *
     * @description Similar to CCTP domains, this number uniquely identifies
     * the chain within the Gateway protocol.
     *
     * @example 0 for Ethereum, 6 for Base
     */
    domain: number;
    /**
     * Version-specific Gateway contract addresses.
     *
     * @description Contains the addresses for each supported Gateway protocol
     * version, following the same pattern as {@link CCTPContracts}.
     */
    contracts: GatewayContracts;
    /**
     * Indicate whether the chain supports the Forwarding Service as a source
     * and/or destination within the Gateway protocol.
     *
     * @example
     * ```typescript
     * forwarderSupported: { source: true, destination: true }
     * ```
     */
    forwarderSupported: {
        /** Whether this chain can be used as a source in forwarded transfers. */
        source: boolean;
        /** Whether this chain can be used as a destination in forwarded transfers. */
        destination: boolean;
    };
}
/**
 * Kit-specific contract addresses for enhanced chain functionality.
 *
 * @description Maps contract types to their addresses on a specific chain.
 * All contract types are optional, allowing chains to selectively support
 * specific kit features.
 *
 * @example
 * ```typescript
 * import type { KitContracts } from '@core/chains'
 *
 * const contracts: KitContracts = {
 *   bridge: "0x1234567890abcdef1234567890abcdef12345678"
 * }
 *
 * // Future example with multiple contract types:
 * const futureContracts: KitContracts = {
 *   bridge: "0x1234567890abcdef1234567890abcdef12345678",
 *   // Note: other contract types would be added to KitContractType union
 *   // customType: "0xabcdef1234567890abcdef1234567890abcdef12"
 * }
 * ```
 */
type KitContracts = Partial<Record<KitContractType, string>>;
/**
 * Enumeration of all blockchains known to this library.
 *
 * This enum contains every blockchain that has a chain definition, regardless
 * of whether bridging is currently supported. For chains that support bridging
 * via CCTPv2, see {@link BridgeChain}.
 *
 * @enum
 * @category Enums
 * @description Provides string identifiers for each blockchain with a definition.
 * @see {@link BridgeChain} for the subset of chains that support CCTPv2 bridging.
 */
declare enum Blockchain {
    Algorand = "Algorand",
    Algorand_Testnet = "Algorand_Testnet",
    Aptos = "Aptos",
    Aptos_Testnet = "Aptos_Testnet",
    Arc_Testnet = "Arc_Testnet",
    Arbitrum = "Arbitrum",
    Arbitrum_Sepolia = "Arbitrum_Sepolia",
    Avalanche = "Avalanche",
    Avalanche_Fuji = "Avalanche_Fuji",
    Base = "Base",
    Base_Sepolia = "Base_Sepolia",
    Celo = "Celo",
    Celo_Alfajores_Testnet = "Celo_Alfajores_Testnet",
    Codex = "Codex",
    Codex_Testnet = "Codex_Testnet",
    Edge = "Edge",
    Edge_Testnet = "Edge_Testnet",
    Ethereum = "Ethereum",
    Ethereum_Sepolia = "Ethereum_Sepolia",
    Hedera = "Hedera",
    Hedera_Testnet = "Hedera_Testnet",
    HyperEVM = "HyperEVM",
    HyperEVM_Testnet = "HyperEVM_Testnet",
    Injective = "Injective",
    Injective_Testnet = "Injective_Testnet",
    Ink = "Ink",
    Ink_Testnet = "Ink_Testnet",
    Linea = "Linea",
    Linea_Sepolia = "Linea_Sepolia",
    Monad = "Monad",
    Monad_Testnet = "Monad_Testnet",
    Morph = "Morph",
    Morph_Testnet = "Morph_Testnet",
    NEAR = "NEAR",
    NEAR_Testnet = "NEAR_Testnet",
    Noble = "Noble",
    Noble_Testnet = "Noble_Testnet",
    Optimism = "Optimism",
    Optimism_Sepolia = "Optimism_Sepolia",
    Pharos = "Pharos",
    Pharos_Testnet = "Pharos_Testnet",
    Polkadot_Asset_Hub = "Polkadot_Asset_Hub",
    Polkadot_Westmint = "Polkadot_Westmint",
    Plume = "Plume",
    Plume_Testnet = "Plume_Testnet",
    Polygon = "Polygon",
    Polygon_Amoy_Testnet = "Polygon_Amoy_Testnet",
    Sei = "Sei",
    Sei_Testnet = "Sei_Testnet",
    Solana = "Solana",
    Solana_Devnet = "Solana_Devnet",
    Sonic = "Sonic",
    Sonic_Testnet = "Sonic_Testnet",
    Stellar = "Stellar",
    Stellar_Testnet = "Stellar_Testnet",
    Sui = "Sui",
    Sui_Testnet = "Sui_Testnet",
    Unichain = "Unichain",
    Unichain_Sepolia = "Unichain_Sepolia",
    World_Chain = "World_Chain",
    World_Chain_Sepolia = "World_Chain_Sepolia",
    XDC = "XDC",
    XDC_Apothem = "XDC_Apothem",
    ZKSync_Era = "ZKSync_Era",
    ZKSync_Sepolia = "ZKSync_Sepolia"
}
/**
 * Enumeration of blockchains that support Gateway V1 operations
 * (deposit, spend, balance, delegate, removeFund).
 *
 * Derived from the full {@link Blockchain} enum but filtered to only
 * include chains with active Gateway V1 contract support. When new chains
 * gain Gateway V1 support, they are added to this enum.
 *
 * @enum
 * @category Enums
 *
 * @remarks
 * - This enum is the **canonical source** of Gateway-supported chains.
 * - Use this enum (or its string literals) in unified-balance-kit calls
 *   for type safety.
 *
 * @see {@link Blockchain} for the complete list of all known blockchains.
 * @see {@link UnifiedBalanceChainIdentifier} for the type that accepts these values.
 */
declare enum UnifiedBalanceChain {
    Arbitrum = "Arbitrum",
    Avalanche = "Avalanche",
    Base = "Base",
    Ethereum = "Ethereum",
    HyperEVM = "HyperEVM",
    Optimism = "Optimism",
    Polygon = "Polygon",
    Sei = "Sei",
    Solana = "Solana",
    Sonic = "Sonic",
    Unichain = "Unichain",
    World_Chain = "World_Chain",
    Arbitrum_Sepolia = "Arbitrum_Sepolia",
    Arc_Testnet = "Arc_Testnet",
    Avalanche_Fuji = "Avalanche_Fuji",
    Base_Sepolia = "Base_Sepolia",
    Ethereum_Sepolia = "Ethereum_Sepolia",
    HyperEVM_Testnet = "HyperEVM_Testnet",
    Optimism_Sepolia = "Optimism_Sepolia",
    Polygon_Amoy_Testnet = "Polygon_Amoy_Testnet",
    Sei_Testnet = "Sei_Testnet",
    Solana_Devnet = "Solana_Devnet",
    Sonic_Testnet = "Sonic_Testnet",
    Unichain_Sepolia = "Unichain_Sepolia",
    World_Chain_Sepolia = "World_Chain_Sepolia"
}
/**
 * Type representing valid unified-balance chain identifiers.
 *
 * Constrains chain parameters to only accept chains that support
 * Gateway V1 operations.
 *
 * Accepts:
 * - An {@link UnifiedBalanceChain} enum value (e.g., `UnifiedBalanceChain.Ethereum`)
 * - A string literal matching an UnifiedBalanceChain value (e.g., `'Ethereum'`)
 * - A {@link ChainDefinition} object for a supported chain
 *
 * @see {@link UnifiedBalanceChain} for the enum of supported chains.
 * @see {@link ChainIdentifier} for the less restrictive type accepting all chains.
 */
type UnifiedBalanceChainIdentifier = ChainDefinition | UnifiedBalanceChain | `${UnifiedBalanceChain}`;

/**
 * Core type definitions for blockchain transaction execution and gas estimation.
 *
 * This module provides TypeScript interfaces and types for handling blockchain
 * transactions across different networks, with a focus on EVM-compatible chains
 * and gas estimation.
 *
 * @module types
 */

/**
 * Estimated gas information for a blockchain transaction.
 *
 * This interface provides a unified way to represent gas costs across different
 * blockchain networks, supporting both EVM-style gas calculations and other
 * fee models.
 *
 * @interface EstimatedGas
 * @category Types
 * @example
 * ```typescript
 * // EVM chain example
 * const evmGas: EstimatedGas = {
 *   gas: 21000n,
 *   gasPrice: 1000000000n, // 1 Gwei
 *   fee: (21000n * 1000000000n).toString() // Total fee in wei
 * };
 *
 * // Solana example
 * const solanaGas: EstimatedGas = {
 *   gas: 5000n, // Lamports for compute units
 *   fee: '5000' // Total fee in Lamports
 * };
 * ```
 */
interface EstimatedGas {
    /**
     * The amount of gas estimated for the transaction.
     * For EVM chains, this represents the gas units.
     * For other chains, this might represent compute units or similar metrics.
     *
     * @example 21000n, 5000n
     */
    gas: bigint;
    /**
     * The estimated price per unit of gas.
     * This is primarily used in EVM chains where gas price is a separate metric.
     *
     * @example 1000000000n
     */
    gasPrice: bigint;
    /**
     * The total estimated fee as a string.
     * This field is useful for chains where gas/gasPrice isn't the whole story
     * or when the total fee needs to be represented in a different format.
     * For EVM chains, this is the total fee in wei (gas * gasPrice).
     *
     * @example "21000000000000", "5000"
     */
    fee: string;
}
/**
 * Override parameters for EVM gas estimation.
 *
 * These parameters allow customization of gas estimation behavior
 * for EVM-compatible chains.
 *
 * @interface EvmEstimateOverrides
 */
interface EvmEstimateOverrides {
    /**
     * The sender's address for the transaction.
     * @example "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"
     */
    from?: string;
    /**
     * The value to be sent with the transaction in wei.
     * @example 1000000000000000000n // 1 ETH
     */
    value?: bigint;
    /**
     * The block tag to use for estimation.
     * @example "latest", "safe", "finalized"
     */
    blockTag?: 'latest' | 'earliest' | 'pending' | 'safe' | 'finalized';
    /**
     * The maximum gas limit for the transaction.
     * @example 3000000
     */
    gasLimit?: number;
    /**
     * The maximum fee per gas unit (EIP-1559).
     * @example 20000000000n // 20 Gwei
     */
    maxFeePerGas?: bigint;
    /**
     * The maximum priority fee per gas unit (EIP-1559).
     * @example 1500000000n // 1.5 Gwei
     */
    maxPriorityFeePerGas?: bigint;
}
/**
 * Extended override parameters for EVM transaction execution.
 *
 * Includes all estimation overrides plus additional parameters
 * specific to transaction execution.
 *
 * @interface EvmExecuteOverrides
 * @extends EvmEstimateOverrides
 */
interface EvmExecuteOverrides extends EvmEstimateOverrides {
    /**
     * The nonce to use for the transaction.
     * If not provided, the current nonce of the sender will be used.
     * @example 42
     */
    nonce?: number;
}
/**
 * Raw EVM call data tuple for a single contract interaction.
 *
 * Represents the minimal data needed to submit an EVM transaction:
 * the target contract address, the ABI-encoded calldata, and an
 * optional native token value. Used by EIP-5792 batched execution
 * to compose multiple calls into a single `wallet_sendCalls` request.
 *
 * @interface EvmCallData
 *
 * @example
 * ```typescript
 * const callData: EvmCallData = {
 *   to: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   data: '0x095ea7b3000000000000000000000000...',
 * }
 * ```
 */
interface EvmCallData {
    /** The target contract address. */
    to: `0x${string}`;
    /** The ABI-encoded function calldata. */
    data: `0x${string}`;
    /** Optional native token value to send with the call. */
    value?: bigint | undefined;
}
/**
 * Prepared contract execution for EVM chains.
 *
 * Represents a prepared contract execution that can be estimated
 * and executed on EVM-compatible chains.
 *
 * @interface EvmPreparedChainRequest
 */
interface EvmPreparedChainRequest {
    /** The type of the prepared execution. */
    type: 'evm';
    /**
     * Estimate the gas cost for the contract execution.
     *
     * @param overrides - Optional parameters to override the default estimation behavior
     * @param fallback - Optional fallback gas information to use if the estimation fails
     * @returns A promise that resolves to the estimated gas information
     * @throws If the estimation fails
     */
    estimate(overrides?: EvmEstimateOverrides, fallback?: EstimatedGas): Promise<EstimatedGas>;
    /**
     * Execute the prepared contract call.
     *
     * @param overrides - Optional parameters to override the default execution behavior
     * @returns A promise that resolves to the transaction hash
     * @throws If the execution fails
     */
    execute(overrides?: EvmExecuteOverrides): Promise<string>;
    /**
     * Return the raw call tuple without executing or estimating.
     *
     * Expose the `{ to, data, value }` triple that would be sent on-chain so
     * callers can feed it into EIP-5792 `wallet_sendCalls` or other batching
     * mechanisms. This method is optional -- adapters that do not support
     * calldata extraction (e.g. Ethers v6) may omit it.
     *
     * @returns The raw EVM call data for this prepared request.
     * @throws Never — synchronous accessor with no failure path.
     * @since 2.0.0
     *
     * @example
     * ```typescript
     * const prepared = await adapter.prepare(params, ctx)
     * if (prepared.getCallData) {
     *   const { to, data, value } = prepared.getCallData()
     *   console.log('Target:', to, 'Data:', data)
     * }
     * ```
     */
    getCallData?(): EvmCallData;
}
/**
 * Union type for all supported prepared contract executions.
 * Currently only supports EVM chains, but can be extended for other chains.
 */
type PreparedChainRequest = EvmPreparedChainRequest | SolanaPreparedChainRequest | NoopPreparedChainRequest;
/**
 * Parameters for preparing an EVM contract execution.
 */
type EvmPreparedChainRequestParams = {
    /** The type of the prepared execution. */
    type: 'evm';
    /** The ABI of the contract. */
    abi: Abi | string[];
    /** The address of the contract. */
    address: `0x${string}`;
    /** The name of the function to call. */
    functionName: string;
    /** The arguments to pass to the function. */
    args: unknown[];
    /**
     * Specific block number to read contract state at (read-only calls only).
     * Used for historical reads, e.g. checking delegate status at Gateway's
     * processed height rather than the latest block. Ignored for write
     * operations (transactions).
     */
    blockNumber?: bigint;
} & Partial<EvmEstimateOverrides>;
/**
 * Parameters for preparing an EIP-712 typed data signing request (EVM).
 * When executed, returns the signature hex string.
 */
interface EvmSignTypedDataPreparedChainRequestParams {
    type: 'evm-sign-typed-data';
    typedData: {
        types: Record<string, unknown[]>;
        domain: Record<string, unknown>;
        primaryType: string;
        message: Record<string, unknown>;
    };
}
/**
 * Solana-specific parameters for preparing a transaction.
 *
 * @example
 * ```typescript
 * import type { SolanaPreparedChainRequestParams } from '@core/adapter'
 *
 * const params: SolanaPreparedChainRequestParams = {
 *   instructions: [transferInstruction],
 *   addressLookupTables: [],
 * }
 * ```
 */
interface SolanaPreparedChainRequestParams {
    /**
     * The array of instructions to include in the transaction.
     *
     * @remarks
     * Used for instruction-based transaction building. Mutually exclusive with
     * `serializedTransaction`.
     */
    instructions?: TransactionInstruction[];
    /**
     * A pre-serialized transaction as a Uint8Array (e.g., from a service like Jupiter).
     *
     * @remarks
     * Used for executing pre-built transactions from external services.
     * The transaction may be partially signed. Mutually exclusive with `instructions`.
     */
    serializedTransaction?: Uint8Array;
    /**
     * Additional signers besides the Adapter's wallet (e.g. program-derived authorities).
     */
    signers?: Signer[];
    /**
     * Optional override for how many compute units this transaction may consume.
     * If omitted, the network's default compute budget applies.
     */
    computeUnitLimit?: number;
    /**
     * Optional Address Lookup Table accounts for transaction compression.
     * Used to reduce transaction size by compressing frequently-used addresses.
     * This is used by @solana/web3.js adapters that have already fetched the ALT data.
     */
    addressLookupTableAccounts?: AddressLookupTableAccount[];
    /**
     * Optional Address Lookup Table addresses for transaction compression.
     * Used by adapters that need to fetch ALT data themselves (e.g., @solana/kit adapters).
     * These are base58-encoded addresses of ALT accounts to use for compression.
     */
    addressLookupTableAddresses?: string[];
}
/**
 * Parameters for preparing a message signing request (Solana).
 * When executed, returns the signature.
 *
 * @example
 * ```typescript
 * import type { SolanaSignMessagePreparedChainRequestParams } from '@core/adapter'
 *
 * const params: SolanaSignMessagePreparedChainRequestParams = {
 *   type: 'solana-sign-message',
 *   message: new TextEncoder().encode('Sign this message'),
 * }
 * ```
 */
interface SolanaSignMessagePreparedChainRequestParams {
    type: 'solana-sign-message';
    message: Uint8Array;
}
/**
 * Solana-specific configuration for transaction estimation.
 * @interface SolanaEstimateOverrides
 */
interface SolanaEstimateOverrides {
    /** Optional compute unit limit for the transaction. */
    computeUnitLimit?: number;
}
/**
 * Solana-specific configuration for transaction execution.
 * @interface SolanaExecuteOverrides
 * @extends SolanaEstimateOverrides
 */
interface SolanaExecuteOverrides extends SolanaEstimateOverrides {
    /** The commitment level for the transaction. */
    preflightCommitment?: 'processed' | 'confirmed' | 'finalized';
    /** The maximum number of retries for the transaction. */
    maxRetries?: number;
    /** Whether to skip the preflight check. */
    skipPreflight?: boolean;
}
/**
 * Solana-specific prepared chain request.
 * @interface SolanaPreparedChainRequest
 */
interface SolanaPreparedChainRequest {
    /** The type of the chain request. */
    type: 'solana';
    /** Estimate the compute units and fee for the transaction. */
    estimate(overrides?: SolanaEstimateOverrides, fallback?: EstimatedGas): Promise<EstimatedGas>;
    /** Execute the prepared transaction. */
    execute(overrides?: SolanaExecuteOverrides): Promise<string>;
}
/**
 * No-op prepared chain request for unsupported operations.
 *
 * This interface represents a prepared chain request that performs no operation.
 * It is returned when an action is not supported by the target chain or when
 * no actual blockchain interaction is required.
 *
 * @remarks
 * The estimate and execute methods return placeholder values since no actual
 * transaction is performed. This allows the calling code to handle unsupported
 * operations gracefully without breaking the expected interface contract.
 *
 * @example
 * ```typescript
 * const noopRequest: NoopPreparedChainRequest = {
 *   type: 'noop',
 *   estimate: async () => ({ gasLimit: 0n, gasPrice: 0n, totalFee: 0n }),
 *   execute: async () => '0x0000000000000000000000000000000000000000000000000000000000000000'
 * }
 * ```
 */
interface NoopPreparedChainRequest {
    /** The type of the prepared request. */
    type: 'noop';
    /**
     * Placeholder for the estimate method.
     * @returns The estimated gas cost.
     */
    estimate: (overrides?: EvmEstimateOverrides | SolanaEstimateOverrides, fallback?: EstimatedGas) => Promise<EstimatedGas>;
    /**
     * Placeholder for the execute method.
     * @returns The transaction hash.
     */
    execute: () => Promise<string>;
}
/**
 * Union type for all supported contract execution parameters.
 * Currently only supports EVM chains, but can be extended for other chains.
 */
type PreparedChainRequestParams = EvmPreparedChainRequestParams | EvmSignTypedDataPreparedChainRequestParams | SolanaPreparedChainRequestParams | SolanaSignMessagePreparedChainRequestParams;
/**
 * Response from waiting for a transaction to be mined and confirmed on the blockchain.
 *
 * @interface WaitForTransactionResponse
 */
interface WaitForTransactionResponse {
    /**
     * The transaction hash identifier.
     * @example "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
     */
    txHash: string;
    /**
     * The final status of the transaction execution.
     * Indicates whether the transaction was successfully executed or reverted.
     * @example "success", "reverted"
     */
    status: 'success' | 'reverted';
    /**
     * The total amount of gas used by all transactions in the block up to and including this transaction.
     * Represents the cumulative gas consumption within the block.
     * @example 2100000n
     */
    cumulativeGasUsed?: bigint;
    /**
     * The amount of gas actually consumed by this specific transaction.
     * This value is always less than or equal to the gas limit set for the transaction.
     * @example 21000n
     */
    gasUsed?: bigint;
    /**
     * The block number where the transaction was mined.
     * Represents the sequential position of the block in the blockchain.
     * @example 18500000n
     */
    blockNumber?: bigint;
    /**
     * The hash of the block containing this transaction.
     * Provides a unique identifier for the block where the transaction was included.
     * @example "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
     */
    blockHash?: string;
    /**
     * The zero-based index position of the transaction within the block.
     * Indicates the order in which this transaction appears in the block.
     * @example 5
     */
    transactionIndex?: number;
    /**
     * The actual gas price paid per unit of gas for this transaction.
     * For EIP-1559 transactions, this reflects the base fee plus priority fee.
     * @example 15000000000n // 15 Gwei
     */
    effectiveGasPrice?: bigint;
}
interface WaitForTransactionConfig {
    /**
     * The timeout for the transaction to be mined and confirmed on the blockchain.
     * @example 10000
     */
    timeout?: number | undefined;
    /**
     * The number of confirmations to wait for the transaction to be mined and confirmed on the blockchain.
     * @example 1
     */
    confirmations?: number;
    /**
     * The maximum supported transaction version for getTransaction.
     * Defaults to 0 if not provided.
     * @example 0
     */
    maxSupportedTransactionVersion?: number;
}
/**
 * Type utility to extract the address context from adapter capabilities.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type
 * @returns The address context type or never if capabilities are undefined
 */
type ExtractAddressContext<TAdapterCapabilities extends AdapterCapabilities> = TAdapterCapabilities extends {
    addressContext: infer TContext;
} ? TContext : never;
type AddressField<TAddressContext> = TAddressContext extends 'user-controlled' ? {
    /**
     * ℹ️ Address is forbidden for user-controlled adapters.
     *
     * User-controlled adapters (like browser wallets or private key adapters)
     * automatically resolve the address from the connected wallet or signer.
     * Providing an explicit address would conflict with this behavior.
     *
     * @example
     * ```typescript
     * // ℹ️ This will cause a TypeScript error:
     * const context: AdapterContext<{ addressContext: 'user-controlled' }> = {
     *   adapter: userAdapter,
     *   chain: 'Ethereum',
     *   address: '0x123...' // Error: Address is forbidden for user-controlled adapters
     * }
     * ```
     */
    address?: never;
} : TAddressContext extends 'developer-controlled' ? {
    /**
     * ℹ️ Address is required for developer-controlled adapters.
     *
     * Developer-controlled adapters (like enterprise providers or server-side adapters)
     * require an explicit address for each operation since they don't have a single
     * connected wallet. The address must be provided for every operation.
     *
     * @example
     * ```typescript
     * // ℹ️ This is required:
     * const context: AdapterContext<{ addressContext: 'developer-controlled' }> = {
     *   adapter: devAdapter,
     *   chain: 'Ethereum',
     *   address: '0x123...' // Required for developer-controlled adapters
     * }
     *
     * // ℹ️ This will cause a TypeScript error:
     * const context: AdapterContext<{ addressContext: 'developer-controlled' }> = {
     *   adapter: devAdapter,
     *   chain: 'Ethereum'
     *   // Error: Address is required for developer-controlled adapters
     * }
     * ```
     */
    address: string;
} : {
    /**
     * Address is optional for legacy adapters.
     *
     * Legacy adapters without defined capabilities maintain backward compatibility
     * by allowing optional address specification.
     */
    address?: string;
};
/**
 * Generic operation context for adapter methods with compile-time address validation.
 *
 * This type provides compile-time enforcement of address requirements based on the
 * adapter's capabilities. The address field behavior is determined by the adapter's
 * address control model:
 *
 * - **User-controlled adapters** (default): The `address` field is forbidden (never) because
 *   the address is automatically resolved from the connected wallet or signer.
 * - **Developer-controlled adapters**: The `address` field is required (string) because
 *   each operation must explicitly specify which address to use.
 * - **Legacy adapters**: The `address` field remains optional for backward compatibility.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type to derive address requirements from
 *
 * @example
 * ```typescript
 * import { OperationContext } from '@core/adapter'
 *
 * // User-controlled adapter context (default - address forbidden)
 * type UserContext = OperationContext<{ addressContext: 'user-controlled', supportedChains: [] }>
 * const userCtx: UserContext = {
 *   chain: 'Ethereum'
 *   // address: '0x123...' // ❌ TypeScript error: address not allowed
 * }
 *
 * // Developer-controlled adapter context (explicit - address required)
 * type DevContext = OperationContext<{ addressContext: 'developer-controlled', supportedChains: [] }>
 * const devCtx: DevContext = {
 *   chain: 'Ethereum',
 *   address: '0x123...' // ✅ Required for developer-controlled
 * }
 * ```
 */
type OperationContext<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> = {
    /**
     * The blockchain network to use for this operation.
     */
    chain: ChainIdentifier;
} & AddressField<ExtractAddressContext<TAdapterCapabilities>>;
/**
 * Fully resolved context for an adapter operation, with concrete chain and address.
 *
 * This interface guarantees that both the blockchain network (`chain`) and the account
 * address (`address`) are present and valid. It is produced by resolving an {@link OperationContext},
 * which may have optional or conditional fields, into a form suitable for internal logic and action handlers.
 *
 * - `chain`: A fully resolved {@link ChainDefinition}, either explicitly provided or inferred from the adapter.
 * - `address`: A string representing the resolved account address, determined by the context or adapter,
 *   depending on the address control model (developer- or user-controlled).
 *
 * Use this type when an operation requires both the chain and address to be unambiguous and available.
 *
 * @example
 * ```ts
 * import { ResolvedOperationContext} from "@core/adapter"
 * import { Solana, ChainDefinition } from '@core/chains';
 *
 * const context: ResolvedOperationContext = {
 *   chain: Solana,
 *   address: '7Gk1v...abc123', // a valid Solana address
 * };
 *
 * // Use context.chain and context.address in adapter operations
 * ```
 */
interface ResolvedOperationContext {
    /**
     * The chain identifier for this operation.
     * Guaranteed to be defined - either from context or adapter default.
     */
    chain: ChainDefinition;
    /**
     * The address for this operation.
     * Guaranteed to be defined - either specified (developer-controlled) or resolved (user-controlled).
     */
    address: string;
}

/**
 * Base interface for all action parameter objects.
 *
 * Provide a compile-time marker to explicitly identify objects that represent
 * action parameters (leaf nodes) versus namespace containers that should be
 * traversed during type recursion.
 *
 * @remarks
 * This marker property exists only at the type level and is stripped away
 * during compilation. It serves as a deterministic way to identify action
 * parameter objects without relying on property name heuristics.
 *
 * All action parameter objects must extend this interface to be properly
 * recognized by the recursive utility types in the action system.
 */
interface ActionParameters {
    /**
     * Compile-time marker identifying this as an action parameter object.
     *
     * This property is used by the type system to distinguish between
     * namespace containers and action parameter definitions. It does not
     * exist at runtime and is purely for TypeScript's type checking.
     */
    readonly __isActionParams: true;
}

/**
 * EIP-2612 permit signature parameters for gasless token approvals.
 *
 * Contains the signature components and deadline required for permit-based
 * token spending authorization without requiring separate approval transactions.
 *
 * @example
 * ```typescript
 * const permitParams: PermitParams = {
 *   deadline: BigInt(Math.floor(Date.now() / 1000) + 3600), // 1 hour from now
 *   v: 27,
 *   r: '0x1234567890abcdef...',
 *   s: '0xfedcba0987654321...'
 * }
 * ```
 */
interface PermitParams {
    /**
     * Permit expiration timestamp (Unix timestamp in seconds).
     *
     * The permit signature becomes invalid after this timestamp.
     * Must be greater than the current block timestamp.
     */
    deadline: bigint;
    /**
     * Recovery parameter of the ECDSA signature (27 or 28).
     *
     * Used to recover the public key from the signature components.
     */
    v: number;
    /**
     * R component of the ECDSA signature.
     *
     * First 32 bytes of the signature as a hex string.
     */
    r: string;
    /**
     * S component of the ECDSA signature.
     *
     * Second 32 bytes of the signature as a hex string.
     */
    s: string;
}
/**
 * Action map for Circle's Cross-Chain Transfer Protocol (CCTP) version 2 operations.
 *
 * Define the parameter schemas for CCTP v2 actions that enable native USDC
 * transfers between supported blockchain networks. Use Circle's attestation
 * service to verify and complete cross-chain transactions with cryptographic
 * proof of burn and mint operations.
 *
 * @remarks
 * CCTP v2 represents Circle's native cross-chain transfer protocol that allows
 * USDC to move between chains without traditional lock-and-mint bridging.
 * Instead, USDC is burned on the source chain and minted natively on the
 * destination chain using cryptographic attestations.
 *
 * The protocol supports both "slow" (free) and "fast" (fee-based) transfer
 * modes, with configurable finality thresholds and destination execution
 * parameters for advanced use cases.
 *
 * @example
 * ```typescript
 * import type { CCTPv2ActionMap } from '@core/adapter/actions/cctp/v2'
 * import { mainnet, polygon } from '@core/chains'
 *
 * // Deposit and burn USDC for cross-chain transfer
 * const burnParams: CCTPv2ActionMap['depositForBurn'] = {
 *   amount: '1000000', // 1 USDC (6 decimals)
 *   mintRecipient: '0x742d35Cc6634C0532925a3b8D8E5e8d8D8e5e8d8D8e5e8',
 *   maxFee: '1000', // 0.001 USDC fast fee
 *   minFinalityThreshold: 65,
 *   fromChain: mainnet,
 *   toChain: polygon
 * }
 *
 * // Receive and mint USDC on destination chain
 * const receiveParams: CCTPv2ActionMap['receiveMessage'] = {
 *   eventNonce: '0x123abc...',
 *   attestation: '0xdef456...',
 *   message: '0x789012...',
 *   fromChain: mainnet,
 *   toChain: polygon
 * }
 * ```
 *
 * @see {@link ChainDefinitionWithCCTPv2} for supported chain definitions
 */
interface CCTPv2ActionMap {
    /**
     * Initiate a cross-chain USDC transfer by depositing and burning tokens on the source chain.
     *
     * Burn USDC tokens on the source chain and generate a message for attestation
     * by Circle's infrastructure. The burned tokens will be minted on the destination
     * chain once the attestation is obtained and the receive message is executed.
     *
     * @remarks
     * This action represents the first step in a CCTP cross-chain transfer. After
     * execution, you must wait for Circle's attestation service to observe the burn
     * event and provide a cryptographic attestation that can be used to mint the
     * equivalent amount on the destination chain.
     *
     * The `maxFee` parameter enables fast transfers through Circle's fast liquidity
     * network, where liquidity providers can fulfill transfers immediately in exchange
     * for a fee. Set to "0" for slower, free transfers that wait for full finality.
     */
    depositForBurn: ActionParameters & {
        /**
         * Amount of USDC to deposit and burn (in token's smallest unit).
         *
         * Specify the amount in the token's atomic units (e.g., for USDC with
         * 6 decimals, "1000000" represents 1 USDC). This amount will be burned
         * on the source chain and minted on the destination chain.
         */
        amount: bigint;
        /**
         * Address of the recipient who will receive minted tokens on the destination chain.
         *
         * Provide the destination address as a 32-byte hex string (bytes32 format).
         */
        mintRecipient: string;
        /**
         * Address authorized to call receiveMessage on the destination chain.
         *
         * Restrict who can execute the final minting step on the destination chain.
         * If not specified or set to bytes32(0), any address can call receiveMessage.
         * Use this for advanced integrations requiring specific execution control.
         *
         * @defaultValue bytes32(0) - allows any address to complete the transfer
         */
        destinationCaller?: string;
        /**
         * Maximum fee to pay for fast transfer fulfillment.
         *
         * Specify the maximum amount (in the same units as `amount`) you're willing
         * to pay for immediate liquidity. Set to "0" for free transfers that wait
         * for full chain finality. Higher fees increase the likelihood of fast
         * fulfillment.
         */
        maxFee: bigint;
        /**
         * Minimum finality threshold for attestation eligibility.
         *
         * Set the number of confirmations required before Circle's attestation
         * service will observe and attest to the burn event. Higher values
         * provide stronger finality guarantees but increase transfer time.
         * Typical values: 1000 for fast transfers, 2000 for maximum security.
         */
        minFinalityThreshold: number;
        /**
         * Source chain definition where tokens will be burned.
         */
        fromChain: ChainDefinitionWithCCTPv2;
        /**
         * Destination chain definition where tokens will be minted.
         */
        toChain: ChainDefinitionWithCCTPv2;
    };
    /**
     * Complete a cross-chain transfer by receiving and processing an attested message.
     *
     * Execute the final step of a CCTP transfer by submitting Circle's attestation
     * and the original message to mint USDC tokens on the destination chain.
     * This action consumes the attestation and delivers tokens to the specified
     * recipient from the original burn operation.
     *
     * @remarks
     * This action must be called after obtaining a valid attestation from Circle's
     * API for a corresponding `depositForBurn` operation. The attestation proves
     * that tokens were burned on the source chain and authorizes minting the
     * equivalent amount on the destination chain.
     *
     * The message parameter contains the original burn message data, while the
     * attestation provides the cryptographic proof. Both must match exactly
     * with Circle's records for the transaction to succeed.
     */
    receiveMessage: ActionParameters & {
        /**
         * Unique nonce identifying the specific burn event.
         *
         * Provide the event nonce from the MessageSent event emitted by the
         * depositForBurn transaction. This must be a 0x-prefixed 64-character
         * hex string representing the 32-byte nonce value.
         */
        readonly eventNonce: string;
        /**
         * Cryptographic attestation from Circle's infrastructure.
         *
         * Submit the attestation obtained from Circle's API that proves the
         * corresponding burn event occurred and was observed. This must be
         * a valid 0x-prefixed hex string containing Circle's signature data.
         */
        readonly attestation: string;
        /**
         * Original message bytes from the source chain burn event.
         *
         * Provide the raw message data emitted in the MessageSent event from
         * the depositForBurn transaction. This 0x-prefixed hex string contains
         * the encoded transfer details that will be verified against the attestation.
         */
        readonly message: string;
        /**
         * Source chain definition where the original burn occurred.
         */
        readonly fromChain: ChainDefinitionWithCCTPv2;
        /**
         * Destination chain definition where tokens will be minted.
         */
        readonly toChain: ChainDefinitionWithCCTPv2;
        /**
         * Optional destination wallet address on the destination chain to receive minted USDC.
         *
         * When provided (e.g., for Solana), the mint instruction will derive the
         * recipient's Associated Token Account (ATA) from this address instead of
         * the adapter's default address.
         */
        readonly destinationAddress?: string;
        /**
         * The mint recipient address from the decoded CCTP message.
         *
         * This is the actual address encoded in the burn message where tokens will be minted.
         * For Solana, this is already the Associated Token Account (ATA) address, not the owner.
         * For EVM chains, this is the recipient's wallet address.
         */
        readonly mintRecipient?: string;
    };
    /**
     * Initiate a cross-chain USDC transfer using a custom bridge contract with preapproval funnel.
     *
     * This action combines token approval and burning into a single transaction using
     * a custom bridge contract that supports preapproval functionality. It provides
     * enhanced gas efficiency by eliminating separate approval transactions while
     * maintaining the same developer interface as standard CCTP transfers.
     *
     * @remarks
     * This action is only available on chains that support custom bridge contracts,
     * as determined by `hasCustomContractSupport(chain, 'bridge')`. The custom bridge
     * handles token approval internally and supports advanced features like protocol
     * fees and custom routing logic.
     *
     * For basic use cases, this provides the same interface as `depositForBurn`.
     * For advanced use cases, optional protocol fee parameters enable custom fee
     * collection and revenue sharing models.
     *
     * @example
     * ```typescript
     * // Basic usage (same as depositForBurn)
     * await adapter.action('cctp.v2.customBurn', {
     *   amount: BigInt('1000000'),
     *   mintRecipient: '0x...',
     *   maxFee: BigInt('1000'),
     *   minFinalityThreshold: 65
     * })
     *
     * // Advanced usage with protocol fees
     * await adapter.action('cctp.v2.customBurn', {
     *   amount: BigInt('1000000'),
     *   mintRecipient: '0x...',
     *   maxFee: BigInt('1000'),
     *   minFinalityThreshold: 65,
     *   protocolFee: BigInt('100'),
     *   feeRecipient: '0xFeeRecipientAddress'
     * })
     * ```
     */
    customBurn: ActionParameters & {
        /**
         * Amount of USDC to burn (in token's smallest unit).
         *
         * Specify the amount in the token's atomic units (e.g., for USDC with
         * 6 decimals, 1000000n represents 1 USDC). This amount will be burned
         * on the source chain and minted on the destination chain.
         */
        amount: bigint;
        /**
         * Address of the recipient who will receive minted tokens on the destination chain.
         *
         * Provide the destination address as a 32-byte hex string (bytes32 format).
         */
        mintRecipient: string;
        /**
         * Address authorized to call receiveMessage on the destination chain.
         *
         * Restrict who can execute the final minting step on the destination chain.
         * If not specified or set to bytes32(0), any address can call receiveMessage.
         * Use this for advanced integrations requiring specific execution control.
         *
         * @defaultValue bytes32(0) - allows any address to complete the transfer
         */
        destinationCaller?: string;
        /**
         * Maximum fee to pay for fast transfer fulfillment.
         *
         * Specify the maximum amount (in the same units as `amount`) you're willing
         * to pay for immediate liquidity. Set to "0" for free transfers that wait
         * for full chain finality. Higher fees increase the likelihood of fast
         * fulfillment.
         */
        maxFee: bigint;
        /**
         * Minimum finality threshold for attestation eligibility.
         *
         * Set the number of confirmations required before Circle's attestation
         * service will observe and attest to the burn event. Higher values
         * provide stronger finality guarantees but increase transfer time.
         * Typical values: 65 for standard transfers, 2000 for maximum security.
         */
        minFinalityThreshold: number;
        /**
         * Protocol fee amount (in token's smallest unit).
         *
         * Additional fee charged by the custom bridge for enhanced functionality.
         * This fee is separate from the Circle fast transfer fee and is paid to
         * the specified fee recipient. Enables custom fee collection and revenue
         * sharing models for bridge operators.
         *
         * @defaultValue 0n - no protocol fee for basic usage
         */
        protocolFee?: bigint | undefined;
        /**
         * Address to receive the protocol fee.
         *
         * Wallet address where the protocol fee will be sent. This enables
         * custom fee collection and revenue sharing models for bridge operators.
         * Only relevant when protocolFee is greater than 0.
         *
         * @defaultValue bridge contract address - safe fallback for zero fees
         */
        feeRecipient?: string | undefined;
        /**
         * Source chain definition where tokens will be burned.
         */
        fromChain: ChainDefinitionWithCCTPv2;
        /**
         * Destination chain definition where tokens will be minted.
         */
        toChain: ChainDefinitionWithCCTPv2;
        /**
         * Permit parameters for the custom bridge contract.
         */
        permitParams?: PermitParams;
    };
    /**
     * Initiate a cross-chain USDC transfer using a custom bridge contract with hook data for CCTP forwarding.
     *
     * This action combines the custom bridge functionality with CCTP forwarding hookData.
     * It uses either `bridgeWithPreapprovalAndHook` or `bridgeWithPermitAndHook` contract
     * functions depending on whether permit parameters are provided.
     *
     * @remarks
     * When CCTP forwarding is enabled with custom burn, Circle's relay infrastructure will:
     * 1. Watch for the burn transaction with forwarding hookData
     * 2. Fetch the attestation automatically
     * 3. Submit the destination mint transaction on behalf of the user
     * 4. Deduct the relay fee from the minted USDC
     *
     * The hookData must be formatted with the CCTP forwarding magic bytes prefix
     * followed by version and length fields. Use the `buildForwardingHookData`
     * utility to construct properly formatted hookData.
     *
     * @example
     * ```typescript
     * import { buildForwardingHookData } from '@core/utils'
     * import { hasCustomContractSupport } from '@core/chains'
     *
     * if (hasCustomContractSupport(sourceChain, 'bridge')) {
     *   await adapter.action('cctp.v2.customBurnWithHook', {
     *     amount: BigInt('1000000'),
     *     mintRecipient: '0x...',
     *     maxFee: BigInt('50000'),
     *     minFinalityThreshold: 1000,
     *     fromChain: ethereum,
     *     toChain: base,
     *     hookData: buildForwardingHookData()
     *   })
     * }
     * ```
     */
    customBurnWithHook: CCTPv2ActionMap['customBurn'] & {
        /**
         * Hex-encoded hook data for CCTP forwarding.
         *
         * The hookData signals to Circle's Orbit relayer that forwarding is requested.
         * Must be formatted with the CCTP forwarding magic bytes prefix ("cctp-forward"
         * right-padded to 24 bytes) followed by uint32 version and uint32 length fields.
         *
         * Use the `buildForwardingHookData` utility to construct properly formatted hookData.
         */
        hookData: string;
    };
    /**
     * Initiate a cross-chain USDC transfer with hook data for CCTP forwarding.
     *
     * This action extends the standard `depositForBurn` with an additional `hookData`
     * parameter that signals to Circle's Orbit relayer that the user wants automated
     * attestation fetching and destination mint execution.
     *
     * @remarks
     * When CCTP forwarding is enabled, Circle's relay infrastructure will:
     * 1. Watch for the burn transaction with forwarding hookData
     * 2. Fetch the attestation automatically
     * 3. Submit the destination mint transaction on behalf of the user
     * 4. Deduct the relay fee from the minted USDC
     *
     * The hookData must be formatted with the CCTP forwarding magic bytes prefix
     * followed by version and length fields. Use the `buildForwardingHookData`
     * utility to construct properly formatted hookData.
     *
     * @example
     * ```typescript
     * import { buildForwardingHookData } from '@core/utils'
     *
     * await adapter.action('cctp.v2.depositForBurnWithHook', {
     *   amount: BigInt('1000000'),
     *   mintRecipient: '0x...',
     *   maxFee: BigInt('50000'), // Must cover burn fee + forwarding fee
     *   minFinalityThreshold: 1000,
     *   fromChain: ethereum,
     *   toChain: base,
     *   hookData: buildForwardingHookData()
     * })
     * ```
     */
    depositForBurnWithHook: CCTPv2ActionMap['depositForBurn'] & {
        /**
         * Hex-encoded hook data for CCTP forwarding.
         *
         * The hookData signals to Circle's Orbit relayer that forwarding is requested.
         * Must be formatted with the CCTP forwarding magic bytes prefix ("cctp-forward"
         * right-padded to 24 bytes) followed by uint32 version and uint32 length fields.
         *
         * Use the `buildForwardingHookData` utility to construct properly formatted hookData.
         */
        hookData: string;
    };
}

/**
 * Central registry for Cross-Chain Transfer Protocol (CCTP) action namespaces.
 *
 * Define versioned action maps for CCTP operations across different protocol
 * versions. Each version key represents a specific CCTP implementation with
 * its own parameter schemas and operational requirements.
 *
 * @remarks
 * CCTP actions enable cross-chain USDC transfers through Circle's native
 * bridging protocol. Each version namespace contains actions specific to
 * that protocol iteration, allowing for protocol upgrades while maintaining
 * backward compatibility in the action system.
 *
 * This interface follows the same pattern as other action namespaces but
 * is organized by protocol version rather than token type.
 *
 * @see {@link CCTPv2ActionMap} for version 2 action definitions
 */
interface CCTPActionMap {
    /** CCTP version 2 operations for cross-chain USDC transfers. */
    readonly v2: CCTPv2ActionMap;
}

/**
 * Permit signature standards for gasless token approvals.
 *
 * Defines the permit types that can be used to approve token spending
 * without requiring a separate approval transaction.
 *
 * @remarks
 * - NONE: No permit, tokens must be pre-approved via separate transaction
 * - EIP2612: Standard ERC-20 permit (USDC, DAI v2, and most modern tokens)
 */
declare enum PermitType {
    /** No permit required - tokens must be pre-approved */
    NONE = 0,
    /** EIP-2612 standard permit */
    EIP2612 = 1
}
/**
 * Token input with permit signature for gasless approval.
 *
 * The Adapter Contract uses this to pull tokens from the user's wallet
 * using permit signatures instead of requiring separate approval transactions.
 *
 * @example
 * ```typescript
 * const tokenInput: TokenInput = {
 *   permitType: PermitType.EIP2612,
 *   token: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', // USDC
 *   from: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
 *   amount: 1000000n, // 1 USDC
 *   permitCalldata: '0x...' // Encoded permit(value, deadline, v, r, s)
 * }
 * ```
 */
interface TokenInput {
    /**
     * Type of permit to execute.
     */
    permitType: PermitType;
    /**
     * Token contract address to pull from user.
     */
    token: `0x${string}`;
    /**
     * Amount of tokens to pull via permit.
     */
    amount: bigint;
    /**
     * ABI-encoded permit calldata.
     *
     * For EIP-2612: encode(value, deadline, v, r, s)
     * For Permit2: encode(permit, signature)
     *
     * @example '0x0000000000000000000000000000000000000000000000000000000000989680...'
     */
    permitCalldata: `0x${string}`;
}
/**
 * Single instruction to execute within the Adapter Contract.
 *
 * Each instruction represents a contract call (swap, fee collection, etc.)
 * with pre-execution approval and post-execution validation.
 *
 * @example
 * ```typescript
 * const swapInstruction: Instruction = {
 *   target: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE', // LiFi Diamond
 *   data: '0x...',  // LiFi swap calldata
 *   value: 0n,
 *   tokenIn: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', // USDC
 *   amountToApprove: 1000000000n, // 1000 USDC to approve
 *   tokenOut: '0xdAC17F958D2ee523a2206206994597C13D831ec7', // USDT
 *   minTokenOut: 995000000n // 995 USDT minimum (0.5% slippage)
 * }
 * ```
 */
interface Instruction {
    /**
     * Target contract address to call.
     *
     * Can be a DEX router, fee taker contract, or token contract.
     */
    target: `0x${string}`;
    /**
     * ABI-encoded calldata for the target contract.
     */
    data: `0x${string}`;
    /**
     * ETH value to send with the call (for native token operations).
     *
     * @defaultValue 0n
     */
    value: bigint;
    /**
     * Token to approve to target before executing instruction.
     *
     * Set to zero address (0x00...00) to disable pre-approval.
     */
    tokenIn: `0x${string}`;
    /**
     * Amount of tokenIn to approve to target before executing instruction.
     *
     * @remarks
     * Field name matches the adapter contract's `amountToApprove` parameter exactly.
     *
     * @defaultValue 0n if tokenIn is zero address
     */
    amountToApprove: bigint;
    /**
     * Token to validate minimum balance after instruction.
     *
     * Set to zero address (0x00...00) to disable post-validation.
     */
    tokenOut: `0x${string}`;
    /**
     * Minimum required balance of tokenOut after instruction.
     *
     * @defaultValue 0n if tokenOut is zero address
     */
    minTokenOut: bigint;
}
/**
 * Token recipient for residual sweep.
 *
 * After all instructions complete, the Adapter Contract sweeps
 * any remaining balances to the specified beneficiaries.
 */
interface TokenRecipient {
    /**
     * Token contract address to sweep.
     */
    token: `0x${string}`;
    /**
     * Address to receive swept tokens.
     */
    beneficiary: `0x${string}`;
}
/**
 * Execution parameters for the Adapter Contract.
 *
 * This struct is signed via EIP-712 by the Circle proxy and verified
 * on-chain to ensure the execution is authorized.
 *
 * @remarks
 * The executeParams are provided by the stablecoin-service and must be
 * passed to the Adapter Contract exactly as received (no modification).
 *
 * @example
 * ```typescript
 * const executeParams: ExecuteParams = {
 *   instructions: [
 *     { target: dexRouter, data: swapCalldata, ... }
 *   ],
 *   tokens: [
 *     { token: USDC, beneficiary: userAddress },
 *     { token: USDT, beneficiary: userAddress }
 *   ],
 *   execId: 123456789n,
 *   deadline: BigInt(Math.floor(Date.now() / 1000) + 1800),
 *   metadata: '0x'
 * }
 * ```
 */
interface ExecuteParams {
    /**
     * Array of instructions to execute sequentially.
     *
     * Each instruction can be a swap, fee collection, or other contract call.
     */
    instructions: Instruction[];
    /**
     * Token recipients for residual sweep.
     *
     * Typically a 2-tuple: [tokenIn recipient, tokenOut recipient]
     */
    tokens: TokenRecipient[];
    /**
     * Unique execution identifier for replay protection.
     *
     * Must be globally unique and is marked as used after execution.
     */
    execId: bigint;
    /**
     * Execution deadline timestamp (Unix seconds).
     *
     * Transaction reverts if block.timestamp is greater than deadline.
     */
    deadline: bigint;
    /**
     * Optional metadata for tracking and analytics.
     */
    metadata: `0x${string}`;
}
/**
 * Parameters for executing a swap transaction via the Adapter smart contract.
 *
 * This action executes swap transactions through the Adapter Contract, which
 * handles token approvals via permits (EIP-2612, Permit2, etc.) and executes
 * multi-step swap instructions atomically on-chain.
 *
 * @remarks
 * The swap flow uses the Adapter Contract pattern:
 * 1. Service provides `executeParams` and `signature` (proxy-signed EIP-712)
 * 2. SDK builds `tokenInputs` with permit signatures for gasless approvals
 * 3. SDK calls AdapterContract.execute(executeParams, tokenInputs, signature)
 * 4. Adapter Contract pulls tokens via permits, executes swaps, validates outputs
 *
 * This enables:
 * - Single atomic transaction (permit + swap in one tx)
 * - Gasless approvals via EIP-2612/Permit2
 * - Slippage protection enforced on-chain
 * - Multi-step instructions (swap + fees) atomically
 *
 * **Permit Support**: The SDK constructs `TokenInput` with `permitCalldata`
 * containing the encoded permit signature. The Adapter Contract executes
 * the permit on-chain before pulling tokens.
 *
 * @example
 * ```typescript
 * import type { ExecuteSwapParams } from '@core/adapter'
 * import { createSwap } from '@core/service-client'
 * import { PermitType } from '@core/adapter'
 *
 * // Get swap transaction from service
 * const swapResponse = await createSwap({
 *   tokenInAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   tokenOutAddress: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
 *   tokenInChain: 'Ethereum',
 *   fromAddress: '0x...',
 *   toAddress: '0x...',
 *   amount: '1000000',
 *   apiKey: 'KIT_KEY:...',
 * })
 *
 * // Build token inputs with permit
 * const tokenInputs: TokenInput[] = [{
 *   permitType: PermitType.EIP2612,
 *   token: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   from: userAddress,
 *   amount: 1000000n,
 *   permitCalldata: '0x...' // Encoded permit signature
 * }]
 *
 * // Prepare action parameters
 * const params: ExecuteSwapParams = {
 *   executeParams: swapResponse.transaction.executeParams,
 *   tokenInputs,
 *   signature: swapResponse.transaction.signature,
 *   inputAmount: BigInt(swapResponse.amount),
 *   tokenInAddress: swapResponse.tokenInAddress as `0x${string}`
 * }
 * ```
 */
interface ExecuteSwapEVMParams extends ActionParameters {
    /**
     * Execution parameters from the stablecoin-service.
     *
     * Contains instructions, token recipients, execution ID, deadline, and metadata.
     * This is an EIP-712 signed struct that the Adapter Contract validates.
     *
     * Provided by the service - do not modify.
     */
    executeParams: ExecuteParams;
    /**
     * Token inputs with permit signatures for gasless approvals.
     *
     * The SDK constructs this array with permit data for each token that needs
     * to be pulled from the user's wallet. The Adapter Contract executes these
     * permits on-chain before executing swap instructions.
     *
     * @remarks
     * For EIP-2612 permits, the SDK must:
     * 1. Build typed data with token, spender (Adapter), amount, nonce, deadline
     * 2. Get user signature via `adapter.signTypedData()`
     * 3. Encode as permitCalldata: encode(value, deadline, v, r, s)
     *
     * @example
     * ```typescript
     * [{
     *   permitType: PermitType.EIP2612,
     *   token: '0xUSDC',
     *   from: userAddress,
     *   amount: 1000000n,
     *   permitCalldata: '0x...'
     * }]
     * ```
     */
    tokenInputs: TokenInput[];
    /**
     * EIP-712 signature from the Circle proxy service.
     *
     * The service signs the executeParams to authorize the execution.
     * The Adapter Contract verifies this signature on-chain.
     *
     * Provided by the service - do not modify.
     */
    signature: `0x${string}`;
    /**
     * Swap input amount in base units.
     *
     * @remarks
     * The amount of tokens being swapped, provided in the token's base units (e.g., wei for ETH,
     * smallest denomination for ERC20 tokens). This value should be extracted from the service
     * response, as it represents the authoritative swap amount for the operation.
     *
     * For native currency swaps (ETH → USDC), this amount is sent as the transaction `value`.
     * For ERC20 swaps (USDC → USDT), this amount determines the permit or approval quantity.
     *
     * @see CreateSwapResponse.amount - Service response field containing this value
     *
     * @example
     * ```typescript
     * import { createSwap } from '@core/service-client'
     *
     * // Get swap transaction from service
     * const response = await createSwap({
     *   tokenInAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
     *   amount: '1000000', // 1 USDC (6 decimals)
     *   ...
     * })
     *
     * // Prepare swap execution using service response amount
     * await adapter.prepareAction('swap.execute', {
     *   executeParams: response.transaction.executeParams,
     *   tokenInputs,
     *   signature: response.transaction.signature,
     *   inputAmount: BigInt(response.amount),
     *   tokenInAddress: response.tokenInAddress,
     * }, context)
     * ```
     */
    inputAmount: bigint;
    /**
     * Token address being swapped from.
     *
     * @remarks
     * Used to determine if the swap involves native currency (ETH, MATIC, etc.) or ERC20 tokens.
     * When tokenInAddress is NATIVE_TOKEN_ADDRESS (0xEeee...), the inputAmount is sent as tx.value.
     *
     * @see CreateSwapResponse.tokenInAddress - Service response field containing this value
     *
     * @example '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE' for ETH
     * @example '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48' for USDC
     */
    tokenInAddress: `0x${string}`;
}
/**
 * Parameters for executing a swap transaction on Solana.
 *
 * This action executes swap transactions on Solana chains by deserializing
 * and executing a pre-built transaction provided by the stablecoin-service.
 *
 * @remarks
 * Unlike EVM chains that use the Adapter Contract pattern, Solana swaps
 * execute a fully serialized transaction provided by the service. The
 * transaction is base64-encoded and contains all necessary instructions
 * for the swap operation.
 *
 * The service handles:
 * - DEX aggregator routing (Jupiter, etc.)
 * - Fee collection
 * - Slippage protection
 * - Token account management
 *
 * @example
 * ```typescript
 * import type { ExecuteSwapSolanaParams } from '@core/adapter'
 * import { createSwap } from '@core/service-client'
 *
 * // Get swap transaction from service
 * const swapResponse = await createSwap({
 *   tokenInAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *   tokenOutAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
 *   tokenInChain: 'Solana',
 *   fromAddress: 'YubQzu18FDqJRyNfG8JqHmsdbxhnoQqcKUHBdUkN6tP',
 *   toAddress: 'YubQzu18FDqJRyNfG8JqHmsdbxhnoQqcKUHBdUkN6tP',
 *   amount: '1000000',
 *   apiKey: 'KIT_KEY:...',
 * })
 *
 * // Prepare action parameters
 * const params: ExecuteSwapSolanaParams = {
 *   serializedTransaction: swapResponse.transaction.data
 * }
 * ```
 */
interface ExecuteSwapSolanaParams extends ActionParameters {
    /**
     * Base64-encoded serialized Solana transaction.
     *
     * This transaction is fully constructed by the stablecoin-service and
     * contains all swap instructions, fee payments, and token account setup.
     * The transaction must be deserialized, signed, and submitted to the network.
     *
     * Provided by the service - do not modify.
     *
     * @example 'AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAQAJFQg...'
     */
    serializedTransaction: string;
}
/**
 * Parameters accepted by the swap.execute action, supporting both EVM and Solana chains.
 *
 * @remarks
 * This union type covers all chain-specific swap execution parameter interfaces
 * currently supported by the App Kit. Extend this union to support
 * additional blockchains as needed. Each member provides all fields required
 * to prepare and execute a pre-built swap transaction on its respective chain.
 *
 * **Type Narrowing**: The correct parameter type is inferred from the chain type
 * in the `OperationContext` passed to `adapter.prepareAction()`. Action handlers
 * use property-based type guards (checking for `executeParams`/`tokenInputs` for EVM
 * or `serializedTransaction` for Solana) to narrow the union type at runtime.
 *
 * - {@link ExecuteSwapEVMParams} - For EVM chains (has `executeParams` and `tokenInputs`)
 * - {@link ExecuteSwapSolanaParams} - For Solana chains (has `serializedTransaction`)
 */
type ExecuteSwapParams = ExecuteSwapEVMParams | ExecuteSwapSolanaParams;
/**
 * Action map for swap operations on EVM chains.
 *
 * This namespace contains actions related to token swapping operations.
 * These actions handle the execution of pre-built swap transactions from
 * DEX aggregators and routing services.
 *
 * @remarks
 * The swap namespace is designed to be extensible for future swap-related
 * operations such as multi-hop swaps, batched swaps, or swap-and-bridge
 * compositions.
 */
interface SwapActionMap {
    /**
     * Execute a pre-built swap transaction.
     *
     * This action prepares and executes swap transactions constructed by the
     * stablecoin-service API. It accepts transaction parameters (to, data, value)
     * and returns a prepared chain request suitable for gas estimation or execution.
     */
    readonly execute: ExecuteSwapParams;
}

interface TokenActionMap {
    /**
     * Set an allowance for a delegate to spend tokens on behalf of the wallet.
     *
     * On chains without native allowance support, this may return a noop result
     * indicating the step can be safely skipped.
     */
    approve: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address that will be approved to spend the tokens.
         */
        delegate: string;
        /**
         * The amount of tokens to approve for spending (in token's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Check the current allowance between an owner and spender for any token.
     *
     * On chains without allowance support, this typically returns the maximum
     * possible value to indicate unlimited spending capability.
     */
    allowance: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address of the wallet that owns the tokens. If not provided, it will be
         * automatically derived from the adapter context.
         */
        walletAddress?: string | undefined;
        /**
         * The address to check the allowance for.
         */
        delegate: string;
    };
    /**
     * Transfer tokens directly from the wallet to another address.
     */
    transfer: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address to send the tokens to.
         */
        to: string;
        /**
         * The amount of tokens to transfer (in token's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Transfer tokens from one address to another using a pre-approved allowance.
     *
     * On chains without allowance support, this may behave differently or throw
     * an error if the operation is not supported.
     */
    transferFrom: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address to transfer tokens from (must have given allowance to the caller).
         */
        from: string;
        /**
         * The address to send the tokens to.
         */
        to: string;
        /**
         * The amount of tokens to transfer (in token's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Get the current token balance for a wallet address.
     */
    balanceOf: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address to check the balance for. If not provided, it will be
         * automatically derived from the adapter context.
         */
        walletAddress?: string | undefined;
    };
}

/**
 * USDC-specific operations that automatically resolve the token address.
 *
 * These include all standard ERC20 operations plus additional safety functions
 * that USDC supports. The interface provides the same core operations as
 * {@link TokenActionMap} but without requiring a `tokenAddress` parameter,
 * plus additional USDC-specific extensions.
 *
 * @example
 * ```typescript
 * // USDC operations (address auto-resolved)
 * await adapter.action('usdc.approve', {
 *   delegate: '0x1234...',
 *   amount: '1000000' // 1 USDC
 * })
 *
 * // USDC-specific safe allowance functions
 * await adapter.action('usdc.increaseAllowance', {
 *   delegate: '0x1234...',
 *   amount: '500000' // increase by 0.5 USDC
 * })
 *
 * // vs. general token operations (address required)
 * await adapter.action('token.approve', {
 *   tokenAddress: '0xA0b86a33E6441c8C1c7C16e4c5e3e5b5e4c5e3e5b5e4c5e',
 *   delegate: '0x1234...',
 *   amount: '1000000'
 * })
 * ```
 */
type BaseUSDCActions = {
    [K in keyof TokenActionMap]: Omit<TokenActionMap[K], 'tokenAddress'>;
};
/**
 * USDC action map with both standard ERC20 operations and USDC-specific extensions.
 *
 * This provides all standard token operations plus additional safety functions
 * that USDC implements beyond the base ERC20 standard.
 */
interface USDCActionMap {
    /**
     * Set an allowance for a delegate to spend USDC tokens on behalf of the wallet.
     *
     * Automatically uses the USDC contract address for the current chain.
     * On chains without native allowance support, this may return a noop result.
     */
    approve: BaseUSDCActions['approve'];
    /**
     * Check the current allowance between an owner and spender for USDC tokens.
     *
     * Automatically uses the USDC contract address for the current chain.
     * This is a read-only operation.
     */
    allowance: BaseUSDCActions['allowance'];
    /**
     * Safely increase the allowance for a delegate to spend USDC tokens.
     *
     * This is a USDC-specific function that provides safer allowance management
     * compared to direct approve() calls. Automatically uses the USDC contract
     * address for the current chain.
     */
    increaseAllowance: ActionParameters & {
        /**
         * The address that will have their allowance increased.
         */
        delegate: string;
        /**
         * The amount to increase the allowance by (in USDC's smallest unit).
         */
        amount: bigint;
        /**
         * The chain definition for the current chain.
         */
        chain?: ChainDefinition;
    };
    /**
     * Safely decrease the allowance for a delegate to spend USDC tokens.
     *
     * This is a USDC-specific function that provides safer allowance management.
     * Automatically uses the USDC contract address for the current chain.
     */
    decreaseAllowance: ActionParameters & {
        /**
         * The address that will have their allowance decreased.
         */
        delegate: string;
        /**
         * The amount to decrease the allowance by (in USDC's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Transfer USDC tokens directly from the wallet to another address.
     *
     * Automatically uses the USDC contract address for the current chain.
     */
    transfer: BaseUSDCActions['transfer'];
    /**
     * Transfer USDC tokens from one address to another using a pre-approved allowance.
     *
     * Automatically uses the USDC contract address for the current chain.
     * The caller must have sufficient allowance from the 'from' address.
     */
    transferFrom: BaseUSDCActions['transferFrom'];
    /**
     * Get the current USDC balance for a wallet address.
     *
     * Automatically uses the USDC contract address for the current chain.
     * This is a read-only operation.
     */
    balanceOf: Omit<BaseUSDCActions['balanceOf'], 'tokenAddress'>;
    /**
     * Get the EIP-712 domain name of the USDC contract on the current chain.
     *
     * Automatically uses the USDC contract address for the current chain.
     * This is a read-only operation with no parameters.
     */
    name: ActionParameters & {
        /**
         * Optional chain override; defaults to the operation context chain.
         */
        chain?: ChainDefinition;
    };
}

/**
 * USDT-specific operations that automatically resolve the token address.
 *
 * These include standard ERC20 operations. The interface provides the same core
 * operations as {@link TokenActionMap} but without requiring a `tokenAddress`
 * parameter.
 *
 * @example
 * ```typescript
 * // USDT operations (address auto-resolved)
 * await adapter.action('usdt.transfer', {
 *   to: '0x1234...',
 *   amount: '1000000' // 1 USDT
 * })
 *
 * // vs. general token operations (address required)
 * await adapter.action('token.transfer', {
 *   tokenAddress: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
 *   to: '0x1234...',
 *   amount: '1000000'
 * })
 * ```
 */
type BaseUSDTActions = {
    [K in keyof TokenActionMap]: Omit<TokenActionMap[K], 'tokenAddress'>;
};
/**
 * USDT action map with standard ERC20 operations.
 *
 * This provides standard token operations for USDT transfers.
 */
interface USDTActionMap {
    /**
     * Transfer USDT tokens directly from the wallet to another address.
     *
     * Automatically uses the USDT contract address for the current chain.
     */
    transfer: BaseUSDTActions['transfer'];
}

/**
 * Versioned wrapper for Gateway action namespaces.
 *
 * Follows the same pattern as {@link CCTPActionMap}: each version is a
 * nested namespace so that action keys read `gateway.v1.deposit`, etc.
 *
 * @see {@link GatewayV1ActionMap} for v1 action definitions
 */
interface GatewayActionMap {
    /** Gateway protocol v1 operations. */
    readonly v1: GatewayV1ActionMap;
}
/**
 * Action map for Circle Gateway Wallet v1 contract operations.
 *
 * Mirrors the GatewayWallet interface: deposit variants, delegate management,
 * and balance queries.
 *
 * @see https://developers.circle.com/gateway/references/contract-interfaces-and-events
 * @see https://developers.circle.com/gateway/references/solana-programs
 */
interface GatewayV1ActionMap {
    /**
     * Deposit tokens after approving the Gateway contract. Balance is credited to the caller.
     *
     * Corresponds to `deposit(address token, uint256 value)`.
     */
    deposit: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Deposit tokens on behalf of another address after approving. Balance is credited to `depositor`.
     *
     * Corresponds to `depositFor(address token, address depositor, uint256 value)`.
     */
    depositFor: ActionParameters & {
        /** Token contract address. */
        token: string;
        /** Address that will own the resulting balance. */
        depositor: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Deposit with EIP-2612 permit (gasless approval via signature).
     *
     * Corresponds to `depositWithPermit(token, owner, value, deadline, signature)` (bytes)
     * or the overload with (v, r, s). Use `signature` for EIP-7597 (SCA); use (v, r, s) for EOA.
     */
    depositWithPermit: ActionParameters & {
        /** Token contract address. */
        token: string;
        /** Depositor's address (owner in permit). */
        owner: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Permit deadline (Unix timestamp) or max uint256 for no expiration. */
        deadline: bigint;
        /** Signature as bytes (EIP-7597) or omit and use v, r, s. */
        signature?: `0x${string}`;
        /** ECDSA v (when not using signature bytes). */
        v?: number;
        /** ECDSA r (when not using signature bytes). */
        r?: `0x${string}`;
        /** ECDSA s (when not using signature bytes). */
        s?: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Deposit with EIP-3009 transferWithAuthorization (receiveWithAuthorization).
     *
     * Corresponds to `depositWithAuthorization(token, from, value, validAfter, validBefore, nonce, signature)`
     * or the overload with (v, r, s).
     */
    depositWithAuthorization: ActionParameters & {
        /** Token contract address. */
        token: string;
        /** Depositor's address (from in authorization). */
        from: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Unix timestamp after which the authorization is valid. */
        validAfter: bigint;
        /** Unix timestamp before which the authorization is valid. */
        validBefore: bigint;
        /** Unique nonce (bytes32). */
        nonce: `0x${string}`;
        /** Signature as bytes (EIP-7598) or omit and use v, r, s. */
        signature?: `0x${string}`;
        /** ECDSA v (when not using signature bytes). */
        v?: number;
        /** ECDSA r (when not using signature bytes). */
        r?: `0x${string}`;
        /** ECDSA s (when not using signature bytes). */
        s?: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Grant spending rights to a delegate on the caller's Gateway account.
     *
     * Corresponds to `addDelegate(address token, address delegate)`.
     */
    addDelegate: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Address to authorize as a delegate. */
        delegate: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Revoke spending rights from a delegate on the caller's Gateway account.
     *
     * Corresponds to `removeDelegate(address token, address delegate)`.
     */
    removeDelegate: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Address to revoke as a delegate. */
        delegate: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Check whether an address is authorized as a delegate for a depositor's balance.
     *
     * Corresponds to `isAuthorizedForBalance(address token, address depositor, address addr)`.
     */
    isDelegate: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** The depositor (balance owner) address. */
        depositor: string;
        /** The address to check for delegate status. */
        delegate: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
        /** EVM: specific block number to read state at (for finality-aware checks). */
        blockNumber?: bigint;
        /** Solana: commitment level for the account read. */
        commitment?: 'confirmed' | 'finalized';
    };
    /**
     * Start a delayed fund removal from a Gateway account.
     *
     * Corresponds to `initiateWithdrawal(address token, uint256 value)` (EVM)
     * or the `initiate_withdrawal` instruction (Solana).
     */
    initiateWithdrawal: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Complete a fund removal after the withdrawal delay has elapsed.
     *
     * Corresponds to `withdraw(address token)` (EVM) or the `withdraw`
     * instruction (Solana). No amount parameter -- the contract returns the
     * full pending withdrawal balance.
     */
    withdraw: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Read the pending withdrawal balance for a depositor.
     *
     * Corresponds to `withdrawingBalance(address token, address depositor)` (EVM)
     * or reading `withdrawing_amount` from the `GatewayDeposit` PDA (Solana).
     */
    withdrawingBalance: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** The depositor whose pending withdrawal to query. */
        depositor: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Read the block number at which a pending withdrawal can be completed.
     *
     * Corresponds to `withdrawalBlock(address token, address depositor)` (EVM)
     * or reading `withdrawal_block` from the `GatewayDeposit` PDA (Solana).
     */
    withdrawalBlock: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** The depositor whose withdrawal block to query. */
        depositor: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Execute gatewayBurn on the Gateway Wallet contract.
     * Burns tokens from a source chain as part of a cross-chain spend.
     *
     * Corresponds to `gatewayBurn(bytes calldataBytes, bytes signature)`.
     */
    gatewayBurn: ActionParameters & {
        /** ABI-encoded burn intent calldata. */
        calldataBytes: `0x${string}`;
        /** Signature over the burn intent(s). */
        signature: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Execute gatewayMint on the Gateway Minter contract.
     * Mints tokens on the destination chain to complete a cross-chain spend.
     *
     * Corresponds to `gatewayMint(bytes attestationPayload, bytes signature)`.
     */
    gatewayMint: ActionParameters & {
        /** Attestation payload from the Gateway API. */
        attestation: `0x${string}`;
        /** Signature over the attestation. */
        signature: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Sign burn intents using EIP-712 typed data (EVM) or binary encoding (Solana).
     * Returns the signature needed for the Gateway API transfer call.
     */
    signBurnIntents: ActionParameters & {
        /** EIP-712 typed data for EVM, or binary-encoded data for Solana. */
        typedData: unknown;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
}

/**
 * Native token-related action maps for the bridge kit.
 *
 * This module provides action definitions for native token operations.
 */
interface NativeActionMap {
    /**
     * Transfer native tokens directly from the wallet to another address.
     */
    transfer: ActionParameters & {
        /**
         * The chain to transfer the native tokens on.
         */
        chain?: ChainIdentifier;
        /**
         * The address to send the native tokens to.
         */
        to: string;
        /**
         * The amount of native tokens to transfer.
         */
        amount: bigint;
    };
    /**
     * Get the native token balance (SOL, ETH, etc.) for a wallet address.
     */
    balanceOf: ActionParameters & {
        /**
         * The address to check the native balance for. If not provided, it will be
         * automatically derived from the adapter context.
         */
        walletAddress?: string | undefined;
    };
}

/**
 * Central registry of all available action namespaces and their operations.
 *
 * Define the complete action map structure used throughout the bridge kit.
 * Each top-level key represents a namespace (e.g., 'token', 'usdc') containing
 * related operations. The structure supports arbitrary nesting depth through
 * the recursive utility types provided in this module.
 *
 * @remarks
 * This interface serves as the foundation for type-safe action dispatching
 * and provides compile-time validation of action keys and payload types.
 * All action-related utility types derive from this central definition.
 *
 * @see {@link ActionKeys} for dot-notation action paths
 * @see {@link ActionPayload} for extracting payload types
 */
interface ActionMap {
    /** CCTP-specific operations with automatic address resolution. */
    readonly cctp: CCTPActionMap;
    /** Gateway Wallet operations, versioned (e.g. gateway.v1.deposit). */
    readonly gateway: GatewayActionMap;
    /** Native token operations (ETH, SOL, MATIC, etc.). */
    readonly native: NativeActionMap;
    /** General token operations requiring explicit token addresses. */
    readonly token: TokenActionMap;
    /** USDC-specific operations with automatic address resolution. */
    readonly usdc: USDCActionMap;
    /** USDT-specific operations with automatic address resolution. */
    readonly usdt: USDTActionMap;
    /** Swap operations for DEX aggregator integrations. */
    readonly swap: SwapActionMap;
}
/**
 * Determine if a type represents an action parameter object (leaf node).
 *
 * Check whether a type extends the ActionParameters interface, which provides
 * an explicit marker for identifying action parameter objects versus namespace
 * containers that should be traversed during type recursion.
 *
 * @typeParam T - The type to examine for parameter object characteristics
 *
 * @remarks
 * This utility type provides deterministic leaf detection for the recursive
 * type system. By requiring all action parameter objects to extend the
 * ActionParameters interface, we eliminate the need for property name
 * heuristics and make the system more maintainable.
 *
 * @see {@link ActionParameters} for the base interface
 * @see {@link NestedKeys} for usage in path extraction
 */
type IsActionParameterObject<T> = T extends ActionParameters ? true : false;
/**
 * Recursively extract all nested keys from an object type as dot-notation string literals.
 *
 * Traverse object structures of arbitrary depth and generate string literal
 * types representing all possible paths through the structure using dot
 * notation. Stop recursion when encountering action parameter objects (leaves).
 *
 * @typeParam T - The object type to extract nested keys from
 *
 * @remarks
 * This type is the foundation for generating type-safe action paths in
 * dot notation. It automatically adapts to changes in the ActionMap
 * structure and supports unlimited nesting depth for future extensibility.
 *
 * The recursion stops when it encounters objects that match the
 * {@link IsActionParameterObject} criteria, ensuring that only valid
 * action paths are generated.
 *
 * @see {@link ActionKeys} for ActionMap-specific paths
 * @see {@link NestedValue} for extracting types at specific paths
 * @see {@link IsActionParameterObject} for leaf detection logic
 */
type NestedKeys<T> = {
    [K in Extract<keyof T, string>]: IsActionParameterObject<T[K]> extends true ? K : T[K] extends object ? `${K}.${NestedKeys<T[K]>}` : never;
}[Extract<keyof T, string>];
/**
 * Recursively extract the value type at a given dot-notation path.
 *
 * Navigate through nested object types using a dot-notation string path
 * and return the type of the value at that location. Parse the path
 * recursively by splitting on dots and traversing the object structure.
 *
 * @typeParam T - The object type to navigate through
 * @typeParam K - The dot-notation path as a string literal type
 *
 * @remarks
 * This utility type enables type-safe access to deeply nested object
 * properties using dot notation paths. It forms the foundation for
 * extracting payload types from action paths in the ActionMap.
 *
 * @see {@link ActionPayload} for ActionMap-specific value extraction
 * @see {@link NestedKeys} for generating valid path types
 */
type NestedValue<T, K extends string> = K extends `${infer First}.${infer Rest}` ? First extends keyof T ? NestedValue<T[First], Rest> : never : K extends keyof T ? T[K] : never;
/**
 * Union type of all nested action keys in dot notation.
 *
 * Generate string literal types for all possible action paths in the
 * ActionMap structure. Automatically adapt to changes in the ActionMap
 * and support arbitrary levels of nesting for future extensibility.
 *
 * @remarks
 * This type serves as the canonical source for all valid action identifiers
 * in the bridge kit. It ensures compile-time validation of action keys
 * and enables type-safe action dispatching throughout the application.
 *
 * @see {@link ActionPayload} for extracting parameter types
 * @see {@link NamespaceActions} for namespace-specific actions
 * @see {@link ActionMap} for the underlying structure
 */
type ActionKeys = NestedKeys<ActionMap>;
/**
 * Extract the payload type for a specific action based on its dot-notation key.
 *
 * Resolve the parameter type for any action by providing its complete path
 * in dot notation. Leverage the recursive NestedValue type to navigate to
 * the correct payload type regardless of nesting depth. The internal
 * ActionParameters marker is automatically removed from the result.
 *
 * @typeParam T - The action key in dot notation (must extend ActionKeys)
 *
 * @remarks
 * This utility type enables type-safe parameter passing for action
 * dispatching. It automatically infers the correct parameter shape
 * based on the action key, providing compile-time validation and
 * excellent IntelliSense support.
 *
 * The internal `__isActionParams` marker used for type system recursion
 * is automatically omitted from the resulting type, providing clean
 * parameter objects for consumers.
 *
 * @see {@link ActionKeys} for available action identifiers
 * @see {@link NestedValue} for the underlying path resolution logic
 */
type ActionPayload<T extends ActionKeys> = Omit<NestedValue<ActionMap, T>, '__isActionParams'>;

/**
 * Type-safe action handler function signature for specific action types.
 *
 * Defines the contract for functions that process action payloads and return
 * prepared chain requests. Each handler is strongly typed to accept only the
 * payload structure corresponding to its specific action key.
 *
 * @typeParam TActionKey - The specific action key this handler processes.
 * @param params - The action payload matching the specified action key.
 * @param context - The resolved operation context with concrete chain and address values.
 * @returns A promise resolving to a prepared chain request.
 *
 * @example
 * ```typescript
 * import type { ActionHandler } from '@core/adapter'
 *
 * const depositHandler: ActionHandler<'cctp.v2.depositForBurn'> = async (params, context) => {
 *   // context is always defined and has concrete chain and address values
 *   console.log(context.chain.name);
 *   console.log(context.address);
 *   // ... handler logic ...
 *   return preparedRequest;
 * }
 * ```
 */
type ActionHandler<TActionKey extends ActionKeys> = (params: ActionPayload<TActionKey>, context: ResolvedOperationContext) => Promise<PreparedChainRequest>;
/**
 * Type-safe mapping of all available action keys to their corresponding handlers.
 *
 * This type defines a registry object where each key is a valid action key
 * (as defined by {@link ActionKeys}) and each value is an {@link ActionHandler}
 * capable of processing the payload for that action. This enables strongly-typed
 * handler registration and lookup for all supported actions in the App Kits.
 *
 * @remarks
 * Each handler is typed as {@link ActionHandler}, which means the handler
 * must accept the payload type for the specific action key it is registered under.
 * This provides type safety for handler registration and execution, but does not
 * enforce per-key handler parameterization at the type level. For stricter per-key
 * typing, consider using mapped types or generic registry patterns.
 *
 * @example
 * ```typescript
 * import type { ActionHandlers } from '@core/adapter'
 * import type { ActionHandler } from '@core/adapter'
 *
 * const handlers: ActionHandlers = {
 *   'cctp.v2.depositForBurn': async (params, resolved) => {
 *     // params is correctly typed for 'cctp.v2.depositForBurn'
 *     // resolved has concrete chain and address values
 *     // ...handler logic...
 *   },
 *   'usdc.approve': async (params, resolved) => {
 *     // params is correctly typed for 'usdc.approve'
 *     // resolved has concrete chain and address values
 *     // ...handler logic...
 *   }
 * }
 * ```
 */
type ActionHandlers = {
    [K in ActionKeys]?: ActionHandler<K>;
};
/**
 * Type-safe registry for managing and executing blockchain action handlers.
 *
 * Provides a centralized system for registering action handlers with full
 * TypeScript type safety, ensuring that handlers can only be registered
 * with compatible action keys and payload types. Supports both individual
 * handler registration and batch registration operations.
 *
 * @remarks
 * The registry uses a Map internally for O(1) lookups and maintains type
 * safety through generic constraints and careful type assertions. All
 * type assertions are validated at registration time to ensure runtime
 * type safety matches compile-time guarantees.
 */
declare class ActionRegistry {
    readonly actionHandlers: Map<ActionKeys, ActionHandler<ActionKeys>>;
    /**
     * Register a type-safe action handler for a specific action key.
     *
     * Associates an action handler function with its corresponding action key,
     * ensuring compile-time type safety between the action and its expected
     * payload structure. The handler will be available for execution via
     * {@link executeAction}.
     *
     * @typeParam TActionKey - The specific action key being registered.
     * @param action - The action key to register the handler for.
     * @param handler - The handler function for processing this action type.
     * @returns Void.
     *
     * @throws Error When action parameter is not a valid string.
     * @throws TypeError When handler parameter is not a function.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     * import type { ActionHandler } from '@core/adapter'
     *
     * const registry = new ActionRegistry()
     *
     * // Register a CCTP deposit handler
     * const depositHandler: ActionHandler<'cctp.v2.depositForBurn'> = async (params, resolved) => {
     *   console.log('Processing deposit:', params.amount)
     *   return {
     *     chainId: params.chainId,
     *     data: '0x...',
     *     to: '0x...',
     *     value: '0'
     *   }
     * }
     *
     * registry.registerHandler('cctp.v2.depositForBurn', depositHandler)
     * ```
     */
    registerHandler<TActionKey extends ActionKeys>(action: TActionKey, handler: ActionHandler<TActionKey>): void;
    /**
     * Register multiple action handlers in a single operation.
     *
     * Efficiently register multiple handlers from a record object, where keys
     * are action identifiers and values are their corresponding handler
     * functions. Provides a convenient way to bulk-register handlers while
     * maintaining type safety.
     *
     * @param handlers - A record mapping action keys to their handler functions.
     * @returns Void.
     *
     * @throws {Error} When handlers parameter is not a valid object.
     * @throws {Error} When any individual handler registration fails.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     * import type { ActionHandler, ActionHandlers } from '@core/adapter'
     *
     * const registry = new ActionRegistry()
     *
     * // Register multiple handlers at once
     * const tokenHandlers: ActionHandlers = {
     *   'token.approve': async (params, resolved) => ({
     *     chainId: resolved.chain,
     *     data: '0x095ea7b3...',
     *     to: params.tokenAddress,
     *     value: '0'
     *   }),
     *   'token.transfer': async (params, resolved) => ({
     *     chainId: resolved.chain,
     *     data: '0xa9059cbb...',
     *     to: params.tokenAddress,
     *     value: '0'
     *   })
     * }
     *
     * registry.registerHandlers(tokenHandlers)
     * console.log('Registered multiple token handlers')
     * ```
     */
    registerHandlers(handlers: ActionHandlers): void;
    /**
     * Check whether a specific action is supported by this registry.
     *
     * Determine if a handler has been registered for the given action key.
     * Use this method to conditionally execute actions or provide appropriate
     * error messages when actions are not available.
     *
     * @param action - The action key to check for support.
     * @returns True if the action is supported, false otherwise.
     *
     * @throws {Error} When action parameter is not a valid string.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     *
     * const registry = new ActionRegistry()
     *
     * // Check if actions are supported before attempting to use them
     * if (registry.supportsAction('token.approve')) {
     *   console.log('Token approval is supported')
     * } else {
     *   console.log('Token approval not available')
     * }
     *
     * // Conditional logic based on support
     * const action = 'cctp.v2.depositForBurn'
     * if (registry.supportsAction(action)) {
     *   // Safe to execute
     *   console.log(`${action} is available`)
     * } else {
     *   console.warn(`${action} is not registered`)
     * }
     * ```
     */
    supportsAction(action: ActionKeys): boolean;
    /**
     * Execute a registered action handler with type-safe parameters.
     *
     * Look up and execute the handler associated with the given action key,
     * passing the provided parameters and context, returning the resulting prepared
     * chain request. TypeScript ensures the parameters match the expected
     * structure for the specified action.
     *
     * @typeParam TActionKey - The specific action key being executed.
     * @param action - The action key identifying which handler to execute.
     * @param params - The parameters to pass to the action handler.
     * @param context - The resolved operation context with concrete chain and address values.
     * @returns A promise resolving to the prepared chain request.
     * @throws {KitError} When the handler execution fails with a structured error.
     * @throws {Error} When no handler is registered for the specified action.
     * @throws {Error} When the handler execution fails with an unstructured error.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     * import type { ChainEnum } from '@core/chains'
     *
     * const registry = new ActionRegistry()
     *
     * // First register a handler
     * registry.registerHandler('token.approve', async (params, context) => ({
     *   chainId: context.chain, // Always defined
     *   data: '0x095ea7b3...',
     *   to: params.tokenAddress,
     *   value: '0'
     * }))
     *
     * // Execute the action with resolved context (typically called from adapter.prepareAction)
     * const resolvedContext = { chain: 'Base', address: '0x123...' }
     * const result = await registry.executeAction('token.approve', {
     *   chainId: ChainEnum.Ethereum,
     *   tokenAddress: '0xA0b86a33E6441c8C1c7C16e4c5e3e5b5e4c5e3e5b5e4c5e',
     *   delegate: '0x1234567890123456789012345678901234567890',
     *   amount: '1000000'
     * }, resolvedContext)
     *
     * console.log('Transaction prepared:', result.data)
     * ```
     */
    executeAction<TActionKey extends ActionKeys>(action: TActionKey, params: ActionPayload<TActionKey>, context: ResolvedOperationContext): Promise<PreparedChainRequest>;
}

/**
 * Defines the capabilities of an adapter, including address handling patterns and supported chains.
 *
 * @interface TAdapterCapabilities
 * @category Types
 * @description
 * This interface specifies how an adapter manages address control and which blockchain networks it supports.
 * It is used for capability discovery, validation, and to inform consumers about the adapter's operational model.
 *
 * The `addressContext` property determines both address selection behavior and bridge API requirements:
 * - `'user-controlled'`: User controls addresses through wallet UI, address optional in operations
 * - `'developer-controlled'`: Service manages addresses programmatically, address required in operations
 *
 * @example
 * ```typescript
 * // Browser wallet adapter (user-controlled)
 * const capabilities: AdapterCapabilities = {
 *   addressContext: 'user-controlled', // User selects address in wallet UI
 *   supportedChains: [Ethereum, Base, Polygon]
 * }
 *
 * // Enterprise provider adapter (developer-controlled)
 * const capabilities: AdapterCapabilities = {
 *   addressContext: 'developer-controlled', // Address must be specified per operation
 *   supportedChains: [Ethereum, Base, Solana]
 * }
 * ```
 */
interface AdapterCapabilities {
    /**
     * Defines who controls address selection for wallet operations.
     *
     * - `'user-controlled'`: User controls addresses through wallet UI (browser wallets, hardware wallets)
     *   - Address is implicit in bridge operations (uses wallet's current address)
     *   - Adapter may listen for accountsChanged/chainChanged events
     *   - Suitable for MetaMask, Coinbase Wallet, WalletConnect, private keys, etc.
     *
     * - `'developer-controlled'`: Service manages addresses programmatically (enterprise providers)
     *   - Address must be explicitly provided in bridge operations
     *   - No event listening (addresses controlled programmatically)
     *   - Suitable for Fireblocks, Circle Wallets, institutional custody, etc.
     */
    addressContext: 'user-controlled' | 'developer-controlled';
    /**
     * The set of blockchain networks this adapter supports.
     * Used for validation, capability discovery, and to restrict operations to supported chains.
     */
    supportedChains: ChainDefinition[];
}
/**
 * Abstract class defining the standard interface for an adapter that interacts with a specific blockchain.
 *
 * An `Adapter` is responsible for encapsulating chain-specific logic necessary to
 * perform operations like sending transactions, querying balances, or interacting with smart contracts.
 * Implementations of this class will provide concrete logic for a particular blockchain protocol.
 *
 * This abstraction allows the App Kit to work with multiple blockchains in a uniform way.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type for compile-time address validation.
 * When provided, enables strict typing of operation context based on the adapter's address control model.
 */
declare abstract class Adapter<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> {
    /**
     * The type of the chain for this adapter.
     *
     * - For concrete adapters, this should be a real chain type (e.g., `'evm'`, `'solana'`, etc.) from the ChainType union.
     * - For hybrid adapters (adapters that route to concrete adapters supporting multiple ecosystems),
     *   set this property to the string literal `'hybrid'`.
     *
     * Note: `'hybrid'` is not a legal ChainType and should only be used as a marker for multi-ecosystem adapters.
     * Hybrid adapters do not interact directly with any chain, but instead route requests to a concrete underlying adapter.
     *
     * @example
     *   // For an EVM-only adapter:
     *   chainType = 'evm'
     *
     *   // For a hybrid adapter:
     *   chainType = 'hybrid'
     */
    abstract chainType: ChainType | 'hybrid';
    /**
     * Capabilities of this adapter, defining address control model and supported chains.
     *
     * This property determines how the adapter behaves, especially for address selection
     * and bridge API requirements. The `addressContext` must match the adapter's type parameter.
     *
     * @remarks
     * The `addressContext` value must align with the adapter's generic type parameter for proper
     * type safety in bridge operations.
     *
     * @example
     * ```typescript
     * // User-controlled adapter (private key, browser wallet)
     * capabilities = {
     *   addressContext: 'user-controlled', // Address implicit in bridge operations
     *   supportedChains: [Ethereum, Base, Polygon]
     * }
     *
     * // Developer-controlled adapter (enterprise provider)
     * capabilities = {
     *   addressContext: 'developer-controlled', // Address required in bridge operations
     *   supportedChains: [Ethereum, Base, Solana]
     * }
     * ```
     */
    capabilities?: TAdapterCapabilities;
    /**
     * Registry of available actions for this adapter.
     *
     * The {@link ActionRegistry} provides a catalog of supported operations
     * (such as token transfers, approvals, etc.) that can be performed by this adapter
     * on the connected blockchain. This enables dynamic discovery and invocation
     * of chain-specific or cross-chain actions in a type-safe manner.
     *
     * @readonly
     */
    readonly actionRegistry: ActionRegistry;
    /**
     * Prepares (but does not execute) an action for the connected blockchain.
     *
     * This method looks up the appropriate action handler for the given action key
     * and prepares the transaction request using the provided parameters. The returned
     * {@link PreparedChainRequest} allows developers to estimate gas costs and execute
     * the transaction at a later time, enabling pre-flight simulation and deferred execution.
     *
     * **Compile-time Address Validation**: When used with typed adapters that have capabilities,
     * this method enforces address requirements at compile time:
     * - **User-controlled adapters**: The `address` field is forbidden in the context
     * - **Developer-controlled adapters**: The `address` field is required in the context
     * - **Legacy adapters**: The `address` field remains optional for backward compatibility
     *
     * @remarks
     * This method does not send any transaction to the network. Instead, it returns a
     * prepared request object with `estimate()` and `execute()` methods, allowing
     * developers to inspect, simulate, or submit the transaction as needed.
     *
     * @param action - The action key identifying which handler to use for preparation.
     * @param params - The parameters to pass to the action handler.
     * @param ctx - Operation context with compile-time validated address requirements based on adapter capabilities.
     * @returns A promise that resolves to a {@link PreparedChainRequest} for estimation and execution.
     * @throws Error If the specified action key does not correspond to a registered handler.
     * @throws Error If the provided parameters are invalid for the action.
     * @throws Error If the operation context cannot be resolved.
     *
     * @example
     * ```typescript
     * // User-controlled adapter (address forbidden)
     * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
     * await userAdapter.prepareAction('token.approve', params, {
     *   chain: 'Ethereum'
     *   // address: '0x123...' // ❌ TypeScript error: address not allowed
     * })
     *
     * // Developer-controlled adapter (address required)
     * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
     * await devAdapter.prepareAction('token.approve', params, {
     *   chain: 'Ethereum',
     *   address: '0x123...' // ✅ Required for developer-controlled
     * })
     * ```
     */
    prepareAction<TActionKey extends ActionKeys>(action: TActionKey, params: ActionPayload<TActionKey>, ctx: OperationContext<TAdapterCapabilities>): Promise<PreparedChainRequest>;
    /**
     * Prepares a transaction for future gas estimation and execution.
     *
     * This method should handle any preliminary steps required before a transaction
     * can be estimated or sent. This might include things like serializing transaction
     * data, but it should NOT yet send anything to the network.
     *
     * The returned object contains two functions:
     *  - `estimate()`: Asynchronously calculates and returns the {@link EstimatedGas} for the prepared transaction.
     *  - `execute()`: Asynchronously executes the prepared transaction and returns a promise that resolves
     *                 with the transaction result (e.g., a transaction hash, receipt, or other chain-specific response).
     *
     * **Compile-time Address Validation**: When used with typed adapters that have capabilities,
     * this method enforces address requirements at compile time:
     * - **User-controlled adapters**: The `address` field is forbidden in the context
     * - **Developer-controlled adapters**: The `address` field is required in the context
     * - **Legacy adapters**: The `address` field remains optional for backward compatibility
     *
     * @remarks
     * The specific parameters for `prepare` might vary greatly between chain implementations.
     * Consider defining a generic type or a base type for `transactionRequest` if common patterns emerge,
     * or allow `...args: any[]` if extreme flexibility is needed by implementers.
     * For this abstract definition, we keep it parameter-less, assuming implementations will add specific
     * parameters as needed for their `prepare` method (e.g. `prepare(txDetails: MyChainTxDetails)`).
     *
     * @param params - The prepared chain request parameters for the specific blockchain.
     * @param ctx - Operation context with compile-time validated address requirements based on adapter capabilities.
     * @returns An object containing `estimate` and `execute` methods for the prepared transaction.
     *
     * @example
     * ```typescript
     * // User-controlled adapter (address forbidden)
     * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
     * await userAdapter.prepare(params, {
     *   chain: 'Ethereum'
     *   // address: '0x123...' // ❌ TypeScript error: address not allowed
     * })
     *
     * // Developer-controlled adapter (address required)
     * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
     * await devAdapter.prepare(params, {
     *   chain: 'Ethereum',
     *   address: '0x123...' // ✅ Required for developer-controlled
     * })
     * ```
     */
    abstract prepare(params: PreparedChainRequestParams, ctx: OperationContext<TAdapterCapabilities>): Promise<PreparedChainRequest>;
    /**
     * Retrieves the public address of the connected wallet.
     *
     * This address is used as the default sender for transactions
     * and interactions initiated by this adapter.
     *
     * @param chain - The chain to use for address resolution.
     * @returns A promise that resolves to the blockchain address as a string.
     */
    abstract getAddress(chain: ChainDefinition): Promise<string>;
    /**
     * Switches the adapter to operate on the specified chain.
     *
     * This abstract method must be implemented by concrete adapters to handle their specific
     * chain switching logic. The behavior varies by adapter type:
     * - **Private key adapters**: Recreate clients with new RPC endpoints
     * - **Browser wallet adapters**: Request chain switch via EIP-1193 or equivalent
     * - **Multi-entity adapters**: Typically a no-op (operations are contextual)
     *
     * @param chain - The target chain to switch to.
     * @returns A promise that resolves when the chain switch is complete.
     * @throws When the chain switching fails or is not supported.
     *
     * @remarks
     * This method is called by `ensureChain()` after validation is complete.
     * Implementations should focus only on the actual switching logic, not validation.
     *
     * @example
     * ```typescript
     * // EVM adapter implementation
     * protected async switchToChain(chain: ChainDefinition): Promise<void> {
     *   if (chain.type !== 'evm') {
     *     throw new Error('Only EVM chains supported')
     *   }
     *   await this.recreateWalletClient(chain)
     * }
     *
     * // Multi-entity adapter implementation
     * protected async switchToChain(chain: ChainDefinition): Promise<void> {
     *   // No-op - operations are contextual
     *   return
     * }
     * ```
     */
    abstract switchToChain(chain: ChainDefinition): Promise<void>;
    /**
     * Ensures the adapter is operating on the specified chain, switching if necessary.
     *
     * This method provides a unified interface for establishing chain preconditions across different adapter types.
     * The behavior varies based on the adapter's capabilities:
     * - **Private key adapters**: Recreate clients with new RPC endpoints
     * - **Browser wallet adapters**: Request chain switch via EIP-1193 or equivalent
     * - **Multi-entity adapters**: Validate chain support (operations are contextual)
     *
     * @param chain - The target chain for operations.
     * @returns A promise that resolves when the adapter is operating on the specified chain.
     * @throws When the target chain is not supported or chain switching fails.
     *
     * @remarks
     * This method always calls `switchToChain()` to ensure consistency across all adapter types.
     * The underlying implementations handle idempotent switching efficiently (e.g., browser wallets
     * gracefully handle switching to the current chain, private key adapters recreate lightweight clients).
     *
     * @example
     * ```typescript
     * // Private key adapter - switches chains seamlessly
     * await privateKeyAdapter.ensureChain(Base)
     *
     * // Browser wallet - requests user to switch chains
     * await metamaskAdapter.ensureChain(Polygon)
     *
     * // Multi-entity adapter - validates chain is supported
     * await circleWalletsAdapter.ensureChain(Ethereum)
     * ```
     */
    ensureChain(targetChain: ChainDefinition): Promise<void>;
    /**
     * Validate that the target chain is supported by this adapter.
     *
     * @param targetChain - The chain to validate.
     * @throws KitError with INVALID_CHAIN code if the chain is not supported by this adapter.
     */
    validateChainSupport(targetChain: ChainDefinition): void;
    /**
     * Waits for a transaction to be mined and confirmed on the blockchain.
     *
     * This method should block until the transaction is confirmed on the blockchain.
     * The response includes comprehensive transaction details for the confirmed transaction.
     *
     * @param txHash - The hash of the transaction to wait for.
     * @param config - Optional configuration for waiting behavior including timeout and confirmations.
     * @param chain - The chain definition where the transaction was submitted.
     * @returns Promise resolving to comprehensive transaction details.
     */
    abstract waitForTransaction(txHash: string, config: WaitForTransactionConfig | undefined, chain: ChainDefinition): Promise<WaitForTransactionResponse>;
    /**
     * Calculate the total transaction fee including compute cost and buffer for the configured chain.
     *
     * This method computes the fee by multiplying the base compute units by the current
     * fee rate, then adds a configurable buffer to account for fee fluctuations and ensure
     * transaction success. The buffer is specified in basis points (1 basis point = 0.01%).
     *
     * @param baseComputeUnits - The base compute units for the transaction (gas for EVM, compute units for Solana, etc.).
     * @param bufferBasisPoints - The buffer to add as basis points (e.g., 500 = 5%). Defaults to implementation-specific value.
     * @param chain - The chain definition to calculate fees for.
     * @returns A promise that resolves to the total transaction fee as a bigint.
     */
    abstract calculateTransactionFee(baseComputeUnits: bigint, bufferBasisPoints: bigint | undefined, chain: ChainDefinition): Promise<EstimatedGas>;
    /**
     * Get the decimal places for a token address on a given chain.
     *
     * This method fetches the number of decimal places from a token contract.
     * Different chain types implement this differently:
     * - EVM: Calls the `decimals()` function on ERC-20 contracts
     * - Solana: Reads the `decimals` field from the SPL token mint account
     *
     * @param tokenAddress - The token contract address (EVM) or mint address (Solana)
     * @param chain - The chain definition where the token is deployed
     * @returns Promise resolving to the number of decimal places for the token
     * @throws Error when the token contract doesn't exist or decimals cannot be fetched
     *
     * @example
     * ```typescript
     * import { EthersAdapter } from '@circle-fin/adapter-ethers-v6'
     * import { Ethereum } from '@core/chains'
     *
     * const adapter = new EthersAdapter({ signer })
     *
     * // Fetch decimals for DAI token
     * const decimals = await adapter.getTokenDecimals(
     *   '0x6B175474E89094C44Da98b954EedeAC495271d0F',
     *   Ethereum
     * )
     * console.log(decimals) // 18
     * ```
     */
    abstract getTokenDecimals(tokenAddress: string, chain: ChainDefinition): Promise<number>;
}

/**
 * Configuration options for the API polling utility.
 *
 * @remarks
 * These settings control the behavior of the API polling process:
 * - timeout: Maximum time (ms) to wait for each request before aborting
 * - maxRetries: Maximum number of retry attempts for failed requests
 * - retryDelay: Time (ms) to wait between retry attempts
 * - headers: Optional HTTP headers to include with each request
 */
interface ApiPollingConfig {
    /** Maximum time in milliseconds to wait for each request */
    timeout: number;
    /** Maximum number of retry attempts for failed requests */
    maxRetries: number;
    /** Time in milliseconds to wait between retry attempts */
    retryDelay: number;
    /** Optional HTTP headers to include with requests */
    headers?: Record<string, string> | undefined;
}

/**
 * A type-safe event emitter for managing action-based event subscriptions.
 *
 * Actionable provides a strongly-typed publish/subscribe pattern for events,
 * where each event (action) has its own specific payload type. Handlers can
 * subscribe to specific events or use a wildcard to receive all events.
 *
 * @typeParam AllActions - A record mapping action names to their payload types.
 *
 * @example
 * ```typescript
 * import { Actionable } from '@circle-fin/bridge-kit/utils';
 *
 * // Define your action types
 * type TransferActions = {
 *   started: { txHash: string; amount: string };
 *   completed: { txHash: string; destinationTxHash: string };
 *   failed: { error: Error };
 * };
 *
 * // Create an actionable instance
 * const transferEvents = new Actionable<TransferActions>();
 *
 * // Subscribe to a specific event
 * transferEvents.on('completed', (payload) => {
 *   console.log(`Transfer completed with hash: ${payload.destinationTxHash}`);
 * });
 *
 * // Subscribe to all events
 * transferEvents.on('*', (payload) => {
 *   console.log('Event received:', payload);
 * });
 *
 * // Dispatch an event
 * transferEvents.dispatch('completed', {
 *   txHash: '0x123',
 *   destinationTxHash: '0xabc'
 * });
 * ```
 */
declare class Actionable<AllActions> {
    private readonly handlers;
    private readonly wildcard;
    /**
     * Register a handler for a specific action.
     *
     * @param action - The specific action key to listen for.
     * @param handler - The callback function to execute when the action occurs.
     *
     * @example
     * ```typescript
     * const events = new Actionable<{ dataReceived: string }>();
     *
     * events.on('dataReceived', (data) => {
     *   console.log(`Received: ${data}`);
     * });
     * ```
     */
    on<Action extends keyof AllActions>(action: Action, handler: (payload: AllActions[Action]) => void): void;
    /**
     * Register a handler for all actions using the wildcard '*'.
     *
     * @param action - The wildcard '*' signifying interest in all actions.
     * @param handler - The callback function to execute for any action.
     *
     * @example
     * ```typescript
     * const events = new Actionable<{ started: boolean; completed: string }>();
     *
     * events.on('*', (payload) => {
     *   console.log('Action occurred:', payload);
     * });
     * ```
     */
    on(action: '*', handler: (payload: AllActions[keyof AllActions]) => void): void;
    /**
     * Remove a previously registered handler for a specific action.
     *
     * @param action - The specific action key to unregister from.
     * @param handler - The callback function to remove.
     *
     * @example
     * ```typescript
     * const events = new Actionable<{ dataReceived: string }>();
     *
     * const handler = (data: string) => console.log(data);
     * events.on('dataReceived', handler);
     *
     * // Later, to remove the handler:
     * events.off('dataReceived', handler);
     * ```
     */
    off<Action extends keyof AllActions>(action: Action, handler: (payload: AllActions[Action]) => void): void;
    /**
     * Remove a previously registered wildcard handler.
     *
     * @param action - The wildcard '*' signifying removal from all actions.
     * @param handler - The callback function to remove.
     *
     * @example
     * ```typescript
     * const events = new Actionable<{ started: boolean; completed: string }>();
     *
     * const globalHandler = (payload: any) => console.log(payload);
     * events.on('*', globalHandler);
     *
     * // Later, to remove the handler:
     * events.off('*', globalHandler);
     * ```
     */
    off(action: '*', handler: (payload: AllActions[keyof AllActions]) => void): void;
    /**
     * Dispatch an action with its payload to all registered handlers.
     *
     * This method notifies both:
     * - Handlers registered specifically for this action
     * - Wildcard handlers registered for all actions
     *
     * @param action - The action key identifying the event type.
     * @param payload - The data associated with the action.
     *
     * @example
     * ```typescript
     * type Actions = {
     *   transferStarted: { amount: string; destination: string };
     *   transferComplete: { txHash: string };
     * };
     *
     * const events = new Actionable<Actions>();
     *
     * // Dispatch an event
     * events.dispatch('transferStarted', {
     *   amount: '100',
     *   destination: '0xABC123'
     * });
     * ```
     */
    dispatch<K extends keyof AllActions>(action: K, payload: AllActions[K]): void;
}

/**
 * Module augmentation to register known token symbols.
 *
 * @remarks
 * This file augments the `TokenSymbolRegistry` interface to provide
 * type-safe autocomplete for built-in tokens.
 *
 * When imported, TypeScript will recognize 'USDC' as a valid
 * `TokenSymbol` value with autocomplete support.
 *
 * Other packages or applications can create their own augmentations
 * to add additional tokens.
 *
 * @example
 * ```typescript
 * import '@core/tokens' // Automatically includes this augmentation
 *
 * const symbol: TokenSymbol = 'USDC' // ✓ Autocomplete shows USDC
 * ```
 */
declare module './types' {
    /**
     * Module augmentation: Adds known token symbols as valid keys
     * to the TokenSymbolRegistry interface.
     *
     * Keys are explicitly listed to ensure IDE autocomplete works properly.
     */
    interface TokenSymbolRegistry {
        USDC: true;
        USDT: true;
        EURC: true;
        DAI: true;
        USDE: true;
        PYUSD: true;
        WETH: true;
        WBTC: true;
        WSOL: true;
        WAVAX: true;
        WPOL: true;
        ETH: true;
        POL: true;
        PLUME: true;
        MON: true;
        cirBTC: true;
    }
}

/**
 * Module augmentation to register Blockchain enum values as ChainIdentifiers.
 *
 * @remarks
 * This file augments the `ChainRegistry` interface to provide type-safe
 * autocomplete for all `Blockchain` enum values from `@core/chains`.
 *
 * When this augmentation is imported (via `@core/tokens`), TypeScript will
 * recognize all blockchain identifiers as valid `ChainIdentifier` values
 * with IDE autocomplete support.
 *
 * The `Blockchain` enum values are converted to their string representations,
 * enabling both enum values and string literals to be accepted as chain identifiers.
 *
 * @example
 * ```typescript
 * import { Blockchain } from '@core/chains'
 * import type { ChainIdentifier } from '@core/tokens'
 *
 * // Using enum value
 * const chain1: ChainIdentifier = Blockchain.Ethereum
 *
 * // Using string literal (with autocomplete!)
 * const chain2: ChainIdentifier = 'Base'
 *
 * // Arbitrary strings also work (escape hatch for custom chains)
 * const chain3: ChainIdentifier = 'my-custom-chain'
 * ```
 */

declare module './types' {
    /**
     * Module augmentation: Adds all Blockchain enum values as valid keys
     * to the ChainRegistry interface for type-safe chain identifier support.
     *
     * This ensures both enum property access (e.g., Blockchain.Ethereum) and plain
     * string literals (e.g., 'Ethereum') are accepted by TypeScript as chain keys,
     * providing robust autocomplete and error checking.
     *
     * NOTE:
     * - This interface intentionally has no body. It merges a mapped Record type
     *   into ChainRegistry solely for type augmentation.
     * - This empty-body construct is a necessary TypeScript idiom for module
     *   augmentation with Record types—directly listing mapped keys is not
     *   feasible in interface extensions.
     *
     * eslint-disable-next-line directives below suppress linter complaints about
     * the empty interface/mapping, which are benign and required for this pattern.
     */
    interface ChainRegistry extends Record<`${Blockchain}`, true> {
    }
}

/**
 * Simplified error information structure for logging and events.
 *
 * @remarks
 * This lightweight type is used for error reporting in events, logs, and
 * observability systems. It provides essential error context without the
 * full ErrorDetails structure. Used across retry mechanisms, adapters,
 * and other subsystems that need to record error information.
 *
 * @example
 * ```typescript
 * import { ErrorInfo } from '@core/errors'
 *
 * const info: ErrorInfo = {
 *   name: 'NETWORK_TIMEOUT',
 *   message: 'Request timed out after 5000ms',
 *   code: 3002
 * }
 * ```
 */
interface ErrorInfo {
    /** Error name (e.g., 'TypeError', 'KitError', 'NETWORK_TIMEOUT'). */
    name: string;
    /** Error message describing what went wrong. */
    message: string;
    /** Optional error code if the error has one (e.g., KitError codes). */
    code?: number;
    /** Error category (e.g., INPUT, RPC, ONCHAIN, BALANCE, NETWORK, UNKNOWN). Only set for KitError instances. */
    type?: string;
}

/**
 * Runtime array of token identifiers supported by the Gateway v1 provider.
 *
 * @example
 * ```typescript
 * import { SUPPORTED_TOKENS } from '@circle-fin/provider-gateway-v1'
 *
 * if (SUPPORTED_TOKENS.includes('USDC')) {
 *   console.log('USDC is supported')
 * }
 * ```
 */
declare const SUPPORTED_TOKENS: readonly ["USDC"];
/**
 * Token identifiers supported by the Gateway v1 provider.
 *
 * @example
 * ```typescript
 * import type { SupportedToken } from '@circle-fin/provider-gateway-v1'
 *
 * const token: SupportedToken = 'USDC'
 * ```
 */
type SupportedToken = (typeof SUPPORTED_TOKENS)[number];
/** Human-readable name identifying the Gateway v1 provider. */
declare const GATEWAY_V1_PROVIDER_NAME = "GATEWAY_V1";

/**
 * Represents the context of an adapter used for cross-chain operations.
 *
 * An AdapterContext must always specify both the adapter and the chain explicitly.
 * The address field behavior is determined by the adapter's address control model:
 *
 * - **Developer-controlled adapters**: The `address` field is required because
 *   each operation must explicitly specify which address to use.
 * - **User-controlled adapters**: The `address` field is forbidden because
 *   the address is automatically resolved from the connected wallet or signer.
 * - **Legacy adapters**: The `address` field remains optional for backward compatibility.
 *
 * This ensures clear, debuggable code where the intended chain is always visible at the call site,
 * and address requirements are enforced at compile time based on adapter capabilities.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type to derive address requirements from
 * @typeParam TChainIdentifier - The chain identifier type constraint (defaults to ChainIdentifier)
 *
 * @example
 * ```typescript
 * // Developer-controlled adapter (address required)
 * const devContext: AdapterContext<{ addressContext: 'developer-controlled', supportedChains: [] }> = {
 *   adapter: myDevAdapter,
 *   chain: 'Ethereum',
 *   address: '0x123...' // Required
 * }
 *
 * // User-controlled adapter (address forbidden)
 * const userContext: AdapterContext<{ addressContext: 'user-controlled', supportedChains: [] }> = {
 *   adapter: myUserAdapter,
 *   chain: 'Ethereum'
 *   // address: '0x123...' // TypeScript error: not allowed
 * }
 * ```
 */
type AdapterContext<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends ChainIdentifier = ChainIdentifier> = {
    /** The adapter instance for blockchain operations */
    adapter: Adapter<TAdapterCapabilities>;
    /** The chain reference, which can be a ChainDefinition, Blockchain enum, or string literal */
    chain: TChainIdentifier;
} & AddressField<ExtractAddressContext<TAdapterCapabilities>>;

/**
 * Token allowance strategy used to authorize a Gateway deposit.
 *
 * - `'approve'` — traditional ERC-20 `approve` transaction.
 * - `'permit'` — gasless EIP-2612 off-chain signature.
 * - `'authorize'` — EIP-3009 `transferWithAuthorization`.
 *
 * @example
 * ```typescript
 * import type { AllowanceStrategy } from '@circle-fin/provider-gateway-v1'
 *
 * const strategy: AllowanceStrategy = 'permit'
 * ```
 */
type AllowanceStrategy = 'approve' | 'permit' | 'authorize';
/**
 * Parameters for depositing tokens into the caller's own Gateway
 * account on a specific chain.
 *
 * @remarks
 * Although a Gateway account can span multiple chains (e.g. all EVM
 * chains share the same account), every deposit targets exactly one
 * chain.  The depositor is identified by the adapter context.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { DepositParams } from '@circle-fin/provider-gateway-v1'
 *
 * const params: DepositParams = {
 *   from: { adapter: evmAdapter, chain: 'Ethereum' },
 *   amount: '100',
 *   token: 'USDC',
 *   allowanceStrategy: 'permit',
 * }
 * ```
 */
interface DepositParams<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> {
    /**
     * The adapter context identifying the depositor and chain.
     */
    from: AdapterContext<TAdapterCapabilities, TChainIdentifier>;
    /**
     * The amount of tokens to deposit (human-readable decimal string).
     *
     * @example "100", "0.5"
     */
    amount: string;
    /**
     * The token to deposit.
     */
    token: SupportedToken;
    /**
     * The token allowance strategy to authorize the deposit.
     *
     * @defaultValue 'authorize'
     */
    allowanceStrategy?: AllowanceStrategy;
}
/**
 * Parameters for depositing tokens into *another* Gateway account.
 *
 * @remarks
 * Extends {@link DepositParams} with a `depositAccount` field that
 * specifies the Gateway account to credit instead of the caller's
 * own account.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { DepositForParams } from '@circle-fin/provider-gateway-v1'
 *
 * const params: DepositForParams = {
 *   from: { adapter: evmAdapter, chain: 'Ethereum' },
 *   amount: '100',
 *   token: 'USDC',
 *   depositAccount: '0x1234…abcd',
 * }
 * ```
 */
interface DepositForParams<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> extends Omit<DepositParams<TAdapterCapabilities, TChainIdentifier>, 'allowanceStrategy'> {
    /**
     * The Gateway account address to credit with the deposit.
     *
     * When provided the deposit is credited to this account rather
     * than the caller's own.
     */
    depositAccount: string;
}
/**
 * Result returned after a successful deposit operation.
 *
 * @example
 * ```typescript
 * import type { DepositResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: DepositResult = {
 *   amount: '100',
 *   token: 'USDC',
 *   depositedTo: '0xABCD…1234',
 *   depositedBy: '0x5678…EFGH',
 *   chain: 'Ethereum',
 *   txHash: '0xabcdef…',
 *   explorerUrl: 'https://etherscan.io/tx/0xabcdef…',
 * }
 * ```
 */
interface DepositResult {
    /** The deposited amount (human-readable decimal string). */
    amount: string;
    /** The token that was deposited. */
    token: SupportedToken;
    /** The Gateway account address credited by the deposit. */
    depositedTo: string;
    /** The address that signed and funded the deposit. */
    depositedBy: string;
    /** The chain on which the deposit occurred. */
    chain: Blockchain;
    /**
     * Unique identifier returned by the blockchain once the
     * transaction is mined.
     */
    txHash: string;
    /**
     * Link to view the transaction details on the appropriate
     * blockchain explorer.
     *
     * @remarks
     * May be `undefined` when the explorer URL cannot be resolved
     * for the chain.
     */
    explorerUrl?: string;
}

/**
 * Deposit USDC into a Gateway account on a specific chain.
 *
 * Supports three EVM allowance strategies (`approve`, `permit`, `authorize`)
 * and Solana (no separate approval needed).
 *
 * For the `approve` strategy the flow is: increaseAllowance → deposit.
 * If the deposit step fails, a best-effort `approve(gateway, 0)` is issued
 * to revoke the dangling allowance before re-throwing.
 *
 * @param params - Resolved deposit parameters from the kit layer.
 * @returns The deposit confirmation including tx hash and explorer URL.
 * @throws If the chain is unsupported or the transaction fails.
 */
declare function deposit<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: DepositParams<TAdapterCapabilities>): Promise<DepositResult>;
/**
 * Deposit USDC into another Gateway account (not the caller's).
 *
 * Only the `approve` allowance strategy is supported for depositFor.
 * Solana deposits do not require a separate approval step.
 *
 * @param params - Resolved depositFor parameters from the kit layer.
 * @returns The deposit confirmation including tx hash and explorer URL.
 * @throws If the chain is unsupported or the transaction fails.
 */
declare function depositFor<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: DepositForParams<TAdapterCapabilities>): Promise<DepositResult>;

/**
 * Data payload for a single step in a spend operation.
 *
 * @remarks
 * Each spend step carries its current state, optional transaction details,
 * and error information when the step fails.
 *
 * @example
 * ```typescript
 * import type { SpendStep } from '@circle-fin/provider-gateway-v1'
 *
 * const step: SpendStep = {
 *   name: 'mint',
 *   state: 'success',
 *   txHash: '0xabc…',
 *   explorerUrl: 'https://basescan.org/tx/0xabc…',
 * }
 * ```
 */
interface SpendStep {
    /** Human-readable name of the step (e.g., "buildBurnIntents", "mint"). */
    name: string;
    /** The state of the step. */
    state: 'pending' | 'success' | 'error';
    /** Optional transaction hash for this step (if applicable). */
    txHash?: string;
    /** Optional explorer URL for viewing this transaction on a block explorer. */
    explorerUrl?: string;
    /** Optional data for the step. */
    data?: unknown;
    /** Optional human-readable error message. */
    errorMessage?: string;
    /** Optional raw error object. */
    error?: unknown;
}
/**
 * Destination for a Gateway spend (mint) operation.
 *
 * @remarks
 * Omitting `recipientAddress` causes funds to be minted to the
 * address resolved from the adapter.  Providing it overrides the
 * default destination.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { SpendDestination } from '@circle-fin/provider-gateway-v1'
 *
 * const destination: SpendDestination = {
 *   adapter: avalancheAdapter,
 *   chain: 'Avalanche',
 *   recipientAddress: '0xDEST…abcd',
 * }
 * ```
 */
type SpendDestination<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> = {
    /** The adapter for executing on-chain calls. */
    adapter: Adapter<TAdapterCapabilities>;
    /** The destination chain. */
    chain: TChainIdentifier;
    /**
     * Optional custom recipient address.  When omitted the adapter's
     * resolved address is used.
     */
    recipientAddress?: string;
    /**
     * Enable Circle's Forwarding Service for automatic mint submission.
     * When `true`, the Gateway API handles the destination mint via its
     * relayer and the SDK polls for completion instead of executing a
     * user-signed mint transaction.
     */
    useForwarder?: boolean;
} & AddressField<ExtractAddressContext<TAdapterCapabilities>>;
/**
 * Forwarder-only destination for Gateway spend operations.
 *
 * Used when Circle's Forwarding Service handles the mint transaction
 * and no destination adapter is available. Set `useForwarder` to `true`
 * and provide a `recipientAddress`.
 *
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { ForwarderSpendDestination } from '@circle-fin/provider-gateway-v1'
 *
 * const destination: ForwarderSpendDestination = {
 *   chain: 'Base',
 *   recipientAddress: '0xDEST…abcd',
 *   useForwarder: true,
 * }
 * ```
 */
interface ForwarderSpendDestination<TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> {
    /** The destination chain where USDC will be minted. */
    chain: TChainIdentifier;
    /** The recipient address that will receive the minted USDC. */
    recipientAddress: string;
    /** Enable Circle's Forwarding Service for the destination mint. */
    useForwarder: boolean;
}
/**
 * Union of spend destination variants.
 *
 * @see {@link SpendDestination}
 * @see {@link ForwarderSpendDestination}
 */
type SpendDestinationUnion<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> = SpendDestination<TAdapterCapabilities, TChainIdentifier> | ForwarderSpendDestination<TChainIdentifier>;
/**
 * An amount of USDC to pull from a specific chain.
 *
 * @example
 * ```typescript
 * import type { Allocation } from '@circle-fin/provider-gateway-v1'
 *
 * const allocation: Allocation = {
 *   amount: '50',
 *   chain: 'Ethereum',
 * }
 * ```
 */
interface Allocation {
    /**
     * The amount to pull from this chain (human-readable decimal
     * string).
     */
    amount: string;
    /**
     * The chain from which to pull the funds.
     *
     * @remarks
     * All allocations in a single spend must be either all mainnet
     * or all testnet.  Mixing is not allowed.
     */
    chain: UnifiedBalanceChainIdentifier;
}
/**
 * Extends {@link Allocation} with the resolved source Gateway
 * account address.
 *
 * @example
 * ```typescript
 * import type { AllocationResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: AllocationResult = {
 *   amount: '50',
 *   chain: 'Ethereum',
 *   sourceAccount: '0x1234…5678',
 * }
 * ```
 */
interface AllocationResult extends Allocation {
    /** The Gateway account address from which this amount was pulled. */
    sourceAccount: string;
}
/**
 * A spend source providing an adapter and optional per-chain allocations.
 *
 * @remarks
 * When `allocations` is omitted the provider's automatic allocation
 * logic decides which chains to draw from.  The top-level `amountIn`
 * field on {@link SpendParams} is **required** in that case.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 *
 * @example
 * ```typescript
 * import type { SpendSource } from '@circle-fin/provider-gateway-v1'
 *
 * // With explicit allocations
 * const withAlloc: SpendSource = {
 *   adapter: evmAdapter,
 *   allocations: [
 *     { amount: '40', chain: 'Ethereum' },
 *     { amount: '60', chain: 'Base' },
 *   ],
 * }
 *
 * // Adapter-only (auto-allocation)
 * const adapterOnly: SpendSource = {
 *   adapter: evmAdapter,
 * }
 * ```
 */
type SpendSource<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> = {
    /** The adapter for executing on-chain calls. */
    adapter: Adapter<TAdapterCapabilities>;
    /**
     * Optional per-chain allocations describing how much to pull from
     * each chain.  When omitted the provider computes allocations
     * automatically using the `amountIn` field on {@link SpendParams}.
     */
    allocations?: Allocation | Allocation[];
    /**
     * Optional Gateway account to pull from (delegate scenarios).
     *
     * @remarks
     * When omitted the adapter's resolved address is used.  When
     * provided you must be a delegate for this account.
     */
    sourceAccount?: string;
} & AddressField<ExtractAddressContext<TAdapterCapabilities>>;
interface RetryMintConfig {
    attestation: string;
    signature: string;
}
interface SpendConfig {
    customFee?: {
        value: string;
        recipientAddress: string;
    };
    /**
     * When provided, skip estimate/sign/transfer and proceed directly to
     * the on-chain mint using a previously obtained attestation.
     *
     * @remarks
     * The `useForwarder` flag on the destination is ignored during retry
     * because the attestation was already issued — the Forwarding Service
     * is only involved in the initial transfer, not re-mints.
     */
    retry?: RetryMintConfig;
}
/**
 * Parameters for spending (minting) USDC on a destination chain from
 * one or more Gateway account sources.
 *
 * @remarks
 * `from` can be a single source or an array when pulling from
 * multiple adapters (e.g. an EVM account and a Solana account).
 *
 * @typeParam TFromAdapterCapabilities - Source adapter capabilities.
 * @typeParam TToAdapterCapabilities - Destination adapter capabilities.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { SpendParams } from '@circle-fin/provider-gateway-v1'
 *
 * const params: SpendParams = {
 *   from: {
 *     adapter: evmAdapter,
 *     allocations: { amount: '100', chain: 'Ethereum' },
 *   },
 *   to: { adapter: avalancheAdapter, chain: 'Avalanche' },
 *   token: 'USDC',
 * }
 * ```
 */
interface SpendParams<TFromAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TToAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> {
    /**
     * One or more sources to pull funds from.
     *
     * Optional when `config.retry` is provided (mint-only retry).
     */
    from?: SpendSource<TFromAdapterCapabilities> | SpendSource<TFromAdapterCapabilities>[];
    /** Where to mint the USDC on the destination chain. */
    to: SpendDestinationUnion<TToAdapterCapabilities, TChainIdentifier>;
    /** The token to spend.  Currently only USDC is supported. */
    token: SupportedToken;
    /**
     * Total USDC amount to spend (human-readable decimal string).
     *
     * Required when sources are adapter-only (no explicit allocations).
     * The provider resolves per-chain allocations at burn-intent
     * creation time.
     */
    amountIn?: string;
    config?: SpendConfig;
}
/**
 * Result returned after a successful spend (mint) operation.
 *
 * @example
 * ```typescript
 * import type { SpendResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: SpendResult = {
 *   allocations: [
 *     { amount: '100', chain: 'Ethereum', sourceAccount: '0x…' },
 *   ],
 *   recipientAddress: '0xDEST…abcd',
 *   destinationChain: 'Avalanche',
 *   txHash: '0xabcdef…',
 *   explorerUrl: 'https://snowtrace.io/tx/0xabcdef…',
 *   fees: [ { type: 'provider', token: 'USDC', amount: '0.001', allocations: [] }, ... ],
 * }
 * ```
 */
interface SpendResult {
    /**
     * Flattened list of allocations that were executed, each with its
     * source Gateway account. Only present for non-retry spends.
     */
    allocations?: AllocationResult[];
    /** The address that received the minted USDC. */
    recipientAddress: string;
    /** The destination chain on which the recipient received the USDC. */
    destinationChain: Blockchain;
    /**
     * Unique identifier returned by the blockchain once the
     * transaction is mined.
     */
    txHash: string;
    /**
     * Link to view the transaction details on the appropriate
     * blockchain explorer.
     *
     * @remarks
     * May be `undefined` when the explorer URL cannot be resolved
     * for the chain.
     */
    explorerUrl?: string;
    /**
     * Fee breakdown (provider, gasFee, optional kit, forwarder) for the
     * executed spend. Same shape as {@link EstimateSpendResult.fees}.
     * Omitted when using `config.retry` (no estimate was run).
     */
    fees?: FeeEntry[];
    /**
     * Gateway transfer identifier. Present when `useForwarder` is enabled
     * and can be used to query transfer status via `GET /v1/transfer/{id}`.
     */
    transferId?: string;
    /**
     * Block height after which the transfer attestation expires.
     * Returned by the Gateway transfer API.
     */
    expirationBlock?: string;
    /**
     * Ordered list of steps executed during the spend operation.
     *
     * @remarks
     * Each entry records the outcome of one phase of the spend flow.
     * For a normal spend the order is:
     * `buildBurnIntents` → `signBurnIntents` → `fetchAttestation` → `mint`.
     * For a retry spend only `mint` is present.
     */
    steps?: SpendStep[];
}
/**
 * Shape of a single intent as returned by the Gateway estimate API.
 *
 * Mirrors {@link TransferSpec} but uses plain strings for all address
 * and numeric fields because the JSON response has not yet been parsed
 * into `Hex` / `bigint` types.
 *
 * @example
 * ```typescript
 * import type { EstimatedIntentItem } from './types'
 *
 * const item: EstimatedIntentItem = {
 *   maxBlockHeight: '999999',
 *   maxFee: '1010000',
 *   spec: {
 *     version: 1,
 *     sourceDomain: 0,
 *     destinationDomain: 6,
 *     sourceContract: '0x00…',
 *     destinationContract: '0x00…',
 *     sourceToken: '0x00…',
 *     destinationToken: '0x00…',
 *     sourceDepositor: '0x00…',
 *     destinationRecipient: '0x00…',
 *     sourceSigner: '0x00…',
 *     destinationCaller: '0x00…',
 *     value: '1000000',
 *     salt: '0x00…',
 *   },
 * }
 * ```
 */
interface EstimatedIntentItem {
    /** Maximum block height until which this estimated intent is valid. */
    maxBlockHeight: string;
    /** Maximum fee in USDC atomic units (as a decimal string). */
    maxFee: string;
    /** Transfer specification with all fields as raw API strings. */
    spec: {
        version: number;
        sourceDomain: number;
        destinationDomain: number;
        sourceContract: string;
        destinationContract: string;
        sourceToken: string;
        destinationToken: string;
        sourceDepositor: string;
        destinationRecipient: string;
        sourceSigner: string;
        destinationCaller: string;
        value: string;
        salt: string;
    };
}
/**
 * Fee category describing the origin of a fee line item.
 *
 * - `'provider'`  — Fee charged by the cross-chain provider (e.g. protocol fee).
 * - `'gasFee'`    — On-chain gas cost denominated in the transfer token (e.g. USDC).
 * - `'kit'`       — Fee charged by the kit / developer integration.
 * - `'forwarder'` — Fee charged by Circle's Forwarding Service for automatic mint.
 */
type FeeType = 'provider' | 'gasFee' | 'kit' | 'forwarder';
/**
 * Per-chain breakdown of a fee amount.
 *
 * @example
 * ```typescript
 * import type { FeeAllocation } from '@circle-fin/provider-gateway-v1'
 *
 * const allocation: FeeAllocation = {
 *   chain: 'Ethereum',
 *   amount: '0.00005',
 * }
 * ```
 */
interface FeeAllocation {
    /** The chain to which this portion of the fee applies. */
    chain: Blockchain;
    /** The fee amount on this chain (human-readable decimal string). */
    amount: string;
}
/**
 * A single fee line item within an estimate.
 *
 * @remarks
 * Each entry describes a fee category (`type`), the token it is
 * denominated in, the aggregate `amount`, and an optional per-chain
 * `allocations` breakdown.
 *
 * @example
 * ```typescript
 * import type { FeeEntry } from '@circle-fin/provider-gateway-v1'
 *
 * // Fee with per-chain allocation breakdown
 * const providerFee: FeeEntry = {
 *   type: 'provider',
 *   token: 'USDC',
 *   amount: '0.00011',
 *   allocations: [
 *     { chain: 'Ethereum', amount: '0.00005' },
 *     { chain: 'Polygon', amount: '0.00006' },
 *   ],
 * }
 *
 * // Flat fee without allocations (e.g. forwarder)
 * const forwarderFee: FeeEntry = {
 *   type: 'forwarder',
 *   token: 'USDC',
 *   amount: '0.005',
 * }
 * ```
 */
interface FeeEntry {
    /** The category of this fee. */
    type: FeeType;
    /** The token in which this fee is denominated (e.g. `'USDC'`, `'ETH'`). */
    token: string;
    /** Aggregate fee amount (human-readable decimal string). */
    amount: string;
    /** Per-chain breakdown of the fee. Omitted for flat fees (e.g. forwarder). */
    allocations?: FeeAllocation[];
    /**
     * When `type === 'kit'`, the address that receives the kit fee.
     * Omitted for other fee types.
     */
    recipientAddress?: string;
}
/**
 * Cost estimation for a spend (mint) operation.
 *
 * @remarks
 * Returned by the provider's `estimateSpend` method to give callers
 * visibility into the expected fees *before* executing a spend.
 * Each entry in `fees` represents a distinct fee category with its
 * per-chain allocation breakdown.
 *
 * @example
 * ```typescript
 * import type { EstimateSpendResult } from '@circle-fin/provider-gateway-v1'
 *
 * const estimate: EstimateSpendResult = {
 *   fees: [
 *     {
 *       type: 'provider',
 *       token: 'USDC',
 *       amount: '0.00011',
 *       allocations: [
 *         { chain: 'Ethereum', amount: '0.00005' },
 *         { chain: 'Polygon', amount: '0.00006' },
 *       ],
 *     },
 *     {
 *       type: 'gasFee',
 *       token: 'USDC',
 *       amount: '0.0025',
 *       allocations: [
 *         { chain: 'Ethereum', amount: '0.0015' },
 *         { chain: 'Polygon', amount: '0.0010' },
 *       ],
 *     },
 *     {
 *       type: 'kit',
 *       token: 'USDC',
 *       amount: '0.05',
 *       allocations: [
 *         { chain: 'Ethereum', amount: '0.05' },
 *       ],
 *     },
 *   ],
 * }
 * ```
 */
interface EstimateSpendResult {
    /** Itemised fee breakdown for the spend operation. */
    fees: FeeEntry[];
}

/**
 * Execute a Gateway spend (mint): move USDC from source chain(s) to the destination chain.
 *
 * When `config.retry` is provided, skips estimate/sign/transfer and mints using the
 * supplied attestation and signature. Otherwise runs the full flow and mints on success.
 *
 * Step events are dispatched through the optional `dispatcher` as each phase completes:
 * `buildBurnIntents` → `signBurnIntents` → `transfer` → `mint` (normal path) or
 * `mint` only (retry path).
 *
 * @typeParam TFromAdapterCapabilities - Capabilities of the source adapter(s).
 * @typeParam TToAdapterCapabilities - Capabilities of the destination adapter.
 * @param params - Spend parameters: source(s), destination, token, optional custom fee and retry.
 * @param dispatcher - Optional action dispatcher for emitting spend step events.
 * @returns The spend result (allocations, recipient, destination chain, tx hash, explorer URL, steps).
 * @throws Error When `from` is missing and retry is not used.
 * @throws KitError (TRANSACTION_REVERTED, RESUMABLE) When the destination mint transaction fails.
 *   The attestation and signature are available in `error.cause.trace` for retry.
 *
 * @example
 * ```typescript
 * import { spend } from '@circle-fin/provider-gateway-v1'
 * const result = await spend({
 *   from: { adapter: evmAdapter, chain: 'Ethereum', allocations: [{ chain: 'Ethereum', amount: '100' }] },
 *   to: { adapter: baseAdapter, chain: 'Base' },
 *   token: 'USDC',
 * })
 * console.log(result.txHash, result.explorerUrl)
 * ```
 */
declare function spend<TFromAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TToAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: SpendParams<TFromAdapterCapabilities, TToAdapterCapabilities>, dispatcher?: Actionable<GatewayV1Actions> | null): Promise<SpendResult>;
/**
 * Estimate fees for a Gateway spend without executing it.
 *
 * Returns provider (transfer) fees, gas fees, and optional kit (custom) fee
 * with per-chain breakdown when applicable.
 *
 * @typeParam TFromAdapterCapabilities - Capabilities of the source adapter(s).
 * @typeParam TToAdapterCapabilities - Capabilities of the destination adapter.
 * @param params - Same shape as spend (from, to, token, optional config.customFee).
 * @returns Object with a `fees` array of {@link FeeEntry} (provider, gasFee, kit).
 *
 * @example
 * ```typescript
 * import { estimateSpend } from '@circle-fin/provider-gateway-v1'
 * const { fees } = await estimateSpend({
 *   from: { adapter, chain: 'Ethereum', allocations: [{ chain: 'Ethereum', amount: '100' }] },
 *   to: { adapter: baseAdapter, chain: 'Base' },
 *   token: 'USDC',
 * })
 * fees.forEach((f) => console.log(f.type, f.amount, f.allocations))
 * ```
 */
declare function estimateSpend<TFromAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TToAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: SpendParams<TFromAdapterCapabilities, TToAdapterCapabilities>): Promise<EstimateSpendResult>;

/**
 * Network type for balance queries when the target chain(s) are not
 * explicitly specified. Default is mainnet.
 */
type NetworkType = 'mainnet' | 'testnet';
/**
 * A single balance source identifying an account to query.
 *
 * Provide **at least one** of `adapter` or `address`:
 *
 * - **Address only** — pass `address` without `adapter` to query by
 *   raw Gateway account address.
 * - **Adapter (user-controlled)** — pass `adapter` without `address`;
 *   the wallet address is resolved automatically.
 * - **Adapter (developer-controlled)** — pass both `adapter` and
 *   `address`; the explicit address is required because there is no
 *   single connected wallet.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 *
 * @example
 * ```typescript
 * import type { BalanceSource } from '@circle-fin/provider-gateway-v1'
 *
 * // Address-only (no adapter needed)
 * const addrSource: BalanceSource = {
 *   address: '0x1234…abcd',
 *   chains: ['Ethereum', 'Base'],
 * }
 *
 * // Adapter (user-controlled wallet)
 * const adapterSource: BalanceSource = {
 *   adapter: evmAdapter,
 *   chains: 'Ethereum',
 * }
 *
 * // Adapter (developer-controlled) — address required
 * const devSource: BalanceSource = {
 *   adapter: circleWalletsAdapter,
 *   address: '0x1234…abcd',
 *   chains: ['Ethereum'],
 * }
 * ```
 */
interface BalanceSource<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> {
    /** The adapter whose resolved address is used to fetch balances. */
    adapter?: Adapter<TAdapterCapabilities>;
    /**
     * The account address to query balances for.
     *
     * - Required when no `adapter` is provided (address-only query).
     * - Required for developer-controlled adapters.
     * - Must be omitted for user-controlled adapters (auto-resolved).
     */
    address?: string;
    /**
     * Chains to fetch balances from.
     *
     * - If omitted, get balances from all supported chains.
     * - If provided, only get balances for the specified chain(s).
     */
    chains?: UnifiedBalanceChainIdentifier | UnifiedBalanceChainIdentifier[];
}
/**
 * Accept a single item or an array of items of the same type.
 *
 * @typeParam T - The element type.
 */
type OneOrMany<T> = T | T[];
/**
 * One or more balance sources, each of which may be a single object
 * or an array.
 */
type Sources = OneOrMany<BalanceSource>;
/**
 * Parameters for the balances and pending-deposits API requests.
 *
 * Specify the `token` to query and one or more `sources` identifying
 * the accounts or adapters whose balances should be retrieved.
 * When `includePending` is true, the result includes pending balances
 * and pending transaction details per chain.
 *
 * @example
 * ```typescript
 * import type { GetBalancesParams } from '@circle-fin/provider-gateway-v1'
 *
 * // Single adapter source
 * const params1: GetBalancesParams = {
 *   token: 'USDC',
 *   sources: { adapter: evmAdapter },
 * }
 *
 * // Single address source with pending
 * const params2: GetBalancesParams = {
 *   token: 'USDC',
 *   sources: { address: '0x1234…abcd', chains: 'Ethereum' },
 *   includePending: true,
 * }
 *
 * // Multiple address sources
 * const params3: GetBalancesParams = {
 *   token: 'USDC',
 *   sources: [
 *     { address: '0x8f3Cf7…', chains: ['ChainA', 'ChainB'] },
 *     { address: '0x4B0897…', chains: ['ChainB', 'ChainC'] },
 *   ],
 * }
 *
 * // Adapter only (confirmed balances only; includePending defaults to false)
 * const params4: GetBalancesParams = {
 *   token: 'USDC',
 *   sources: { adapter: evmAdapter },
 * }
 * ```
 */
interface GetBalancesParams {
    /**
     * The token to query balances for.
     */
    token: SupportedToken;
    /**
     * One or more sources identifying the accounts or adapters to
     * query.  Accepts a single object or an array.
     */
    sources: Sources;
    /**
     * When true, the result includes pending balances.
     * When false or omitted, only confirmed balances
     * are returned.
     *
     * @defaultValue false
     */
    includePending?: boolean;
    /**
     * Network to use when no chains are specified on a source.
     * When omitted, mainnet is used when chains cannot be derived.
     *
     * @defaultValue 'mainnet'
     */
    networkType?: NetworkType;
}
/**
 * A single balance entry in a balances result.
 *
 * @example
 * ```typescript
 * import type { ConfirmedBalanceEntry } from '@circle-fin/provider-gateway-v1'
 *
 * const entry: ConfirmedBalanceEntry = {
 *   chain: 'Ethereum',
 *   depositor: '0x1234…abcd',
 *   balance: '125.50',
 * }
 * ```
 */
interface ConfirmedBalanceEntry {
    /** The chain on which this balance resides. */
    chain: Blockchain;
    /** Gateway account (depositor) address. */
    depositor: string;
    /** Balance amount (human-readable decimal string). */
    balance: string;
}
/**
 * A pending transaction included in {@link GetBalancesResult}
 * when `includePending` is true.
 *
 * @example
 * ```typescript
 * import type { PendingBalanceTransaction } from '@circle-fin/provider-gateway-v1'
 *
 * const tx: PendingBalanceTransaction = {
 *   transactionHash: '0x2c5f3e4a…',
 *   amount: '50.00',
 *   blockTimestamp: '2023-11-07T05:31:56Z',
 * }
 * ```
 */
interface PendingBalanceTransaction {
    /** Transaction hash of the pending deposit. */
    transactionHash: string;
    /** Pending amount (human-readable decimal string). */
    amount: string;
    /** ISO 8601 timestamp of the block. */
    blockTimestamp: string;
}
/**
 * Per-chain balance within a breakdown in {@link GetBalancesResult}.
 *
 * When `includePending` is true, `pendingBalance` and `pendingTransactions`
 * are present.
 *
 * @example
 * ```typescript
 * import type { ChainBalanceBreakdown } from '@circle-fin/provider-gateway-v1'
 *
 * // Confirmed only (includePending: false)
 * const chain: ChainBalanceBreakdown = {
 *   chain: 'Arbitrum',
 *   confirmedBalance: '1500.00',
 * }
 *
 * // With pending (includePending: true)
 * const chainWithPending: ChainBalanceBreakdown = {
 *   chain: 'Ethereum',
 *   confirmedBalance: '1000.00',
 *   pendingBalance: '50.00',
 *   pendingTransactions: [
 *     { transactionHash: '0x2c5f3e…', amount: '50.00', blockTimestamp: '2023-11-07T05:31:56Z' },
 *   ],
 * }
 * ```
 */
interface ChainBalanceBreakdown {
    /** The chain. */
    chain: Blockchain;
    /** Confirmed balance (human-readable decimal string). */
    confirmedBalance: string;
    /**
     * Pending balance on this chain.
     * Present only when {@link GetBalancesParams.includePending} is true.
     */
    pendingBalance?: string;
    /**
     * Pending deposit transactions on this chain.
     * Present only when {@link GetBalancesParams.includePending} is true.
     */
    pendingTransactions?: PendingBalanceTransaction[];
}
/**
 * Per-account balance breakdown used in {@link GetBalancesResult}.
 *
 * When `includePending` is true, `totalPending` is present and each chain
 * entry may include `pendingBalance` and `pendingTransactions`.
 *
 * @example
 * ```typescript
 * import type { BalanceWithPendingBreakdown } from '@circle-fin/provider-gateway-v1'
 *
 * const entry: BalanceWithPendingBreakdown = {
 *   depositor: '0x71C765…',
 *   totalConfirmed: '1000.00',
 *   totalPending: '50.00',
 *   breakdown: [
 *     { chain: 'Ethereum', confirmedBalance: '1000.00', pendingBalance: '50.00', pendingTransactions: [...] },
 *   ],
 * }
 * ```
 */
interface BalanceWithPendingBreakdown {
    /** Gateway account (depositor) address. */
    depositor: string;
    /** Total confirmed balance across chains (human-readable decimal string). */
    totalConfirmed: string;
    /**
     * Total pending balance across chains.
     * Present only when `includePending` is true.
     */
    totalPending?: string;
    /** Per-chain breakdown for this depositor. */
    breakdown: ChainBalanceBreakdown[];
}
/**
 * Result returned from {@link IGatewayProvider.getBalances} (combined confirmed and pending).
 *
 * When `includePending` is false (default), only `totalConfirmedBalance` and
 * `breakdown` with confirmed fields are returned. When `includePending` is true,
 * `totalPendingBalance` is present and breakdown entries include pending amounts
 * and `pendingTransactions` per chain.
 *
 * @example
 * ```typescript
 * import type { GetBalancesResult } from '@circle-fin/provider-gateway-v1'
 *
 * // includePending: false
 * const result: GetBalancesResult = {
 *   token: 'USDC',
 *   totalConfirmedBalance: '3500.00',
 *   breakdown: [
 *     {
 *       depositor: '0xAAAd67…',
 *       totalConfirmed: '2500.00',
 *       breakdown: [
 *         { chain: 'Arbitrum', confirmedBalance: '1500.00' },
 *         { chain: 'Optimism', confirmedBalance: '1000.00' },
 *       ],
 *     },
 *   ],
 * }
 *
 * // includePending: true
 * const resultWithPending: GetBalancesResult = {
 *   token: 'USDC',
 *   totalConfirmedBalance: '3500.00',
 *   totalPendingBalance: '650.00',
 *   breakdown: [
 *     {
 *       depositor: '0x71C765…',
 *       totalConfirmed: '1000.00',
 *       totalPending: '50.00',
 *       breakdown: [
 *         {
 *           chain: 'Ethereum',
 *           confirmedBalance: '1000.00',
 *           pendingBalance: '50.00',
 *           pendingTransactions: [
 *             { transactionHash: '0x2c5f3e…', amount: '50.00', blockTimestamp: '2023-11-07T05:31:56Z' },
 *           ],
 *         },
 *       ],
 *     },
 *   ],
 * }
 * ```
 */
interface GetBalancesResult {
    /** Token that was queried. */
    token: SupportedToken;
    /** Total confirmed balance across all accounts and chains (human-readable decimal string). */
    totalConfirmedBalance: string;
    /**
     * Total pending balance across all accounts and chains.
     * Present only when `includePending` is true.
     */
    totalPendingBalance?: string;
    /** Per-account, per-chain breakdown. */
    breakdown: BalanceWithPendingBreakdown[];
}
/**
 * Confirmed deposits result (flat per-chain, per-depositor list).
 *
 * Flat list of per-chain, per-depositor confirmed balances.
 *
 * @example
 * ```typescript
 * import type { GetConfirmedDepositsResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: GetConfirmedDepositsResult = {
 *   token: 'USDC',
 *   balances: [
 *     { chain: 'Ethereum', depositor: '0x…', balance: '1000.00' },
 *     { chain: 'Base', depositor: '0x…', balance: '200.00' },
 *   ],
 * }
 * ```
 */
interface GetConfirmedDepositsResult {
    /** Token that was queried. */
    token: SupportedToken;
    /** Per-chain, per-depositor confirmed balances. */
    balances: ConfirmedBalanceEntry[];
}
/**
 * Raw response shape from the Gateway API pending-deposits endpoint (POST /v1/deposits).
 * @internal
 */
interface GatewayDepositsResponse {
    token: string;
    /** Pending deposit entries (not yet confirmed). */
    deposits: {
        depositor: string;
        domain: number;
        transactionHash: string;
        amount: string;
        status: string;
        blockHeight: string;
        blockHash: string;
        blockTimestamp: string;
    }[];
}
/**
 * A single pending deposit entry.
 *
 * @example
 * ```typescript
 * import type { PendingDeposit } from '@circle-fin/provider-gateway-v1'
 *
 * const deposit: PendingDeposit = {
 *   depositor: '0x1234…abcd',
 *   chain: 'Ethereum',
 *   transactionHash: '0x2c5f3e4a…',
 *   amount: '100',
 *   status: 'pending',
 *   blockHeight: '15000000',
 *   blockHash: '0x1dcc4de8…',
 *   blockTimestamp: '2023-11-07T05:31:56Z',
 * }
 * ```
 */
interface PendingDeposit {
    /** Gateway account (depositor) address. */
    depositor: string;
    /** Chain on which the deposit is pending. */
    chain: Blockchain;
    /** Transaction hash of the deposit. */
    transactionHash: string;
    /** Pending amount (human-readable decimal string). */
    amount: string;
    /**
     * Status string from the Gateway API.
     *
     * @remarks
     * The API does not guarantee a fixed enumeration; values may include
     * `pending`, `confirmed`, and other labels as the service evolves.
     */
    status: string;
    /** Block height at which the deposit was observed. */
    blockHeight: string;
    /** Hash of the block containing the deposit. */
    blockHash: string;
    /** ISO 8601 timestamp of the block. */
    blockTimestamp: string;
}
/**
 * Result returned from the pending deposits API.
 *
 * @example
 * ```typescript
 * import type { GetPendingDepositsResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: GetPendingDepositsResult = {
 *   token: 'USDC',
 *   deposits: [
 *     {
 *       depositor: '0x…',
 *       chain: 'Ethereum',
 *       transactionHash: '0x…',
 *       amount: '100',
 *       status: 'pending',
 *       blockHeight: '15000000',
 *       blockHash: '0x…',
 *       blockTimestamp: '2023-11-07T05:31:56Z',
 *     },
 *   ],
 * }
 * ```
 */
interface GetPendingDepositsResult {
    /** Token that was queried. */
    token: SupportedToken;
    /** List of pending deposits for the queried sources. */
    deposits: PendingDeposit[];
}
/**
 * Raw Gateway API response structure for balance queries.
 *
 * @remarks
 * This is the direct response from the Gateway API `/v1/balances` endpoint.
 * It should be transformed into appropriate result types for consumer use.
 *
 * @internal
 */
interface GatewayBalancesResponse {
    /**
     * The token type.
     */
    token: SupportedToken;
    /**
     * Array of balance entries from the API.
     */
    balances: {
        /**
         * The Gateway domain ID.
         */
        domain: number;
        /**
         * The depositor address.
         */
        depositor: string;
        /**
         * The available balance in human-readable decimal format.
         */
        balance: string;
    }[];
}

/**
 * Fetch combined confirmed and pending balances for one or more accounts.
 *
 * Sources are normalized once upfront and shared between the confirmed
 * and pending API calls to avoid redundant async adapter resolution.
 *
 * @param params - Balance query parameters. Provide either an adapter
 *   (address resolved automatically) or a raw account address.
 *   Optionally narrow by chain(s). Set `includePending: true` to
 *   include pending balances and transaction details in the result.
 * @param config - Optional custom retry configuration.
 * @returns Promise resolving to totalConfirmedBalance, optional
 *   totalPendingBalance, and per-depositor per-chain breakdown.
 * @throws KitError When chains do not support Gateway.
 * @throws KitError When an API request fails after retries.
 * @throws KitError When response validation fails.
 *
 * @example
 * ```typescript
 * // Confirmed only
 * const result = await getBalances({
 *   token: 'USDC',
 *   sources: { account: '0x1234…' },
 * })
 *
 * // With pending
 * const result = await getBalances({
 *   token: 'USDC',
 *   sources: { account: '0x1234…', chains: ['Ethereum'] },
 *   includePending: true,
 * })
 * ```
 */
declare function getBalances(params: GetBalancesParams, config?: Partial<ApiPollingConfig>): Promise<GetBalancesResult>;

/**
 * Parameters for adding or removing a delegate on a Gateway account.
 *
 * @remarks
 * Delegation allows a different signer to move funds out of the
 * owner's account.  The delegate must be added explicitly per chain.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { UpdateDelegateParams } from '@circle-fin/provider-gateway-v1'
 *
 * const params: UpdateDelegateParams = {
 *   from: { adapter: evmAdapter, chain: 'Ethereum' },
 *   delegateAddress: '0xDELEGATE…1111',
 *   token: 'USDC',
 * }
 * ```
 */
interface UpdateDelegateParams<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> {
    /**
     * The owner's adapter context containing the adapter, chain, and
     * account address to which the delegate will be authorized.
     */
    from: AdapterContext<TAdapterCapabilities, TChainIdentifier>;
    /**
     * The address being added or removed as an authorized delegate.
     */
    delegateAddress: string;
    /** The token for which delegation applies. */
    token: SupportedToken;
}
/**
 * Result returned after a successful add or remove delegate
 * operation.
 *
 * @example
 * ```typescript
 * import type { UpdateDelegateResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: UpdateDelegateResult = {
 *   account: '0xOWNER…1234',
 *   delegateAddress: '0xDELEGATE…1111',
 *   chain: 'Ethereum',
 *   state: 'added',
 *   txHash: '0xabc…',
 *   explorerUrl: 'https://etherscan.io/tx/0xabc…',
 * }
 * ```
 */
interface UpdateDelegateResult {
    /** The Gateway account that was modified. */
    account: string;
    /** The delegate address that was added or removed. */
    delegateAddress: string;
    /**
     * The chain on which the delegate was updated.
     *
     * @remarks
     * Delegates must be added explicitly per chain.  You cannot
     * authorize a delegate for all chains at once.
     */
    chain: Blockchain;
    /** Whether the delegate was added or removed. */
    state: 'added' | 'removed';
    /**
     * Unique identifier returned by the blockchain once the
     * transaction is mined.
     */
    txHash: string;
    /**
     * Link to view the transaction details on the appropriate
     * blockchain explorer.
     *
     * @remarks
     * May be `undefined` when the explorer URL cannot be resolved
     * for the chain.
     */
    explorerUrl?: string;
}
/**
 * The finality-aware status of a delegate on a Gateway account.
 *
 * - `'none'`    — not a delegate on-chain.
 * - `'pending'` — delegate set on-chain but Gateway hasn't finalized it yet;
 *                 spend will fail until the status advances to `'ready'`.
 * - `'ready'`   — finalized at Gateway; spend will succeed.
 */
type DelegateStatus = 'none' | 'pending' | 'ready';
/**
 * Parameters for checking the delegate status of an address on a
 * Gateway account.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { GetDelegateStatusParams } from '@circle-fin/provider-gateway-v1'
 *
 * const params: GetDelegateStatusParams = {
 *   from: { adapter: evmAdapter, chain: 'Ethereum' },
 *   delegateAddress: '0xDELEGATE…1111',
 *   token: 'USDC',
 * }
 * ```
 */
interface GetDelegateStatusParams<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> {
    /** The adapter context identifying the account owner and chain. */
    from: AdapterContext<TAdapterCapabilities, TChainIdentifier>;
    /** The address to check for delegate status. */
    delegateAddress: string;
    /** The token for which delegation is checked. */
    token: SupportedToken;
}

/**
 * Grant spending rights to another address on the owner's Gateway account.
 *
 * Calls `addDelegate(token, delegate)` on the Gateway Wallet contract (EVM)
 * or the `add_delegate` instruction (Solana).
 *
 * @param params - The owner's adapter context (`from`), delegate address, and token.
 * @returns Promise resolving to the delegate update result.
 * @throws KitError on self-delegation or if the chain is unsupported.
 *
 * @example
 * ```typescript
 * import { addDelegate } from '@circle-fin/provider-gateway-v1'
 * import type { UpdateDelegateParams } from '@circle-fin/provider-gateway-v1'
 *
 * declare const params: UpdateDelegateParams
 * const result = await addDelegate(params)
 * // result.state === 'added'
 * ```
 */
declare function addDelegate<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: UpdateDelegateParams<TAdapterCapabilities>): Promise<UpdateDelegateResult>;
/**
 * Revoke spending rights from a delegate on the owner's Gateway account.
 *
 * Calls `removeDelegate(token, delegate)` on the Gateway Wallet contract (EVM)
 * or the `remove_delegate` instruction (Solana).
 *
 * @param params - The owner's adapter context (`from`), delegate address, and token.
 * @returns Promise resolving to the delegate update result.
 * @throws KitError on self-delegation or if the chain is unsupported.
 *
 * @example
 * ```typescript
 * import { removeDelegate } from '@circle-fin/provider-gateway-v1'
 * import type { UpdateDelegateParams } from '@circle-fin/provider-gateway-v1'
 *
 * declare const params: UpdateDelegateParams
 * const result = await removeDelegate(params)
 * // result.state === 'removed'
 * ```
 */
declare function removeDelegate<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: UpdateDelegateParams<TAdapterCapabilities>): Promise<UpdateDelegateResult>;
/**
 * Check the finality-aware status of a delegate on a Gateway account.
 *
 * Uses a two-step optimization:
 * 1. Read `isAuthorizedForBalance` at the latest block (cheap, no HTTP).
 *    If `false`, return `'none'` immediately.
 * 2. Only when the latest read is `true`, fetch Gateway's `processedHeight`
 *    via `/v1/info` and re-read at that block. If the re-read returns `true`,
 *    the delegate is `'ready'` (finalized); otherwise it is `'pending'`.
 *
 * @param params - The adapter context (`from`), delegate address, and token.
 * @returns Promise resolving to `'none'`, `'pending'`, or `'ready'`.
 * @throws KitError if the chain is unsupported or `/v1/info` fails.
 *
 * @remarks
 * If the Gateway `/v1/info` endpoint is unreachable or returns an error,
 * the function throws rather than degrading to `'pending'`. This is
 * intentional: a transient Gateway outage means the finality state is
 * unknown, and silently returning `'pending'` could mask an infrastructure
 * issue. Callers should handle the error and retry as appropriate.
 *
 * @example
 * ```typescript
 * import { getDelegateStatus } from '@circle-fin/provider-gateway-v1'
 * import type { GetDelegateStatusParams } from '@circle-fin/provider-gateway-v1'
 *
 * declare const params: GetDelegateStatusParams
 * const status = await getDelegateStatus(params)
 * if (status === 'ready') { // safe to spend }
 * ```
 */
declare function getDelegateStatus<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: GetDelegateStatusParams<TAdapterCapabilities>): Promise<DelegateStatus>;

/**
 * Parameters for initiating a delayed fund removal from a Gateway
 * account.
 *
 * @remarks
 * Fund removals have a mandatory 7-day delay before they can be
 * completed.  Only one removal may be pending per chain at a
 * time.  Initiating a second removal on the same chain adds the
 * requested amount to the existing pending removal and restarts
 * the 7-day timer.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { InitiateRemoveFundParams } from '@circle-fin/provider-gateway-v1'
 *
 * const params: InitiateRemoveFundParams = {
 *   from: { adapter: evmAdapter, chain: 'Ethereum' },
 *   amount: '100',
 *   token: 'USDC',
 * }
 * ```
 */
interface InitiateRemoveFundParams<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> {
    /**
     * The account owner's adapter context containing the adapter,
     * chain, and address.
     */
    from: AdapterContext<TAdapterCapabilities, TChainIdentifier>;
    /** The amount to remove (human-readable decimal string). */
    amount: string;
    /** The token to remove. */
    token: SupportedToken;
}
/**
 * Result returned after successfully initiating a fund removal.
 *
 * @example
 * ```typescript
 * import type { InitiateRemoveFundResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: InitiateRemoveFundResult = {
 *   amount: '100',
 *   token: 'USDC',
 *   account: '0xOWNER…1234',
 *   chain: 'Ethereum',
 *   withdrawingBalance: '100',
 *   withdrawalBlock: 19_500_000,
 *   txHash: '0xabc…',
 *   explorerUrl: 'https://etherscan.io/tx/0xabc…',
 * }
 * ```
 */
interface InitiateRemoveFundResult {
    /** The amount requested for removal. */
    amount: string;
    /** The token type. */
    token: SupportedToken;
    /** The Gateway account from which this removal will occur. */
    account: string;
    /** The chain on which this removal was initiated. */
    chain: Blockchain;
    /** The balance currently in the withdrawing state for this account. */
    withdrawingBalance: string;
    /** The block number at which the removal can be completed. */
    withdrawalBlock: number;
    /**
     * Unique identifier returned by the blockchain once the
     * transaction is mined.
     */
    txHash: string;
    /**
     * Link to view the transaction details on the appropriate
     * blockchain explorer.
     *
     * @remarks
     * May be `undefined` when the explorer URL cannot be resolved
     * for the chain.
     */
    explorerUrl?: string;
}
/**
 * Parameters for completing a fund removal after the 7-day activation
 * period.
 *
 * @typeParam TAdapterCapabilities - Adapter capability constraints.
 * @typeParam TChainIdentifier - Accepted chain identifier type.
 *
 * @example
 * ```typescript
 * import type { RemoveFundParams } from '@circle-fin/provider-gateway-v1'
 *
 * const params: RemoveFundParams = {
 *   from: { adapter: evmAdapter, chain: 'Ethereum' },
 *   token: 'USDC',
 * }
 * ```
 */
interface RemoveFundParams<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TChainIdentifier extends UnifiedBalanceChainIdentifier = UnifiedBalanceChainIdentifier> {
    /**
     * The account owner's adapter context.  Must match the context
     * used when initiating the fund removal.
     */
    from: AdapterContext<TAdapterCapabilities, TChainIdentifier>;
    /** The token to remove. */
    token: SupportedToken;
}
/**
 * Result returned after successfully completing a fund removal.
 *
 * @example
 * ```typescript
 * import type { RemoveFundResult } from '@circle-fin/provider-gateway-v1'
 *
 * const result: RemoveFundResult = {
 *   amount: '100',
 *   token: 'USDC',
 *   account: '0xOWNER…1234',
 *   chain: 'Ethereum',
 *   txHash: '0xdef…',
 *   explorerUrl: 'https://etherscan.io/tx/0xdef…',
 * }
 * ```
 */
interface RemoveFundResult {
    /** The final removed amount. */
    amount: string;
    /** The token type. */
    token: SupportedToken;
    /** The Gateway account from which the tokens were removed. */
    account: string;
    /** The chain on which the removal occurred. */
    chain: Blockchain;
    /**
     * Unique identifier returned by the blockchain once the
     * transaction is mined.
     */
    txHash: string;
    /**
     * Link to view the transaction details on the appropriate
     * blockchain explorer.
     *
     * @remarks
     * May be `undefined` when the explorer URL cannot be resolved
     * for the chain.
     */
    explorerUrl?: string;
}

/**
 * Start a delayed fund removal from a Gateway account.
 *
 * Dispatches `initiateWithdrawal` via the adapter action registry. A
 * mandatory withdrawal delay must elapse before {@link removeFund} can
 * complete the removal.
 *
 * @param params - The account owner's adapter context (`from`), amount, and token.
 * @returns Promise resolving to the initiation details including the
 *   `withdrawalBlock` at which {@link removeFund} may be called.
 * @throws If the chain does not support Gateway v1 or the transaction fails.
 */
declare function initiateRemoveFund<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: InitiateRemoveFundParams<TAdapterCapabilities>): Promise<InitiateRemoveFundResult>;
/**
 * Complete a fund removal after the withdrawal delay has elapsed.
 *
 * Dispatches `withdraw` via the adapter action registry. The full pending
 * withdrawal balance is returned to the caller — no `amount` is required.
 *
 * @param params - The account owner's adapter context (`from`) and token.
 * @returns Promise resolving to the removal details including the final
 *   removed `amount` and txHash.
 * @throws If the chain does not support Gateway v1 or the transaction fails.
 *
 * @see initiateRemoveFund to start the process.
 */
declare function removeFund<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: RemoveFundParams<TAdapterCapabilities>): Promise<RemoveFundResult>;

/**
 * Return all chains supported by the provider for the given token.
 *
 * Uses static chain definitions filtered by {@link isGatewayV1Supported}.
 * No network calls are made.
 *
 * @param token - Optional token filter. Only tokens listed in
 *   {@link SUPPORTED_TOKENS} are accepted; any other value returns an
 *   empty array.
 * @returns Array of supported chain definitions.
 */
declare function getSupportedChains(token?: SupportedToken): ChainDefinition[];

/**
 * Standard tags attached to every gateway lifecycle event.
 */
interface GatewayEventTags {
    /** Operation name (e.g. 'deposit', 'spend'). */
    opName: string;
    /** Chain identifier relevant to the operation. */
    chain: string;
}
/**
 * Base payload structure shared by all gateway lifecycle events.
 *
 * @typeParam TData - Operation-specific data carried in the event.
 */
interface GatewayEventPayload<TData = unknown> {
    /** The provider protocol that emitted this event. */
    protocol: 'gateway';
    /** The provider version. */
    version: 'v1';
    /** Contextual tags for filtering/categorization. */
    tags: GatewayEventTags;
    /** Operation-specific data associated with the event. */
    data: TData;
}
interface DepositStartedData {
    amount: string;
    token: SupportedToken;
}
interface DepositForStartedData {
    amount: string;
    token: SupportedToken;
    depositAccount: string;
}
interface SpendStartedData {
    destinationChain: string;
    token: SupportedToken;
}
interface GetBalancesStartedData {
    token: SupportedToken;
}
interface DelegateStartedData {
    delegateAddress: string;
}
interface InitiateRemoveFundStartedData {
    amount: string;
    token: SupportedToken;
}
interface RemoveFundStartedData {
    token: SupportedToken;
}
type GatewayFailedData = ErrorInfo;
/**
 * Complete action map for gateway lifecycle events.
 *
 * Each key follows the `gateway.{operation}.{stage}` naming convention
 * where stage is `started`, `succeeded`, or `failed`.
 *
 * @example
 * ```typescript
 * const kit = new UnifiedBalanceKit()
 *
 * kit.on('gateway.deposit.started', (payload) => {
 *   console.log(payload.data.amount, payload.data.token)
 * })
 *
 * kit.on('gateway.spend.succeeded', (payload) => {
 *   console.log(payload.data.txHash)
 * })
 * ```
 */
interface GatewayV1Actions {
    'gateway.deposit.started': GatewayEventPayload<DepositStartedData>;
    'gateway.deposit.succeeded': GatewayEventPayload<DepositResult>;
    'gateway.deposit.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.depositFor.started': GatewayEventPayload<DepositForStartedData>;
    'gateway.depositFor.succeeded': GatewayEventPayload<DepositResult>;
    'gateway.depositFor.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.spend.started': GatewayEventPayload<SpendStartedData>;
    'gateway.spend.succeeded': GatewayEventPayload<SpendResult>;
    'gateway.spend.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.spend.step.buildBurnIntents': GatewayEventPayload<SpendStep>;
    'gateway.spend.step.signBurnIntents': GatewayEventPayload<SpendStep>;
    'gateway.spend.step.fetchAttestation': GatewayEventPayload<SpendStep>;
    'gateway.spend.step.mint': GatewayEventPayload<SpendStep>;
    'gateway.estimateSpend.started': GatewayEventPayload<SpendStartedData>;
    'gateway.estimateSpend.succeeded': GatewayEventPayload<EstimateSpendResult>;
    'gateway.estimateSpend.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.getBalances.started': GatewayEventPayload<GetBalancesStartedData>;
    'gateway.getBalances.succeeded': GatewayEventPayload<GetBalancesResult>;
    'gateway.getBalances.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.addDelegate.started': GatewayEventPayload<DelegateStartedData>;
    'gateway.addDelegate.succeeded': GatewayEventPayload<UpdateDelegateResult>;
    'gateway.addDelegate.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.removeDelegate.started': GatewayEventPayload<DelegateStartedData>;
    'gateway.removeDelegate.succeeded': GatewayEventPayload<UpdateDelegateResult>;
    'gateway.removeDelegate.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.initiateRemoveFund.started': GatewayEventPayload<InitiateRemoveFundStartedData>;
    'gateway.initiateRemoveFund.succeeded': GatewayEventPayload<InitiateRemoveFundResult>;
    'gateway.initiateRemoveFund.failed': GatewayEventPayload<GatewayFailedData>;
    'gateway.removeFund.started': GatewayEventPayload<RemoveFundStartedData>;
    'gateway.removeFund.succeeded': GatewayEventPayload<RemoveFundResult>;
    'gateway.removeFund.failed': GatewayEventPayload<GatewayFailedData>;
}
/** Union of all gateway action names. */
type GatewayActionName = keyof GatewayV1Actions;
/**
 * Interface for a Gateway provider that supports cross-chain USDC
 * operations via Circle Gateway.
 *
 * @remarks
 * Implementations of this interface provide the core primitives for
 * deposit, spend, balance queries, delegation management, and
 * fund removals.  The Gateway v1 provider ships as the default
 * implementation, but the interface is designed for extensibility so
 * that third-party or future providers can be swapped in with zero
 * application-level code changes.
 *
 * @example
 * ```typescript
 * import type { IGatewayProvider } from '@circle-fin/provider-gateway-v1'
 *
 * function useProvider(provider: IGatewayProvider): void {
 *   const chains = provider.getSupportedChains()
 *   console.log('Supported chains:', chains.map(c => c.name))
 * }
 * ```
 */
interface IGatewayProvider<TProviderActions = GatewayV1Actions> {
    /** Human-readable name of this provider. */
    readonly name: string;
    /**
     * Type-level phantom field for TypeScript inference when merging
     * actions across providers. Never read at runtime.
     */
    readonly actions?: TProviderActions;
    /**
     * The action dispatcher for gateway lifecycle events.
     *
     * Set via {@link IGatewayProvider.registerDispatcher | registerDispatcher}.
     * When present, operations emit `gateway.{operation}.{started|succeeded|failed}`
     * events through this dispatcher.
     */
    actionDispatcher?: Actionable<TProviderActions> | null;
    /**
     * Register an event dispatcher for gateway lifecycle events.
     *
     * @param dispatcher - The `Actionable` instance to dispatch events through.
     *
     * @example
     * ```typescript
     * import { Actionable } from '@core/utils'
     * import { createGatewayV1Provider, type GatewayV1Actions } from '@circle-fin/provider-gateway-v1'
     *
     * const provider = createGatewayV1Provider()
     * const dispatcher = new Actionable<GatewayV1Actions>()
     * provider.registerDispatcher(dispatcher)
     * ```
     */
    registerDispatcher(dispatcher: Actionable<TProviderActions>): void;
    /**
     * Deposit USDC into a Gateway account on a specific chain.
     *
     * @param params - The deposit details including the depositor's
     *   adapter context (`from`), amount, and token.
     * @returns Promise resolving to the deposit confirmation.
     *
     * @example
     * ```typescript
     * const result = await provider.deposit({
     *   from: { adapter, chain: 'Ethereum' },
     *   amount: '100',
     * })
     * console.log('Deposited to:', result.depositedTo)
     * ```
     */
    deposit<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: DepositParams<TAdapterCapabilities>): Promise<DepositResult>;
    /**
     * Deposit USDC into another Gateway account (not the caller's).
     *
     * @param params - The deposit details including the depositor's
     *   adapter context (`from`), amount, and the Gateway account
     *   address to credit.
     * @returns Promise resolving to the deposit confirmation.
     *
     * @example
     * ```typescript
     * const result = await provider.depositFor({
     *   from: { adapter, chain: 'Ethereum' },
     *   amount: '100',
     *   depositAccount: '0x1234…abcd',
     * })
     * console.log('Deposited to:', result.depositedTo)
     * ```
     */
    depositFor<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: DepositForParams<TAdapterCapabilities>): Promise<DepositResult>;
    /**
     * Spend (mint) USDC on a destination chain by pulling funds from
     * one or more Gateway account sources.
     *
     * @param params - The spend details including source(s),
     *   destination, and token.
     * @returns Promise resolving to the spend confirmation.
     *
     * @example
     * ```typescript
     * const result = await provider.spend({
     *   from: {
     *     adapter,
     *     allocations: { amount: '100', chain: 'Ethereum' },
     *   },
     *   to: { adapter, chain: 'Avalanche' },
     *   token: 'USDC',
     * })
     * console.log('Minted on:', result.destinationChain)
     * ```
     */
    spend<TFromAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TToAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: SpendParams<TFromAdapterCapabilities, TToAdapterCapabilities>): Promise<SpendResult>;
    /**
     * Estimate the fees for a spend operation without executing it.
     *
     * @param params - The same spend parameters used in
     *   {@link IGatewayProvider.spend}.
     * @returns Promise resolving to the fee estimate.
     *
     * @example
     * ```typescript
     * const est = await provider.estimateSpend({
     *   from: {
     *     adapter,
     *     allocations: { amount: '100', chain: 'Ethereum' },
     *   },
     *   to: { adapter, chain: 'Avalanche' },
     *   token: 'USDC',
     * })
     * console.log('Total fee:', est.total)
     * ```
     */
    estimateSpend<TFromAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities, TToAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: SpendParams<TFromAdapterCapabilities, TToAdapterCapabilities>): Promise<EstimateSpendResult>;
    /**
     * Fetch combined confirmed and pending balances for one or more
     * accounts (aggregated breakdown).
     *
     * @param params - The token and one or more sources (adapter or
     *   raw account address). Optionally narrow by chain(s). Set
     *   `includePending: true` to include pending balances and
     *   pending transaction details in the result.
     * @returns Promise resolving to totalConfirmedBalance, optional
     *   totalPendingBalance, and per-account, per-chain breakdown.
     *
     * @example
     * ```typescript
     * const result = await provider.getBalances({
     *   token: 'USDC',
     *   sources: { address: '0x1234…abcd', chains: ['Ethereum'] },
     *   includePending: true,
     * })
     * console.log('Total:', result.totalConfirmedBalance, result.totalPendingBalance)
     * ```
     */
    getBalances(params: GetBalancesParams): Promise<GetBalancesResult>;
    /**
     * Grant spending rights to another address on the owner's
     * Gateway account.
     *
     * @param params - The owner's adapter context (`from`) and the
     *   delegate address to authorize.
     * @returns Promise resolving to the delegate update result.
     *
     * @example
     * ```typescript
     * const result = await provider.addDelegate({
     *   from: { adapter, chain: 'Ethereum' },
     *   delegateAddress: '0xDELEGATE…1111',
     * })
     * console.log('Delegate state:', result.state)
     * ```
     */
    addDelegate<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: UpdateDelegateParams<TAdapterCapabilities>): Promise<UpdateDelegateResult>;
    /**
     * Revoke spending rights from a delegate on the owner's
     * Gateway account.
     *
     * @param params - The owner's adapter context (`from`) and the
     *   delegate address to revoke.
     * @returns Promise resolving to the delegate update result.
     *
     * @example
     * ```typescript
     * const result = await provider.removeDelegate({
     *   from: { adapter, chain: 'Ethereum' },
     *   delegateAddress: '0xDELEGATE…1111',
     * })
     * console.log('Delegate state:', result.state)
     * ```
     */
    removeDelegate<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: UpdateDelegateParams<TAdapterCapabilities>): Promise<UpdateDelegateResult>;
    /**
     * Kick off a 7-day delayed fund removal from a Gateway account.
     *
     * @param params - The account owner's adapter context (`from`),
     *   amount, and optional token type.
     * @returns Promise resolving to the initiation details.
     *
     * @example
     * ```typescript
     * const result = await provider.initiateRemoveFund({
     *   from: { adapter, chain: 'Ethereum' },
     *   amount: '100',
     * })
     * console.log('Tx:', result.txHash, result.explorerUrl)
     * ```
     */
    initiateRemoveFund<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: InitiateRemoveFundParams<TAdapterCapabilities>): Promise<InitiateRemoveFundResult>;
    /**
     * Complete a fund removal once the 7-day activation period (after
     * initiation) has passed.
     *
     * @param params - The account owner's adapter context (`from`)
     *   matching the original fund removal.
     * @returns Promise resolving to the removal details.
     * @throws If the 7-day period has not yet elapsed.
     *
     * @example
     * ```typescript
     * const result = await provider.removeFund({
     *   from: { adapter, chain: 'Ethereum' },
     * })
     * console.log('Removed:', result.amount)
     * ```
     */
    removeFund<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: RemoveFundParams<TAdapterCapabilities>): Promise<RemoveFundResult>;
    /**
     * Check the finality-aware status of a delegate on a Gateway account.
     *
     * Returns `'none'` if the address is not a delegate, `'pending'` if
     * it has been added on-chain but Gateway hasn't finalized it yet, or
     * `'ready'` when Gateway recognizes the delegate and spend will work.
     *
     * @param params - The adapter context (`from`) and delegate address.
     * @returns Promise resolving to the delegate status.
     *
     * @example
     * ```typescript
     * const status = await provider.getDelegateStatus({
     *   from: { adapter, chain: 'Ethereum' },
     *   delegateAddress: '0xDELEGATE…1111',
     * })
     * if (status === 'ready') { // safe to spend }
     * ```
     */
    getDelegateStatus<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities>(params: GetDelegateStatusParams<TAdapterCapabilities>): Promise<DelegateStatus>;
    /**
     * Return all chains supported by this provider for the given
     * token.
     *
     * @param token - The token to filter by (defaults to USDC).
     * @returns Array of supported chain definitions.
     *
     * @example
     * ```typescript
     * const chains = provider.getSupportedChains('USDC')
     * console.log(chains.map(c => c.name))
     * ```
     */
    getSupportedChains(token?: SupportedToken): ChainDefinition[];
}

/**
 * Creates a Gateway v1 provider instance (functional implementation).
 *
 * Returns a plain object that implements {@link IGatewayProvider} by
 * delegating to the standalone functions in `operations/`.
 *
 * @returns An {@link IGatewayProvider} instance.
 *
 * @example
 * ```typescript
 * import { createGatewayV1Provider } from '@circle-fin/provider-gateway-v1'
 *
 * const provider = createGatewayV1Provider()
 * const chains = provider.getSupportedChains()
 * ```
 */
declare function createGatewayV1Provider(): IGatewayProvider;

export { GATEWAY_V1_PROVIDER_NAME, addDelegate, createGatewayV1Provider, deposit, depositFor, estimateSpend, getBalances, getDelegateStatus, getSupportedChains, initiateRemoveFund, removeDelegate, removeFund, spend };
export type { Allocation, AllocationResult, AllowanceStrategy, BalanceSource, BalanceWithPendingBreakdown, ChainBalanceBreakdown, ConfirmedBalanceEntry, DelegateStatus, DepositForParams, DepositParams, DepositResult, EstimateSpendResult, EstimatedIntentItem, FeeAllocation, FeeEntry, FeeType, ForwarderSpendDestination, GatewayActionName, GatewayBalancesResponse, GatewayDepositsResponse, GatewayV1Actions, GetBalancesParams, GetBalancesResult, GetConfirmedDepositsResult, GetDelegateStatusParams, GetPendingDepositsResult, IGatewayProvider, InitiateRemoveFundParams, InitiateRemoveFundResult, NetworkType, PendingBalanceTransaction, PendingDeposit, RemoveFundParams, RemoveFundResult, RetryMintConfig, Sources, SpendConfig, SpendDestination, SpendDestinationUnion, SpendParams, SpendResult, SpendSource, SpendStep, SupportedToken, UpdateDelegateParams, UpdateDelegateResult };
