/**
 * Copyright (c) 2026, Circle Internet Group, Inc. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var zod = require('zod');
var bytes = require('@ethersproject/bytes');
var address = require('@ethersproject/address');
var bs58 = require('bs58');
var units = require('@ethersproject/units');
var web3_js = require('@solana/web3.js');
require('bn.js');
require('@coral-xyz/anchor');
require('@noble/curves/ed25519');

function _interopDefault (e) { return e && e.__esModule ? e.default : e; }

var bs58__default = /*#__PURE__*/_interopDefault(bs58);

/**
 * Maximum value for uint256 (2^256 - 1).
 *
 * Used as default maxBlockHeight for EVM burn intents with no expiration.
 */
const MAX_UINT256 = 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffn;
/**
 * Maximum value for uint64 (2^64 - 1).
 *
 * Used as default maxBlockHeight for Solana burn intents with no expiration.
 * Solana uses 64-bit slot heights rather than 256-bit block numbers.
 */
const MAX_UINT64 = 0xffffffffffffffffn;
/**
 * 32-byte zero value (0x0000...0000, 64 hex chars).
 *
 * Used as the default destinationCaller in burn intents to allow
 * anyone to call the mint function on the destination chain.
 */
const ZERO_BYTES32 = '0x0000000000000000000000000000000000000000000000000000000000000000';
/**
 * Default maximum fee in USDC atomic units (2.01 USDC = 2,010,000).
 *
 * This is a conservative default that covers typical Gateway fees.
 * The actual fee charged may be less than this amount.
 */
const DEFAULT_MAX_FEE = 2010000n;
// ---------------------------------------------------------------------------
// Supported Token
// ---------------------------------------------------------------------------
/**
 * Runtime array of token identifiers supported by the Gateway v1 provider.
 *
 * @example
 * ```typescript
 * import { SUPPORTED_TOKENS } from '@circle-fin/provider-gateway-v1'
 *
 * if (SUPPORTED_TOKENS.includes('USDC')) {
 *   console.log('USDC is supported')
 * }
 * ```
 */
const SUPPORTED_TOKENS = ['USDC'];
// ---------------------------------------------------------------------------
// Provider Identity
// ---------------------------------------------------------------------------
/** Human-readable name identifying the Gateway v1 provider. */
const GATEWAY_V1_PROVIDER_NAME = 'GATEWAY_V1';
/**
 * Gateway API base URL for mainnet.
 */
const GATEWAY_API_BASE_URL = 'https://gateway-api.circle.com';
/**
 * Gateway API base URL for testnet.
 */
const GATEWAY_API_TESTNET_BASE_URL = 'https://gateway-api-testnet.circle.com';
// ---------------------------------------------------------------------------
// Gateway Fee Constants
// ---------------------------------------------------------------------------
/**
 * Gateway transfer fee expressed as a scaled basis-point integer.
 *
 * The actual rate is 0.5 bps (0.005 %). Because BigInt arithmetic
 * cannot represent 0.5 directly, the rate is pre-scaled by 10:
 *
 *   `fee = value * GATEWAY_TRANSFER_FEE_SCALED_BPS / 100_000n`
 *
 * where 100 000 = standard BPS divisor (10 000) × the same 10× factor.
 * Same-chain transfers (withdrawals) do not incur this fee.
 *
 * @see {@link https://developers.circle.com/gateway/references/fees | Gateway Fees}
 */
const GATEWAY_TRANSFER_FEE_SCALED_BPS = 5n;
// ---------------------------------------------------------------------------
// Circle Fee Recipient Addresses
// ---------------------------------------------------------------------------
/** Gateway domain used by Solana (mainnet & devnet). */
const SOLANA_GATEWAY_DOMAIN = 5;
/**
 * Number of decimal places for USDC amounts.
 *
 * @example
 * ```typescript
 * import { USDC_DECIMALS } from '@circle-fin/provider-gateway-v1'
 *
 * const humanReadable = Number(atomicAmount) / 10 ** USDC_DECIMALS
 * ```
 */
const USDC_DECIMALS$1 = 6;

/**
 * Valid recoverability values for error handling strategies.
 *
 * - FATAL errors are thrown immediately (invalid inputs, insufficient funds)
 * - RETRYABLE errors are returned when a flow fails to start but could work later
 * - RESUMABLE errors are returned when a flow fails mid-execution but can be continued
 */
const RECOVERABILITY_VALUES = [
    'RETRYABLE',
    'RESUMABLE',
    'FATAL',
];
/**
 * Error type constants for categorizing errors by origin.
 *
 * This const object provides a reference for error types, enabling
 * IDE autocomplete and preventing typos when creating custom errors.
 *
 * @remarks
 * While internal error definitions use string literals with type annotations
 * for strict type safety, this constant is useful for developers creating
 * custom error instances or checking error types programmatically.
 *
 * @example
 * ```typescript
 * import { ERROR_TYPES, KitError } from '@core/errors'
 *
 * // Use for type checking
 * if (error.type === ERROR_TYPES.BALANCE) {
 *   console.log('This is a balance error')
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Use as reference when creating custom errors
 * const error = new KitError({
 *   code: 9999,
 *   name: 'CUSTOM_ERROR',
 *   type: ERROR_TYPES.BALANCE,  // IDE autocomplete works here
 *   recoverability: 'FATAL',
 *   message: 'Custom balance error'
 * })
 * ```
 */
const ERROR_TYPES = {
    /** User input validation and parameter checking */
    INPUT: 'INPUT',
    /** Insufficient token balances and amount validation */
    BALANCE: 'BALANCE',
    /** On-chain execution: reverts, gas issues, transaction failures */
    ONCHAIN: 'ONCHAIN',
    /** Blockchain RPC provider issues and endpoint problems */
    RPC: 'RPC',
    /** Internet connectivity, DNS resolution, connection issues */
    NETWORK: 'NETWORK',
    /** API throttling, request frequency limits errors */
    RATE_LIMIT: 'RATE_LIMIT',
    /** Service errors */
    SERVICE: 'SERVICE',
    /** Catch-all for unrecognized errors (code 0) */
    UNKNOWN: 'UNKNOWN',
};
/**
 * Array of valid error type values for validation.
 * Derived from ERROR_TYPES const object.
 */
const ERROR_TYPE_VALUES = Object.values(ERROR_TYPES);

// Create mutable arrays for Zod enum validation
const RECOVERABILITY_ARRAY = [...RECOVERABILITY_VALUES];
const ERROR_TYPE_ARRAY = [...ERROR_TYPE_VALUES];
/**
 * Error code ranges for validation.
 * Single source of truth for valid error code ranges.
 *
 * Note: Code 0 is special - it's the UNKNOWN catch-all error.
 */
const ERROR_CODE_RANGES = [
    { min: 1000, max: 1999, type: 'INPUT' },
    { min: 3000, max: 3999, type: 'NETWORK' },
    { min: 4000, max: 4999, type: 'RPC' },
    { min: 5000, max: 5999, type: 'ONCHAIN' },
    { min: 7000, max: 7999, type: 'RATE_LIMIT' },
    { min: 8000, max: 8999, type: 'SERVICE' },
    { min: 9000, max: 9999, type: 'BALANCE' },
];
/** Special code for UNKNOWN errors */
const UNKNOWN_ERROR_CODE = 0;
/**
 * Zod schema for validating ErrorDetails objects.
 *
 * This schema provides runtime validation for all ErrorDetails properties,
 * ensuring type safety and proper error handling for JavaScript consumers.
 *
 * @example
 * ```typescript
 * import { errorDetailsSchema } from '@core/errors'
 *
 * const result = errorDetailsSchema.safeParse({
 *   code: 1001,
 *   name: 'INPUT_NETWORK_MISMATCH',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Source and destination networks must be different'
 * })
 *
 * if (!result.success) {
 *   console.error('Validation failed:', result.error.issues)
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Runtime error
 * const result = errorDetailsSchema.safeParse({
 *   code: 9001,
 *   name: 'BALANCE_INSUFFICIENT_TOKEN',
 *   type: 'BALANCE',
 *   recoverability: 'FATAL',
 *   message: 'Insufficient USDC balance'
 * })
 * ```
 */
const errorDetailsSchema = zod.z.object({
    /**
     * Numeric identifier following standardized ranges:
     * - 0: UNKNOWN - Catch-all for unrecognized errors
     * - 1000-1999: INPUT errors - Parameter validation
     * - 3000-3999: NETWORK errors - Connectivity issues
     * - 4000-4999: RPC errors - Provider issues, gas estimation
     * - 5000-5999: ONCHAIN errors - Transaction/simulation failures
     * - 7000-7999: RATE_LIMIT errors - API throttling
     * - 8000-8999: SERVICE errors - Internal service errors
     * - 9000-9999: BALANCE errors - Insufficient funds
     */
    code: zod.z
        .number()
        .int('Error code must be an integer')
        .refine((code) => code === UNKNOWN_ERROR_CODE ||
        ERROR_CODE_RANGES.some((range) => code >= range.min && code <= range.max), {
        message: 'Error code must be 0 (UNKNOWN) or in valid ranges: 1000-1999 (INPUT), 3000-3999 (NETWORK), 4000-4999 (RPC), 5000-5999 (ONCHAIN), 9000-9999 (BALANCE)',
    }),
    /** Human-readable ID (e.g., "INPUT_NETWORK_MISMATCH", "BALANCE_INSUFFICIENT_TOKEN") */
    name: zod.z
        .string()
        .min(1, 'Error name must be a non-empty string')
        .regex(/^[A-Z_][A-Z0-9_]*$/, 'Error name must match pattern: ^[A-Z_][A-Z0-9_]*$'),
    /** Error category indicating where the error originated */
    type: zod.z.enum(ERROR_TYPE_ARRAY, {
        errorMap: () => ({
            message: 'Error type must be one of: INPUT, BALANCE, ONCHAIN, RPC, NETWORK, UNKNOWN',
        }),
    }),
    /** Error handling strategy */
    recoverability: zod.z.enum(RECOVERABILITY_ARRAY, {
        errorMap: () => ({
            message: 'Recoverability must be one of: RETRYABLE, RESUMABLE, FATAL',
        }),
    }),
    /** User-friendly explanation with context */
    message: zod.z
        .string()
        .min(1, 'Error message must be a non-empty string')
        .max(1000, 'Error message must be 1000 characters or less'),
    /** Raw error details, context, or the original error that caused this one. */
    cause: zod.z
        .object({
        /** Free-form error payload from underlying system */
        trace: zod.z.unknown().optional(),
    })
        .optional(),
});

/**
 * Validates an ErrorDetails object using Zod schema.
 *
 * @param details - The object to validate
 * @returns The validated ErrorDetails object
 * @throws TypeError When validation fails
 *
 * @example
 * ```typescript
 * import { validateErrorDetails } from '@core/errors'
 *
 * try {
 *   const validDetails = validateErrorDetails({
 *     code: 1001,
 *     name: 'NETWORK_MISMATCH',
 *     recoverability: 'FATAL',
 *     message: 'Source and destination networks must be different'
 *   })
 * } catch (error) {
 *   console.error('Validation failed:', error.message)
 * }
 * ```
 */
function validateErrorDetails(details) {
    const result = errorDetailsSchema.safeParse(details);
    if (!result.success) {
        const issues = result.error.issues
            .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
            .join(', ');
        throw new TypeError(`Invalid ErrorDetails: ${issues}`);
    }
    return result.data;
}

/**
 * Maximum length for error messages in fallback validation errors.
 *
 * KitError enforces a 1000-character limit on error messages. When creating
 * fallback validation errors that combine multiple Zod issues, we use 950
 * characters to leave a 50-character buffer for:
 * - The error message prefix ("Invalid bridge parameters: ")
 * - Potential encoding differences or formatting overhead
 * - Safety margin to prevent KitError constructor failures
 *
 * This ensures that even with concatenated issue summaries, the final message
 * stays within KitError's constraints.
 */
const MAX_MESSAGE_LENGTH = 950;
/**
 * Standard error message for invalid amount format.
 *
 * The SDK enforces strict dot-decimal notation for amount values. This constant
 * provides a consistent error message when users provide amounts with:
 * - Comma decimals (e.g., "1,5")
 * - Thousand separators (e.g., "1,000.50")
 * - Non-numeric characters
 * - Invalid format
 */
const AMOUNT_FORMAT_ERROR_MESSAGE = 'Amount must be a numeric string with dot (.) as decimal separator (e.g., "10.5", "100"), with no thousand separators or comma decimals';
/**
 * Error message for invalid maxFee format.
 *
 * Used when validating the maxFee configuration parameter. The maxFee can be zero
 * or positive and must follow strict dot-decimal notation.
 */
const MAX_FEE_FORMAT_ERROR_MESSAGE = 'maxFee must be a numeric string with dot (.) as decimal separator (e.g., "1", "0.5", ".5", "1.5"), with no thousand separators or comma decimals';

/**
 * Structured error class for App Kit operations.
 *
 * This class extends the native Error class while implementing the ErrorDetails
 * interface, providing a consistent error format for programmatic handling
 * across the App Kits ecosystem. All properties are immutable to ensure
 * error objects cannot be modified after creation.
 *
 * @example
 * ```typescript
 * import { KitError } from '@core/errors'
 *
 * const error = new KitError({
 *   code: 1001,
 *   name: 'INPUT_NETWORK_MISMATCH',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Cannot bridge between mainnet and testnet'
 * })
 *
 * if (error instanceof KitError) {
 *   console.log(`Error ${error.code}: ${error.name}`)
 *   // → "Error 1001: INPUT_NETWORK_MISMATCH"
 * }
 * ```
 *
 * @example
 * ```typescript
 * import { KitError } from '@core/errors'
 *
 * // Error with cause information
 * const error = new KitError({
 *   code: 1002,
 *   name: 'INPUT_INVALID_AMOUNT',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Amount must be greater than zero',
 *   cause: {
 *     trace: { providedAmount: -100, minimumAmount: 0 }
 *   }
 * })
 *
 * throw error
 * ```
 */
class KitError extends Error {
    /** Numeric identifier following standardized ranges (1000+ for INPUT errors) */
    code;
    /** Human-readable ID (e.g., "NETWORK_MISMATCH") */
    name;
    /** Error category indicating where the error originated */
    type;
    /** Error handling strategy */
    recoverability;
    /** Raw error details, context, or the original error that caused this one. */
    cause;
    /**
     * Create a new KitError instance.
     *
     * @param details - The error details object containing all required properties.
     * @throws \{TypeError\} When details parameter is missing or invalid.
     */
    constructor(details) {
        // Truncate message if it exceeds maximum length to prevent validation errors
        let message = details.message;
        if (message.length > MAX_MESSAGE_LENGTH) {
            message = `${message.slice(0, MAX_MESSAGE_LENGTH - 3)}...`;
        }
        const truncatedDetails = { ...details, message };
        // Validate input at runtime for JavaScript consumers using Zod
        const validatedDetails = validateErrorDetails(truncatedDetails);
        super(validatedDetails.message);
        // Set properties as readonly at runtime
        Object.defineProperties(this, {
            name: {
                value: validatedDetails.name,
                writable: false,
                enumerable: true,
                configurable: false,
            },
            code: {
                value: validatedDetails.code,
                writable: false,
                enumerable: true,
                configurable: false,
            },
            type: {
                value: validatedDetails.type,
                writable: false,
                enumerable: true,
                configurable: false,
            },
            recoverability: {
                value: validatedDetails.recoverability,
                writable: false,
                enumerable: true,
                configurable: false,
            },
            ...(validatedDetails.cause && {
                cause: {
                    value: validatedDetails.cause,
                    writable: false,
                    enumerable: true,
                    configurable: false,
                },
            }),
        });
    }
}

/**
 * Standardized error code ranges for consistent categorization:
 *
 * - 0: UNKNOWN - Catch-all for unrecognized errors
 * - 1000-1999: INPUT errors - Parameter validation, input format errors
 * - 3000-3999: NETWORK errors - Internet connectivity, DNS, connection issues
 * - 4000-4999: RPC errors - Blockchain provider issues, gas estimation, nonce errors
 * - 5000-5999: ONCHAIN errors - Transaction/simulation failures, gas exhaustion, reverts
 * - 7000-7999: RATE_LIMIT errors - API throttling, request frequency limits
 * - 8000-8999: SERVICE errors - Internal service errors, server failures
 * - 9000-9999: BALANCE errors - Insufficient funds, token balance, allowance
 */
/**
 * Standardized error definitions for INPUT type errors.
 *
 * Each entry combines the numeric error code, string name, and type
 * to ensure consistency when creating error instances.
 *
 * Error codes follow a hierarchical numbering scheme where the first digit
 * indicates the error category (1 = INPUT) and subsequent digits provide
 * specific error identification within that category.
 *
 *
 * @example
 * ```typescript
 * import { InputError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...InputError.NETWORK_MISMATCH,
 *   recoverability: 'FATAL',
 *   message: 'Source and destination networks must be different'
 * })
 *
 * // Access code, name, and type individually if needed
 * console.log(InputError.NETWORK_MISMATCH.code)  // 1001
 * console.log(InputError.NETWORK_MISMATCH.name)  // 'INPUT_NETWORK_MISMATCH'
 * console.log(InputError.NETWORK_MISMATCH.type)  // 'INPUT'
 * ```
 */
const InputError = {
    /** Network type mismatch between chains (mainnet vs testnet) */
    NETWORK_MISMATCH: {
        code: 1001,
        name: 'INPUT_NETWORK_MISMATCH',
        type: 'INPUT',
    },
    /** Invalid amount format or value (negative, zero, or malformed) */
    INVALID_AMOUNT: {
        code: 1002,
        name: 'INPUT_INVALID_AMOUNT',
        type: 'INPUT',
    },
    /** Invalid wallet or contract address format */
    INVALID_ADDRESS: {
        code: 1004,
        name: 'INPUT_INVALID_ADDRESS',
        type: 'INPUT',
    },
    /** Invalid or unsupported chain identifier */
    INVALID_CHAIN: {
        code: 1005,
        name: 'INPUT_INVALID_CHAIN',
        type: 'INPUT',
    },
    /** Unsupported token for chain */
    UNSUPPORTED_TOKEN: {
        code: 1006,
        name: 'INPUT_UNSUPPORTED_TOKEN',
        type: 'INPUT',
    },
    /** No route satisfies the slippage or minimum-output constraint */
    SLIPPAGE_CONSTRAINT_NOT_MET: {
        code: 1009,
        name: 'INPUT_SLIPPAGE_CONSTRAINT_NOT_MET',
        type: 'INPUT',
    },
    /** General validation failure for complex validation rules */
    VALIDATION_FAILED: {
        code: 1098,
        name: 'INPUT_VALIDATION_FAILED',
        type: 'INPUT',
    }};
/**
 * Standardized error definitions for BALANCE type errors.
 *
 * BALANCE errors indicate insufficient funds or allowance issues
 * that prevent transaction execution.
 *
 * @example
 * ```typescript
 * import { BalanceError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...BalanceError.INSUFFICIENT_TOKEN,
 *   recoverability: 'FATAL',
 *   message: 'Insufficient USDC balance on Ethereum',
 *   cause: { trace: { required: '100', available: '50' } }
 * })
 * ```
 */
const BalanceError = {
    /** Insufficient token balance for transaction */
    INSUFFICIENT_TOKEN: {
        code: 9001,
        name: 'BALANCE_INSUFFICIENT_TOKEN',
        type: 'BALANCE',
    },
    /** Insufficient native token (ETH/SOL/etc) for gas fees */
    INSUFFICIENT_GAS: {
        code: 9002,
        name: 'BALANCE_INSUFFICIENT_GAS',
        type: 'BALANCE',
    }};
/**
 * Standardized error definitions for ONCHAIN type errors.
 *
 * ONCHAIN errors occur during transaction execution, simulation,
 * or interaction with smart contracts on the blockchain.
 *
 * @example
 * ```typescript
 * import { OnchainError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...OnchainError.SIMULATION_FAILED,
 *   recoverability: 'FATAL',
 *   message: 'Simulation failed: ERC20 transfer amount exceeds balance',
 *   cause: { trace: { reason: 'ERC20: transfer amount exceeds balance' } }
 * })
 * ```
 */
const OnchainError = {
    /** Transaction reverted on-chain after execution */
    TRANSACTION_REVERTED: {
        code: 5001,
        name: 'ONCHAIN_TRANSACTION_REVERTED',
        type: 'ONCHAIN',
    },
    /** Pre-flight transaction simulation failed */
    SIMULATION_FAILED: {
        code: 5002,
        name: 'ONCHAIN_SIMULATION_FAILED',
        type: 'ONCHAIN',
    },
    /** Transaction ran out of gas during execution */
    OUT_OF_GAS: {
        code: 5003,
        name: 'ONCHAIN_OUT_OF_GAS',
        type: 'ONCHAIN',
    },
    /** Transaction size exceeds blockchain limit */
    TRANSACTION_TOO_LARGE: {
        code: 5005,
        name: 'ONCHAIN_TRANSACTION_TOO_LARGE',
        type: 'ONCHAIN',
    },
    /** Unknown blockchain error that cannot be categorized */
    UNKNOWN_BLOCKCHAIN_ERROR: {
        code: 5099,
        name: 'ONCHAIN_UNKNOWN_BLOCKCHAIN_ERROR',
        type: 'ONCHAIN',
    },
};
/**
 * Standardized error definitions for RPC type errors.
 *
 * RPC errors occur when communicating with blockchain RPC providers,
 * including endpoint failures, invalid responses, and provider-specific issues.
 *
 * @example
 * ```typescript
 * import { RpcError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...RpcError.ENDPOINT_ERROR,
 *   recoverability: 'RETRYABLE',
 *   message: 'RPC endpoint unavailable on Ethereum',
 *   cause: { trace: { endpoint: 'https://mainnet.infura.io' } }
 * })
 * ```
 */
const RpcError = {
    /** RPC endpoint returned error or is unavailable */
    ENDPOINT_ERROR: {
        code: 4001,
        name: 'RPC_ENDPOINT_ERROR',
        type: 'RPC',
    },
    /** Invalid or unexpected RPC response format */
    INVALID_RESPONSE: {
        code: 4002,
        name: 'RPC_INVALID_RESPONSE',
        type: 'RPC',
    }};
/**
 * Standardized error definitions for NETWORK type errors.
 *
 * NETWORK errors indicate connectivity issues at the network layer,
 * including DNS failures, connection timeouts, and unreachable endpoints.
 *
 * @example
 * ```typescript
 * import { NetworkError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...NetworkError.CONNECTION_FAILED,
 *   recoverability: 'RETRYABLE',
 *   message: 'Failed to connect to Ethereum network',
 *   cause: { trace: { error: 'ECONNREFUSED' } }
 * })
 * ```
 */
const NetworkError = {
    /** Network connection failed or unreachable */
    CONNECTION_FAILED: {
        code: 3001,
        name: 'NETWORK_CONNECTION_FAILED',
        type: 'NETWORK',
    },
    /** Network request timeout */
    TIMEOUT: {
        code: 3002,
        name: 'NETWORK_TIMEOUT',
        type: 'NETWORK',
    },
    /** Gateway API returned an error response or an unexpected response shape */
    GATEWAY_API_ERROR: {
        code: 3007,
        name: 'NETWORK_GATEWAY_API_ERROR',
        type: 'NETWORK',
    },
};

/**
 * Creates error for network type mismatch between source and destination.
 *
 * This error is thrown when attempting to bridge between chains that have
 * different network types (e.g., mainnet to testnet), which is not supported
 * for security reasons.
 *
 * @param sourceChain - The source chain definition
 * @param destChain - The destination chain definition
 * @returns KitError with specific network mismatch details
 *
 * @example
 * ```typescript
 * import { createNetworkMismatchError } from '@core/errors'
 * import { Ethereum, BaseSepolia } from '@core/chains'
 *
 * // This will throw a detailed error
 * throw createNetworkMismatchError(Ethereum, BaseSepolia)
 * // Message: "Cannot bridge between Ethereum (mainnet) and Base Sepolia (testnet). Source and destination networks must both be testnet or both be mainnet."
 * ```
 */
function createNetworkMismatchError(sourceChain, destChain) {
    const sourceNetworkType = sourceChain.isTestnet ? 'testnet' : 'mainnet';
    const destNetworkType = destChain.isTestnet ? 'testnet' : 'mainnet';
    const errorDetails = {
        ...InputError.NETWORK_MISMATCH,
        recoverability: 'FATAL',
        message: `Cannot bridge between ${sourceChain.name} (${sourceNetworkType}) and ${destChain.name} (${destNetworkType}). Source and destination networks must both be testnet or both be mainnet.`,
        cause: {
            trace: { sourceChain: sourceChain.name, destChain: destChain.name },
        },
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for invalid amount format or precision.
 *
 * This error is thrown when the provided amount doesn't meet validation
 * requirements such as precision, range, or format.
 *
 * @param amount - The invalid amount string
 * @param reason - Specific reason why amount is invalid
 * @returns KitError with amount details and validation rule
 *
 * @example
 * ```typescript
 * import { createInvalidAmountError } from '@core/errors'
 *
 * throw createInvalidAmountError('0.000001', 'Amount must be at least 0.01 USDC')
 * // Message: "Invalid amount '0.000001': Amount must be at least 0.01 USDC"
 *
 * throw createInvalidAmountError('1,000.50', 'Amount must be a numeric string with dot (.) as decimal separator, with no thousand separators or comma decimals')
 * // Message: "Invalid amount '1,000.50': Amount must be a numeric string with dot (.) as decimal separator, with no thousand separators or comma decimals."
 * ```
 */
function createInvalidAmountError(amount, reason) {
    const errorDetails = {
        ...InputError.INVALID_AMOUNT,
        recoverability: 'FATAL',
        message: `Invalid amount '${amount}': ${reason}.`,
        cause: {
            trace: { amount, reason },
        },
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for invalid wallet address format.
 *
 * This error is thrown when the provided address doesn't match the expected
 * format for the specified chain.
 *
 * @param address - The invalid address string
 * @param chain - Chain name where address is invalid
 * @param expectedFormat - Description of expected address format
 * @returns KitError with address details and format requirements
 *
 * @example
 * ```typescript
 * import { createInvalidAddressError } from '@core/errors'
 *
 * throw createInvalidAddressError('0x123', 'Ethereum', '42-character hex string starting with 0x')
 * // Message: "Invalid address '0x123' for Ethereum. Expected 42-character hex string starting with 0x."
 *
 * throw createInvalidAddressError('invalid', 'Solana', 'base58-encoded string')
 * // Message: "Invalid address 'invalid' for Solana. Expected base58-encoded string."
 * ```
 */
function createInvalidAddressError(address, chain, expectedFormat) {
    const errorDetails = {
        ...InputError.INVALID_ADDRESS,
        recoverability: 'FATAL',
        message: `Invalid address '${address}' for ${chain}. Expected ${expectedFormat}.`,
        cause: {
            trace: { address, chain, expectedFormat },
        },
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for invalid chain configuration.
 *
 * This error is thrown when the provided chain doesn't meet the required
 * configuration or is not supported for the operation.
 *
 * @param chain - The invalid chain name or identifier
 * @param reason - Specific reason why chain is invalid
 * @returns KitError with chain details and validation rule
 *
 * @example
 * ```typescript
 * import { createInvalidChainError } from '@core/errors'
 *
 * throw createInvalidChainError('UnknownChain', 'Chain is not supported by this bridge')
 * // Message: "Invalid chain 'UnknownChain': Chain is not supported by this bridge"
 * ```
 */
function createInvalidChainError(chain, reason) {
    const errorDetails = {
        ...InputError.INVALID_CHAIN,
        recoverability: 'FATAL',
        message: `Invalid chain '${chain}': ${reason}.`,
        cause: {
            trace: { chain, reason },
        },
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for general validation failure.
 *
 * This error is thrown when input validation fails for reasons not covered
 * by more specific error types.
 *
 * @param field - The field that failed validation
 * @param value - The invalid value (can be any type)
 * @param reason - Specific reason why validation failed
 * @returns KitError with validation details
 *
 * @example
 * ```typescript
 * import { createValidationFailedError } from '@core/errors'
 *
 * throw createValidationFailedError('recipient', 'invalid@email', 'Must be a valid wallet address')
 * // Message: "Validation failed for 'recipient': 'invalid@email' - Must be a valid wallet address"
 *
 * throw createValidationFailedError('chainId', 999, 'Unsupported chain ID')
 * // Message: "Validation failed for 'chainId': 999 - Unsupported chain ID"
 *
 * throw createValidationFailedError('config', { invalid: true }, 'Missing required properties')
 * // Message: "Validation failed for 'config': [object Object] - Missing required properties"
 * ```
 */
function createValidationFailedError(field, value, reason) {
    // Convert value to string for display, handling different types appropriately
    let valueString;
    if (typeof value === 'string') {
        valueString = `'${value}'`;
    }
    else if (typeof value === 'object' && value !== null) {
        valueString = JSON.stringify(value);
    }
    else {
        valueString = String(value);
    }
    const errorDetails = {
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: `Validation failed for '${field}': ${valueString} - ${reason}.`,
        cause: {
            trace: { field, value, reason },
        },
    };
    return new KitError(errorDetails);
}
/**
 * Creates a KitError from a Zod validation error with detailed error information.
 *
 * This factory function converts Zod validation failures into standardized KitError
 * instances with INPUT_VALIDATION_FAILED code (1098). It extracts all Zod issues
 * and includes them in both the error message and trace for debugging, providing
 * developers with comprehensive validation feedback.
 *
 * The error message includes all validation errors concatenated with semicolons.
 *
 * @param zodError - The Zod validation error containing one or more validation issues
 * @param context - Context string describing what was being validated (e.g., 'bridge parameters', 'user input')
 * @returns KitError with INPUT_VALIDATION_FAILED code and structured validation details
 *
 * @example
 * ```typescript
 * import { createValidationErrorFromZod } from '@core/errors'
 * import { z } from 'zod'
 *
 * const schema = z.object({
 *   name: z.string().min(3),
 *   age: z.number().positive()
 * })
 *
 * const result = schema.safeParse({ name: 'ab', age: -1 })
 * if (!result.success) {
 *   throw createValidationErrorFromZod(result.error, 'user data')
 * }
 * // Throws: KitError with message:
 * // "Invalid user data: name: String must contain at least 3 character(s); age: Number must be greater than 0"
 * // And cause.trace.validationErrors containing all validation errors as an array
 * ```
 *
 * @example
 * ```typescript
 * // Usage in validation functions
 * import { createValidationErrorFromZod } from '@core/errors'
 *
 * function validateBridgeParams(params: unknown): asserts params is BridgeParams {
 *   const result = bridgeParamsSchema.safeParse(params)
 *   if (!result.success) {
 *     throw createValidationErrorFromZod(result.error, 'bridge parameters')
 *   }
 * }
 * ```
 */
function createValidationErrorFromZod(zodError, context) {
    // Format each Zod issue as "path: message"
    const validationErrors = zodError.issues.map((issue) => {
        const path = issue.path.length > 0 ? `${issue.path.join('.')}: ` : '';
        return `${path}${issue.message}`;
    });
    // Join all errors with semicolons to show complete validation feedback
    const issueSummary = validationErrors.join('; ');
    const allErrors = issueSummary || 'Invalid Input';
    // Build full message from context and validation errors
    const fullMessage = `Invalid ${context}: ${allErrors}`;
    const errorDetails = {
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: fullMessage,
        cause: {
            trace: {
                validationErrors, // Array of formatted error strings for display
                zodError: zodError.message, // Original Zod error message
                zodIssues: zodError.issues, // Full Zod issues array for debugging
            },
        },
    };
    return new KitError(errorDetails);
}

/**
 * Creates error for insufficient token balance.
 *
 * This error is thrown when a wallet does not have enough tokens to
 * complete a transaction. The error is FATAL as it requires user
 * intervention to add funds.
 *
 * @param chain - The blockchain network where the balance check failed
 * @param token - The token symbol (e.g., 'USDC', 'ETH')
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with insufficient token balance details
 *
 * @example
 * ```typescript
 * import { createInsufficientTokenBalanceError } from '@core/errors'
 *
 * throw createInsufficientTokenBalanceError('Ethereum', 'USDC')
 * // Message: "Insufficient USDC balance on Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * try {
 *   await transfer(...)
 * } catch (error) {
 *   throw createInsufficientTokenBalanceError('Base', 'USDC', {
 *     rawError: error,
 *     balance: '1000000',
 *     amount: '5000000',
 *   })
 * }
 * ```
 */
function createInsufficientTokenBalanceError(chain, token, trace) {
    return new KitError({
        ...BalanceError.INSUFFICIENT_TOKEN,
        recoverability: 'FATAL',
        message: `Insufficient ${token} balance on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
                token,
            },
        },
    });
}
/**
 * Creates error for insufficient gas funds.
 *
 * This error is thrown when a wallet does not have enough native tokens
 * (ETH, SOL, etc.) to pay for transaction gas fees. The error is FATAL
 * as it requires user intervention to add gas funds.
 *
 * @param chain - The blockchain network where the gas check failed
 * @param nativeToken - Native token symbol (e.g. 'ETH', 'SOL', 'AVAX') for a specific message, defaults to 'native token'
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with insufficient gas details
 *
 * @example
 * ```typescript
 * import { createInsufficientGasError } from '@core/errors'
 *
 * throw createInsufficientGasError('Ethereum')
 * // Message: "Insufficient native token on Ethereum to cover gas fees"
 *
 * throw createInsufficientGasError('Ethereum', 'ETH')
 * // Message: "Insufficient ETH on Ethereum to cover gas fees"
 * ```
 *
 * @example
 * ```typescript
 * throw createInsufficientGasError('Ethereum', 'ETH', {
 *   rawError: error,
 *   walletAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
 * })
 * ```
 */
function createInsufficientGasError(chain, nativeToken = 'native token', trace) {
    return new KitError({
        ...BalanceError.INSUFFICIENT_GAS,
        recoverability: 'FATAL',
        message: `Insufficient ${nativeToken} on ${chain} to cover gas fees`,
        cause: {
            trace: {
                ...trace,
                chain,
            },
        },
    });
}

/**
 * Creates error for transaction simulation failures.
 *
 * This error is thrown when a pre-flight transaction simulation fails,
 * typically due to contract logic that would revert. The error is FATAL
 * as it indicates the transaction would fail if submitted.
 *
 * @param chain - The blockchain network where the simulation failed
 * @param reason - The reason for simulation failure (e.g., revert message)
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with simulation failure details
 *
 * @example
 * ```typescript
 * import { createSimulationFailedError } from '@core/errors'
 *
 * throw createSimulationFailedError('Ethereum', 'ERC20: insufficient allowance')
 * // Message: "Simulation failed on Ethereum: ERC20: insufficient allowance"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * throw createSimulationFailedError('Ethereum', 'ERC20: insufficient allowance', {
 *   rawError: error,
 *   txHash: '0x1234...',
 *   gasLimit: '21000',
 * })
 * ```
 */
function createSimulationFailedError(chain, reason, trace) {
    return new KitError({
        ...OnchainError.SIMULATION_FAILED,
        recoverability: 'FATAL',
        message: `Simulation failed on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason,
            },
        },
    });
}
/**
 * Creates error for transaction reverts.
 *
 * This error is thrown when a transaction is submitted and confirmed
 * but reverts on-chain. The error is FATAL as it indicates the
 * transaction executed but failed.
 *
 * @param chain - The blockchain network where the transaction reverted
 * @param reason - The reason for the revert (e.g., revert message)
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @param txHash - The transaction hash if the transaction was submitted (optional)
 * @param explorerUrl - The block explorer URL for the transaction (optional)
 * @returns KitError with transaction revert details
 *
 * @example
 * ```typescript
 * import { createTransactionRevertedError } from '@core/errors'
 *
 * throw createTransactionRevertedError('Base', 'Slippage exceeded')
 * // Message: "Transaction reverted on Base: Slippage exceeded"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context and transaction details for debugging
 * throw createTransactionRevertedError(
 *   'Base',
 *   'Slippage exceeded',
 *   { rawError: error },
 *   '0x123...',
 *   'https://basescan.org/tx/0x123...'
 * )
 * ```
 */
function createTransactionRevertedError(chain, reason, trace, txHash, explorerUrl) {
    return new KitError({
        ...OnchainError.TRANSACTION_REVERTED,
        recoverability: 'FATAL',
        message: `Transaction reverted on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason,
                ...(txHash !== undefined && txHash !== '' && { txHash }),
                ...(explorerUrl !== undefined && explorerUrl !== '' && { explorerUrl }),
            },
        },
    });
}
/**
 * Creates error for out of gas failures.
 *
 * This error is thrown when a transaction runs out of gas during execution.
 * The error is FATAL as it requires adjusting gas limits or transaction logic.
 *
 * @param chain - The blockchain network where the transaction ran out of gas
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @param txHash - The transaction hash if the transaction was submitted (optional)
 * @param explorerUrl - The block explorer URL for the transaction (optional)
 * @returns KitError with out of gas details
 *
 * @example
 * ```typescript
 * import { createOutOfGasError } from '@core/errors'
 *
 * throw createOutOfGasError('Polygon')
 * // Message: "Transaction ran out of gas on Polygon"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * throw createOutOfGasError('Polygon', {
 *   gasUsed: '50000',
 *   gasLimit: '45000',
 * },
 *  '0xabc...',
 *   'https://polygonscan.com/tx/0xabc...'
 * )
 * ```
 */
function createOutOfGasError(chain, trace, txHash, explorerUrl) {
    return new KitError({
        ...OnchainError.OUT_OF_GAS,
        recoverability: 'FATAL',
        message: `Transaction ran out of gas on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
                ...(txHash !== undefined && txHash !== '' && { txHash }),
                ...(explorerUrl !== undefined && explorerUrl !== '' && { explorerUrl }),
            },
        },
    });
}
/**
 * Creates error for transaction size exceeding blockchain limits.
 *
 * This error is thrown when a transaction's serialized size exceeds
 * the blockchain's maximum transaction size limit. The error is FATAL
 * as it requires reducing the transaction size (e.g., fewer instructions,
 * smaller data payloads, or splitting into multiple transactions).
 *
 * Common on Solana where transactions have strict size limits (e.g., max 1232 bytes).
 *
 * @param chain - The blockchain network where the size limit was exceeded
 * @param rawError - The original error from the underlying system (optional)
 * @returns KitError with transaction size exceeded details
 *
 * @example
 * ```typescript
 * import { createTransactionTooLargeError } from '@core/errors'
 *
 * throw createTransactionTooLargeError('Solana')
 * // Message: "Transaction size exceeds limit on Solana"
 * ```
 *
 * @example
 * ```typescript
 * import { createTransactionTooLargeError } from '@core/errors'
 *
 * // With raw error containing size details
 * throw createTransactionTooLargeError(
 *   'Solana',
 *   new Error('transaction too large: max: encoded/raw 1644/1232')
 * )
 * // Error includes size information in cause.trace
 * ```
 */
function createTransactionTooLargeError(chain, rawError) {
    return new KitError({
        ...OnchainError.TRANSACTION_TOO_LARGE,
        recoverability: 'FATAL',
        message: `Transaction size exceeds limit on ${chain}`,
        cause: {
            trace: {
                chain,
                rawError,
            },
        },
    });
}
/**
 * Creates error for unknown blockchain errors that cannot be categorized.
 *
 * This error is used as a fallback when a blockchain error doesn't match
 * any known patterns (balance, simulation, gas, network, RPC, etc.).
 * The error is FATAL as we cannot determine if it's retriable without
 * understanding the underlying cause.
 *
 * The original error message and context are preserved in the trace for
 * debugging purposes.
 *
 * @param chain - The blockchain network where the error occurred
 * @param originalMessage - The original error message from the blockchain
 * @param rawError - The original error object from the underlying system (optional)
 * @returns KitError with unknown blockchain error details
 *
 * @example
 * ```typescript
 * import { createUnknownBlockchainError } from '@core/errors'
 *
 * throw createUnknownBlockchainError('Ethereum', 'Unknown protocol error')
 * // Message: "Unknown blockchain error on Ethereum: Unknown protocol error"
 * ```
 *
 * @example
 * ```typescript
 * import { createUnknownBlockchainError } from '@core/errors'
 *
 * // With raw error for debugging
 * const rawError = new Error('Unexpected blockchain state')
 * throw createUnknownBlockchainError('Solana', rawError.message, rawError)
 * // Error preserves full context in cause.trace
 * ```
 */
function createUnknownBlockchainError(chain, originalMessage, rawError) {
    const errorMessage = originalMessage
        ? 'Unknown blockchain error on ' + chain + ': ' + originalMessage
        : 'Unknown blockchain error on ' + chain;
    return new KitError({
        ...OnchainError.UNKNOWN_BLOCKCHAIN_ERROR,
        recoverability: 'FATAL',
        message: errorMessage,
        cause: {
            trace: {
                chain,
                rawError,
            },
        },
    });
}

/**
 * Create error for RPC endpoint failures.
 *
 * Throw when an RPC provider endpoint fails, returns an error,
 * or is unavailable. The error is RETRYABLE as RPC issues are often temporary.
 *
 * @param chain - The blockchain network where the RPC error occurred.
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with RPC endpoint error details.
 *
 * @example
 * ```typescript
 * import { createRpcEndpointError } from '@core/errors'
 *
 * throw createRpcEndpointError('Ethereum')
 * // Message: "RPC endpoint error on Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * throw createRpcEndpointError('Ethereum', {
 *   rawError: error,
 *   endpoint: 'https://mainnet.infura.io/v3/...',
 *   statusCode: 429,
 * })
 * ```
 */
function createRpcEndpointError(chain, trace) {
    return new KitError({
        ...RpcError.ENDPOINT_ERROR,
        recoverability: 'RETRYABLE',
        message: `RPC endpoint error on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
            },
        },
    });
}

/**
 * Create error for network connection failures.
 *
 * Throw when network connectivity issues prevent reaching
 * the blockchain network. The error is RETRYABLE as network issues are
 * often temporary.
 *
 * @param chain - The blockchain network where the connection failed.
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with network connection error details.
 *
 * @example
 * ```typescript
 * import { createNetworkConnectionError } from '@core/errors'
 *
 * throw createNetworkConnectionError('Ethereum')
 * // Message: "Network connection failed for Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * throw createNetworkConnectionError('Ethereum', {
 *   rawError: error,
 *   endpoint: 'https://eth-mainnet.g.alchemy.com/v2/...',
 *   retryCount: 3,
 * })
 * ```
 */
function createNetworkConnectionError(chain, trace) {
    return new KitError({
        ...NetworkError.CONNECTION_FAILED,
        recoverability: 'RETRYABLE',
        message: `Network connection failed for ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
            },
        },
    });
}

/**
 * Normalizes optional transaction details for error factories.
 *
 * Converts empty strings to undefined to ensure clean error traces.
 *
 * @param txHash - The transaction hash.
 * @param explorerUrl - The explorer URL.
 * @returns Normalized values or undefined.
 */
function normalizeTransactionDetails(txHash, explorerUrl) {
    const normalized = {};
    if (txHash !== undefined && txHash !== '') {
        normalized.txHash = txHash;
    }
    if (explorerUrl !== undefined && explorerUrl !== '') {
        normalized.explorerUrl = explorerUrl;
    }
    return normalized;
}
/**
 * Pattern that matches on-chain revert reasons caused by slippage or
 * price constraints. When a revert matches, the error is surfaced as
 * {@link InputError.SLIPPAGE_CONSTRAINT_NOT_MET} (RETRYABLE) instead of
 * a generic simulation-failed / transaction-reverted error.
 *
 * @internal
 */
const SLIPPAGE_REVERT_PATTERN = /slippage|lower than the minimum required|less than the initial balance|minimum.?output|price.?impact|stop.?limit|InsufficientOutput|InsufficientFinalBalance/i;
/**
 * Handle simulation / execution revert errors, distinguishing slippage
 * constraint failures from generic reverts and simulation failures.
 *
 * @internal
 */
function parseRevertError(msg, error, context) {
    const reason = extractRevertReason(msg, error) ?? 'Transaction reverted';
    if (SLIPPAGE_REVERT_PATTERN.test(reason)) {
        return new KitError({
            ...InputError.SLIPPAGE_CONSTRAINT_NOT_MET,
            recoverability: 'RETRYABLE',
            message: `Transaction on ${context.chain} reverted: "${reason}". ` +
                'Try increasing slippageBps or adjusting stopLimit.',
            cause: { trace: { rawError: error, chain: context.chain, reason } },
        });
    }
    if (/simulation failed/i.test(msg) || context.operation === 'simulation') {
        return createSimulationFailedError(context.chain, reason, {
            rawError: error,
        });
    }
    const { txHash, explorerUrl } = normalizeTransactionDetails(context.txHash, context.explorerUrl);
    return createTransactionRevertedError(context.chain, reason, { rawError: error }, txHash, explorerUrl);
}
/**
 * Parses raw blockchain errors into structured KitError instances.
 *
 * This function uses pattern matching to identify common blockchain error
 * types and converts them into standardized KitError format. It handles
 * errors from viem, ethers, Solana web3.js, and other blockchain libraries.
 *
 * The parser recognizes 6 main error patterns:
 * 1. Insufficient balance errors
 * 2. Simulation/execution reverted errors
 * 3. Gas-related errors
 * 4. Network connectivity errors
 * 5. RPC provider errors
 * 6. Transaction size limit errors
 *
 * When errors don't match known patterns, the parser uses operation context
 * (e.g., 'simulation', 'estimateGas') to categorize them appropriately.
 * Unrecognized errors without context are categorized as UNKNOWN_BLOCKCHAIN_ERROR.
 *
 * @param error - The raw error from the blockchain library
 * @param context - Context information including chain and optional token
 * @returns A structured KitError instance
 *
 * @example
 * ```typescript
 * import { parseBlockchainError } from '@core/errors'
 *
 * try {
 *   await walletClient.sendTransaction(...)
 * } catch (error) {
 *   throw parseBlockchainError(error, {
 *     chain: 'Ethereum',
 *     token: 'USDC',
 *     operation: 'transfer'
 *   })
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Minimal usage
 * try {
 *   await connection.sendTransaction(...)
 * } catch (error) {
 *   throw parseBlockchainError(error, { chain: 'Solana' })
 * }
 * ```
 *
 * @example
 * ```typescript
 * // With transaction hash and explorer URL
 * import { buildExplorerUrl } from '@core/utils'
 * import { Ethereum } from '@core/chains'
 *
 * try {
 *   const txHash = await walletClient.sendTransaction(...)
 *   await waitForTransaction(txHash)
 * } catch (error) {
 *   const explorerUrl = buildExplorerUrl(Ethereum, txHash)
 *   throw parseBlockchainError(error, {
 *     chain: 'Ethereum',
 *     txHash,
 *     explorerUrl
 *   })
 * }
 * ```
 */
function parseBlockchainError(error, context) {
    const msg = extractMessage(error);
    const token = context.token ?? 'token';
    // Pattern 0: Insufficient native gas token errors
    // Must run BEFORE the generic balance pattern because RPC messages like
    // "insufficient funds for gas * price + value" and "insufficient funds
    // for intrinsic transaction cost" contain "insufficient funds" which
    // would otherwise match the token balance pattern below.
    if (/insufficient funds for (gas|intrinsic transaction cost)|sender doesn't have enough funds to send tx/i.test(msg)) {
        return createInsufficientGasError(context.chain, undefined, {
            rawError: error,
        });
    }
    // Pattern 1: Insufficient token balance errors
    // Matches balance-related errors from ERC20 contracts, native transfers, and Solana programs
    if (/transfer amount exceeds balance|insufficient (balance|funds)|burn amount exceeded/i.test(msg)) {
        return createInsufficientTokenBalanceError(context.chain, token, {
            rawError: error,
        });
    }
    // Pattern 1b: Gateway-specific contract reverts
    // Matched before the generic simulation/revert pattern so the error
    // messages are actionable rather than opaque hex selectors.
    const gatewayError = parseGatewayContractError(msg, context, error);
    if (gatewayError !== null) {
        return gatewayError;
    }
    // Pattern 2: Simulation and execution reverts
    // Matches contract revert errors and simulation failures
    if (/execution reverted|simulation failed|transaction reverted|transaction failed/i.test(msg)) {
        return parseRevertError(msg, error, context);
    }
    // Pattern 3: Gas-related errors
    // Matches gas estimation failures and gas exhaustion
    // Check specific patterns first, then generic "gas" patterns
    // Gas estimation failures are RPC issues
    if (/gas estimation failed|cannot estimate gas/i.test(msg)) {
        return createRpcEndpointError(context.chain, { rawError: error });
    }
    // Gas exhaustion errors
    // Use specific patterns without wildcards to avoid ReDoS
    if (/out of gas|gas limit exceeded|exceeds block gas limit/i.test(msg)) {
        const { txHash, explorerUrl } = normalizeTransactionDetails(context.txHash, context.explorerUrl);
        return createOutOfGasError(context.chain, { rawError: error }, txHash, explorerUrl);
    }
    // Pattern 4: Network connectivity errors
    // Matches connection failures, DNS errors, and timeouts
    if (/connection (refused|failed)|network|timeout|ENOTFOUND|ECONNREFUSED/i.test(msg)) {
        return createNetworkConnectionError(context.chain, { rawError: error });
    }
    // Pattern 5: RPC provider errors
    // Matches RPC endpoint errors, invalid responses, rate limits, and
    // transient JSON-RPC internal errors (e.g. ethers.js "could not coalesce error").
    // Note: "internal error" alone is too broad — contracts like USDT emit
    // "An internal error was received" for on-chain assertion failures.
    // We require JSON-RPC context (codes -32603/-32000) instead.
    if (/rpc|invalid response|rate limit|too many requests|could not coalesce|no response|server error|json-rpc\s+internal|internal json-rpc|-32603|-32000/i.test(msg)) {
        return createRpcEndpointError(context.chain, { rawError: error });
    }
    // Pattern 6: Transaction size limit errors
    // Matches transaction size errors from various blockchains:
    // - Solana: "transaction too large: max: encoded/raw 1644/1232"
    // - Generic: "transaction exceeds size limit", "max transaction size"
    // Split into two checks to reduce regex complexity for SonarQube
    const isSizeError = /transaction (?:too large|exceeds size limit|size exceeds)|encoded\/raw\s+\d+\/\d+|max transaction size/i.test(msg) || /(?:tx|transaction) size is too big:\s*\d+,\s*max:\s*\d+/i.test(msg);
    if (isSizeError) {
        return createTransactionTooLargeError(context.chain, error);
    }
    // Fallback based on operation context
    // Gas-related operations are RPC calls
    if (context.operation === 'estimateGas' ||
        context.operation === 'getGasPrice') {
        return createRpcEndpointError(context.chain, { rawError: error });
    }
    // Simulation operations that don't match standard patterns should still be
    // categorized as simulation failures. This handles cases where blockchain
    // libraries throw generic errors (e.g., "fail", "error") during staticCall
    // operations without descriptive messages. The operation context is authoritative
    // about what was being attempted, even when error messages are unclear.
    //
    // Example: ethers.js staticCall rejection with message "fail"
    //   - Message doesn't match /execution reverted|simulation failed/
    //   - But context.operation === 'simulation' tells us it was a simulation
    //   - Result: SIMULATION_FAILED (accurate) vs UNKNOWN_BLOCKCHAIN_ERROR (misleading)
    if (context.operation === 'simulation') {
        return createSimulationFailedError(context.chain, msg.length > 0 ? msg : 'Simulation failed', { rawError: error });
    }
    // Final fallback for truly unrecognized errors
    // Only errors that don't match any pattern AND lack operation context
    // are categorized as unknown.
    return createUnknownBlockchainError(context.chain, msg.length > 0 ? msg : 'Unknown error', { rawError: error });
}
/**
 * Type guard to check if error has Solana-Kit structure with logs.
 *
 * Checks if the error object contains a context with logs array,
 * which is the structure used by Solana Kit errors.
 *
 * @param error - Unknown error to check
 * @returns True if error has Solana-Kit logs structure
 */
function hasSolanaLogs(error) {
    return (error !== null &&
        typeof error === 'object' &&
        'context' in error &&
        error.context !== null &&
        typeof error.context === 'object' &&
        'logs' in error.context &&
        Array.isArray(error.context.logs));
}
/**
 * Extracts a human-readable error message from various error types.
 *
 * Handles Error objects, string errors, objects with message properties,
 * Solana-Kit errors with context logs, and falls back to string representation.
 * For Solana-Kit errors, extracts Anchor error messages from transaction logs.
 *
 * @param error - Unknown error to extract message from
 * @returns Extracted error message string
 *
 * @example
 * ```typescript
 * const msg1 = extractMessage(new Error('test'))  // 'test'
 * const msg2 = extractMessage('string error')     // 'string error'
 * const msg3 = extractMessage({ message: 'obj' }) // 'obj'
 * ```
 */
function extractMessage(error) {
    // Check for Solana-Kit errors with context.logs
    if (hasSolanaLogs(error)) {
        // Extract Anchor error message from logs
        const anchorLog = error.context.logs.find((log) => log.includes('AnchorError') || log.includes('Error Message'));
        if (anchorLog !== undefined) {
            // Return the anchor error log which contains the detailed message
            return anchorLog;
        }
    }
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    if (typeof error === 'object' && error !== null && 'message' in error) {
        return String(error.message);
    }
    return String(error);
}
/**
 * Mapping of custom error selectors to human-readable error names.
 *
 * These selectors correspond to custom errors from the contracts.
 * When a transaction reverts with a custom error, the 4-byte selector
 * (first 4 bytes of keccak256 of the error signature) is included in the error message.
 *
 */
const CUSTOM_ERROR_SELECTORS = {
    '0xd93c0665': 'This contract is currently paused', // EnforcedPause()
    '0x3ee5aeb5': 'Security check failed due to a reentrancy attempt', // ReentrancyGuardReentrantCall()
    '0x8baa579f': 'The provided signature is invalid or could not be verified', // InvalidSignature()
    '0x1ab7da6b': 'This request has expired', // DeadlineExpired()
    '0x64eee62e': 'No instructions provided', // EmptyInstructions()
    '0x3c46992e': 'Too many execution steps were provided', // TooManyInstructions()
    '0xe066e60e': 'Exceeds maximum token inputs limit', // TooManyTokenInputs()
    '0x5566df5c': 'The beneficiary address is invalid', // InvalidBeneficiary()
    '0xf41d7bc6': 'Execution ID already used', // ExecIdUsed()
    '0x948726e2': 'The account balance does not meet the required minimum', // InvalidBalanceState()
    '0x01aa0452': 'The permit type provided is not supported', // UnsupportedPermitType()
    '0x13be252b': 'Token approval failed and the allowance is insufficient', // InsufficientAllowance()
    '0x5274afe7': 'Token transfer or approval failed', // SafeERC20FailedOperation(address)
    '0x00bc1dcb': 'One of the execution targets is invalid', // InvalidInstruction(uint256)
    '0x5d693841': 'Cannot approve a zero address or a native token', // InvalidApprovalConfig(uint256)
    '0x3ec5cfe1': 'Cannot validate output for a zero address token', // InvalidOutputConfig(uint256)
    '0x492fd70e': 'Instruction call failed without revert data', // ExecutionFailed(uint256)
    '0xba235e1a': 'The received token amount is lower than the minimum required', // InsufficientOutput(uint256,address,uint256,uint256)
    '0x9147d463': 'Final balance is less than the initial balance', // InsufficientFinalBalance(address,uint256,uint256)
    '0xf4b3b1bc': 'Native token transfer to the beneficiary failed', // NativeTransferFailed()
};
/**
 * Attempts to extract an error selector from an error object or message.
 *
 * Checks multiple sources in priority order:
 * 1. `error.data` field
 * 2. Message pattern: "custom error 0x8baa579f"
 *
 * @param msg - The error message
 * @param error - The error object (optional)
 * @returns The 4 bytes selector , or undefined if not found
 */
function extractErrorSelector(msg, error) {
    // Check error.data field
    if (error !== null && typeof error === 'object' && 'data' in error) {
        if (typeof error.data === 'string' && /^0x[0-9a-f]{8}$/i.test(error.data)) {
            return error.data.toLowerCase();
        }
    }
    // Check for "custom error 0x8baa579f" in the message
    const match = /custom error (0x[0-9a-f]{8})\b/i.exec(msg);
    const selector = match?.[1];
    if (selector !== undefined && selector.length > 0) {
        return selector.toLowerCase();
    }
    return undefined;
}
/**
 * Extracts the revert reason from an error message and error object.
 *
 * Attempts to parse out the meaningful reason from execution revert errors,
 * removing common prefixes like "execution reverted:" or "reverted:".
 * If the error contains a custom error selector, it will be resolved to its
 * human-readable description with the selector included for developer reference.
 *
 * Supports multiple error formats:
 * - Custom error with selector in `error.data` field (e.g., `{ data: "0x8baa579f", ... }`)
 * - Message with selector pattern: `"Execution reverted with reason: custom error 0x8baa579f"`
 * - Standard revert: `"execution reverted: Insufficient funds"`
 *
 * @param msg - The error message to extract from
 * @param error - The full error object (optional, used to extract selector from `data` field)
 * @returns The extracted revert reason, or null if not found
 *
 * @example
 * ```typescript
 * const reason = extractRevertReason(
 *   'execution reverted: ERC20: transfer amount exceeds balance'
 * )
 * // Returns: 'ERC20: transfer amount exceeds balance'
 * ```
 *
 * @example
 * ```typescript
 * const reason = extractRevertReason(
 *   'Simulation failed: Execution reverted with reason: Insufficient allowance'
 * )
 * // Returns: 'Insufficient allowance'
 * ```
 *
 * @example
 * ```typescript
 * // Custom error with selector in message
 * const reason = extractRevertReason(
 *   'Execution reverted with reason: custom error 0x8baa579f'
 * )
 * // Returns: 'The provided signature is invalid or could not be verified (0x8baa579f)'
 * ```
 *
 * @example
 * ```typescript
 * // Error with data field
 * const reason = extractRevertReason(
 *   'execution reverted (unknown custom error)',
 *   { data: '0x8baa579f' }
 * )
 * // Returns: 'The provided signature is invalid or could not be verified (0x8baa579f)'
 * ```
 *
 * @example
 * ```typescript
 * // Unrecognized selector preserved for debugging
 * const reason = extractRevertReason(
 *   'execution reverted (unknown custom error)',
 *   { data: '0xdeadbeef' }
 * )
 * // Returns: 'Transaction reverted with error (0xdeadbeef)'
 * ```
 */
function extractRevertReason(msg, error) {
    // Try to extract and decode custom error selector
    const selector = extractErrorSelector(msg, error);
    if (selector !== undefined) {
        const errorMessage = CUSTOM_ERROR_SELECTORS[selector];
        if (errorMessage !== undefined) {
            return `${errorMessage} (${selector})`;
        }
    }
    // Try to extract reason after "execution reverted:" or "reason:"
    // Use [^\n.]+ instead of .+? to avoid ReDoS vulnerability
    // Fall back to standard revert reason extraction
    const patterns = [
        /(?:execution reverted|reverted):\s*([^\n.]+)/i,
        /reason:\s*([^\n.]+)/i,
        /with reason:\s*([^\n.]+)/i,
    ];
    for (const pattern of patterns) {
        const match = pattern.exec(msg);
        const extractedReason = match?.at(1);
        if (extractedReason !== undefined && extractedReason.length > 0) {
            return extractedReason.trim();
        }
    }
    // Preserve unrecognized selector so it appears in error output for debugging
    if (selector !== undefined) {
        return `Transaction reverted with error (${selector})`;
    }
    return null;
}
/**
 * Parses Gateway smart-contract revert selectors into specific KitError types.
 *
 * Returns `null` when the message does not match any known Gateway revert,
 * allowing the caller to fall through to generic patterns.
 *
 * @param msg - The extracted error message string.
 * @param context - Parse error context (chain, token, operation).
 * @param error - The original raw error for the trace payload.
 * @returns A KitError if a Gateway pattern matched, otherwise `null`.
 *
 * @internal Called by {@link parseBlockchainError} — not re-exported from
 *   the `@core/errors` barrel.
 *
 * @example
 * ```typescript
 * // Internal usage within parseBlockchainError:
 * import { parseGatewayContractError } from './parseBlockchainError'
 *
 * const gatewayError = parseGatewayContractError(
 *   'execution reverted: WithdrawalValueExceedsAvailableBalance',
 *   { chain: 'Ethereum', token: 'USDC', operation: 'withdraw' },
 *   new Error('execution reverted'),
 * )
 * if (gatewayError !== null) {
 *   // KitError with INSUFFICIENT_TOKEN balance details
 *   console.log(gatewayError.message)
 * }
 *
 * // Returns null for unrecognised reverts (caller falls through to generic parsing)
 * const unknown = parseGatewayContractError(
 *   'execution reverted: SomeUnknownError()',
 *   { chain: 'Base', token: 'USDC', operation: 'deposit' },
 *   new Error('execution reverted'),
 * )
 * console.log(unknown) // null
 * ```
 */
function parseGatewayContractError(msg, context, error) {
    const token = context.token ?? 'token';
    if (/WithdrawalValueExceedsAvailableBalance|InsufficientDepositBalance/i.test(msg)) {
        return createInsufficientTokenBalanceError(context.chain, token, {
            rawError: error,
        });
    }
    if (/WithdrawalNotYetAvailable|WithdrawalDelayNotElapsed/i.test(msg)) {
        return createTransactionRevertedError(context.chain, 'Withdrawal is not yet available — the withdrawal delay has not elapsed', { rawError: error });
    }
    if (/NoWithdrawingBalance/i.test(msg)) {
        return createTransactionRevertedError(context.chain, 'No pending withdrawal balance — call initiateWithdrawal() first', { rawError: error });
    }
    return null;
}

/**
 * Type guard to check if an error is a KitError instance.
 *
 * This guard enables TypeScript to narrow the type from `unknown` to
 * `KitError`, providing access to structured error properties like
 * code, name, and recoverability.
 *
 * @param error - Unknown error to check
 * @returns True if error is KitError with proper type narrowing
 *
 * @example
 * ```typescript
 * import { isKitError } from '@core/errors'
 *
 * try {
 *   await kit.bridge(params)
 * } catch (error) {
 *   if (isKitError(error)) {
 *     // TypeScript knows this is KitError
 *     console.log(`Structured error: ${error.name} (${error.code})`)
 *   } else {
 *     console.log('Regular error:', error)
 *   }
 * }
 * ```
 */
function isKitError(error) {
    return error instanceof KitError;
}
/**
 * Safely extracts error message from any error type.
 *
 * This utility handles different error types gracefully, extracting
 * meaningful messages from Error instances, string errors, or providing
 * a fallback for unknown error types. Never throws.
 *
 * @param error - Unknown error to extract message from
 * @returns Error message string, or fallback message
 *
 * @example
 * ```typescript
 * import { getErrorMessage } from '@core/errors'
 *
 * try {
 *   await riskyOperation()
 * } catch (error) {
 *   const message = getErrorMessage(error)
 *   console.log('Error occurred:', message)
 *   // Works with Error, KitError, string, or any other type
 * }
 * ```
 */
function getErrorMessage(error) {
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    if (typeof error === 'object' && error !== null && 'message' in error) {
        return String(error.message);
    }
    return 'An unknown error occurred';
}
/**
 * Extract structured error information for logging and events.
 *
 * @remarks
 * Safely extracts error information from any thrown value, handling:
 * - KitError objects (message preserved - safe to log)
 * - Standard Error objects (message redacted for security)
 * - Plain objects with name/message/code (message redacted)
 * - Primitive values (logged as-is since they contain no structured data)
 *
 * For security, only KitError messages are included. Other error messages are
 * redacted to prevent logging sensitive data like tokens or PII.
 *
 * @param error - The error to extract info from.
 * @returns Structured error information.
 *
 * @example
 * ```typescript
 * import { extractErrorInfo } from '@core/errors'
 *
 * // Standard Error - message is redacted for security
 * const info1 = extractErrorInfo(new Error('Something went wrong'))
 * // { name: 'Error', message: 'An error occurred. See error name and code for details.' }
 *
 * // KitError - message is preserved (safe type)
 * const error = createNetworkConnectionError('Ethereum')
 * const info2 = extractErrorInfo(error)
 * // { name: 'NETWORK_CONNECTION_FAILED', message: 'Network connection failed for Ethereum', code: 3001 }
 *
 * // Primitive value - logged as-is
 * const info3 = extractErrorInfo('string error')
 * // { name: 'UnknownError', message: 'string error' }
 * ```
 */
function extractErrorInfo(error) {
    if (error === null || typeof error !== 'object') {
        return {
            name: 'UnknownError',
            message: String(error),
        };
    }
    const err = error;
    // Only preserve messages for KitError instances (safe type)
    // For other errors, redact message for security
    const errorMessage = isKitError(error)
        ? getErrorMessage(error)
        : 'An error occurred. See error name and code for details.';
    const info = {
        name: err.name ?? 'UnknownError',
        message: errorMessage,
    };
    if (typeof err.code === 'number') {
        info.code = err.code;
    }
    if (isKitError(error)) {
        info.type = error.type;
    }
    return info;
}

/**
 * Validates if an address format is correct for the specified chain.
 *
 * This function checks the explicit chain `type` property first, then falls back
 * to name-based matching to determine whether to validate as a Solana or EVM address.
 *
 * @param address - The address to validate
 * @param chain - The chain identifier or chain definition (cannot be null)
 * @returns True if the address format is valid for the chain, false otherwise
 *
 * @example
 * ```typescript
 * import { isValidAddressForChain } from '@core/errors'
 *
 * // EVM address validation
 * isValidAddressForChain('0x742d35Cc6634C0532925a3b8D0C0C1C4C5C6C7C8', 'Ethereum')
 * // → true
 *
 * // Solana address validation
 * isValidAddressForChain('9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM', { name: 'Solana', type: 'solana' })
 * // → true
 *
 * // Invalid format
 * isValidAddressForChain('invalid', 'Ethereum')
 * // → false
 * ```
 */
function isValidAddressForChain(address, chain) {
    const chainType = typeof chain === 'object' ? chain.type : undefined;
    const name = typeof chain === 'string' ? chain : chain.name;
    // Use explicit chain type if available, fallback to name matching
    const isSolana = chainType !== undefined
        ? chainType === 'solana'
        : name.toLowerCase().includes('solana');
    if (isSolana) {
        // Solana base58 address: 32-44 characters from base58 alphabet
        return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address);
    }
    // EVM hex address: 0x followed by 40 hex characters
    return /^0x[a-fA-F0-9]{40}$/.test(address);
}

// -----------------------------------------------------------------------------
// Blockchain Enum
// -----------------------------------------------------------------------------
/**
 * Enumeration of all blockchains known to this library.
 *
 * This enum contains every blockchain that has a chain definition, regardless
 * of whether bridging is currently supported. For chains that support bridging
 * via CCTPv2, see {@link BridgeChain}.
 *
 * @enum
 * @category Enums
 * @description Provides string identifiers for each blockchain with a definition.
 * @see {@link BridgeChain} for the subset of chains that support CCTPv2 bridging.
 */
var Blockchain;
(function (Blockchain) {
    Blockchain["Algorand"] = "Algorand";
    Blockchain["Algorand_Testnet"] = "Algorand_Testnet";
    Blockchain["Aptos"] = "Aptos";
    Blockchain["Aptos_Testnet"] = "Aptos_Testnet";
    Blockchain["Arc_Testnet"] = "Arc_Testnet";
    Blockchain["Arbitrum"] = "Arbitrum";
    Blockchain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    Blockchain["Avalanche"] = "Avalanche";
    Blockchain["Avalanche_Fuji"] = "Avalanche_Fuji";
    Blockchain["Base"] = "Base";
    Blockchain["Base_Sepolia"] = "Base_Sepolia";
    Blockchain["Celo"] = "Celo";
    Blockchain["Celo_Alfajores_Testnet"] = "Celo_Alfajores_Testnet";
    Blockchain["Codex"] = "Codex";
    Blockchain["Codex_Testnet"] = "Codex_Testnet";
    Blockchain["Edge"] = "Edge";
    Blockchain["Edge_Testnet"] = "Edge_Testnet";
    Blockchain["Ethereum"] = "Ethereum";
    Blockchain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    Blockchain["Hedera"] = "Hedera";
    Blockchain["Hedera_Testnet"] = "Hedera_Testnet";
    Blockchain["HyperEVM"] = "HyperEVM";
    Blockchain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    Blockchain["Injective"] = "Injective";
    Blockchain["Injective_Testnet"] = "Injective_Testnet";
    Blockchain["Ink"] = "Ink";
    Blockchain["Ink_Testnet"] = "Ink_Testnet";
    Blockchain["Linea"] = "Linea";
    Blockchain["Linea_Sepolia"] = "Linea_Sepolia";
    Blockchain["Monad"] = "Monad";
    Blockchain["Monad_Testnet"] = "Monad_Testnet";
    Blockchain["Morph"] = "Morph";
    Blockchain["Morph_Testnet"] = "Morph_Testnet";
    Blockchain["NEAR"] = "NEAR";
    Blockchain["NEAR_Testnet"] = "NEAR_Testnet";
    Blockchain["Noble"] = "Noble";
    Blockchain["Noble_Testnet"] = "Noble_Testnet";
    Blockchain["Optimism"] = "Optimism";
    Blockchain["Optimism_Sepolia"] = "Optimism_Sepolia";
    Blockchain["Pharos"] = "Pharos";
    Blockchain["Pharos_Testnet"] = "Pharos_Testnet";
    Blockchain["Polkadot_Asset_Hub"] = "Polkadot_Asset_Hub";
    Blockchain["Polkadot_Westmint"] = "Polkadot_Westmint";
    Blockchain["Plume"] = "Plume";
    Blockchain["Plume_Testnet"] = "Plume_Testnet";
    Blockchain["Polygon"] = "Polygon";
    Blockchain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    Blockchain["Sei"] = "Sei";
    Blockchain["Sei_Testnet"] = "Sei_Testnet";
    Blockchain["Solana"] = "Solana";
    Blockchain["Solana_Devnet"] = "Solana_Devnet";
    Blockchain["Sonic"] = "Sonic";
    Blockchain["Sonic_Testnet"] = "Sonic_Testnet";
    Blockchain["Stellar"] = "Stellar";
    Blockchain["Stellar_Testnet"] = "Stellar_Testnet";
    Blockchain["Sui"] = "Sui";
    Blockchain["Sui_Testnet"] = "Sui_Testnet";
    Blockchain["Unichain"] = "Unichain";
    Blockchain["Unichain_Sepolia"] = "Unichain_Sepolia";
    Blockchain["World_Chain"] = "World_Chain";
    Blockchain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
    Blockchain["XDC"] = "XDC";
    Blockchain["XDC_Apothem"] = "XDC_Apothem";
    Blockchain["ZKSync_Era"] = "ZKSync_Era";
    Blockchain["ZKSync_Sepolia"] = "ZKSync_Sepolia";
})(Blockchain || (Blockchain = {}));
/**
 * Enum representing the subset of {@link Blockchain} that supports swap operations.
 *
 * This enum provides compile-time type safety for swap chain selection,
 * ensuring only supported chains are available in IDE autocomplete
 * when building swap parameters.
 *
 * @remarks
 * Unlike the full {@link Blockchain} enum, SwapChain only includes networks
 * where the swap functionality is actively supported by the library.
 * Using this enum prevents runtime errors from attempting unsupported
 * cross-chain swaps.
 *
 * Currently supports:
 * - Ethereum mainnet
 * - Base mainnet
 * - Polygon mainnet
 * - Solana mainnet
 *
 * @example
 * ```typescript
 * import { SwapChain, swap, createSwapKitContext } from '@circle-fin/swap-kit'
 * import { createViemAdapterFromPrivateKey } from '@circle-fin/adapter-viem-v2'
 *
 * const context = createSwapKitContext()
 * const adapter = createViemAdapterFromPrivateKey({
 *   privateKey: process.env.PRIVATE_KEY
 * })
 *
 * // ✅ Autocomplete shows only swap-supported chains
 * const result = await swap(context, {
 *   from: {
 *     adapter,
 *     chain: SwapChain.Ethereum // Autocomplete: Ethereum, Base, Polygon, Solana
 *   },
 *   tokenIn: 'USDC',
 *   tokenOut: 'USDT',
 *   amount: '100.0'
 * })
 * ```
 *
 * @example
 * ```typescript
 * // String literals also work (constrained to SwapChain values)
 * const result = await swap(context, {
 *   from: {
 *     adapter,
 *     chain: 'Ethereum' // ✅ Only SwapChain strings allowed
 *   },
 *   tokenIn: 'USDC',
 *   tokenOut: 'NATIVE',
 *   amount: '50.0'
 * })
 *
 * // ❌ TypeScript error - Sui not in SwapChain enum
 * const invalidResult = await swap(context, {
 *   from: {
 *     adapter,
 *     chain: 'Sui' // Compile-time error!
 *   },
 *   tokenIn: 'USDC',
 *   tokenOut: 'USDT',
 *   amount: '100.0'
 * })
 * ```
 */
/**
 * Enum representing chains that support same-chain swaps through the Swap Kit.
 *
 * Unlike the full {@link Blockchain} enum, SwapChain includes mainnet
 * networks and explicitly whitelisted testnets (e.g., {@link Arc_Testnet})
 * where adapter contracts are deployed (CCTPv2 support).
 *
 * Dynamic validation via {@link isSwapSupportedChain} ensures chains
 * automatically work when adapter contracts and supported tokens are deployed.
 *
 * @example
 * ```typescript
 * import { SwapChain } from '@core/chains'
 * import { swap } from '@circle-fin/swap-kit'
 *
 * const result = await swap(context, {
 *   from: {
 *     adapter,
 *     chain: SwapChain.Arbitrum  // Now supported!
 *   },
 *   tokenIn: 'USDC',
 *   tokenOut: 'WETH',
 *   amount: '100.0'
 * })
 * ```
 *
 * @see {@link isSwapSupportedChain} for runtime validation
 * @see {@link getSwapSupportedChains} for all supported chains
 */
var SwapChain;
(function (SwapChain) {
    // Original 4 chains
    SwapChain["Ethereum"] = "Ethereum";
    SwapChain["Base"] = "Base";
    SwapChain["Polygon"] = "Polygon";
    SwapChain["Solana"] = "Solana";
    // Additional supported chains
    SwapChain["Arbitrum"] = "Arbitrum";
    SwapChain["Optimism"] = "Optimism";
    SwapChain["Avalanche"] = "Avalanche";
    SwapChain["Linea"] = "Linea";
    SwapChain["Ink"] = "Ink";
    SwapChain["World_Chain"] = "World_Chain";
    SwapChain["Unichain"] = "Unichain";
    SwapChain["Plume"] = "Plume";
    SwapChain["Sei"] = "Sei";
    SwapChain["Sonic"] = "Sonic";
    SwapChain["XDC"] = "XDC";
    SwapChain["HyperEVM"] = "HyperEVM";
    SwapChain["Monad"] = "Monad";
    // Testnet chains with swap support
    SwapChain["Arc_Testnet"] = "Arc_Testnet";
})(SwapChain || (SwapChain = {}));
// -----------------------------------------------------------------------------
// Bridge Chain Enum (CCTPv2 Supported Chains)
// -----------------------------------------------------------------------------
/**
 * Enumeration of blockchains that support cross-chain bridging via CCTPv2.
 *
 * The enum is derived from the full {@link Blockchain} enum but filtered to only
 * include chains with active CCTPv2 support. When new chains gain CCTPv2 support,
 * they are added to this enum.
 *
 * @enum
 * @category Enums
 *
 * @remarks
 * - This enum is the **canonical source** of bridging-supported chains.
 * - Use this enum (or its string literals) in `kit.bridge()` calls for type safety.
 * - Attempting to use a chain not in this enum will produce a TypeScript compile error.
 *
 * @example
 * ```typescript
 * import { BridgeKit, BridgeChain } from '@circle-fin/bridge-kit'
 *
 * const kit = new BridgeKit()
 *
 * // ✅ Valid - autocomplete suggests only supported chains
 * await kit.bridge({
 *   from: { adapter, chain: BridgeChain.Ethereum },
 *   to: { adapter, chain: BridgeChain.Base },
 *   amount: '100'
 * })
 *
 * // ✅ Also valid - string literals work with autocomplete
 * await kit.bridge({
 *   from: { adapter, chain: 'Ethereum_Sepolia' },
 *   to: { adapter, chain: 'Base_Sepolia' },
 *   amount: '100'
 * })
 *
 * // ❌ Compile error - Algorand is not in BridgeChain
 * await kit.bridge({
 *   from: { adapter, chain: 'Algorand' }, // TypeScript error!
 *   to: { adapter, chain: 'Base' },
 *   amount: '100'
 * })
 * ```
 *
 * @see {@link Blockchain} for the complete list of all known blockchains.
 * @see {@link BridgeChainIdentifier} for the type that accepts these values.
 */
var BridgeChain;
(function (BridgeChain) {
    // Mainnet chains with CCTPv2 support
    BridgeChain["Arbitrum"] = "Arbitrum";
    BridgeChain["Avalanche"] = "Avalanche";
    BridgeChain["Base"] = "Base";
    BridgeChain["Codex"] = "Codex";
    BridgeChain["Edge"] = "Edge";
    BridgeChain["Ethereum"] = "Ethereum";
    BridgeChain["HyperEVM"] = "HyperEVM";
    BridgeChain["Injective"] = "Injective";
    BridgeChain["Ink"] = "Ink";
    BridgeChain["Linea"] = "Linea";
    BridgeChain["Monad"] = "Monad";
    BridgeChain["Morph"] = "Morph";
    BridgeChain["Optimism"] = "Optimism";
    BridgeChain["Pharos"] = "Pharos";
    BridgeChain["Plume"] = "Plume";
    BridgeChain["Polygon"] = "Polygon";
    BridgeChain["Sei"] = "Sei";
    BridgeChain["Solana"] = "Solana";
    BridgeChain["Sonic"] = "Sonic";
    BridgeChain["Unichain"] = "Unichain";
    BridgeChain["World_Chain"] = "World_Chain";
    BridgeChain["XDC"] = "XDC";
    // Testnet chains with CCTPv2 support
    BridgeChain["Arc_Testnet"] = "Arc_Testnet";
    BridgeChain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    BridgeChain["Avalanche_Fuji"] = "Avalanche_Fuji";
    BridgeChain["Base_Sepolia"] = "Base_Sepolia";
    BridgeChain["Codex_Testnet"] = "Codex_Testnet";
    BridgeChain["Edge_Testnet"] = "Edge_Testnet";
    BridgeChain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    BridgeChain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    BridgeChain["Injective_Testnet"] = "Injective_Testnet";
    BridgeChain["Ink_Testnet"] = "Ink_Testnet";
    BridgeChain["Linea_Sepolia"] = "Linea_Sepolia";
    BridgeChain["Monad_Testnet"] = "Monad_Testnet";
    BridgeChain["Morph_Testnet"] = "Morph_Testnet";
    BridgeChain["Optimism_Sepolia"] = "Optimism_Sepolia";
    BridgeChain["Pharos_Testnet"] = "Pharos_Testnet";
    BridgeChain["Plume_Testnet"] = "Plume_Testnet";
    BridgeChain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    BridgeChain["Sei_Testnet"] = "Sei_Testnet";
    BridgeChain["Solana_Devnet"] = "Solana_Devnet";
    BridgeChain["Sonic_Testnet"] = "Sonic_Testnet";
    BridgeChain["Unichain_Sepolia"] = "Unichain_Sepolia";
    BridgeChain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
    BridgeChain["XDC_Apothem"] = "XDC_Apothem";
})(BridgeChain || (BridgeChain = {}));
// -----------------------------------------------------------------------------
// Unified Balance Chain Enum (Gateway V1 Supported Chains)
// -----------------------------------------------------------------------------
/**
 * Enumeration of blockchains that support Gateway V1 operations
 * (deposit, spend, balance, delegate, removeFund).
 *
 * Derived from the full {@link Blockchain} enum but filtered to only
 * include chains with active Gateway V1 contract support. When new chains
 * gain Gateway V1 support, they are added to this enum.
 *
 * @enum
 * @category Enums
 *
 * @remarks
 * - This enum is the **canonical source** of Gateway-supported chains.
 * - Use this enum (or its string literals) in unified-balance-kit calls
 *   for type safety.
 *
 * @see {@link Blockchain} for the complete list of all known blockchains.
 * @see {@link UnifiedBalanceChainIdentifier} for the type that accepts these values.
 */
var UnifiedBalanceChain;
(function (UnifiedBalanceChain) {
    // Mainnet chains with Gateway V1 support
    UnifiedBalanceChain["Arbitrum"] = "Arbitrum";
    UnifiedBalanceChain["Avalanche"] = "Avalanche";
    UnifiedBalanceChain["Base"] = "Base";
    UnifiedBalanceChain["Ethereum"] = "Ethereum";
    UnifiedBalanceChain["HyperEVM"] = "HyperEVM";
    UnifiedBalanceChain["Optimism"] = "Optimism";
    UnifiedBalanceChain["Polygon"] = "Polygon";
    UnifiedBalanceChain["Sei"] = "Sei";
    UnifiedBalanceChain["Solana"] = "Solana";
    UnifiedBalanceChain["Sonic"] = "Sonic";
    UnifiedBalanceChain["Unichain"] = "Unichain";
    UnifiedBalanceChain["World_Chain"] = "World_Chain";
    // Testnet chains with Gateway V1 support
    UnifiedBalanceChain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    UnifiedBalanceChain["Arc_Testnet"] = "Arc_Testnet";
    UnifiedBalanceChain["Avalanche_Fuji"] = "Avalanche_Fuji";
    UnifiedBalanceChain["Base_Sepolia"] = "Base_Sepolia";
    UnifiedBalanceChain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    UnifiedBalanceChain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    UnifiedBalanceChain["Optimism_Sepolia"] = "Optimism_Sepolia";
    UnifiedBalanceChain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    UnifiedBalanceChain["Sei_Testnet"] = "Sei_Testnet";
    UnifiedBalanceChain["Solana_Devnet"] = "Solana_Devnet";
    UnifiedBalanceChain["Sonic_Testnet"] = "Sonic_Testnet";
    UnifiedBalanceChain["Unichain_Sepolia"] = "Unichain_Sepolia";
    UnifiedBalanceChain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
})(UnifiedBalanceChain || (UnifiedBalanceChain = {}));
// Earn Chain Enum
// -----------------------------------------------------------------------------
/**
 * Enumeration of blockchains that support earn (vault deposit/withdraw)
 * operations through the Earn Kit.
 *
 * Currently only Ethereum mainnet is supported. Additional chains
 * will be added as vault protocol support expands.
 *
 * @example
 * ```typescript
 * import { EarnChain } from '@core/chains'
 *
 * const result = await earnKit.deposit({
 *   from: { adapter, chain: EarnChain.Ethereum },
 *   vaultAddress: '0x...',
 *   amount: '100',
 * })
 * ```
 */
var EarnChain;
(function (EarnChain) {
    EarnChain["Ethereum"] = "Ethereum";
})(EarnChain || (EarnChain = {}));

/**
 * Helper function to define a chain with proper TypeScript typing.
 *
 * This utility function works with TypeScript's `as const` assertion to create
 * strongly-typed, immutable chain definition objects. It preserves literal types
 * from the input and ensures the resulting object maintains all type information.
 *
 * When used with `as const`, it allows TypeScript to infer the most specific
 * possible types for all properties, including string literals and numeric literals,
 * rather than widening them to general types like string or number.
 * @typeParam T - The specific chain definition type (must extend ChainDefinition)
 * @param chain - The chain definition object, typically with an `as const` assertion
 * @returns The same chain definition with preserved literal types
 * @example
 * ```typescript
 * // Define an EVM chain with literal types preserved
 * const Ethereum = defineChain({
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   name: 'Ethereum',
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   usdcAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   eurcAddress: null,
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       TokenMessengerV1: '0xbd3fa81b58ba92a82136038b25adec7066af3155',
 *       MessageTransmitterV1: '0x0a992d191deec32afe36203ad87d7d289a738f81'
 *     }
 *   }
 * } as const);
 * ```
 */
function defineChain(chain) {
    return chain;
}

/**
 * Algorand Mainnet chain definition
 * @remarks
 * This represents the official production network for the Algorand blockchain.
 */
const Algorand = defineChain({
    type: 'algorand',
    chain: Blockchain.Algorand,
    name: 'Algorand',
    title: 'Algorand Mainnet',
    nativeCurrency: {
        name: 'Algo',
        symbol: 'ALGO',
        decimals: 6,
    },
    isTestnet: false,
    explorerUrl: 'https://explorer.perawallet.app/tx/{hash}',
    rpcEndpoints: ['https://mainnet-api.algonode.cloud'],
    eurcAddress: null,
    usdcAddress: '31566704',
    usdtAddress: null,
    cctp: null,
});

/**
 * Algorand Testnet chain definition
 * @remarks
 * This represents the official testnet for the Algorand blockchain.
 */
const AlgorandTestnet = defineChain({
    type: 'algorand',
    chain: Blockchain.Algorand_Testnet,
    name: 'Algorand Testnet',
    title: 'Algorand Test Network',
    nativeCurrency: {
        name: 'Algo',
        symbol: 'ALGO',
        decimals: 6,
    },
    isTestnet: true,
    explorerUrl: 'https://testnet.explorer.perawallet.app/tx/{hash}',
    rpcEndpoints: ['https://testnet-api.algonode.cloud'],
    eurcAddress: null,
    usdcAddress: '10458941',
    usdtAddress: null,
    cctp: null,
});

/**
 * Aptos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Aptos blockchain.
 */
const Aptos = defineChain({
    type: 'aptos',
    chain: Blockchain.Aptos,
    name: 'Aptos',
    title: 'Aptos Mainnet',
    nativeCurrency: {
        name: 'Aptos',
        symbol: 'APT',
        decimals: 8,
    },
    isTestnet: false,
    explorerUrl: 'https://explorer.aptoslabs.com/txn/{hash}?network=mainnet',
    rpcEndpoints: ['https://fullnode.mainnet.aptoslabs.com/v1'],
    eurcAddress: null,
    usdcAddress: '0xbae207659db88bea0cbead6da0ed00aac12edcdda169e591cd41c94180b46f3b',
    usdtAddress: '0x357b0b74bc833e95a115ad22604854d6b0fca151cecd94111770e5d6ffc9dc2b',
    cctp: {
        domain: 9,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9bce6734f7b63e835108e3bd8c36743d4709fe435f44791918801d0989640a9d',
                messageTransmitter: '0x177e17751820e4b4371873ca8c30279be63bdea63b88ed0f2239c2eea10f1772',
                confirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
});

/**
 * Aptos Testnet chain definition
 * @remarks
 * This represents the official test network for the Aptos blockchain.
 */
const AptosTestnet = defineChain({
    type: 'aptos',
    chain: Blockchain.Aptos_Testnet,
    name: 'Aptos Testnet',
    title: 'Aptos Test Network',
    nativeCurrency: {
        name: 'Aptos',
        symbol: 'APT',
        decimals: 8,
    },
    isTestnet: true,
    explorerUrl: 'https://explorer.aptoslabs.com/txn/{hash}?network=testnet',
    rpcEndpoints: ['https://fullnode.testnet.aptoslabs.com/v1'],
    eurcAddress: null,
    usdcAddress: '0x69091fbab5f7d635ee7ac5098cf0c1efbe31d68fec0f2cd565e8d168daf52832',
    usdtAddress: null,
    cctp: {
        domain: 9,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x5f9b937419dda90aa06c1836b7847f65bbbe3f1217567758dc2488be31a477b9',
                messageTransmitter: '0x081e86cebf457a0c6004f35bd648a2794698f52e0dde09a48619dcd3d4cc23d9',
                confirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
});

/**
 * Complete swap token registry - single source of truth for all swap-supported tokens.
 *
 * @remarks
 * All packages should import from this registry for swap operations.
 * Adding a new swap token requires updating only this registry.
 *
 * The NATIVE token is handled separately as it resolves dynamically based on chain.
 *
 * @example
 * ```typescript
 * import { SWAP_TOKEN_REGISTRY } from '@core/chains'
 *
 * // Get token decimals
 * const decimals = SWAP_TOKEN_REGISTRY.USDC.decimals  // 6
 *
 * // Check if token is stablecoin
 * const isStable = SWAP_TOKEN_REGISTRY.DAI.category === 'stablecoin'  // true
 * ```
 */
const SWAP_TOKEN_REGISTRY = {
    // ============================================================================
    // Stablecoins (6 decimals)
    // ============================================================================
    USDC: {
        symbol: 'USDC',
        decimals: 6,
        category: 'stablecoin',
        description: 'USD Coin',
    },
    EURC: {
        symbol: 'EURC',
        decimals: 6,
        category: 'stablecoin',
        description: 'Euro Coin',
    },
    USDT: {
        symbol: 'USDT',
        decimals: 6,
        category: 'stablecoin',
        description: 'Tether USD',
    },
    PYUSD: {
        symbol: 'PYUSD',
        decimals: 6,
        category: 'stablecoin',
        description: 'PayPal USD',
    },
    // ============================================================================
    // Stablecoins (18 decimals)
    // ============================================================================
    DAI: {
        symbol: 'DAI',
        decimals: 18,
        category: 'stablecoin',
        description: 'MakerDAO stablecoin',
    },
    USDE: {
        symbol: 'USDE',
        decimals: 18,
        category: 'stablecoin',
        description: 'Ethena USD (synthetic dollar)',
    },
    // ============================================================================
    // Wrapped Tokens
    // ============================================================================
    WBTC: {
        symbol: 'WBTC',
        decimals: 8,
        category: 'wrapped',
        description: 'Wrapped Bitcoin',
    },
    WETH: {
        symbol: 'WETH',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Ethereum',
    },
    WSOL: {
        symbol: 'WSOL',
        decimals: 9,
        category: 'wrapped',
        description: 'Wrapped Solana',
    },
    WAVAX: {
        symbol: 'WAVAX',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Avalanche',
    },
    WPOL: {
        symbol: 'WPOL',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Polygon',
    },
    CIRBTC: {
        symbol: 'CIRBTC',
        decimals: 8,
        category: 'wrapped',
        description: 'Circle Bitcoin',
    },
};
/**
 * Special NATIVE token constant for swap operations.
 *
 * @remarks
 * NATIVE is handled separately from SWAP_TOKEN_REGISTRY because it resolves
 * dynamically based on the chain (ETH on Ethereum, SOL on Solana, etc.).
 * Its decimals are chain-specific.
 */
const NATIVE_TOKEN = 'NATIVE';
/**
 * Array of all supported swap token symbols including NATIVE.
 * Useful for iteration, validation, and filtering.
 */
[
    ...Object.keys(SWAP_TOKEN_REGISTRY),
    NATIVE_TOKEN,
];

/**
 * The bridge contract address for EVM testnet networks.
 *
 * This contract handles USDC transfers on testnet environments across
 * EVM-compatible chains. Use this address when deploying or testing
 * cross-chain USDC transfers on test networks.
 */
const BRIDGE_CONTRACT_EVM_TESTNET = '0xC5567a5E3370d4DBfB0540025078e283e36A363d';
/**
 * The bridge contract address for EVM mainnet networks.
 *
 * This contract handles USDC transfers on mainnet environments across
 * EVM-compatible chains. Use this address for production cross-chain
 * USDC transfers on live networks.
 */
const BRIDGE_CONTRACT_EVM_MAINNET = '0xB3FA262d0fB521cc93bE83d87b322b8A23DAf3F0';
/**
 * The adapter contract address for EVM mainnet networks.
 *
 * This contract serves as an adapter for integrating with various protocols
 * on EVM-compatible chains. Use this address for mainnet adapter integrations.
 */
const ADAPTER_CONTRACT_EVM_MAINNET = '0x7FB8c7260b63934d8da38aF902f87ae6e284a845';
/**
 * The adapter contract address for EVM testnet networks.
 *
 * This contract serves as an adapter for integrating with various protocols
 * on EVM-compatible testnet chains. Use this address for testnet adapter
 * integrations (e.g., Arc Testnet).
 */
const ADAPTER_CONTRACT_EVM_TESTNET = '0xBBD70b01a1CAbc96d5b7b129Ae1AAabdf50dd40b';
/**
 * The GatewayWallet contract address for EVM mainnet networks.
 *
 * This contract manages wallet operations for Gateway transactions
 * on mainnet environments across EVM-compatible chains.
 */
const GATEWAY_WALLET_EVM_MAINNET = '0x77777777Dcc4d5A8B6E418Fd04D8997ef11000eE';
/**
 * The GatewayMinter contract address for EVM mainnet networks.
 *
 * This contract handles minting operations for Gateway transactions
 * on mainnet environments across EVM-compatible chains.
 */
const GATEWAY_MINTER_EVM_MAINNET = '0x2222222d7164433c4C09B0b0D809a9b52C04C205';
/**
 * The GatewayWallet contract address for EVM testnet networks.
 *
 * This contract manages wallet operations for Gateway transactions
 * on testnet environments across EVM-compatible chains.
 */
const GATEWAY_WALLET_EVM_TESTNET = '0x0077777d7EBA4688BDeF3E311b846F25870A19B9';
/**
 * The GatewayMinter contract address for EVM testnet networks.
 *
 * This contract handles minting operations for Gateway transactions
 * on testnet environments across EVM-compatible chains.
 */
const GATEWAY_MINTER_EVM_TESTNET = '0x0022222ABE238Cc2C7Bb1f21003F0a260052475B';
/**
 * The GatewayWallet program address for Solana mainnet.
 *
 * This program manages wallet operations for Gateway transactions
 * on Solana mainnet.
 */
const GATEWAY_WALLET_SOLANA_MAINNET = 'GATEwy4YxeiEbRJLwB6dXgg7q61e6zBPrMzYj5h1pRXQ';
/**
 * The GatewayMinter program address for Solana mainnet.
 *
 * This program handles minting operations for Gateway transactions
 * on Solana mainnet.
 */
const GATEWAY_MINTER_SOLANA_MAINNET = 'GATEm5SoBJiSw1v2Pz1iPBgUYkXzCUJ27XSXhDfSyzVZ';
/**
 * The GatewayWallet program address for Solana devnet.
 *
 * This program manages wallet operations for Gateway transactions
 * on Solana devnet.
 */
const GATEWAY_WALLET_SOLANA_DEVNET = 'GATEwdfmYNELfp5wDmmR6noSr2vHnAfBPMm2PvCzX5vu';
/**
 * The GatewayMinter program address for Solana devnet.
 *
 * This program handles minting operations for Gateway transactions
 * on Solana devnet.
 */
const GATEWAY_MINTER_SOLANA_DEVNET = 'GATEmKK2ECL1brEngQZWCgMWPbvrEYqsV6u29dAaHavr';
/**
 * Circle's fee recipient address for EVM chains.
 *
 * Used by the spend fee-split logic to route Circle's share of custom fees.
 */
const CIRCLE_FEE_RECIPIENT_EVM = '0x19ddF81aAA91dB506f7769b3f285Bd16d77e4DAe';
/**
 * Circle's fee recipient address for Solana.
 *
 * Used by the spend fee-split logic to route Circle's share of custom fees.
 */
const CIRCLE_FEE_RECIPIENT_SOLANA = 'HGMjULXsaMcbXgRhRECkSG3LyiKJgqiNAnLv1zZd8Kpn';

/**
 * Arc Testnet chain definition
 * @remarks
 * This represents the test network for the Arc blockchain,
 * Circle's EVM-compatible Layer-1 designed for stablecoin finance
 * and asset tokenization. Arc uses USDC as the native gas token and
 * features the Malachite Byzantine Fault Tolerant (BFT) consensus
 * engine for sub-second finality.
 */
const ArcTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Arc_Testnet,
    name: 'Arc Testnet',
    title: 'ArcTestnet',
    nativeCurrency: {
        name: 'USDC',
        symbol: 'USDC',
        // Arc uses native USDC with 18 decimals for gas payments (EVM standard).
        // Note: The ERC-20 USDC contract at usdcAddress uses 6 decimals.
        // See: https://docs.arc.network/arc/references/contract-addresses
        decimals: 18,
    },
    chainId: 5042002,
    isTestnet: true,
    explorerUrl: 'https://testnet.arcscan.app/tx/{hash}',
    rpcEndpoints: ['https://rpc.testnet.arc.network/'],
    eurcAddress: '0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a',
    usdcAddress: '0x3600000000000000000000000000000000000000',
    usdtAddress: null,
    cctp: {
        domain: 26,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 26,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Arbitrum Mainnet chain definition
 * @remarks
 * This represents the official production network for the Arbitrum blockchain.
 */
const Arbitrum = defineChain({
    type: 'evm',
    chain: Blockchain.Arbitrum,
    name: 'Arbitrum',
    title: 'Arbitrum Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 42161,
    isTestnet: false,
    explorerUrl: 'https://arbiscan.io/tx/{hash}',
    rpcEndpoints: ['https://arb1.arbitrum.io/rpc'],
    eurcAddress: null,
    usdcAddress: '0xaf88d065e77c8cc2239327c5edb3a432268e5831',
    usdtAddress: null,
    cctp: {
        domain: 3,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x19330d10D9Cc8751218eaf51E8885D058642E08A',
                messageTransmitter: '0xC30362313FBBA5cf9163F0bb16a0e01f01A896ca',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 3,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Arbitrum Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Arbitrum blockchain on Sepolia.
 */
const ArbitrumSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Arbitrum_Sepolia,
    name: 'Arbitrum Sepolia',
    title: 'Arbitrum Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 421614,
    isTestnet: true,
    explorerUrl: 'https://sepolia.arbiscan.io/tx/{hash}',
    rpcEndpoints: ['https://sepolia-rollup.arbitrum.io/rpc'],
    eurcAddress: null,
    usdcAddress: '0x75faf114eafb1BDbe2F0316DF893fd58CE46AA4d',
    usdtAddress: null,
    cctp: {
        domain: 3,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0xaCF1ceeF35caAc005e15888dDb8A3515C41B4872',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 3,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Avalanche Mainnet chain definition
 * @remarks
 * This represents the official production network for the Avalanche blockchain.
 */
const Avalanche = defineChain({
    type: 'evm',
    chain: Blockchain.Avalanche,
    name: 'Avalanche',
    title: 'Avalanche Mainnet',
    nativeCurrency: {
        name: 'Avalanche',
        symbol: 'AVAX',
        decimals: 18,
    },
    chainId: 43114,
    isTestnet: false,
    explorerUrl: 'https://subnets.avax.network/c-chain/tx/{hash}',
    rpcEndpoints: ['https://api.avax.network/ext/bc/C/rpc'],
    eurcAddress: '0xc891eb4cbdeff6e073e859e987815ed1505c2acd',
    usdcAddress: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
    usdtAddress: '0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7',
    cctp: {
        domain: 1,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x6b25532e1060ce10cc3b0a99e5683b91bfde6982',
                messageTransmitter: '0x8186359af5f57fbb40c6b14a588d2a59c0c29880',
                confirmations: 1,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 1,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Avalanche Fuji Testnet chain definition
 * @remarks
 * This represents the official test network for the Avalanche blockchain.
 */
const AvalancheFuji = defineChain({
    type: 'evm',
    chain: Blockchain.Avalanche_Fuji,
    name: 'Avalanche Fuji',
    title: 'Avalanche Fuji Testnet',
    nativeCurrency: {
        name: 'Avalanche',
        symbol: 'AVAX',
        decimals: 18,
    },
    chainId: 43113,
    isTestnet: true,
    explorerUrl: 'https://subnets-test.avax.network/c-chain/tx/{hash}',
    eurcAddress: '0x5e44db7996c682e92a960b65ac713a54ad815c6b',
    usdcAddress: '0x5425890298aed601595a70ab815c96711a31bc65',
    usdtAddress: null,
    cctp: {
        domain: 1,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0xeb08f243e5d3fcff26a9e38ae5520a669f4019d0',
                messageTransmitter: '0xa9fb1b3009dcb79e2fe346c16a604b8fa8ae0a79',
                confirmations: 1,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    rpcEndpoints: ['https://api.avax-test.network/ext/bc/C/rpc'],
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 1,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Base chain definition
 * @remarks
 * This represents the official production network for the Base blockchain.
 */
const Base = defineChain({
    type: 'evm',
    chain: Blockchain.Base,
    name: 'Base',
    title: 'Base Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 8453,
    isTestnet: false,
    explorerUrl: 'https://basescan.org/tx/{hash}',
    rpcEndpoints: ['https://mainnet.base.org', 'https://base.publicnode.com'],
    eurcAddress: '0x60a3e35cc302bfa44cb288bc5a4f316fdb1adb42',
    usdcAddress: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
    usdtAddress: null,
    cctp: {
        domain: 6,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x1682Ae6375C4E4A97e4B583BC394c861A46D8962',
                messageTransmitter: '0xAD09780d193884d503182aD4588450C416D6F9D4',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 6,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Base Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Base blockchain on Sepolia.
 */
const BaseSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Base_Sepolia,
    name: 'Base Sepolia',
    title: 'Base Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 84532,
    isTestnet: true,
    explorerUrl: 'https://sepolia.basescan.org/tx/{hash}',
    rpcEndpoints: ['https://sepolia.base.org'],
    eurcAddress: '0x808456652fdb597867f38412077A9182bf77359F',
    usdcAddress: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
    usdtAddress: null,
    cctp: {
        domain: 6,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 6,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Celo Mainnet chain definition
 * @remarks
 * This represents the official production network for the Celo blockchain.
 */
const Celo = defineChain({
    type: 'evm',
    chain: Blockchain.Celo,
    name: 'Celo',
    title: 'Celo Mainnet',
    nativeCurrency: {
        name: 'Celo',
        symbol: 'CELO',
        decimals: 18,
    },
    chainId: 42220,
    isTestnet: false,
    explorerUrl: 'https://celoscan.io/tx/{hash}',
    rpcEndpoints: ['https://forno.celo.org'],
    eurcAddress: null,
    usdcAddress: '0xcebA9300f2b948710d2653dD7B07f33A8B32118C',
    usdtAddress: '0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e',
    cctp: null,
});

/**
 * Celo Alfajores Testnet chain definition
 * @remarks
 * This represents the official test network for the Celo blockchain.
 */
const CeloAlfajoresTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Celo_Alfajores_Testnet,
    name: 'Celo Alfajores',
    title: 'Celo Alfajores Testnet',
    nativeCurrency: {
        name: 'Celo',
        symbol: 'CELO',
        decimals: 18,
    },
    chainId: 44787,
    isTestnet: true,
    explorerUrl: 'https://alfajores.celoscan.io/tx/{hash}',
    rpcEndpoints: ['https://alfajores-forno.celo-testnet.org'],
    eurcAddress: null,
    usdcAddress: '0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B',
    usdtAddress: null,
    cctp: null,
});

/**
 * Codex Mainnet chain definition
 * @remarks
 * This represents the main network for the Codex blockchain.
 */
const Codex = defineChain({
    type: 'evm',
    chain: Blockchain.Codex,
    name: 'Codex Mainnet',
    title: 'Codex Mainnet',
    nativeCurrency: {
        name: 'ETH',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 81224,
    isTestnet: false,
    explorerUrl: 'https://explorer.codex.xyz/tx/{hash}',
    rpcEndpoints: ['https://rpc.codex.xyz'],
    eurcAddress: null,
    usdcAddress: '0xd996633a415985DBd7D6D12f4A4343E31f5037cf',
    usdtAddress: null,
    cctp: {
        domain: 12,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Codex Testnet chain definition
 * @remarks
 * This represents the test network for the Codex blockchain.
 */
const CodexTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Codex_Testnet,
    name: 'Codex Testnet',
    title: 'Codex Testnet',
    nativeCurrency: {
        name: 'ETH',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 812242,
    isTestnet: true,
    explorerUrl: 'https://explorer.codex-stg.xyz/tx/{hash}',
    rpcEndpoints: ['https://rpc.codex-stg.xyz'],
    eurcAddress: null,
    usdcAddress: '0x6d7f141b6819C2c9CC2f818e6ad549E7Ca090F8f',
    usdtAddress: null,
    cctp: {
        domain: 12,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Edge Mainnet chain definition
 * @remarks
 * This represents the official production network for the Edge blockchain.
 * Edge is an EVM-compatible blockchain.
 */
const Edge = defineChain({
    type: 'evm',
    chain: Blockchain.Edge,
    name: 'Edge',
    title: 'Edge Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 3343,
    isTestnet: false,
    explorerUrl: 'https://pro.edgex.exchange/en-US/explorer/tx/{hash}',
    rpcEndpoints: ['https://edge-mainnet.g.alchemy.com/public'],
    eurcAddress: null,
    usdcAddress: '0x98d2919b9A214E6Fa5384AC81E6864bA686Ad74c',
    usdtAddress: null,
    cctp: {
        domain: 28,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x98706A006bc632Df31CAdFCBD43F38887ce2ca5c',
                messageTransmitter: '0x5b61381Fc9e58E70EfC13a4A97516997019198ee',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: '0x6D1AaE1c34Aeb582022916a67f2A655C6f4eDFF2', //Unique bridge address as CCTP address for Edge is also unique
    },
});

/**
 * Edge Testnet chain definition
 * @remarks
 * This represents the official test network for the Edge blockchain.
 * Edge is an EVM-compatible blockchain.
 */
const EdgeTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Edge_Testnet,
    name: 'Edge Testnet',
    title: 'Edge Testnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 33431,
    isTestnet: true,
    explorerUrl: 'https://edge-testnet.explorer.alchemy.com/tx/{hash}',
    rpcEndpoints: ['https://edge-testnet.g.alchemy.com/public'],
    eurcAddress: null,
    usdcAddress: '0x2d9F7CAD728051AA35Ecdc472a14cf8cDF5CFD6B',
    usdtAddress: null,
    cctp: {
        domain: 28,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Ethereum Mainnet chain definition
 * @remarks
 * This represents the official production network for the Ethereum blockchain.
 */
const Ethereum = defineChain({
    type: 'evm',
    chain: Blockchain.Ethereum,
    name: 'Ethereum',
    title: 'Ethereum Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 1,
    isTestnet: false,
    explorerUrl: 'https://etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://ethereum-rpc.publicnode.com',
        'https://ethereum.publicnode.com',
    ],
    eurcAddress: '0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c',
    usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
    usdtAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
    cctp: {
        domain: 0,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0xbd3fa81b58ba92a82136038b25adec7066af3155',
                messageTransmitter: '0x0a992d191deec32afe36203ad87d7d289a738f81',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 2,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 0,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Ethereum Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Ethereum blockchain on Sepolia.
 */
const EthereumSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Ethereum_Sepolia,
    name: 'Ethereum Sepolia',
    title: 'Ethereum Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 11155111,
    isTestnet: true,
    explorerUrl: 'https://sepolia.etherscan.io/tx/{hash}',
    rpcEndpoints: ['https://ethereum-sepolia-rpc.publicnode.com'],
    eurcAddress: '0x08210F9170F89Ab7658F0B5E3fF39b0E03C594D4',
    usdcAddress: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
    usdtAddress: null,
    cctp: {
        domain: 0,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 2,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 0,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Hedera Mainnet chain definition
 * @remarks
 * This represents the official production network for the Hedera blockchain.
 */
const Hedera = defineChain({
    type: 'hedera',
    chain: Blockchain.Hedera,
    name: 'Hedera',
    title: 'Hedera Mainnet',
    nativeCurrency: {
        name: 'HBAR',
        symbol: 'HBAR',
        decimals: 18,
    },
    isTestnet: false,
    explorerUrl: 'https://hashscan.io/mainnet/transaction/{hash}', // Note: Hedera uses `transaction_id`, not hash. Format is typically `0.0.X-YYYY...`.
    rpcEndpoints: ['https://mainnet.hashio.io/api'],
    eurcAddress: null,
    usdcAddress: '0.0.456858',
    usdtAddress: null,
    cctp: null,
});

/**
 * Hedera Testnet chain definition
 * @remarks
 * This represents the official test network for the Hedera blockchain.
 */
const HederaTestnet = defineChain({
    type: 'hedera',
    chain: Blockchain.Hedera_Testnet,
    name: 'Hedera Testnet',
    title: 'Hedera Test Network',
    nativeCurrency: {
        name: 'HBAR',
        symbol: 'HBAR',
        decimals: 18,
    },
    isTestnet: true,
    explorerUrl: 'https://hashscan.io/testnet/transaction/{hash}', // Note: Hedera uses `transaction_id`, not hash. Format is typically `0.0.X-YYYY...`.
    rpcEndpoints: ['https://testnet.hashio.io/api'],
    eurcAddress: null,
    usdcAddress: '0.0.429274',
    usdtAddress: null,
    cctp: null,
});

/**
 * HyperEVM Mainnet chain definition
 * @remarks
 * This represents the official production network for the HyperEVM blockchain.
 * HyperEVM is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */
const HyperEVM = defineChain({
    type: 'evm',
    chain: Blockchain.HyperEVM,
    name: 'HyperEVM',
    title: 'HyperEVM Mainnet',
    nativeCurrency: {
        name: 'Hype',
        symbol: 'HYPE',
        decimals: 18,
    },
    chainId: 999,
    isTestnet: false,
    explorerUrl: 'https://hyperevmscan.io/tx/{hash}',
    rpcEndpoints: ['https://rpc.hyperliquid.xyz/evm'],
    eurcAddress: null,
    usdcAddress: '0xb88339CB7199b77E23DB6E890353E22632Ba630f',
    usdtAddress: null,
    cctp: {
        domain: 19,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 19,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * HyperEVM Testnet chain definition
 * @remarks
 * This represents the official testnet for the HyperEVM blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */
const HyperEVMTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.HyperEVM_Testnet,
    name: 'HyperEVM Testnet',
    title: 'HyperEVM Test Network',
    nativeCurrency: {
        name: 'Hype',
        symbol: 'HYPE',
        decimals: 18,
    },
    chainId: 998,
    isTestnet: true,
    explorerUrl: 'https://app.hyperliquid-testnet.xyz/explorer/tx/{hash}',
    rpcEndpoints: ['https://rpc.hyperliquid-testnet.xyz/evm'],
    eurcAddress: null,
    usdcAddress: '0x2B3370eE501B4a559b57D449569354196457D8Ab',
    usdtAddress: null,
    cctp: {
        domain: 19,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 19,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Injective Mainnet chain definition
 * @remarks
 * This represents the official production network for the Injective blockchain.
 * Injective is a high-performance, interoperable Layer-1 blockchain built for
 * finance, with an EVM execution layer on top of a Cosmos SDK base and
 * sub-second block finality.
 */
const Injective = defineChain({
    type: 'evm',
    chain: Blockchain.Injective,
    name: 'Injective',
    title: 'Injective Mainnet',
    nativeCurrency: {
        name: 'Injective',
        symbol: 'INJ',
        decimals: 18,
    },
    chainId: 1776,
    isTestnet: false,
    explorerUrl: 'https://injscan.com/transaction/{hash}',
    rpcEndpoints: ['https://sentry.evm-rpc.injective.network'],
    eurcAddress: null,
    usdcAddress: '0xa00C59fF5a080D2b954d0c75e46E22a0c371235a',
    usdtAddress: null,
    cctp: {
        domain: 29,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Injective Testnet chain definition
 * @remarks
 * This represents the official test network for the Injective blockchain.
 * Injective is a high-performance, interoperable Layer-1 blockchain built for
 * finance, with an EVM execution layer on top of a Cosmos SDK base and
 * sub-second block finality.
 */
const InjectiveTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Injective_Testnet,
    name: 'Injective Testnet',
    title: 'Injective Testnet',
    nativeCurrency: {
        name: 'Injective',
        symbol: 'INJ',
        decimals: 18,
    },
    chainId: 1439,
    isTestnet: true,
    explorerUrl: 'https://testnet.explorer.injective.network/transaction/{hash}',
    rpcEndpoints: ['https://k8s.testnet.json-rpc.injective.network'],
    eurcAddress: null,
    usdcAddress: '0x0C382e685bbeeFE5d3d9C29e29E341fEE8E84C5d',
    usdtAddress: null,
    cctp: {
        domain: 29,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Ink Mainnet chain definition
 * @remarks
 * This represents the official production network for the Ink blockchain.
 * Ink is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */
const Ink = defineChain({
    type: 'evm',
    chain: Blockchain.Ink,
    name: 'Ink',
    title: 'Ink Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 57073,
    isTestnet: false,
    explorerUrl: 'https://explorer.inkonchain.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-gel.inkonchain.com',
        'https://rpc-qnd.inkonchain.com',
    ],
    eurcAddress: null,
    usdcAddress: '0x2D270e6886d130D724215A266106e6832161EAEd',
    usdtAddress: null,
    cctp: {
        domain: 21,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Ink Testnet chain definition
 * @remarks
 * This represents the official testnet for the Ink blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */
const InkTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Ink_Testnet,
    name: 'Ink Sepolia',
    title: 'Ink Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 763373,
    isTestnet: true,
    explorerUrl: 'https://explorer-sepolia.inkonchain.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-gel-sepolia.inkonchain.com',
        'https://rpc-qnd-sepolia.inkonchain.com',
    ],
    eurcAddress: null,
    usdcAddress: '0xFabab97dCE620294D2B0b0e46C68964e326300Ac',
    usdtAddress: null,
    cctp: {
        domain: 21,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Linea Mainnet chain definition
 * @remarks
 * This represents the official production network for the Linea blockchain.
 */
const Linea = defineChain({
    type: 'evm',
    chain: Blockchain.Linea,
    name: 'Linea',
    title: 'Linea Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 59144,
    isTestnet: false,
    explorerUrl: 'https://lineascan.build/tx/{hash}',
    rpcEndpoints: ['https://rpc.linea.build'],
    eurcAddress: null,
    usdcAddress: '0x176211869ca2b568f2a7d4ee941e073a821ee1ff',
    usdtAddress: null,
    cctp: {
        domain: 11,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Linea Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Linea blockchain on Sepolia.
 */
const LineaSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Linea_Sepolia,
    name: 'Linea Sepolia',
    title: 'Linea Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 59141,
    isTestnet: true,
    explorerUrl: 'https://sepolia.lineascan.build/tx/{hash}',
    rpcEndpoints: ['https://rpc.sepolia.linea.build'],
    eurcAddress: null,
    usdcAddress: '0xfece4462d57bd51a6a552365a011b95f0e16d9b7',
    usdtAddress: null,
    cctp: {
        domain: 11,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Monad Mainnet chain definition
 * @remarks
 * This represents the official production network for the Monad blockchain.
 * Monad is a high-performance EVM-compatible Layer-1 blockchain featuring
 * over 10,000 TPS, sub-second finality, and near-zero gas fees.
 */
const Monad = defineChain({
    type: 'evm',
    chain: Blockchain.Monad,
    name: 'Monad',
    title: 'Monad Mainnet',
    nativeCurrency: {
        name: 'Monad',
        symbol: 'MON',
        decimals: 18,
    },
    chainId: 143,
    isTestnet: false,
    explorerUrl: 'https://monadscan.com/tx/{hash}',
    rpcEndpoints: ['https://rpc.monad.xyz'],
    eurcAddress: null,
    usdcAddress: '0x754704Bc059F8C67012fEd69BC8A327a5aafb603',
    usdtAddress: null,
    cctp: {
        domain: 15,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Monad Testnet chain definition
 * @remarks
 * This represents the official test network for the Monad blockchain.
 * Monad is a high-performance EVM-compatible Layer-1 blockchain featuring
 * over 10,000 TPS, sub-second finality, and near-zero gas fees.
 */
const MonadTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Monad_Testnet,
    name: 'Monad Testnet',
    title: 'Monad Testnet',
    nativeCurrency: {
        name: 'Monad',
        symbol: 'MON',
        decimals: 18,
    },
    chainId: 10143,
    isTestnet: true,
    explorerUrl: 'https://testnet.monadscan.com/tx/{hash}',
    rpcEndpoints: ['https://testnet-rpc.monad.xyz'],
    eurcAddress: null,
    usdcAddress: '0x534b2f3A21130d7a60830c2Df862319e593943A3',
    usdtAddress: null,
    cctp: {
        domain: 15,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Morph Mainnet chain definition
 * @remarks
 * This represents the official production network for the Morph blockchain.
 * Morph is an EVM-compatible Layer-2 blockchain built on the OP Stack.
 */
const Morph = defineChain({
    type: 'evm',
    chain: Blockchain.Morph,
    name: 'Morph',
    title: 'Morph Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 2818,
    isTestnet: false,
    explorerUrl: 'https://explorer.morph.network/tx/{hash}',
    rpcEndpoints: ['https://rpc.morphl2.io'],
    eurcAddress: null,
    usdcAddress: '0xCfb1186F4e93D60E60a8bDd997427D1F33bc372B',
    usdtAddress: null,
    cctp: {
        domain: 30,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 64,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Morph Hoodi Testnet chain definition
 * @remarks
 * This represents the official test network for the Morph blockchain.
 * Morph is an EVM-compatible Layer-2 blockchain built on the OP Stack.
 */
const MorphTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Morph_Testnet,
    name: 'Morph Hoodi',
    title: 'Morph Hoodi Testnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 2910,
    isTestnet: true,
    explorerUrl: 'https://explorer-hoodi.morphl2.io/tx/{hash}',
    rpcEndpoints: ['https://rpc-hoodi.morphl2.io'],
    eurcAddress: null,
    usdcAddress: '0x7433b41C6c5e1d58D4Da99483609520255ab661B',
    usdtAddress: null,
    cctp: {
        domain: 30,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 64,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * NEAR Protocol Mainnet chain definition
 * @remarks
 * This represents the official production network for the NEAR Protocol blockchain.
 */
const NEAR = defineChain({
    type: 'near',
    chain: Blockchain.NEAR,
    name: 'NEAR Protocol',
    title: 'NEAR Mainnet',
    nativeCurrency: {
        name: 'NEAR',
        symbol: 'NEAR',
        decimals: 24,
    },
    isTestnet: false,
    explorerUrl: 'https://nearblocks.io/txns/{hash}',
    rpcEndpoints: ['https://eth-rpc.mainnet.near.org'],
    eurcAddress: null,
    usdcAddress: '17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1',
    usdtAddress: 'usdt.tether-token.near',
    cctp: null,
});

/**
 * NEAR Testnet chain definition
 * @remarks
 * This represents the official test network for the NEAR Protocol blockchain.
 */
const NEARTestnet = defineChain({
    type: 'near',
    chain: Blockchain.NEAR_Testnet,
    name: 'NEAR Protocol Testnet',
    title: 'NEAR Test Network',
    nativeCurrency: {
        name: 'NEAR',
        symbol: 'NEAR',
        decimals: 24,
    },
    isTestnet: true,
    explorerUrl: 'https://testnet.nearblocks.io/txns/{hash}',
    rpcEndpoints: ['https://eth-rpc.testnet.near.org'],
    eurcAddress: null,
    usdcAddress: '3e2210e1184b45b64c8a434c0a7e7b23cc04ea7eb7a6c3c32520d03d4afcb8af',
    usdtAddress: null,
    cctp: null,
});

/**
 * Noble Mainnet chain definition
 * @remarks
 * This represents the official production network for the Noble blockchain.
 */
const Noble = defineChain({
    type: 'noble',
    chain: Blockchain.Noble,
    name: 'Noble',
    title: 'Noble Mainnet',
    nativeCurrency: {
        name: 'Noble USDC',
        symbol: 'USDC',
        decimals: 6,
    },
    isTestnet: false,
    explorerUrl: 'https://www.mintscan.io/noble/tx/{hash}',
    rpcEndpoints: ['https://noble-rpc.polkachu.com'],
    eurcAddress: null,
    usdcAddress: 'uusdc',
    usdtAddress: null,
    cctp: {
        domain: 4,
        contracts: {
            v1: {
                type: 'merged',
                contract: 'noble12l2w4ugfz4m6dd73yysz477jszqnfughxvkss5',
                confirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
});

/**
 * Noble Testnet chain definition
 * @remarks
 * This represents the official test network for the Noble blockchain.
 */
const NobleTestnet = defineChain({
    type: 'noble',
    chain: Blockchain.Noble_Testnet,
    name: 'Noble Testnet',
    title: 'Noble Test Network',
    nativeCurrency: {
        name: 'Noble USDC',
        symbol: 'USDC',
        decimals: 6,
    },
    isTestnet: true,
    explorerUrl: 'https://www.mintscan.io/noble-testnet/tx/{hash}',
    rpcEndpoints: ['https://noble-testnet-rpc.polkachu.com'],
    eurcAddress: null,
    usdcAddress: 'uusdc',
    usdtAddress: null,
    cctp: {
        domain: 4,
        contracts: {
            v1: {
                type: 'merged',
                contract: 'noble12l2w4ugfz4m6dd73yysz477jszqnfughxvkss5',
                confirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
});

/**
 * Optimism Mainnet chain definition
 * @remarks
 * This represents the official production network for the Optimism blockchain.
 */
const Optimism = defineChain({
    type: 'evm',
    chain: Blockchain.Optimism,
    name: 'Optimism',
    title: 'Optimism Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 10,
    isTestnet: false,
    explorerUrl: 'https://optimistic.etherscan.io/tx/{hash}',
    rpcEndpoints: ['https://mainnet.optimism.io'],
    eurcAddress: null,
    usdcAddress: '0x0b2c639c533813f4aa9d7837caf62653d097ff85',
    usdtAddress: null,
    cctp: {
        domain: 2,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x2B4069517957735bE00ceE0fadAE88a26365528f',
                messageTransmitter: '0x0a992d191deec32afe36203ad87d7d289a738f81',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 2,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Optimism Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Optimism blockchain on Sepolia.
 */
const OptimismSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Optimism_Sepolia,
    name: 'Optimism Sepolia',
    title: 'Optimism Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 11155420,
    isTestnet: true,
    explorerUrl: 'https://sepolia-optimistic.etherscan.io/tx/{hash}',
    rpcEndpoints: ['https://sepolia.optimism.io'],
    eurcAddress: null,
    usdcAddress: '0x5fd84259d66Cd46123540766Be93DFE6D43130D7',
    usdtAddress: null,
    cctp: {
        domain: 2,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 2,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Pharos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Pharos blockchain.
 * Pharos is a modular, full-stack parallel Layer 1 blockchain with
 * sub-second finality and EVM compatibility.
 */
const Pharos = defineChain({
    type: 'evm',
    chain: Blockchain.Pharos,
    name: 'Pharos',
    title: 'Pharos Mainnet',
    nativeCurrency: {
        name: 'Pharos',
        symbol: 'PHAROS',
        decimals: 18,
    },
    chainId: 1672,
    isTestnet: false,
    explorerUrl: 'https://pharos.socialscan.io/tx/{hash}',
    rpcEndpoints: ['https://rpc.pharos.xyz'],
    eurcAddress: null,
    usdcAddress: '0xC879C018dB60520F4355C26eD1a6D572cdAC1815',
    usdtAddress: null,
    cctp: {
        domain: 31,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Pharos Atlantic Testnet chain definition
 * @remarks
 * This represents the official test network for the Pharos blockchain.
 * Pharos is a modular, full-stack parallel Layer 1 blockchain with
 * sub-second finality and EVM compatibility.
 */
const PharosTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Pharos_Testnet,
    name: 'Pharos Atlantic',
    title: 'Pharos Atlantic Testnet',
    nativeCurrency: {
        name: 'Pharos',
        symbol: 'PHAROS',
        decimals: 18,
    },
    chainId: 688689,
    isTestnet: true,
    explorerUrl: 'https://atlantic.pharosscan.xyz/tx/{hash}',
    rpcEndpoints: ['https://atlantic.dplabs-internal.com'],
    eurcAddress: null,
    usdcAddress: '0xcfC8330f4BCAB529c625D12781b1C19466A9Fc8B',
    usdtAddress: null,
    cctp: {
        domain: 31,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Plume Mainnet chain definition
 * @remarks
 * This represents the official production network for the Plume blockchain.
 * Plume is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */
const Plume = defineChain({
    type: 'evm',
    chain: Blockchain.Plume,
    name: 'Plume',
    title: 'Plume Mainnet',
    nativeCurrency: {
        name: 'Plume',
        symbol: 'PLUME',
        decimals: 18,
    },
    chainId: 98866,
    isTestnet: false,
    explorerUrl: 'https://explorer.plume.org/tx/{hash}',
    rpcEndpoints: ['https://rpc.plume.org'],
    eurcAddress: null,
    usdcAddress: '0x222365EF19F7947e5484218551B56bb3965Aa7aF',
    usdtAddress: null,
    cctp: {
        domain: 22,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
});

/**
 * Plume Testnet chain definition
 * @remarks
 * This represents the official testnet for the Plume blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */
const PlumeTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Plume_Testnet,
    name: 'Plume Testnet',
    title: 'Plume Test Network',
    nativeCurrency: {
        name: 'Plume',
        symbol: 'PLUME',
        decimals: 18,
    },
    chainId: 98867,
    isTestnet: true,
    explorerUrl: 'https://testnet-explorer.plume.org/tx/{hash}',
    rpcEndpoints: ['https://testnet-rpc.plume.org'],
    eurcAddress: null,
    usdcAddress: '0xcB5f30e335672893c7eb944B374c196392C19D18',
    usdtAddress: null,
    cctp: {
        domain: 22,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * Polkadot Asset Hub chain definition
 * @remarks
 * This represents the official asset management parachain for the Polkadot blockchain.
 */
const PolkadotAssetHub = defineChain({
    type: 'polkadot',
    chain: Blockchain.Polkadot_Asset_Hub,
    name: 'Polkadot Asset Hub',
    title: 'Polkadot Asset Hub',
    nativeCurrency: {
        name: 'Polkadot',
        symbol: 'DOT',
        decimals: 10,
    },
    isTestnet: false,
    explorerUrl: 'https://polkadot.subscan.io/extrinsic/{hash}',
    rpcEndpoints: ['https://asset-hub-polkadot-rpc.n.dwellir.com'],
    eurcAddress: null,
    usdcAddress: '1337',
    usdtAddress: '1984',
    cctp: null,
});

/**
 * Polkadot Westmint chain definition
 * @remarks
 * This represents an asset management parachain in the Polkadot ecosystem.
 */
const PolkadotWestmint = defineChain({
    type: 'polkadot',
    chain: Blockchain.Polkadot_Westmint,
    name: 'Polkadot Westmint',
    title: 'Polkadot Westmint',
    nativeCurrency: {
        name: 'Polkadot',
        symbol: 'DOT',
        decimals: 10,
    },
    isTestnet: false,
    explorerUrl: 'https://assethub-polkadot.subscan.io/extrinsic/{hash}',
    rpcEndpoints: ['https://westmint-rpc.polkadot.io'],
    eurcAddress: null,
    usdcAddress: 'Asset ID 31337',
    usdtAddress: null,
    cctp: null,
});

/**
 * Polygon Mainnet chain definition
 * @remarks
 * This represents the official production network for the Polygon blockchain.
 */
const Polygon = defineChain({
    type: 'evm',
    chain: Blockchain.Polygon,
    name: 'Polygon',
    title: 'Polygon Mainnet',
    nativeCurrency: {
        name: 'POL',
        symbol: 'POL',
        decimals: 18,
    },
    chainId: 137,
    isTestnet: false,
    explorerUrl: 'https://polygonscan.com/tx/{hash}',
    rpcEndpoints: ['https://polygon.publicnode.com', 'https://polygon.drpc.org'],
    eurcAddress: null,
    usdcAddress: '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
    usdtAddress: null,
    cctp: {
        domain: 7,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9daF8c91AEFAE50b9c0E69629D3F6Ca40cA3B3FE',
                messageTransmitter: '0xF3be9355363857F3e001be68856A2f96b4C39Ba9',
                confirmations: 200,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 33,
                fastConfirmations: 13,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 7,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Polygon Amoy Testnet chain definition
 * @remarks
 * This represents the official test network for the Polygon blockchain.
 */
const PolygonAmoy = defineChain({
    type: 'evm',
    chain: Blockchain.Polygon_Amoy_Testnet,
    name: 'Polygon Amoy',
    title: 'Polygon Amoy Testnet',
    nativeCurrency: {
        name: 'POL',
        symbol: 'POL',
        decimals: 18,
    },
    chainId: 80002,
    isTestnet: true,
    explorerUrl: 'https://amoy.polygonscan.com/tx/{hash}',
    rpcEndpoints: ['https://rpc-amoy.polygon.technology'],
    eurcAddress: null,
    usdcAddress: '0x41e94eb019c0762f9bfcf9fb1e58725bfb0e7582',
    usdtAddress: null,
    cctp: {
        domain: 7,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 200,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 33,
                fastConfirmations: 13,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 7,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Sei Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sei blockchain.
 * Sei is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */
const Sei = defineChain({
    type: 'evm',
    chain: Blockchain.Sei,
    name: 'Sei',
    title: 'Sei Mainnet',
    nativeCurrency: {
        name: 'Sei',
        symbol: 'SEI',
        decimals: 18,
    },
    chainId: 1329,
    isTestnet: false,
    explorerUrl: 'https://seiscan.io/tx/{hash}',
    rpcEndpoints: ['https://evm-rpc.sei-apis.com'],
    eurcAddress: null,
    usdcAddress: '0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392',
    usdtAddress: null,
    cctp: {
        domain: 16,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 16,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Sei Testnet chain definition
 * @remarks
 * This represents the official testnet for the Sei blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */
const SeiTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Sei_Testnet,
    name: 'Sei Testnet',
    title: 'Sei Test Network',
    nativeCurrency: {
        name: 'Sei',
        symbol: 'SEI',
        decimals: 18,
    },
    chainId: 1328,
    isTestnet: true,
    explorerUrl: 'https://testnet.seiscan.io/tx/{hash}',
    rpcEndpoints: ['https://evm-rpc-testnet.sei-apis.com'],
    eurcAddress: null,
    usdcAddress: '0x4fCF1784B31630811181f670Aea7A7bEF803eaED',
    usdtAddress: null,
    cctp: {
        domain: 16,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 16,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Sonic Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sonic blockchain.
 */
const Sonic = defineChain({
    type: 'evm',
    chain: Blockchain.Sonic,
    name: 'Sonic',
    title: 'Sonic Mainnet',
    nativeCurrency: {
        name: 'Sonic',
        symbol: 'S',
        decimals: 18,
    },
    chainId: 146,
    isTestnet: false,
    explorerUrl: 'https://sonicscan.org/tx/{hash}',
    rpcEndpoints: ['https://rpc.soniclabs.com'],
    eurcAddress: null,
    usdcAddress: '0x29219dd400f2Bf60E5a23d13Be72B486D4038894',
    usdtAddress: null,
    cctp: {
        domain: 13,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 13,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Sonic Testnet chain definition
 * @remarks
 * This represents the official test network for the Sonic blockchain.
 */
const SonicTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Sonic_Testnet,
    name: 'Sonic Testnet',
    title: 'Sonic Testnet',
    nativeCurrency: {
        name: 'Sonic',
        symbol: 'S',
        decimals: 18,
    },
    chainId: 14601,
    isTestnet: true,
    explorerUrl: 'https://testnet.sonicscan.org/tx/{hash}',
    rpcEndpoints: ['https://rpc.testnet.soniclabs.com'],
    eurcAddress: null,
    usdcAddress: '0x0BA304580ee7c9a980CF72e55f5Ed2E9fd30Bc51',
    usdtAddress: null,
    cctp: {
        domain: 13,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 13,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Solana Mainnet chain definition
 * @remarks
 * This represents the official production network for the Solana blockchain.
 */
const Solana = defineChain({
    type: 'solana',
    chain: Blockchain.Solana,
    name: 'Solana',
    title: 'Solana Mainnet',
    nativeCurrency: {
        name: 'Solana',
        symbol: 'SOL',
        decimals: 9,
    },
    isTestnet: false,
    explorerUrl: 'https://solscan.io/tx/{hash}',
    rpcEndpoints: ['https://api.mainnet-beta.solana.com'],
    eurcAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
    usdcAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
    usdtAddress: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
    cctp: {
        domain: 5,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: 'CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3',
                messageTransmitter: 'CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd',
                confirmations: 32,
            },
            v2: {
                type: 'split',
                tokenMessenger: 'CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe',
                messageTransmitter: 'CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC',
                confirmations: 32,
                fastConfirmations: 3,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: 'DFaauJEjmiHkPs1JG89A4p95hDWi9m9SAEERY1LQJiC3',
    },
    gateway: {
        domain: 5,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_SOLANA_MAINNET,
                minter: GATEWAY_MINTER_SOLANA_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: false,
        },
    },
});

/**
 * Solana Devnet chain definition
 * @remarks
 * This represents the development test network for the Solana blockchain.
 */
const SolanaDevnet = defineChain({
    type: 'solana',
    chain: Blockchain.Solana_Devnet,
    name: 'Solana Devnet',
    title: 'Solana Development Network',
    nativeCurrency: {
        name: 'Solana',
        symbol: 'SOL',
        decimals: 9,
    },
    isTestnet: true,
    explorerUrl: 'https://solscan.io/tx/{hash}?cluster=devnet',
    eurcAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
    usdcAddress: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
    usdtAddress: null,
    cctp: {
        domain: 5,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: 'CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3',
                messageTransmitter: 'CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd',
                confirmations: 32,
            },
            v2: {
                type: 'split',
                tokenMessenger: 'CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe',
                messageTransmitter: 'CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC',
                confirmations: 32,
                fastConfirmations: 3,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: 'DFaauJEjmiHkPs1JG89A4p95hDWi9m9SAEERY1LQJiC3',
    },
    rpcEndpoints: ['https://api.devnet.solana.com'],
    gateway: {
        domain: 5,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_SOLANA_DEVNET,
                minter: GATEWAY_MINTER_SOLANA_DEVNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: false,
        },
    },
});

/**
 * Stellar Mainnet chain definition
 * @remarks
 * This represents the official production network for the Stellar blockchain.
 */
const Stellar = defineChain({
    type: 'stellar',
    chain: Blockchain.Stellar,
    name: 'Stellar',
    title: 'Stellar Mainnet',
    nativeCurrency: {
        name: 'Stellar Lumens',
        symbol: 'XLM',
        decimals: 7,
    },
    isTestnet: false,
    explorerUrl: 'https://stellar.expert/explorer/public/tx/{hash}',
    rpcEndpoints: ['https://horizon.stellar.org'],
    eurcAddress: 'EURC-GDHU6WRG4IEQXM5NZ4BMPKOXHW76MZM4Y2IEMFDVXBSDP6SJY4ITNPP2',
    usdcAddress: 'USDC-GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN',
    usdtAddress: null,
    cctp: null,
});

/**
 * Stellar Testnet chain definition
 * @remarks
 * This represents the official test network for the Stellar blockchain.
 */
const StellarTestnet = defineChain({
    type: 'stellar',
    chain: Blockchain.Stellar_Testnet,
    name: 'Stellar Testnet',
    title: 'Stellar Test Network',
    nativeCurrency: {
        name: 'Stellar Lumens',
        symbol: 'XLM',
        decimals: 7,
    },
    isTestnet: true,
    explorerUrl: 'https://stellar.expert/explorer/testnet/tx/{hash}',
    rpcEndpoints: ['https://horizon-testnet.stellar.org'],
    eurcAddress: 'EURC-GB3Q6QDZYTHWT7E5PVS3W7FUT5GVAFC5KSZFFLPU25GO7VTC3NM2ZTVO',
    usdcAddress: 'USDC-GBBD47IF6LWK7P7MDEVSCWR7DPUWV3NY3DTQEVFL4NAT4AQH3ZLLFLA5',
    usdtAddress: null,
    cctp: null,
});

/**
 * Sui Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sui blockchain.
 */
const Sui = defineChain({
    type: 'sui',
    chain: Blockchain.Sui,
    name: 'Sui',
    title: 'Sui Mainnet',
    nativeCurrency: {
        name: 'Sui',
        symbol: 'SUI',
        decimals: 9,
    },
    isTestnet: false,
    explorerUrl: 'https://suiscan.xyz/mainnet/tx/{hash}',
    rpcEndpoints: ['https://fullnode.mainnet.sui.io'],
    eurcAddress: null,
    usdcAddress: '0xdba34672e30cb065b1f93e3ab55318768fd6fef66c15942c9f7cb846e2f900e7::usdc::USDC',
    usdtAddress: null,
    cctp: {
        domain: 8,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x2aa6c5d56376c371f88a6cc42e852824994993cb9bab8d3e6450cbe3cb32b94e',
                messageTransmitter: '0x08d87d37ba49e785dde270a83f8e979605b03dc552b5548f26fdf2f49bf7ed1b',
                confirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
});

/**
 * Sui Testnet chain definition
 * @remarks
 * This represents the official test network for the Sui blockchain.
 */
const SuiTestnet = defineChain({
    type: 'sui',
    chain: Blockchain.Sui_Testnet,
    name: 'Sui Testnet',
    title: 'Sui Test Network',
    nativeCurrency: {
        name: 'Sui',
        symbol: 'SUI',
        decimals: 9,
    },
    isTestnet: true,
    explorerUrl: 'https://suiscan.xyz/testnet/tx/{hash}',
    rpcEndpoints: ['https://fullnode.testnet.sui.io'],
    eurcAddress: null,
    usdcAddress: '0xa1ec7fc00a6f40db9693ad1415d0c193ad3906494428cf252621037bd7117e29::usdc::USDC',
    usdtAddress: null,
    cctp: {
        domain: 8,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x31cc14d80c175ae39777c0238f20594c6d4869cfab199f40b69f3319956b8beb',
                messageTransmitter: '0x4931e06dce648b3931f890035bd196920770e913e43e45990b383f6486fdd0a5',
                confirmations: 1,
            },
        },
        forwarderSupported: {
            source: false,
            destination: false,
        },
    },
});

/**
 * Unichain Mainnet chain definition
 * @remarks
 * This represents the official production network for the Unichain blockchain.
 */
const Unichain = defineChain({
    type: 'evm',
    chain: Blockchain.Unichain,
    name: 'Unichain',
    title: 'Unichain Mainnet',
    nativeCurrency: {
        name: 'Uni',
        symbol: 'UNI',
        decimals: 18,
    },
    chainId: 130,
    isTestnet: false,
    explorerUrl: 'https://unichain.blockscout.com/tx/{hash}',
    rpcEndpoints: ['https://mainnet.unichain.org'],
    eurcAddress: null,
    usdcAddress: '0x078D782b760474a361dDA0AF3839290b0EF57AD6',
    usdtAddress: null,
    cctp: {
        domain: 10,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x4e744b28E787c3aD0e810eD65A24461D4ac5a762',
                messageTransmitter: '0x353bE9E2E38AB1D19104534e4edC21c643Df86f4',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 10,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * Unichain Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Unichain blockchain.
 */
const UnichainSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Unichain_Sepolia,
    name: 'Unichain Sepolia',
    title: 'Unichain Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Uni',
        symbol: 'UNI',
        decimals: 18,
    },
    chainId: 1301,
    isTestnet: true,
    explorerUrl: 'https://unichain-sepolia.blockscout.com/tx/{hash}',
    rpcEndpoints: ['https://sepolia.unichain.org'],
    eurcAddress: null,
    usdcAddress: '0x31d0220469e10c4E71834a79b1f276d740d3768F',
    usdtAddress: null,
    cctp: {
        domain: 10,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x8ed94B8dAd2Dc5453862ea5e316A8e71AAed9782',
                messageTransmitter: '0xbc498c326533d675cf571B90A2Ced265ACb7d086',
                confirmations: 65,
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 10,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * World Chain chain definition
 * @remarks
 * This represents the main network for the World Chain blockchain.
 */
const WorldChain = defineChain({
    type: 'evm',
    chain: Blockchain.World_Chain,
    name: 'World Chain',
    title: 'World Chain',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 480,
    isTestnet: false,
    explorerUrl: 'https://worldscan.org/tx/{hash}',
    rpcEndpoints: ['https://worldchain-mainnet.g.alchemy.com/public'],
    eurcAddress: null,
    usdcAddress: '0x79A02482A880bCE3F13e09Da970dC34db4CD24d1',
    usdtAddress: null,
    cctp: {
        domain: 14,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cF5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
    gateway: {
        domain: 14,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * World Chain Sepolia chain definition
 * @remarks
 * This represents the test network for the World Chain blockchain.
 */
const WorldChainSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.World_Chain_Sepolia,
    name: 'World Chain Sepolia',
    title: 'World Chain Sepolia',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 4801,
    isTestnet: true,
    explorerUrl: 'https://sepolia.worldscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://worldchain-sepolia.drpc.org',
        'https://worldchain-sepolia.g.alchemy.com/public',
    ],
    eurcAddress: null,
    usdcAddress: '0x66145f38cBAC35Ca6F1Dfb4914dF98F1614aeA88',
    usdtAddress: null,
    cctp: {
        domain: 14,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
    gateway: {
        domain: 14,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
});

/**
 * XDC Mainnet chain definition
 * @remarks
 * This represents the official production network for the XDC blockchain.
 * XDC is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */
const XDC = defineChain({
    type: 'evm',
    chain: Blockchain.XDC,
    name: 'XDC',
    title: 'XDC Mainnet',
    nativeCurrency: {
        name: 'XDC',
        symbol: 'XDC',
        decimals: 18,
    },
    chainId: 50,
    isTestnet: false,
    explorerUrl: 'https://xdcscan.io/tx/{hash}',
    rpcEndpoints: ['https://erpc.xdcrpc.com', 'https://erpc.xinfin.network'],
    eurcAddress: null,
    usdcAddress: '0xfA2958CB79b0491CC627c1557F441eF849Ca8eb1',
    usdtAddress: null,
    cctp: {
        domain: 18,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 3,
                fastConfirmations: 3,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET,
    },
});

/**
 * XDC Apothem Testnet chain definition
 * @remarks
 * This represents the official test network for the XDC Network, known as Apothem.
 */
const XDCApothem = defineChain({
    type: 'evm',
    chain: Blockchain.XDC_Apothem,
    name: 'Apothem Network',
    title: 'Apothem Network',
    nativeCurrency: {
        name: 'TXDC',
        symbol: 'TXDC',
        decimals: 18,
    },
    chainId: 51,
    isTestnet: true,
    explorerUrl: 'https://testnet.xdcscan.com/tx/{hash}',
    rpcEndpoints: ['https://erpc.apothem.network'],
    eurcAddress: null,
    usdcAddress: '0xb5AB69F7bBada22B28e79C8FFAECe55eF1c771D4',
    usdtAddress: null,
    cctp: {
        domain: 18,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 3,
                fastConfirmations: 1,
            },
        },
        forwarderSupported: {
            source: true,
            destination: true,
        },
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
    },
});

/**
 * ZKSync Era Mainnet chain definition
 * @remarks
 * This represents the official production network for the ZKSync Era blockchain.
 */
const ZKSyncEra = defineChain({
    type: 'evm',
    chain: Blockchain.ZKSync_Era,
    name: 'ZKSync Era',
    title: 'ZKSync Era Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 324,
    isTestnet: false,
    explorerUrl: 'https://explorer.zksync.io/tx/{hash}',
    rpcEndpoints: ['https://mainnet.era.zksync.io'],
    eurcAddress: null,
    usdcAddress: '0x1d17CBcF0D6D143135aE902365D2E5e2A16538D4',
    usdtAddress: null,
    cctp: null,
});

/**
 * ZKSync Era Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the ZKSync Era blockchain on Sepolia.
 */
const ZKSyncEraSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.ZKSync_Sepolia,
    name: 'ZKSync Era Sepolia',
    title: 'ZKSync Era Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    chainId: 300,
    isTestnet: true,
    explorerUrl: 'https://sepolia.explorer.zksync.io/tx/{hash}',
    rpcEndpoints: ['https://sepolia.era.zksync.dev'],
    eurcAddress: null,
    usdcAddress: '0xAe045DE5638162fa134807Cb558E15A3F5A7F853',
    usdtAddress: null,
    cctp: null,
});

var Chains = {
    __proto__: null,
    Algorand: Algorand,
    AlgorandTestnet: AlgorandTestnet,
    Aptos: Aptos,
    AptosTestnet: AptosTestnet,
    Arbitrum: Arbitrum,
    ArbitrumSepolia: ArbitrumSepolia,
    ArcTestnet: ArcTestnet,
    Avalanche: Avalanche,
    AvalancheFuji: AvalancheFuji,
    Base: Base,
    BaseSepolia: BaseSepolia,
    Celo: Celo,
    CeloAlfajoresTestnet: CeloAlfajoresTestnet,
    Codex: Codex,
    CodexTestnet: CodexTestnet,
    Edge: Edge,
    EdgeTestnet: EdgeTestnet,
    Ethereum: Ethereum,
    EthereumSepolia: EthereumSepolia,
    Hedera: Hedera,
    HederaTestnet: HederaTestnet,
    HyperEVM: HyperEVM,
    HyperEVMTestnet: HyperEVMTestnet,
    Injective: Injective,
    InjectiveTestnet: InjectiveTestnet,
    Ink: Ink,
    InkTestnet: InkTestnet,
    Linea: Linea,
    LineaSepolia: LineaSepolia,
    Monad: Monad,
    MonadTestnet: MonadTestnet,
    Morph: Morph,
    MorphTestnet: MorphTestnet,
    NEAR: NEAR,
    NEARTestnet: NEARTestnet,
    Noble: Noble,
    NobleTestnet: NobleTestnet,
    Optimism: Optimism,
    OptimismSepolia: OptimismSepolia,
    Pharos: Pharos,
    PharosTestnet: PharosTestnet,
    Plume: Plume,
    PlumeTestnet: PlumeTestnet,
    PolkadotAssetHub: PolkadotAssetHub,
    PolkadotWestmint: PolkadotWestmint,
    Polygon: Polygon,
    PolygonAmoy: PolygonAmoy,
    Sei: Sei,
    SeiTestnet: SeiTestnet,
    Solana: Solana,
    SolanaDevnet: SolanaDevnet,
    Sonic: Sonic,
    SonicTestnet: SonicTestnet,
    Stellar: Stellar,
    StellarTestnet: StellarTestnet,
    Sui: Sui,
    SuiTestnet: SuiTestnet,
    Unichain: Unichain,
    UnichainSepolia: UnichainSepolia,
    WorldChain: WorldChain,
    WorldChainSepolia: WorldChainSepolia,
    XDC: XDC,
    XDCApothem: XDCApothem,
    ZKSyncEra: ZKSyncEra,
    ZKSyncEraSepolia: ZKSyncEraSepolia
};

/**
 * Check whether a given chain supports Gateway protocol version 1.
 *
 * This type guard function examines a chain definition to determine if it has Gateway v1
 * contract configurations. It checks that the chain has a gateway object with a
 * `contracts.v1` entry present.
 *
 * @param chain - The chain definition to check for Gateway v1 support
 * @returns `true` if `chain.gateway?.contracts?.v1` is defined, `false` otherwise
 *
 * @example
 * ```typescript
 * import { isGatewayV1Supported, Base } from '@core/chains'
 *
 * if (isGatewayV1Supported(Base)) {
 *   // TypeScript knows Base.gateway is defined here
 *   console.log('Gateway domain:', Base.gateway.domain)
 *   console.log('Wallet address:', Base.gateway.contracts.v1.wallet)
 *   console.log('Minter address:', Base.gateway.contracts.v1.minter)
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Usage in conditional flow
 * function getGatewayWalletAddress(chain: ChainDefinition): string | null {
 *   if (isGatewayV1Supported(chain)) {
 *     return chain.gateway.contracts.v1.wallet
 *   }
 *   return null
 * }
 * ```
 */
function isGatewayV1Supported(chain) {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- JS consumers may pass a gateway object without contracts
    return chain.gateway?.contracts?.v1 !== undefined;
}

/**
 * Zod schema for validating Gateway v1 contract addresses.
 *
 * @example
 * ```typescript
 * gatewayV1ContractsSchema.parse({
 *   wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *   minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 * })
 * ```
 */
const gatewayV1ContractsSchema = zod.z
    .object({
    wallet: zod.z
        .string({
        required_error: 'Gateway wallet address is required. Please provide a valid contract address.',
        invalid_type_error: 'Gateway wallet address must be a string.',
    })
        .min(1, 'Gateway wallet address cannot be empty.'),
    minter: zod.z
        .string({
        required_error: 'Gateway minter address is required. Please provide a valid contract address.',
        invalid_type_error: 'Gateway minter address must be a string.',
    })
        .min(1, 'Gateway minter address cannot be empty.'),
})
    .strict(); // Reject any additional properties not defined in the schema
/**
 * Zod schema for validating the versioned Gateway contracts map.
 *
 * @description Mirrors the {@link GatewayContracts} type: a partial map of
 * protocol versions to their contract addresses, following the same pattern
 * as {@link CCTPContracts}.
 *
 * @example
 * ```typescript
 * gatewayContractsSchema.parse({
 *   v1: {
 *     wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *     minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *   }
 * })
 * ```
 */
const gatewayContractsSchema = zod.z
    .object({
    v1: gatewayV1ContractsSchema.optional(),
})
    .strict(); // Reject any additional properties not defined in the schema
/**
 * Zod schema for validating the full Gateway configuration.
 *
 * @description Mirrors the {@link GatewayConfig} type: a domain number plus
 * a versioned contracts map, following the same pattern as {@link CCTPConfig}.
 *
 * @example
 * ```typescript
 * gatewayConfigSchema.parse({
 *   domain: 6,
 *   contracts: {
 *     v1: {
 *       wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *       minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *     }
 *   }
 * })
 * ```
 */
const gatewayConfigSchema = zod.z
    .object({
    domain: zod.z.number({
        required_error: 'Gateway domain is required. Please provide a valid domain number.',
        invalid_type_error: 'Gateway domain must be a number.',
    }),
    contracts: gatewayContractsSchema,
    forwarderSupported: zod.z.object({
        source: zod.z.boolean(),
        destination: zod.z.boolean(),
    }),
})
    .strict(); // Reject any additional properties not defined in the schema
/**
 * Base schema for common chain definition properties.
 * This contains all properties shared between EVM and non-EVM chains.
 */
const baseChainDefinitionSchema = zod.z.object({
    chain: zod.z.nativeEnum(Blockchain, {
        required_error: 'Chain enum is required. Please provide a valid Blockchain enum value.',
        invalid_type_error: 'Chain must be a valid Blockchain enum value.',
    }),
    name: zod.z.string({
        required_error: 'Chain name is required. Please provide a valid chain name.',
        invalid_type_error: 'Chain name must be a string.',
    }),
    title: zod.z.string().optional(),
    nativeCurrency: zod.z.object({
        name: zod.z.string(),
        symbol: zod.z.string(),
        decimals: zod.z.number(),
    }),
    isTestnet: zod.z.boolean({
        required_error: 'isTestnet is required. Please specify whether this is a testnet.',
        invalid_type_error: 'isTestnet must be a boolean.',
    }),
    explorerUrl: zod.z.string({
        required_error: 'Explorer URL is required. Please provide a valid explorer URL.',
        invalid_type_error: 'Explorer URL must be a string.',
    }),
    rpcEndpoints: zod.z.array(zod.z.string()),
    eurcAddress: zod.z.string().nullable(),
    usdcAddress: zod.z.string().nullable(),
    usdtAddress: zod.z.string().nullable(),
    cctp: zod.z.any().nullable(), // We'll accept any CCTP config structure
    kitContracts: zod.z
        .object({
        bridge: zod.z.string().optional(),
        adapter: zod.z.string().optional(),
    })
        .optional(),
    gateway: gatewayConfigSchema.optional(),
});
/**
 * Zod schema for validating EVM chain definitions specifically.
 * This schema extends the base schema with EVM-specific properties.
 *
 * @example
 * ```typescript
 * import { evmChainDefinitionSchema } from '@core/chains/validation'
 * import { Blockchain } from '@core/chains'
 *
 * const ethereumChain = {
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   name: 'Ethereum',
 *   chainId: 1,
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   explorerUrl: 'https://etherscan.io/tx/{hash}',
 *   usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
 *   eurcAddress: null,
 *   cctp: null
 * }
 *
 * const result = evmChainDefinitionSchema.safeParse(ethereumChain)
 * if (result.success) {
 *   console.log('EVM chain definition is valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */
const evmChainDefinitionSchema = baseChainDefinitionSchema
    .extend({
    type: zod.z.literal('evm'),
    chainId: zod.z.number({
        required_error: 'EVM chains must have a chainId. Please provide a valid EVM chain ID.',
        invalid_type_error: 'EVM chain ID must be a number.',
    }),
})
    .strict(); //// Reject any additional properties not defined in the schema
/**
 * Zod schema for validating non-EVM chain definitions.
 * This schema extends the base schema with non-EVM specific properties.
 */
const nonEvmChainDefinitionSchema = baseChainDefinitionSchema
    .extend({
    type: zod.z.enum([
        'algorand',
        'avalanche',
        'solana',
        'aptos',
        'near',
        'stellar',
        'sui',
        'hedera',
        'noble',
        'polkadot',
    ]),
})
    .strict(); // Reject any additional properties not defined in the schema
/**
 * Discriminated union schema for all chain definitions.
 * This schema validates different chain types based on their 'type' field.
 *
 * @example
 * ```typescript
 * import { chainDefinitionSchema } from '@core/chains/validation'
 * import { Blockchain } from '@core/chains'
 *
 * // EVM chain
 * chainDefinitionSchema.parse({
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   // ... other properties
 * })
 *
 * // Non-EVM chain
 * chainDefinitionSchema.parse({
 *   type: 'solana',
 *   chain: Blockchain.Solana,
 *   // ... other properties (no chainId)
 * })
 * ```
 */
const chainDefinitionSchema$2 = zod.z.discriminatedUnion('type', [
    evmChainDefinitionSchema,
    nonEvmChainDefinitionSchema,
]);
/**
 * Zod schema for validating chain identifiers.
 * This schema accepts either a string blockchain identifier, a Blockchain enum value,
 * or a full ChainDefinition object.
 *
 * @example
 * ```typescript
 * import { chainIdentifierSchema } from '@core/chains/validation'
 * import { Blockchain, Ethereum } from '@core/chains'
 *
 * // All of these are valid:
 * chainIdentifierSchema.parse('Ethereum')
 * chainIdentifierSchema.parse(Blockchain.Ethereum)
 * chainIdentifierSchema.parse(Ethereum)
 * ```
 */
zod.z.union([
    zod.z
        .string()
        .refine((val) => val in Blockchain, 'Must be a valid Blockchain enum value as string'),
    zod.z.nativeEnum(Blockchain),
    chainDefinitionSchema$2,
]);
/**
 * Zod schema for validating swap-specific chain identifiers.
 *
 * Validates chains based on:
 * - CCTPv2 support (adapter contract deployed)
 * - Mainnet only (no testnets)
 * - At least one supported token available
 *
 */
zod.z.union([
    // String blockchain identifier (accepts SwapChain enum values)
    zod.z.string().refine((val) => val in SwapChain, (val) => ({
        message: `"${val}" is not a supported swap chain. ` +
            `Supported chains: ${Object.values(SwapChain).join(', ')}`,
    })),
    // SwapChain enum
    zod.z.nativeEnum(SwapChain),
    // ChainDefinition object (checks if chain.chain is in SwapChain)
    chainDefinitionSchema$2.refine((chain) => chain.chain in SwapChain, (chain) => ({
        message: `"${chain.chain}" is not a supported swap chain. ` +
            `Supported chains: ${Object.values(SwapChain).join(', ')}`,
    })),
]);
/**
 * Zod schema for validating bridge chain identifiers.
 *
 * This schema validates that the provided chain is supported for CCTPv2 bridging.
 * It accepts either a BridgeChain enum value, a string matching a BridgeChain value,
 * or a ChainDefinition for a supported chain.
 *
 * Use this schema when validating chain parameters for bridge operations to ensure
 * only CCTPv2-supported chains are accepted at runtime.
 *
 * @example
 * ```typescript
 * import { bridgeChainIdentifierSchema } from '@core/chains/validation'
 * import { BridgeChain, Chains } from '@core/chains'
 *
 * // Valid - BridgeChain enum value
 * bridgeChainIdentifierSchema.parse(BridgeChain.Ethereum)
 *
 * // Valid - string literal
 * bridgeChainIdentifierSchema.parse('Base_Sepolia')
 *
 * // Valid - ChainDefinition (validated by CCTP support)
 * bridgeChainIdentifierSchema.parse(Chains.Solana)
 *
 * // Invalid - Algorand is not in BridgeChain (throws ZodError)
 * bridgeChainIdentifierSchema.parse('Algorand')
 * ```
 *
 * @see {@link BridgeChain} for the enum of supported chains.
 */
zod.z.union([
    zod.z.string().refine((val) => val in BridgeChain, (val) => ({
        message: `Chain "${val}" is not supported for bridging. Only chains in the BridgeChain enum support CCTPv2 bridging.`,
    })),
    chainDefinitionSchema$2.refine((chainDef) => chainDef.chain in BridgeChain, (chainDef) => ({
        message: `Chain "${chainDef.name}" (${chainDef.chain}) is not supported for bridging. Only chains in the BridgeChain enum support CCTPv2 bridging.`,
    })),
]);
/**
 * Zod schema for validating earn-specific chain identifiers.
 *
 * Validate that the provided chain is supported for earn (vault
 * deposit/withdraw) operations. Currently only Ethereum is
 * supported.
 *
 * Accept an EarnChain enum value, a matching string literal, or
 * a ChainDefinition for a supported chain.
 *
 * @example
 * ```typescript
 * import { earnChainIdentifierSchema } from '@core/chains'
 * import { EarnChain, Ethereum } from '@core/chains'
 *
 * // Valid
 * earnChainIdentifierSchema.parse(EarnChain.Ethereum)
 * earnChainIdentifierSchema.parse('Ethereum')
 * earnChainIdentifierSchema.parse(Ethereum)
 *
 * // Invalid (throws ZodError)
 * earnChainIdentifierSchema.parse('Solana')
 * ```
 */
zod.z.union([
    zod.z.string().refine((val) => val in EarnChain, (val) => ({
        message: `"${val}" is not a supported earn chain. ` +
            `Supported chains: ${Object.values(EarnChain).join(', ')}`,
    })),
    zod.z.nativeEnum(EarnChain),
    chainDefinitionSchema$2.refine((chain) => chain.chain in EarnChain, (chain) => ({
        message: `"${chain.chain}" is not a supported earn chain. ` +
            `Supported chains: ${Object.values(EarnChain).join(', ')}`,
    })),
]);
/**
 * Zod schema for validating unified balance chain identifiers.
 *
 * This schema validates that the provided chain is supported for unified balance operations.
 * It accepts either a UnifiedBalanceChain enum value, a string matching a UnifiedBalanceChain value,
 * or a ChainDefinition for a supported chain.
 *
 * Use this schema when validating chain parameters for unified balance operations to ensure
 * only Gateway V1-supported chains are accepted at runtime.
 *
 * @example
 * ```typescript
 * import { unifiedBalanceChainIdentifierSchema } from '@core/chains/validation'
 * import { UnifiedBalanceChain, Chains } from '@core/chains'
 *
 * // Valid - UnifiedBalanceChain enum value
 * unifiedBalanceChainIdentifierSchema.parse(UnifiedBalanceChain.Ethereum)
 *
 * // Valid - string literal
 * unifiedBalanceChainIdentifierSchema.parse('Ethereum')
 *
 * // Invalid - Algorand is not in UnifiedBalanceChain (throws ZodError)
 * unifiedBalanceChainIdentifierSchema.parse('Algorand')
 * ```
 *
 * @see {@link UnifiedBalanceChain} for the enum of supported chains.
 */
const supportedUnifiedBalanceChains = Object.keys(UnifiedBalanceChain).join(', ');
zod.z.union([
    zod.z.string().refine((val) => val in UnifiedBalanceChain, (val) => ({
        message: `Chain "${val}" is not supported for unified balance operations. Supported chains: ${supportedUnifiedBalanceChains}.`,
    })),
    chainDefinitionSchema$2.refine((chainDef) => chainDef.chain in UnifiedBalanceChain, (chainDef) => ({
        message: `Chain "${chainDef.name}" (${chainDef.chain}) is not supported for unified balance operations. Supported chains: ${supportedUnifiedBalanceChains}.`,
    })),
]);

/**
 * @packageDocumentation
 * @module SwapTokenSchemas
 *
 * Zod validation schemas for supported swap tokens.
 */
// Internal enum used after input normalization.
const swapTokenEnumSchema = zod.z.enum([
    ...Object.keys(SWAP_TOKEN_REGISTRY),
    NATIVE_TOKEN,
]);
/**
 * Zod schema for validating supported swap token symbols.
 *
 * Accepts any token symbol from the SWAP_TOKEN_REGISTRY plus NATIVE.
 * Input matching is case-insensitive and normalized to uppercase.
 *
 * @example
 * ```typescript
 * import { supportedSwapTokenSchema } from '@core/chains'
 *
 * const result = supportedSwapTokenSchema.safeParse('USDC')
 * if (result.success) {
 *   console.log('Valid swap token:', result.data)
 * }
 * ```
 */
zod.z
    .string()
    .transform((value) => value.toUpperCase())
    .pipe(swapTokenEnumSchema);

/**
 * Retrieve a chain definition by its blockchain enum value.
 *
 * Searches the set of known chain definitions and returns the one matching the provided
 * blockchain enum or string value. Throws an error if no matching chain is found.
 *
 * @param blockchain - The blockchain enum or its string representation to look up.
 * @returns The corresponding ChainDefinition object for the given blockchain.
 *
 * @throws Error If no chain definition is found for the provided enum value.
 *
 * @example
 * ```typescript
 * import { getChainByEnum } from '@core/chains'
 * import { Blockchain } from '@core/chains'
 *
 * const ethereum = getChainByEnum(Blockchain.Ethereum)
 * console.log(ethereum.name) // "Ethereum"
 * ```
 */
const getChainByEnum = (blockchain) => {
    const chain = Object.values(Chains).find((chain) => {
        return chain.chain === blockchain;
    });
    if (!chain) {
        throw new Error(`No chain definition found for blockchain: ${blockchain}`);
    }
    return chain;
};

/**
 * Resolves a flexible chain identifier to a ChainDefinition.
 *
 * This function handles all three supported formats:
 * - ChainDefinition objects (passed through unchanged)
 * - Blockchain enum values (resolved via getChainByEnum)
 * - String literals of blockchain values (resolved via getChainByEnum)
 *
 * @param chainIdentifier - The chain identifier to resolve
 * @returns The resolved ChainDefinition object
 * @throws Error if the chain identifier cannot be resolved
 *
 * @example
 * ```typescript
 * import { resolveChainIdentifier } from '@core/chains'
 * import { Blockchain, Ethereum } from '@core/chains'
 *
 * // All of these resolve to the same ChainDefinition:
 * const chain1 = resolveChainIdentifier(Ethereum)
 * const chain2 = resolveChainIdentifier(Blockchain.Ethereum)
 * const chain3 = resolveChainIdentifier('Ethereum')
 * ```
 */
function resolveChainIdentifier(chainIdentifier) {
    // Handle null explicitly (typeof null === 'object' in JavaScript)
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (chainIdentifier === null) {
        throw new Error(`Invalid chain identifier type: null. Expected ChainDefinition object, Blockchain enum, or string literal.`);
    }
    // If it's already a ChainDefinition object, return it unchanged
    if (typeof chainIdentifier === 'object') {
        return chainIdentifier;
    }
    // If it's a string or enum value, resolve it via getChainByEnum
    if (typeof chainIdentifier === 'string') {
        return getChainByEnum(chainIdentifier);
    }
    // This should never happen with proper typing, but provide a fallback
    throw new Error(`Invalid chain identifier type: ${typeof chainIdentifier}. Expected ChainDefinition object, Blockchain enum, or string literal.`);
}

/**
 * Extracts chain information including name, display name, and expected address format.
 *
 * This function determines the chain type by checking the explicit `type` property first,
 * then falls back to name-based matching for Solana chains. The expected address format
 * is determined based on the chain type:
 * - EVM chains: 42-character hex address starting with 0x
 * - Solana chains: 44-character base58 encoded string
 * - Other chains: Generic format message based on chain type
 *
 * @param chain - The chain identifier (ChainDefinition object, string name, or undefined/null)
 * @returns Chain information with name, display name, and expected address format
 *
 * @example
 * ```typescript
 * import { extractChainInfo } from '@core/chains'
 *
 * // EVM chain with explicit type
 * const info1 = extractChainInfo({ name: 'Ethereum', type: 'evm' })
 * console.log(info1.name) // → "Ethereum"
 * console.log(info1.displayName) // → "Ethereum"
 * console.log(info1.expectedAddressFormat)
 * // → "42-character hex address starting with 0x"
 *
 * // Solana chain (inferred from name)
 * const info2 = extractChainInfo('Solana')
 * console.log(info2.expectedAddressFormat)
 * // → "44-character base58 encoded string"
 *
 * // Non-EVM chain with explicit type
 * const info3 = extractChainInfo({ name: 'Algorand', type: 'algorand' })
 * console.log(info3.expectedAddressFormat)
 * // → "valid algorand address"
 *
 * // Unknown chain
 * const info4 = extractChainInfo(undefined)
 * console.log(info4.name) // → "unknown"
 * console.log(info4.expectedAddressFormat) // → "valid blockchain address"
 * ```
 */
function extractChainInfo(chain) {
    const name = typeof chain === 'string' ? chain : (chain?.name ?? 'unknown');
    const chainType = typeof chain === 'object' && chain !== null ? chain.type : undefined;
    // Use explicit chain type if available, fallback to name matching
    const isSolana = chainType === undefined
        ? name.toLowerCase().includes('solana')
        : chainType === 'solana';
    // Default to EVM if not Solana and no explicit non-EVM type
    const isEVM = chainType === undefined
        ? !isSolana // Default to EVM for unknown chains (unless they're Solana)
        : chainType === 'evm';
    // Determine expected address format based on chain type
    let expectedAddressFormat;
    if (isSolana) {
        expectedAddressFormat = '44-character base58 encoded string';
    }
    else if (isEVM) {
        expectedAddressFormat = '42-character hex address starting with 0x';
    }
    else {
        expectedAddressFormat = `valid ${chainType ?? 'blockchain'} address`;
    }
    return {
        name,
        displayName: name.replaceAll('_', ' '),
        expectedAddressFormat,
    };
}

/**
 * Check whether the current runtime is Node.js.
 *
 * @returns `true` when running in Node.js, `false` otherwise.
 *
 * @example
 * ```typescript
 * import { isNodeEnvironment } from '@core/utils'
 *
 * if (isNodeEnvironment()) {
 *   console.log('Running in Node.js')
 * }
 * ```
 */
const isNodeEnvironment = () => typeof process !== 'undefined' &&
    typeof process.versions === 'object' &&
    typeof process.versions.node === 'string';
/**
 * Detect the runtime environment and return a shortened identifier.
 *
 * @returns Runtime string, e.g., "node/18", "browser/Chrome", or "unknown"
 */
const getRuntime = () => {
    // Node.js environment
    if (isNodeEnvironment()) {
        // Shorten to major version only
        const majorVersion = process.versions.node.split('.')[0] ?? 'unknown';
        return `node/${majorVersion}`;
    }
    // Browser environment
    if (typeof window !== 'undefined' && typeof navigator !== 'undefined') {
        const userAgent = navigator.userAgent;
        const browserMatchers = {
            Edge: (ua) => ua.includes('Edg'),
            Chrome: (ua) => ua.includes('Chrome') && !ua.includes('Edg'),
            Firefox: (ua) => ua.includes('Firefox'),
            Safari: (ua) => ua.includes('Safari') && !ua.includes('Chrome'),
            Opera: (ua) => ua.includes('Opera') || ua.includes('OPR'),
        };
        for (const [browserName, matcher] of Object.entries(browserMatchers)) {
            if (matcher(userAgent))
                return `browser/${browserName}`;
        }
        return 'browser/unknown';
    }
    return 'unknown';
};
/**
 * Shorten package names by removing common prefixes.
 *
 * @param fullName - Full package name, e.g., "\@circle-fin/bridge-kit"
 * @returns Shortened name, e.g., "bridge-kit"
 */
const shortenPackageName = (fullName) => {
    return fullName.replace('@circle-fin/', '');
};
/**
 * Format a component (name/version) with length optimizations.
 *
 * @param nameWithVersion - Component identifier, e.g., "\@circle-fin/bridge-kit/1.2.3"
 * @returns Formatted component, e.g., "bridge-kit/1.2"
 */
const formatComponent = (nameWithVersion) => {
    // Find the last / to split name and version
    // This handles scoped packages like @circle-fin/bridge-kit/1.0.0 correctly
    const lastSlashIndex = nameWithVersion.lastIndexOf('/');
    if (lastSlashIndex === -1) {
        // No version, just a name
        return shortenPackageName(nameWithVersion);
    }
    const name = nameWithVersion.substring(0, lastSlashIndex);
    const version = nameWithVersion.substring(lastSlashIndex + 1);
    if (name === '')
        return '';
    if (version === '')
        return shortenPackageName(name);
    return `${shortenPackageName(name)}/${version}`;
};
/**
 * Create a new request context from global state.
 *
 * Reads the current external prefix and kit identifier from globalThis.
 * This is used internally by HTTP utilities.
 *
 * @returns A new request context
 * @internal
 */
const createRequestContext = () => {
    const context = {};
    if (typeof globalThis !== 'undefined') {
        if (globalThis.__APP_KITS_EXTERNAL_PREFIX__ !== undefined) {
            context.externalPrefix = globalThis.__APP_KITS_EXTERNAL_PREFIX__;
        }
        if (globalThis.__APP_KITS_CURRENT_KIT__ !== undefined) {
            context.kit = globalThis.__APP_KITS_CURRENT_KIT__;
        }
    }
    return context;
};
/**
 * Build a user agent string from a request context.
 *
 * Formats the context into a user agent string with automatic optimizations
 * (shortened package names and truncated versions). The current implementation
 * tracks a single kit globally.
 *
 * Format: `[external-prefix] kit (runtime)`
 *
 * @param context - Request context or undefined to use the global context
 * @returns Formatted user agent string
 *
 * @example
 * ```typescript
 * // With application prefix and kit
 * const ua = getUserAgent(context)
 * // → "my-app/1.0 bridge-kit/1.2 (node/18)"
 *
 * // Kit only (no application prefix set)
 * const ua = getUserAgent()
 * // → "bridge-kit/1.2 (node/18)"
 * ```
 */
const getUserAgent = (context) => {
    const ctx = createRequestContext();
    const runtime = getRuntime();
    // Build user agent string
    const parts = [];
    // Add external prefix if set
    if (ctx.externalPrefix !== undefined) {
        const formatted = formatComponent(ctx.externalPrefix);
        if (formatted)
            parts.push(formatted);
    }
    // Add kit if set
    if (ctx.kit !== undefined) {
        const formatted = formatComponent(ctx.kit);
        if (formatted)
            parts.push(formatted);
    }
    // Add runtime
    parts.push(`(${runtime})`);
    return parts.join(' ');
};

/**
 * Default configuration values for the API polling utility.
 * @internal
 */
const DEFAULT_CONFIG = {
    timeout: 2_000,
    maxRetries: 10,
    retryDelay: 200,
    headers: {
        'Content-Type': 'application/json',
    },
};
/**
 * Helper to wait for a given number of milliseconds.
 */
const delay = async (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
};
/**
 * Makes a single HTTP request with timeout and validation.
 *
 * This function handles the low-level details of making an HTTP request,
 * including timeout management, response validation, and error handling.
 *
 * @remarks
 * The function uses AbortController for timeout management and includes proper cleanup
 * of timeouts in all code paths. It validates both the HTTP response status and the
 * response data format using the provided type guard before returning.
 *
 * Error handling:
 * - Throws on HTTP error responses (non-200 status codes)
 * - Throws on request timeout
 * - Throws on validation failure
 * - Ensures timeout cleanup in all cases
 *
 * @typeParam TResponseType - The expected response type after validation
 * @param url - The full URL to make the request to
 * @param method - The HTTP method to use
 * @param isValidType - Type guard function to validate the response
 * @param config - Configuration for this request
 * @param body - Optional request body (for POST/PUT/PATCH requests)
 * @returns Promise resolving to the validated response
 * @throws If the request fails, times out, or returns invalid data
 *
 * @example
 * ```typescript
 * const isUserResponse = (obj: unknown): obj is { id: number; name: string } => {
 *   return typeof obj === 'object' && obj !== null &&
 *          'id' in obj && 'name' in obj
 * }
 *
 * const user = await makeApiRequest(
 *   'https://api.example.com/users/1',
 *   'GET',
 *   isUserResponse,
 *   { timeout: 5000 }
 * )
 * ```
 */
const makeApiRequest = async (url, method, isValidType, config, body) => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
        controller.abort('Request timed out');
    }, config.timeout);
    try {
        const requestInit = {
            method,
            headers: config.headers ?? {},
            signal: controller.signal,
        };
        // Add body for methods that support it
        if (body !== undefined && ['POST', 'PUT', 'PATCH'].includes(method)) {
            requestInit.body = JSON.stringify(body);
        }
        const response = await fetch(url, requestInit);
        clearTimeout(timeoutId);
        if (!response.ok) {
            let responseBody;
            try {
                responseBody = (await response.json());
            }
            catch {
                // Parse response body for diagnostics; continue even if malformed
                // so callers always receive HTTP status context
            }
            const httpError = new Error(`HTTP ${String(response.status)} - ${response.statusText}`);
            httpError.responseBody = responseBody;
            throw httpError;
        }
        const parsedJson = (await response.json());
        if (!isValidType(parsedJson)) {
            throw new Error('Invalid response format: response data failed validation');
        }
        return parsedJson;
    }
    finally {
        clearTimeout(timeoutId);
    }
};
/**
 * Determines if an error should trigger a retry attempt.
 *
 * This function implements the retry policy by analyzing error types and messages.
 * It follows these rules:
 * 1. Client errors (HTTP 4xx) are not retried, except for rate limiting (429)
 * 2. Invalid response format errors are not retried
 * 3. All other errors (network, timeout, server errors) are retried
 *
 * @remarks
 * The retry policy is designed to be conservative with retries on client errors
 * (which are unlikely to succeed) while being more lenient with potentially
 * transient failures like network issues or server errors.
 *
 * @param error - The error to analyze
 * @returns True if the error should trigger a retry, false otherwise
 *
 * @example
 * ```typescript
 * try {
 *   await makeApiRequest(...)
 * } catch (err) {
 *   const error = err instanceof Error ? err : new Error(String(err))
 *   if (isRetryableError(error)) {
 *     console.log('Will retry - temporary failure')
 *   } else {
 *     console.log('Will not retry - permanent failure')
 *   }
 * }
 * ```
 */
const isRetryableError = (error) => {
    // Don't retry KitErrors with explicit non-retryable recoverability
    if (error instanceof KitError && error.recoverability !== 'RETRYABLE') {
        return false;
    }
    // Don't retry client errors (4xx) except for 404 (Not Found) and 429 (Rate Limiting)
    if (/HTTP 4(?!(04|29))/.test(error.message)) {
        return false;
    }
    // Don't retry invalid response format errors
    if (error.message.includes('Invalid response format')) {
        return false;
    }
    return true;
};
/**
 * Polls an API endpoint with retry logic and type validation.
 *
 * This utility function provides a robust way to interact with APIs that may be
 * temporarily unavailable or return errors. It implements configurable retry logic
 * with exponential backoff and validates responses using provided type guards.
 *
 * @remarks
 * The function uses a conservative retry policy:
 * - Retries on server errors (5xx) and network issues
 * - Retries on rate limiting (429)
 * - Does not retry on client errors (4xx, except 429)
 * - Does not retry on validation failures
 *
 * Each HTTP request is given a configurable timeout before it is aborted.
 * The function waits between retry attempts to respect API rate limits.
 *
 * @typeParam TResponseType - The expected response type after validation
 * @param url - The API endpoint URL to poll
 * @param method - The HTTP method to use
 * @param isValidType - Type guard function to validate the response
 * @param config - Optional configuration overrides
 * @param body - Optional request body (for POST/PUT/PATCH requests)
 * @returns Promise resolving to the validated response
 * @throws If all retry attempts are exhausted or a non-retryable error occurs
 *
 * @example
 * ```typescript
 * import { pollApiWithValidation } from '@core/utils'
 *
 * // Define a type guard for the expected response
 * const isUserResponse = (obj: unknown): obj is { id: number; name: string } => {
 *   return typeof obj === 'object' && obj !== null &&
 *          'id' in obj && 'name' in obj &&
 *          typeof (obj as any).id === 'number' &&
 *          typeof (obj as any).name === 'string'
 * }
 *
 * // Poll an API with custom configuration
 * const user = await pollApiWithValidation(
 *   'https://api.example.com/users/1',
 *   'GET',
 *   isUserResponse,
 *   {
 *     timeout: 5000,
 *     maxRetries: 5,
 *     retryDelay: 1000
 *   }
 * )
 * ```
 *
 * @example
 * ```typescript
 * // POST request with body
 * const createUser = async (userData: { name: string; email: string }) => {
 *   return pollApiWithValidation(
 *     'https://api.example.com/users',
 *     'POST',
 *     isUserResponse,
 *     { maxRetries: 3 },
 *     userData
 *   )
 * }
 * ```
 */
const pollApiWithValidation = async (url, method, isValidType, config = {}, body) => {
    // Merge headers so that 'User-Agent' is always present and not overwritten
    const effectiveConfig = {
        ...DEFAULT_CONFIG,
        ...config,
        headers: {
            ...DEFAULT_CONFIG.headers,
            ...(config.headers ?? {}),
            // In browser environments, directly setting the 'User-Agent' or similar headers is restricted and may be ignored or cause errors.
            // This is why we use the 'X-User-Agent' header instead.
            ...(typeof window === 'undefined'
                ? { 'User-Agent': getUserAgent() }
                : { 'X-User-Agent': getUserAgent() }),
        },
    };
    let lastError;
    for (let attempt = 1; attempt <= effectiveConfig.maxRetries; attempt++) {
        try {
            return await makeApiRequest(url, method, isValidType, effectiveConfig, body);
        }
        catch (err) {
            const error = err instanceof Error ? err : new Error(String(err));
            if (!isRetryableError(error)) {
                throw error;
            }
            lastError = error;
            if (attempt < effectiveConfig.maxRetries) {
                await delay(effectiveConfig.retryDelay);
            }
        }
    }
    // Preserve responseBody from the last attempt so upstream parsers
    // (e.g. parseApiError) can inspect the server's structured response.
    const retryError = new Error(`Maximum retry attempts (${String(effectiveConfig.maxRetries)}) exceeded: ${String(lastError?.message)}`);
    if (lastError !== undefined &&
        'responseBody' in lastError &&
        lastError.responseBody !== undefined) {
        retryError.responseBody = lastError.responseBody;
    }
    throw retryError;
};
/**
 * Convenience function for making GET requests with validation.
 *
 * @typeParam TResponseType - The expected response type after validation
 * @param url - The API endpoint URL
 * @param isValidType - Type guard function to validate the response
 * @param config - Optional configuration overrides
 * @returns Promise resolving to the validated response
 *
 * @example
 * ```typescript
 * const data = await pollApiGet(
 *   'https://api.example.com/data',
 *   isDataResponse,
 *   { timeout: 3000 }
 * )
 * ```
 */
const pollApiGet = async (url, isValidType, config) => {
    return pollApiWithValidation(url, 'GET', isValidType, config);
};
/**
 * Convenience function for making POST requests with validation.
 *
 * @typeParam TResponseType - The expected response type after validation
 * @typeParam TBody - The type of the request body
 * @param url - The API endpoint URL
 * @param body - The request body
 * @param isValidType - Type guard function to validate the response
 * @param config - Optional configuration overrides
 * @returns Promise resolving to the validated response
 *
 * @example
 * ```typescript
 * const result = await pollApiPost(
 *   'https://api.example.com/submit',
 *   { name: 'John', email: 'john@example.com' },
 *   isSubmissionResponse,
 *   { maxRetries: 3 }
 * )
 * ```
 */
const pollApiPost = async (url, body, isValidType, config) => {
    return pollApiWithValidation(url, 'POST', isValidType, config, body);
};

/**
 * Validates data against a Zod schema with enhanced error reporting.
 *
 * This function performs validation using Zod schemas and provides detailed error
 * messages that include the validation context. It's designed to give developers
 * clear feedback about what went wrong during validation.
 *
 * @param value - The value to validate
 * @param schema - The Zod schema to validate against
 * @param context - Context string to include in error messages (e.g., 'bridge parameters')
 * @returns Asserts that value is of type T (type narrowing)
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098)
 *
 * @example
 * ```typescript
 * validate(params, BridgeParamsSchema, 'bridge parameters')
 * // After this call, TypeScript knows params is of type BridgeParams
 * ```
 */
function validate(value, schema, context) {
    const result = schema.safeParse(value);
    if (!result.success) {
        throw createValidationErrorFromZod(result.error, context);
    }
}

/**
 * Module-level WeakMap for tracking which (schema, validator) combinations
 * have already processed a given object. This avoids mutating user-supplied
 * input objects while ensuring re-validation occurs when schemas change.
 * @internal
 */
const validationStateMap = new WeakMap();
/**
 * Validates data against a Zod schema with state tracking and enhanced error reporting.
 *
 * This function performs validation using Zod schemas while tracking validation state
 * and providing detailed error messages. It's designed for use in scenarios where
 * validation state needs to be monitored and reported.
 *
 * @param value - The value to validate
 * @param schema - The Zod schema to validate against
 * @param context - Context string to include in error messages (e.g., 'bridge parameters')
 * @param validatorName - Symbol identifying the validator for state tracking
 * @returns Asserts that value is of type T (type narrowing)
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098)
 *
 * @example
 * ```typescript
 * const VALIDATOR = Symbol('bridgeValidator')
 * validateWithStateTracking(params, BridgeParamsSchema, 'bridge parameters', VALIDATOR)
 * // params is now narrowed to the schema's output type
 * ```
 */
function validateWithStateTracking(value, schema, context, validatorName) {
    if (value === null) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid ${context}: Value is null`,
            cause: {
                trace: {
                    validationErrors: ['Value is null'],
                },
            },
        });
    }
    if (value === undefined) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid ${context}: Value is undefined`,
            cause: {
                trace: {
                    validationErrors: ['Value is undefined'],
                },
            },
        });
    }
    if (typeof value !== 'object') {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid ${context}: Value must be an object`,
            cause: {
                trace: {
                    validationErrors: [`Value must be an object, got ${typeof value}`],
                },
            },
        });
    }
    const state = validationStateMap.get(value) ?? {
        validatedSchemasByValidator: new Map(),
    };
    // Get the set of schemas that have already validated this object
    // for the given validator. Create a new WeakSet if this is first time.
    const validatedSchemas = state.validatedSchemasByValidator.get(validatorName) ?? new WeakSet();
    if (!(validatedSchemas instanceof WeakSet)) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Invalid validation state: expected WeakSet',
        });
    }
    // Check if this exact schema instance has already validated this object
    if (validatedSchemas.has(schema)) {
        return;
    }
    validate(value, schema, context);
    // Record that this schema has validated the object for this validator
    validatedSchemas.add(schema);
    state.validatedSchemasByValidator.set(validatorName, validatedSchemas);
    validationStateMap.set(value, state);
}

/**
 * Zod schema for validating chain definition objects used in buildExplorerUrl.
 * This schema ensures the chain definition has the required properties for URL generation.
 */
const chainDefinitionSchema$1 = zod.z.object({
    name: zod.z
        .string({
        required_error: 'Chain name is required',
        invalid_type_error: 'Chain name must be a string',
    })
        .min(1, 'Chain name cannot be empty'),
    explorerUrl: zod.z
        .string({
        required_error: 'Explorer URL template is required',
        invalid_type_error: 'Explorer URL template must be a string',
    })
        .min(1, 'Explorer URL template cannot be empty')
        .refine((url) => url.includes('{hash}'), 'Explorer URL template must contain a {hash} placeholder'),
});
/**
 * Zod schema for validating transaction hash strings used in buildExplorerUrl.
 * This schema ensures the transaction hash is a non-empty string.
 */
const transactionHashSchema = zod.z
    .string({
    required_error: 'Transaction hash is required',
    invalid_type_error: 'Transaction hash must be a string',
})
    .transform((hash) => hash.trim())
    .refine((hash) => hash.length > 0, 'Transaction hash cannot be empty');
/**
 * Zod schema for validating buildExplorerUrl function parameters.
 * This schema validates both the chain definition and transaction hash together.
 */
const buildExplorerUrlParamsSchema = zod.z.object({
    chainDef: chainDefinitionSchema$1,
    txHash: transactionHashSchema,
});
/**
 * Zod schema for validating the generated explorer URL.
 * This schema ensures the generated URL is valid.
 */
const explorerUrlSchema = zod.z
    .string()
    .url('Generated explorer URL is invalid');

/**
 * Validates data against a Zod schema and throws a KitError on failure.
 *
 * This utility function provides consistent validation and error formatting across the codebase.
 * It performs the validation and formats error messages with contextual information while
 * preserving all individual validation errors in a structured format.
 *
 * @param value - The value to validate
 * @param schema - The Zod schema to validate against
 * @param message - Error message (e.g., 'Invalid EVM address', 'Configuration error')
 * @returns Asserts that value is of type T (type narrowing)
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098) and detailed error information
 *
 * @example
 * ```typescript
 * import { validateOrThrow } from '@core/utils'
 * import { z } from 'zod'
 *
 * const userSchema = z.object({
 *   name: z.string().min(3),
 *   age: z.number().positive()
 * })
 *
 * // This will throw KitError if validation fails
 * validateOrThrow({ name: 'Jo', age: -1 }, userSchema, 'Invalid user data')
 * // Throws: KitError with code 1098 and message "Invalid user data: name: String must contain at least 3 character(s)"
 * ```
 *
 * @example
 * ```typescript
 * // Usage in assertion functions with flexible messaging
 * validateOrThrow(address, evmAddressSchema, 'Invalid EVM address')
 * validateOrThrow(config, configSchema, 'Configuration error')
 * validateOrThrow(params, paramSchema, 'Bad parameters')
 * ```
 *
 * @example
 * ```typescript
 * // Usage in validation functions
 * function validateUserParams(params: unknown): void {
 *   validateOrThrow(params, userSchema, 'Invalid user parameters')
 *   // If we reach here, params is guaranteed to be valid
 * }
 * ```
 */
function validateOrThrow(value, schema, message) {
    const result = schema.safeParse(value);
    if (!result.success) {
        throw createValidationErrorFromZod(result.error, message);
    }
}

/**
 * Parses and validates data against a Zod schema, returning the transformed result.
 *
 * Unlike `validate` and `validateOrThrow` which use type assertions (`asserts value is T`),
 * this function **returns the parsed data** from Zod. This is important when your schema
 * includes transformations like defaults, coercion, or custom transforms.
 *
 * @typeParam T - The expected output type (caller must specify).
 * @param value - The value to parse and validate.
 * @param schema - The Zod schema to validate against.
 * @param context - Context string to include in error messages (e.g., 'user input', 'config').
 * @returns The parsed and transformed data of type T.
 * @throws KitError with INPUT_VALIDATION_FAILED code (1098) if validation fails.
 *
 * @remarks
 * This function uses `ZodTypeAny` for the schema parameter to avoid TypeScript's
 * "excessively deep type instantiation" error in generic contexts. The caller
 * must provide the expected type `T` explicitly.
 *
 * Use this instead of `validate`/`validateOrThrow` when:
 * - Your schema has `.default()` values
 * - Your schema uses `.coerce` (e.g., `z.coerce.number()`)
 * - Your schema has `.transform()` functions
 * - You need the actual parsed output, not just type narrowing
 *
 * @example
 * ```typescript
 * import { parseOrThrow } from '@core/utils'
 * import { z } from 'zod'
 *
 * const userSchema = z.object({
 *   name: z.string().default('Anonymous'),
 *   age: z.coerce.number(),  // Transforms "25" → 25
 * })
 *
 * type User = z.infer<typeof userSchema>
 *
 * // Explicit type parameter
 * const user = parseOrThrow<User>({ age: '25' }, userSchema, 'user data')
 * console.log(user)  // { name: 'Anonymous', age: 25 }
 * ```
 *
 * @example
 * ```typescript
 * // Usage in generic adapter functions (no deep type instantiation)
 * function validateInput<TInput>(
 *   input: unknown,
 *   schema: z.ZodTypeAny,
 *   name: string,
 * ): TInput {
 *   return parseOrThrow<TInput>(input, schema, `${name} input`)
 * }
 * ```
 */
// eslint-disable-next-line @typescript-eslint/no-unnecessary-type-parameters -- Intentional: T is caller-provided to avoid deep type instantiation from schema inference
function parseOrThrow(value, schema, context) {
    const result = schema.safeParse(value);
    if (!result.success) {
        throw createValidationErrorFromZod(result.error, context);
    }
    return result.data;
}

/**
 * Detect the format of the provided address string.
 *
 * Analyzes the address format and returns the corresponding chain type or bytes32
 * format. Supports EVM addresses (0x-prefixed 40-char hex), bytes32 addresses
 * (0x-prefixed 64-char hex), and Solana addresses (base58 encoded 32-byte keys).
 *
 * @param address - The address string to analyze.
 * @returns The detected format: 'evm', 'solana', or 'bytes32'.
 * @throws Error if the address format is unrecognized.
 *
 * @example
 * ```typescript
 * import { detectFormat } from '@core/utils'
 *
 * // EVM address
 * const evmFormat = detectFormat('0x1234567890abcdef1234567890abcdef12345678')
 * console.log(evmFormat) // 'evm'
 *
 * // Solana address
 * const solanaFormat = detectFormat('11111111111111111111111111111112')
 * console.log(solanaFormat) // 'solana'
 *
 * // Bytes32 address
 * const bytes32Format = detectFormat('0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(bytes32Format) // 'bytes32'
 * ```
 */
const detectFormat = (address) => {
    if (/^0x[0-9a-fA-F]{40}$/.test(address)) {
        return 'evm';
    }
    if (/^0x[0-9a-fA-F]{64}$/.test(address)) {
        return 'bytes32';
    }
    const decoded = bs58__default.decode(address);
    if (decoded.length === 32)
        return 'solana';
    throw new Error(`Unsupported address format: ${address}`);
};
/**
 * Convert an EVM address or Solana base58 key into a 32-byte hex string.
 *
 * This function normalizes addresses from different blockchain formats into a
 * standardized 32-byte hex representation. EVM addresses are zero-padded to
 * 32 bytes, while Solana addresses are decoded from base58 format.
 *
 * @param address - The address string to convert.
 * @returns A 32-byte hex string (0x-prefixed).
 * @throws Error if the address format is unsupported.
 *
 * @example
 * ```typescript
 * import { toBytes32 } from '@core/utils'
 *
 * // Convert EVM address
 * const evmBytes32 = toBytes32('0x1234567890abcdef1234567890abcdef12345678')
 * console.log(evmBytes32) // '0x0000000000000000000000001234567890abcdef1234567890abcdef12345678'
 *
 * // Convert Solana address
 * const solanaBytes32 = toBytes32('11111111111111111111111111111112')
 * console.log(solanaBytes32) // '0x...' (32-byte hex representation)
 * ```
 */
const toBytes32$1 = (address) => {
    const fmt = detectFormat(address);
    switch (fmt) {
        case 'evm':
            // pad 20-byte address → 32 bytes
            return bytes.hexZeroPad(address, 32);
        case 'bytes32':
            return address;
        case 'solana':
            // base58 decode → raw 32 bytes → hex
            return bytes.hexlify(bs58__default.decode(address));
    }
    throw new Error(`Unsupported address format: ${address}`);
};
/**
 * Convert a bytes32 hex string to a checksummed EVM address.
 *
 * This function extracts the last 20 bytes from a 32-byte hex string and
 * converts it to a valid EVM address with EIP-55 checksum formatting.
 *
 * @param bytes32 - The 32-byte hex string (with or without 0x prefix).
 * @returns A checksummed EVM address (0x-prefixed).
 * @throws Error if the input is not a valid hex string.
 *
 * @example
 * ```typescript
 * import { bytes32ToEvm } from '@core/utils'
 *
 * // Convert bytes32 to EVM address
 * const evmAddress = bytes32ToEvm('0x0000000000000000000000001234567890abcdef1234567890abcdef12345678')
 * console.log(evmAddress) // '0x1234567890AbcdEF1234567890aBcdeF12345678' (checksummed)
 *
 * // Works without 0x prefix too
 * const evmAddress2 = bytes32ToEvm('0000000000000000000000001234567890abcdef1234567890abcdef12345678')
 * console.log(evmAddress2) // '0x1234567890AbcdEF1234567890aBcdeF12345678'
 * ```
 */
const bytes32ToEvm = (bytes32) => {
    // remove 0x prefix
    const hex = bytes32.startsWith('0x') ? bytes32.slice(2) : bytes32;
    // take last 20 bytes (40 hex chars)
    const ethHex = '0x' + hex.slice(-40);
    // apply EIP-55 checksum
    return address.getAddress(ethHex);
};
/**
 * Convert a bytes32 hex string to a Solana base58 address.
 *
 * This function takes a 32-byte hex string and converts it to a Solana
 * public key address using base58 encoding.
 *
 * @param bytes32 - The 32-byte hex string (with or without 0x prefix).
 * @returns A Solana address in base58 format.
 * @throws Error if the input is not a valid hex string.
 *
 * @example
 * ```typescript
 * import { bytes32ToSolana } from '@core/utils'
 *
 * // Convert bytes32 to Solana address
 * const solanaAddress = bytes32ToSolana('0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(solanaAddress) // Base58 encoded address
 *
 * // Works without 0x prefix too
 * const solanaAddress2 = bytes32ToSolana('1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(solanaAddress2) // Base58 encoded address
 * ```
 */
function bytes32ToSolana(bytes32) {
    const hex = bytes32.startsWith('0x') ? bytes32.slice(2) : bytes32;
    const buffer = Buffer.from(hex, 'hex');
    return bs58__default.encode(new Uint8Array(buffer));
}
/**
 * Convert any supported address format into the target format.
 * @param address - input address (auto-detected)
 * @param targetFormat - one of 'evm', 'solana', or 'bytes32'
 * @returns converted address string
 */
const convertAddress = (address, targetFormat) => {
    const current = detectFormat(address);
    if (current === targetFormat)
        return address;
    // first normalize to bytes32
    const asBytes32 = toBytes32$1(address);
    // then to target
    switch (targetFormat) {
        case 'bytes32':
            return asBytes32;
        case 'evm':
            return bytes32ToEvm(asBytes32);
        case 'solana':
            return bytes32ToSolana(asBytes32);
    }
    throw new Error(`Unsupported address format: ${address}`);
};

/**
 * Convert a value from its smallest unit representation to a human-readable decimal string.
 *
 * This function normalizes token values from their blockchain representation (where
 * everything is stored as integers in the smallest denomination) to human-readable
 * decimal format. Uses the battle-tested implementation from \@ethersproject/units.
 *
 * @param value - The value in smallest units (e.g., "1000000" for 1 USDC with 6 decimals)
 * @param decimals - The number of decimal places for the unit conversion
 * @returns A human-readable decimal string (e.g., "1.0")
 * @throws Error if the value is not a valid numeric string
 *
 * @example
 * ```typescript
 * import { formatUnits } from '@core/utils'
 *
 * // Format USDC (6 decimals)
 * const usdcFormatted = formatUnits('1000000', 6)
 * console.log(usdcFormatted) // "1.0"
 *
 * // Format ETH (18 decimals)
 * const ethFormatted = formatUnits('1000000000000000000', 18)
 * console.log(ethFormatted) // "1.0"
 *
 * // Format with fractional part
 * const fractionalFormatted = formatUnits('1500000', 6)
 * console.log(fractionalFormatted) // "1.5"
 * ```
 */
const formatUnits = (value, decimals) => {
    return units.formatUnits(value, decimals);
};
/**
 * Convert a human-readable decimal string to its smallest unit representation.
 *
 * This function converts user-friendly decimal values into the integer representation
 * required by blockchain operations, where all values are stored in the smallest
 * denomination. Uses the battle-tested implementation from \@ethersproject/units.
 *
 * @param value - The decimal string to convert (e.g., "1.0")
 * @param decimals - The number of decimal places for the unit conversion
 * @returns The value in smallest units as a bigint (e.g., 1000000n for 1 USDC with 6 decimals)
 * @throws Error if the value is not a valid decimal string
 *
 * @example
 * ```typescript
 * import { parseUnits } from '@core/utils'
 *
 * // Parse USDC (6 decimals)
 * const usdcParsed = parseUnits('1.0', 6)
 * console.log(usdcParsed) // 1000000n
 *
 * // Parse ETH (18 decimals)
 * const ethParsed = parseUnits('1.0', 18)
 * console.log(ethParsed) // 1000000000000000000n
 *
 * // Parse fractional amount
 * const fractionalParsed = parseUnits('1.5', 6)
 * console.log(fractionalParsed) // 1500000n
 *
 * // Parse integer (no decimal point)
 * const integerParsed = parseUnits('42', 6)
 * console.log(integerParsed) // 42000000n
 * ```
 */
const parseUnits = (value, decimals) => {
    return units.parseUnits(value, decimals).toBigInt();
};

/**
 * Create a structured error for token resolution failures.
 *
 * @remarks
 * Returns a `KitError` with `INPUT_UNSUPPORTED_TOKEN` code (1006).
 * The error trace contains the selector and chain context for debugging.
 *
 * @param message - Human-readable error description.
 * @param selector - The token selector that failed to resolve.
 * @param chainId - The chain being resolved for (optional).
 * @param cause - The underlying error, if any (optional).
 * @returns A KitError with INPUT type and FATAL recoverability.
 *
 * @example
 * ```typescript
 * throw createTokenResolutionError(
 *   'Unknown token symbol: FAKE',
 *   'FAKE',
 *   'Ethereum'
 * )
 * ```
 */
function createTokenResolutionError(message, selector, chainId, cause) {
    const trace = {
        selector,
        ...(chainId === undefined ? {} : { chainId }),
        ...({} ),
    };
    return new KitError({
        ...InputError.UNSUPPORTED_TOKEN,
        recoverability: 'FATAL',
        message,
        cause: { trace },
    });
}

/**
 * USDC token definition with addresses and metadata.
 *
 * @remarks
 * This is the built-in USDC definition used by the TokenRegistry.
 * Includes all known USDC addresses across supported chains.
 *
 * Keys use the `Blockchain` enum for type safety. Both enum values
 * and string literals are supported:
 * - `Blockchain.Ethereum` or `'Ethereum'`
 *
 * @example
 * ```typescript
 * import { USDC } from '@core/tokens'
 * import { Blockchain } from '@core/chains'
 *
 * console.log(USDC.symbol)   // 'USDC'
 * console.log(USDC.decimals) // 6
 * console.log(USDC.locators[Blockchain.Ethereum])
 * // '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
 * ```
 */
const USDC = {
    symbol: 'USDC',
    decimals: 6,
    locators: {
        // =========================================================================
        // Mainnets (alphabetically sorted)
        // =========================================================================
        [Blockchain.Arbitrum]: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
        [Blockchain.Avalanche]: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
        [Blockchain.Base]: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        [Blockchain.Celo]: '0xcebA9300f2b948710d2653dD7B07f33A8B32118C',
        [Blockchain.Codex]: '0xd996633a415985DBd7D6D12f4A4343E31f5037cf',
        [Blockchain.Edge]: '0x98d2919b9A214E6Fa5384AC81E6864bA686Ad74c',
        [Blockchain.Ethereum]: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
        [Blockchain.Hedera]: '0.0.456858',
        [Blockchain.HyperEVM]: '0xb88339CB7199b77E23DB6E890353E22632Ba630f',
        [Blockchain.Injective]: '0xa00C59fF5a080D2b954d0c75e46E22a0c371235a',
        [Blockchain.Ink]: '0x2D270e6886d130D724215A266106e6832161EAEd',
        [Blockchain.Linea]: '0x176211869ca2b568f2a7d4ee941e073a821ee1ff',
        [Blockchain.Monad]: '0x754704Bc059F8C67012fEd69BC8A327a5aafb603',
        [Blockchain.Morph]: '0xCfb1186F4e93D60E60a8bDd997427D1F33bc372B',
        [Blockchain.NEAR]: '17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1',
        [Blockchain.Noble]: 'uusdc',
        [Blockchain.Optimism]: '0x0b2c639c533813f4aa9d7837caf62653d097ff85',
        [Blockchain.Pharos]: '0xC879C018dB60520F4355C26eD1a6D572cdAC1815',
        [Blockchain.Plume]: '0x222365EF19F7947e5484218551B56bb3965Aa7aF',
        [Blockchain.Polkadot_Asset_Hub]: '1337',
        [Blockchain.Polygon]: '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
        [Blockchain.Sei]: '0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392',
        [Blockchain.Solana]: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
        [Blockchain.Sonic]: '0x29219dd400f2Bf60E5a23d13Be72B486D4038894',
        [Blockchain.Stellar]: 'USDC-GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN',
        [Blockchain.Sui]: '0xdba34672e30cb065b1f93e3ab55318768fd6fef66c15942c9f7cb846e2f900e7::usdc::USDC',
        [Blockchain.Unichain]: '0x078D782b760474a361dDA0AF3839290b0EF57AD6',
        [Blockchain.World_Chain]: '0x79A02482A880bCE3F13e09Da970dC34db4CD24d1',
        [Blockchain.XDC]: '0xfA2958CB79b0491CC627c1557F441eF849Ca8eb1',
        [Blockchain.ZKSync_Era]: '0x1d17CBcF0D6D143135aE902365D2E5e2A16538D4',
        // =========================================================================
        // Testnets (alphabetically sorted)
        // =========================================================================
        [Blockchain.Arc_Testnet]: '0x3600000000000000000000000000000000000000',
        [Blockchain.Arbitrum_Sepolia]: '0x75faf114eafb1BDbe2F0316DF893fd58CE46AA4d',
        [Blockchain.Avalanche_Fuji]: '0x5425890298aed601595a70AB815c96711a31Bc65',
        [Blockchain.Base_Sepolia]: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
        [Blockchain.Codex_Testnet]: '0x6d7f141b6819C2c9CC2f818e6ad549E7Ca090F8f',
        [Blockchain.Edge_Testnet]: '0x2d9F7CAD728051AA35Ecdc472a14cf8cDF5CFD6B',
        [Blockchain.Ethereum_Sepolia]: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
        [Blockchain.Hedera_Testnet]: '0.0.429274',
        [Blockchain.HyperEVM_Testnet]: '0x2B3370eE501B4a559b57D449569354196457D8Ab',
        [Blockchain.Injective_Testnet]: '0x0C382e685bbeeFE5d3d9C29e29E341fEE8E84C5d',
        [Blockchain.Ink_Testnet]: '0xFabab97dCE620294D2B0b0e46C68964e326300Ac',
        [Blockchain.Linea_Sepolia]: '0xfece4462d57bd51a6a552365a011b95f0e16d9b7',
        [Blockchain.Monad_Testnet]: '0x534b2f3A21130d7a60830c2Df862319e593943A3',
        [Blockchain.Morph_Testnet]: '0x7433b41C6c5e1d58D4Da99483609520255ab661B',
        [Blockchain.NEAR_Testnet]: '3e2210e1184b45b64c8a434c0a7e7b23cc04ea7eb7a6c3c32520d03d4afcb8af',
        [Blockchain.Noble_Testnet]: 'uusdc',
        [Blockchain.Optimism_Sepolia]: '0x5fd84259d66Cd46123540766Be93DFE6D43130D7',
        [Blockchain.Pharos_Testnet]: '0xcfC8330f4BCAB529c625D12781b1C19466A9Fc8B',
        [Blockchain.Plume_Testnet]: '0xcB5f30e335672893c7eb944B374c196392C19D18',
        [Blockchain.Polkadot_Westmint]: '31337',
        [Blockchain.Polygon_Amoy_Testnet]: '0x41e94eb019c0762f9bfcf9fb1e58725bfb0e7582',
        [Blockchain.Sei_Testnet]: '0x4fCF1784B31630811181f670Aea7A7bEF803eaED',
        [Blockchain.Solana_Devnet]: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
        [Blockchain.Sonic_Testnet]: '0x0BA304580ee7c9a980CF72e55f5Ed2E9fd30Bc51',
        [Blockchain.Stellar_Testnet]: 'USDC-GBBD47IF6LWK7P7MDEVSCWR7DPUWV3NY3DTQEVFL4NAT4AQH3ZLLFLA5',
        [Blockchain.Sui_Testnet]: '0xa1ec7fc00a6f40db9693ad1415d0c193ad3906494428cf252621037bd7117e29::usdc::USDC',
        [Blockchain.Unichain_Sepolia]: '0x31d0220469e10c4E71834a79b1f276d740d3768F',
        [Blockchain.World_Chain_Sepolia]: '0x66145f38cBAC35Ca6F1Dfb4914dF98F1614aeA88',
        [Blockchain.XDC_Apothem]: '0xb5AB69F7bBada22B28e79C8FFAECe55eF1c771D4',
        [Blockchain.ZKSync_Sepolia]: '0xAe045DE5638162fa134807Cb558E15A3F5A7F853',
    },
};

/**
 * USDT (Tether) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in USDT definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */
const USDT = {
    symbol: 'USDT',
    decimals: 6,
    locators: {
        [Blockchain.Aptos]: '0x357b0b74bc833e95a115ad22604854d6b0fca151cecd94111770e5d6ffc9dc2b',
        [Blockchain.Arbitrum]: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
        [Blockchain.Avalanche]: '0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7',
        [Blockchain.Celo]: '0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e',
        [Blockchain.Ethereum]: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
        [Blockchain.HyperEVM]: '0xb8ce59fc3717ada4c02eadf9682a9e934f625ebb',
        [Blockchain.Ink]: '0x0200C29006150606B650577BBE7B6248F58470c1',
        [Blockchain.Linea]: '0xA219439258ca9da29E9Cc4cE5596924745e12B93',
        [Blockchain.Monad]: '0xe7cd86e13AC4309349F30B3435a9d337750fC82D',
        [Blockchain.NEAR]: 'usdt.tether-token.near',
        [Blockchain.Optimism]: '0x94b008aA00579c1307B0EF2c499aD98a8ce58e58',
        [Blockchain.Polkadot_Asset_Hub]: '1984',
        [Blockchain.Polygon]: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
        [Blockchain.Sei]: '0x9151434b16b9763660705744891fA906F660EcC5',
        [Blockchain.Solana]: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
        [Blockchain.Unichain]: '0x9151434b16b9763660705744891fA906F660EcC5',
    },
};

/**
 * EURC (Euro Coin) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in EURC definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */
const EURC = {
    symbol: 'EURC',
    decimals: 6,
    locators: {
        [Blockchain.Avalanche]: '0xc891EB4cbdEFf6e073e859e987815Ed1505c2ACD',
        [Blockchain.Base]: '0x60a3E35Cc302bFA44Cb288Bc5a4F316Fdb1adb42',
        [Blockchain.Ethereum]: '0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c',
        [Blockchain.Solana]: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
        [Blockchain.World_Chain]: '0x1C60ba0A0eD1019e8Eb035E6daF4155A5cE2380B',
        // Testnets
        [Blockchain.Arc_Testnet]: '0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a',
    },
};

/**
 * DAI (Maker DAO) stablecoin token definition with addresses and metadata.
 *
 * @remarks
 * Built-in DAI definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */
const DAI = {
    symbol: 'DAI',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 8,
    },
    locators: {
        [Blockchain.Arbitrum]: '0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1',
        [Blockchain.Avalanche]: '0xd586E7F844cEa2F87f50152665BCbc2C279D8d70',
        [Blockchain.Base]: '0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb',
        [Blockchain.Ethereum]: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
        [Blockchain.Linea]: '0x4AF15ec2A0BD43Db75dd04E62FAA3B8EF36b00d5',
        [Blockchain.Optimism]: '0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1',
        [Blockchain.Polygon]: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
        [Blockchain.Solana]: 'EjmyN6qEC1Tf1JxiG1ae7UTJhUxSwk1TCWNWqxWV4J6o',
    },
};

/**
 * USDe (Ethena) synthetic dollar token definition with addresses and metadata.
 *
 * @remarks
 * Built-in USDE definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */
const USDE = {
    symbol: 'USDe',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 9,
    },
    locators: {
        [Blockchain.Arbitrum]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Base]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Ethereum]: '0x4c9EDD5852cd905f086C759E8383e09bff1E68B3',
        [Blockchain.Linea]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Optimism]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Solana]: 'DEkqHyPN7GMRJ5cArtQFAWefqbZb33Hyf6s5iCwjEonT',
    },
};

/**
 * PYUSD (PayPal USD) stablecoin token definition with addresses and metadata.
 *
 * @remarks
 * Built-in PYUSD definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */
const PYUSD = {
    symbol: 'PYUSD',
    decimals: 6,
    locators: {
        [Blockchain.Arbitrum]: '0x46850aD61C2B7d64d08c9C754F45254596696984',
        [Blockchain.Ethereum]: '0x6c3ea9036406852006290770BEdFcAbA0e23A0e8',
        [Blockchain.Solana]: '2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo',
    },
};

/**
 * WETH (Wrapped Ether) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WETH definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WETH is available.
 */
const WETH = {
    symbol: 'WETH',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 9,
    },
    locators: {
        [Blockchain.Arbitrum]: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
        [Blockchain.Avalanche]: '0x49D5c2BdFfac6CE2BFdB6640F4F80f226bc10bAB',
        [Blockchain.Base]: '0x4200000000000000000000000000000000000006',
        [Blockchain.Ethereum]: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
        [Blockchain.Optimism]: '0x4200000000000000000000000000000000000006',
        [Blockchain.Polygon]: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
        [Blockchain.Solana]: '7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs',
    },
};

/**
 * WBTC (Wrapped Bitcoin) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WBTC definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WBTC is available.
 */
const WBTC = {
    symbol: 'WBTC',
    decimals: 8,
    locators: {
        [Blockchain.Ethereum]: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
        [Blockchain.Arbitrum]: '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f',
        [Blockchain.Avalanche]: '0x50b7545627a5162F82A992c33b87aDc75187B218',
    },
};

/**
 * WSOL (Wrapped SOL) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WSOL definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WSOL is available.
 */
const WSOL = {
    symbol: 'WSOL',
    decimals: 9,
    locators: {
        [Blockchain.Solana]: 'So11111111111111111111111111111111111111112',
    },
};

/**
 * WAVAX (Wrapped AVAX) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WAVAX definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WAVAX is available.
 */
const WAVAX = {
    symbol: 'WAVAX',
    decimals: 18,
    locators: {
        [Blockchain.Avalanche]: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7',
    },
};

/**
 * WPOL (Wrapped POL) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WPOL definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WPOL is available.
 */
const WPOL = {
    symbol: 'WPOL',
    decimals: 18,
    locators: {
        [Blockchain.Polygon]: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
    },
};

/**
 * ETH (native Ether alias) token definition with metadata.
 *
 * @remarks
 * Built-in ETH definition for the TokenRegistry. Used as a symbol alias
 * for native ETH (e.g. in swap flows). Chain locators are TBD and will
 * be added when addresses are available. Use raw selector with
 * locator + decimals where native gas token is represented as a contract.
 */
const ETH = {
    symbol: 'ETH',
    decimals: 18,
    locators: {},
};

/**
 * POL (Polygon native token) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in POL definition for the TokenRegistry. Includes chain locators
 * where POL is available as a bridged/wrapped asset.
 */
const POL = {
    symbol: 'POL',
    decimals: 18,
    locators: {
        [Blockchain.Ethereum]: '0x455e53CBB86018Ac2B8092FdCd39d8444aFFC3F6',
    },
};

/**
 * PLUME (Plume network token) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in PLUME definition for the TokenRegistry. Includes chain locators
 * where PLUME is available.
 */
const PLUME = {
    symbol: 'PLUME',
    decimals: 18,
    locators: {
        [Blockchain.Ethereum]: '0x4C1746A800D224393fE2470C70A35717eD4eA5F1',
    },
};

/**
 * MON token definition with Solana mint metadata.
 *
 * @remarks
 * Built-in MON definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */
const MON = {
    symbol: 'MON',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 8,
    },
    locators: {
        [Blockchain.Solana]: 'CrAr4RRJMBVwRsZtT62pEhfA9H5utymC2mVx8e7FreP2',
    },
};

/**
 * cirBTC (Circle Bitcoin) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in cirBTC definition for the TokenRegistry. Currently deployed
 * on Arc Testnet.
 *
 * @example
 * ```typescript
 * import { CIRBTC } from '@core/tokens'
 * import { Blockchain } from '@core/chains'
 *
 * console.log(CIRBTC.symbol)   // 'cirBTC'
 * console.log(CIRBTC.decimals) // 8
 * console.log(CIRBTC.locators[Blockchain.Arc_Testnet])
 * // '0xf0C4a4CE82A5746AbAAd9425360Ab04fbBA432BF'
 * ```
 */
const CIRBTC = {
    symbol: 'cirBTC',
    decimals: 8,
    locators: {
        [Blockchain.Arc_Testnet]: '0xf0C4a4CE82A5746AbAAd9425360Ab04fbBA432BF',
    },
};

// Re-export for consumers
/**
 * All default token definitions.
 *
 * @remarks
 * These tokens are automatically included in the TokenRegistry when created
 * without explicit defaults. Extensions can override these definitions.
 * Includes USDC, USDT, EURC, DAI, USDE, PYUSD, WETH, WBTC, WSOL, WAVAX,
 * WPOL, ETH, POL, PLUME, MON, and cirBTC.
 *
 * @example
 * ```typescript
 * import { createTokenRegistry } from '@core/tokens'
 *
 * // Registry uses these by default
 * const registry = createTokenRegistry()
 *
 * // Add custom tokens (built-ins are still included)
 * const customRegistry = createTokenRegistry({
 *   tokens: [myCustomToken],
 * })
 * ```
 */
const DEFAULT_TOKENS = [
    USDC,
    USDT,
    EURC,
    DAI,
    USDE,
    PYUSD,
    WETH,
    WBTC,
    WSOL,
    WAVAX,
    WPOL,
    ETH,
    POL,
    PLUME,
    MON,
    CIRBTC,
];
/**
 * Uppercased token symbols approved for swap fee collection.
 *
 * @remarks
 * Derived from {@link DEFAULT_TOKENS} so all consumers share a single
 * allowlist source and stay in sync when defaults change.
 */
new Set(DEFAULT_TOKENS.map((t) => t.symbol.toUpperCase()));

/**
 * Define a schema for token registry interfaces.
 *
 * @remarks
 * Validate that a registry exposes the `resolve()` API used by adapters.
 *
 * @example
 * ```typescript
 * import { tokenRegistrySchema } from '@core/tokens'
 *
 * const registry = {
 *   resolve: () => ({ locator: '0x0', decimals: 6 }),
 * }
 *
 * tokenRegistrySchema.parse(registry)
 * ```
 */
zod.z.custom((value) => {
    if (value === null || typeof value !== 'object') {
        return false;
    }
    const record = value;
    return (typeof record['resolve'] === 'function' &&
        typeof record['get'] === 'function' &&
        typeof record['has'] === 'function' &&
        typeof record['symbols'] === 'function' &&
        typeof record['entries'] === 'function');
}, {
    message: 'Invalid token registry',
});

/**
 * Build a complete explorer URL from a chain definition and transaction hash.
 *
 * This function takes a chain definition containing an explorer URL template
 * and replaces the `{hash}` placeholder with the provided transaction hash
 * to create a complete, valid explorer URL.
 *
 * @param chainDef - The chain definition containing the explorer URL template.
 * @param txHash - The transaction hash to insert into the URL template.
 * @returns A complete explorer URL with the transaction hash inserted.
 * @throws Error if the chain definition is null/undefined.
 * @throws Error if the transaction hash is null/undefined/empty.
 * @throws Error if the explorer URL template is missing or empty.
 * @throws Error if the explorer URL template doesn't contain the {hash} placeholder.
 * @throws Error if the resulting URL is invalid.
 *
 * @example
 * ```typescript
 * import { buildExplorerUrl } from '@core/utils'
 * import { Ethereum } from '@core/chains'
 *
 * // Build URL for Ethereum transaction
 * const url = buildExplorerUrl(Ethereum, '0x1234567890abcdef...')
 * console.log(url) // 'https://etherscan.io/tx/0x1234567890abcdef...'
 * ```
 *
 * @example
 * ```typescript
 * import { buildExplorerUrl } from '@core/utils'
 * import { Solana } from '@core/chains'
 *
 * // Build URL for Solana transaction
 * const url = buildExplorerUrl(Solana, 'abc123def456...')
 * console.log(url) // 'https://solscan.io/tx/abc123def456...'
 * ```
 *
 * @example
 * ```typescript
 * import { buildExplorerUrl } from '@core/utils'
 * import { Aptos } from '@core/chains'
 *
 * // Build URL for Aptos transaction with query parameters
 * const url = buildExplorerUrl(Aptos, '0xabc123...')
 * console.log(url) // 'https://explorer.aptoslabs.com/txn/0xabc123...?network=mainnet'
 * ```
 */
function buildExplorerUrl(chainDef, txHash) {
    // Validate input parameters using our standard validation pattern
    validateOrThrow({ chainDef, txHash }, buildExplorerUrlParamsSchema, 'Invalid buildExplorerUrl parameters');
    // Parse and transform input parameters (e.g., trim whitespace from txHash)
    const { chainDef: validChainDef, txHash: validTxHash } = buildExplorerUrlParamsSchema.parse({ chainDef, txHash });
    // Replace all occurrences of the placeholder with the transaction hash
    const explorerUrl = validChainDef.explorerUrl.replace(/{hash}/g, validTxHash);
    // Validate the resulting URL
    validate(explorerUrl, explorerUrlSchema, 'explorer URL');
    return explorerUrl;
}

/**
 * Schema for validating hexadecimal strings with '0x' prefix.
 *
 * This schema validates that a string:
 * - Is a string type
 * - Is not empty after trimming
 * - Starts with '0x'
 * - Contains only valid hexadecimal characters (0-9, a-f, A-F) after '0x'
 *
 * @remarks
 * This schema does not validate length, making it suitable for various hex string types
 * like addresses, transaction hashes, and other hex-encoded data.
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { hexStringSchema } from '@core/adapter'
 *
 * const validAddress = '0x1234567890123456789012345678901234567890'
 * const validTxHash = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 *
 * const addressResult = hexStringSchema.safeParse(validAddress)
 * const txHashResult = hexStringSchema.safeParse(validTxHash)
 * console.log(addressResult.success) // true
 * console.log(txHashResult.success) // true
 * ```
 */
const hexStringSchema = zod.z
    .string()
    .min(1, 'Hex string is required')
    .refine((value) => value.trim().length > 0, 'Hex string cannot be empty')
    .refine((value) => value.startsWith('0x'), 'Hex string must start with 0x prefix')
    .refine((value) => {
    const hexPattern = /^0x[0-9a-fA-F]+$/;
    return hexPattern.test(value);
}, 'Hex string contains invalid characters. Only hexadecimal characters (0-9, a-f, A-F) are allowed after 0x');
/**
 * Schema for validating EVM addresses.
 *
 * This schema validates that a string is a properly formatted EVM address:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 42 characters long (0x + 40 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmAddressSchema } from '@core/adapter'
 *
 * const validAddress = '0x1234567890123456789012345678901234567890'
 *
 * const result = evmAddressSchema.safeParse(validAddress)
 * console.log(result.success) // true
 * ```
 */
const evmAddressSchema = hexStringSchema.refine((value) => value.length === 42, 'EVM address must be exactly 42 characters long (0x + 40 hex characters)');
/**
 * Schema for validating transaction hashes.
 *
 * This schema validates that a string is a properly formatted transaction hash:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 66 characters long (0x + 64 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmTransactionHashSchema } from '@core/adapter'
 *
 * const validTxHash = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 *
 * const result = evmTransactionHashSchema.safeParse(validTxHash)
 * console.log(result.success) // true
 * ```
 */
hexStringSchema.refine((value) => value.length === 66, 'Transaction hash must be exactly 66 characters long (0x + 64 hex characters)');
/**
 * Schema for validating base58-encoded strings.
 *
 * This schema validates that a string:
 * - Is a string type
 * - Is not empty after trimming
 * - Contains only valid base58 characters (1-9, A-H, J-N, P-Z, a-k, m-z)
 * - Does not contain commonly confused characters (0, O, I, l)
 *
 * @remarks
 * This schema does not validate length, making it suitable for various base58-encoded data
 * like Solana addresses, transaction signatures, and other base58-encoded data.
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { base58StringSchema } from '@core/adapter'
 *
 * const validAddress = 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'
 * const validTxHash = '3Jf8k2L5mN9pQ7rS1tV4wX6yZ8aB2cD4eF5gH7iJ9kL1mN3oP5qR7sT9uV1wX3yZ5'
 *
 * const addressResult = base58StringSchema.safeParse(validAddress)
 * const txHashResult = base58StringSchema.safeParse(validTxHash)
 * console.log(addressResult.success) // true
 * console.log(txHashResult.success) // true
 * ```
 */
const base58StringSchema = zod.z
    .string()
    .min(1, 'Base58 string is required')
    .refine((value) => value.trim().length > 0, 'Base58 string cannot be empty')
    .refine((value) => {
    // Base58 alphabet: 123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz
    // Excludes: 0, O, I, l to avoid confusion
    const base58Pattern = /^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$/;
    return base58Pattern.test(value);
}, 'Base58 string contains invalid characters. Only base58 characters (1-9, A-H, J-N, P-Z, a-k, m-z) are allowed');
/**
 * Schema for validating Solana addresses.
 *
 * This schema validates that a string is a properly formatted Solana address:
 * - Must be a valid base58-encoded string
 * - Must be between 32-44 characters long (typical length for base58-encoded 32-byte addresses)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { solanaAddressSchema } from '@core/adapter'
 *
 * const validAddress = 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'
 *
 * const result = solanaAddressSchema.safeParse(validAddress)
 * console.log(result.success) // true
 * ```
 */
base58StringSchema.refine((value) => value.length >= 32 && value.length <= 44, 'Solana address must be between 32-44 characters long (base58-encoded 32-byte address)');
/**
 * Schema for validating Solana transaction hashes.
 *
 * This schema validates that a string is a properly formatted Solana transaction hash:
 * - Must be a valid base58-encoded string
 * - Must be between 86-88 characters long (typical length for base58-encoded 64-byte signatures)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { solanaTransactionHashSchema } from '@core/adapter'
 *
 * const validTxHash = '5VfYmGBjvQKe3xgLtTQPSMEUdpEVHrJwLK7pKBJWKzYpNBE2g3kJrq7RSe9M8DqzQJ5J2aZPTjHLvd4WgxPpJKS'
 *
 * const result = solanaTransactionHashSchema.safeParse(validTxHash)
 * console.log(result.success) // true
 * ```
 */
base58StringSchema.refine((value) => value.length >= 86 && value.length <= 88, 'Solana transaction hash must be between 86-88 characters long (base58-encoded 64-byte signature)');
/**
 * Schema for validating Adapter objects.
 * Checks for the required methods that define an Adapter.
 */
const adapterSchema = zod.z.object({
    prepare: zod.z.function(),
    waitForTransaction: zod.z.function(),
    getAddress: zod.z.function(),
});

/**
 * Validate that the adapter has sufficient token balance for a transaction.
 *
 * This function checks if the adapter's current token balance is greater than or equal
 * to the requested transaction amount. It throws a KitError with code 9001
 * (BALANCE_INSUFFICIENT_TOKEN) if the balance is insufficient, providing detailed
 * information about the shortfall.
 *
 * @param params - The validation parameters containing adapter, amount, token, and token address.
 * @returns A promise that resolves to void if validation passes.
 * @throws {KitError} When the adapter's balance is less than the required amount (code: 9001).
 *
 * @example
 * ```typescript
 * import { validateBalanceForTransaction } from '@core/adapter'
 * import { createViemAdapterFromPrivateKey } from '@circle-fin/adapter-viem-v2'
 * import { isKitError, ERROR_TYPES } from '@core/errors'
 *
 * const adapter = createViemAdapterFromPrivateKey({
 *   privateKey: '0x...',
 *   chain: 'Ethereum',
 * })
 *
 * try {
 *   await validateBalanceForTransaction({
 *     adapter,
 *     amount: '1000000', // 1 USDC (6 decimals)
 *     token: 'USDC',
 *     tokenAddress: '0xA0b86a33E6441c8C1c7C16e4c5e3e5b5e4c5e3e5b5e4c5e',
 *     operationContext: { chain: 'Ethereum' },
 *   })
 *   console.log('Balance validation passed')
 * } catch (error) {
 *   if (isKitError(error) && error.type === ERROR_TYPES.BALANCE) {
 *     console.error('Insufficient funds:', error.message)
 *   }
 * }
 * ```
 */
const validateBalanceForTransaction = async (params) => {
    const { amount, adapter, token, tokenAddress, operationContext } = params;
    const balancePrepared = await adapter.prepareAction('usdc.balanceOf', {
        walletAddress: operationContext.address,
    }, operationContext);
    const balance = await balancePrepared.execute();
    if (BigInt(balance) < BigInt(amount)) {
        // Extract chain name from operationContext
        const chainName = extractChainInfo(operationContext.chain).name;
        // Create KitError with rich context in trace
        throw createInsufficientTokenBalanceError(chainName, token, {
            balance: balance.toString(),
            amount,
            tokenAddress,
            walletAddress: operationContext.address,
        });
    }
};

/**
 * Validate that the adapter has sufficient native token balance for transaction fees.
 *
 * This function checks if the adapter's current native token balance (ETH, SOL, etc.)
 * is greater than zero. It throws a KitError with code 9002 (BALANCE_INSUFFICIENT_GAS)
 * if the balance is zero, indicating the wallet cannot pay for transaction fees.
 *
 * @param params - The validation parameters containing adapter and operation context.
 * @returns A promise that resolves to void if validation passes.
 * @throws {KitError} When the adapter's native balance is zero (code: 9002).
 *
 * @example
 * ```typescript
 * import { validateNativeBalanceForTransaction } from '@core/adapter'
 * import { createViemAdapterFromPrivateKey } from '@circle-fin/adapter-viem-v2'
 * import { isKitError, ERROR_TYPES } from '@core/errors'
 *
 * const adapter = createViemAdapterFromPrivateKey({
 *   privateKey: '0x...',
 *   chain: 'Ethereum',
 * })
 *
 * try {
 *   await validateNativeBalanceForTransaction({
 *     adapter,
 *     operationContext: { chain: 'Ethereum' },
 *   })
 *   console.log('Native balance validation passed')
 * } catch (error) {
 *   if (isKitError(error) && error.type === ERROR_TYPES.BALANCE) {
 *     console.error('Insufficient gas funds:', error.message)
 *   }
 * }
 * ```
 */
const validateNativeBalanceForTransaction = async (params) => {
    const { adapter, operationContext } = params;
    const balancePrepared = await adapter.prepareAction('native.balanceOf', {
        walletAddress: operationContext.address,
    }, operationContext);
    const balance = await balancePrepared.execute();
    if (BigInt(balance) === 0n) {
        const { chain } = operationContext;
        const chainName = extractChainInfo(chain).name;
        const nativeSymbol = typeof chain === 'object' && chain !== null && 'nativeCurrency' in chain
            ? chain.nativeCurrency.symbol
            : undefined;
        throw createInsufficientGasError(chainName, nativeSymbol, {
            balance: '0',
            walletAddress: operationContext.address,
        });
    }
};

/**
 * Permit signature standards for gasless token approvals.
 *
 * Defines the permit types that can be used to approve token spending
 * without requiring a separate approval transaction.
 *
 * @remarks
 * - NONE: No permit, tokens must be pre-approved via separate transaction
 * - EIP2612: Standard ERC-20 permit (USDC, DAI v2, and most modern tokens)
 */
var PermitType;
(function (PermitType) {
    /** No permit required - tokens must be pre-approved */
    PermitType[PermitType["NONE"] = 0] = "NONE";
    /** EIP-2612 standard permit */
    PermitType[PermitType["EIP2612"] = 1] = "EIP2612";
})(PermitType || (PermitType = {}));

/**
 * Extract a minimal {@link OperationContext} from an adapter context's
 * `from` field.  Works with any operation params type whose `from`
 * conforms to `AdapterContext`.
 */
function extractOperationContext(from) {
    return {
        chain: from.chain,
        ...('address' in from && from.address !== undefined
            ? { address: from.address }
            : {}),
    };
}
/**
 * Resolve the signer address from an {@link AdapterContext}.
 *
 * Prefer the explicit `address` from the context (set by the kit layer
 * after resolving developer-controlled or user-controlled wallets).
 * Fall back to `adapter.getAddress()` for user-controlled adapters
 * when the kit layer has not pre-resolved the address.
 *
 * For developer-controlled adapters the fallback is intentionally
 * blocked — `adapter.getAddress()` could return a service-key default
 * that does not match the intended wallet, leading to funds being
 * moved from the wrong account.
 *
 * @param from - The adapter context containing the adapter and chain.
 * @param chain - The resolved chain definition for address derivation.
 * @returns The signer wallet address.
 * @throws KitError (VALIDATION_FAILED) when a developer-controlled
 *   adapter reaches the provider layer without a pre-resolved address.
 */
async function resolveSignerAddress(from, chain) {
    if ('address' in from && from.address) {
        return from.address;
    }
    if (from.adapter.capabilities?.addressContext === 'developer-controlled') {
        throw createValidationFailedError('address', undefined, 'Developer-controlled adapter reached the provider layer without a ' +
            'resolved address. Ensure the kit layer calls resolveAddress() or ' +
            'provide { address } in the adapter context.');
    }
    return await from.adapter.getAddress(chain);
}
/**
 * Assert that the given chain supports Gateway v1 contracts.
 *
 * @throws If the chain does not support Gateway v1.
 */
function assertGatewayV1(chain) {
    if (!isGatewayV1Supported(chain)) {
        throw createInvalidChainError(chain.name, 'does not support Gateway v1 contracts.');
    }
}
/**
 * Assert that `address` is a valid on-chain address for the given chain.
 *
 * @param address - The address string to validate.
 * @param chain - The resolved chain definition.
 * @param paramName - Human-readable parameter name used in the error message.
 * @throws KitError (VALIDATION_FAILED) when the address format is invalid.
 */
function assertValidAddress(address, chain, paramName) {
    if (!isValidAddressForChain(address, chain)) {
        throw createInvalidAddressError(address, chain.name, `valid ${paramName} for this chain`);
    }
}
/**
 * Return the on-chain contract address for the given token on the given chain.
 *
 * Dispatches to the appropriate chain-definition field based on `token`,
 * making operations token-agnostic as new tokens are added to
 * {@link SupportedToken}.
 *
 * @param chain - The chain definition to resolve the address from.
 * @param token - The token identifier (e.g. `'USDC'`, `'EURC'`).
 * @returns The token contract address for the chain.
 * @throws If the chain does not have a configured address for the token.
 */
function getTokenAddress(chain, token) {
    // For now, we only support USDC.
    if (token === 'USDC') {
        if (!chain.usdcAddress) {
            throw createInvalidChainError(chain.name, `USDC address not configured for chain "${chain.name}".`);
        }
        return chain.usdcAddress;
    }
    const unsupported = token;
    throw createTokenResolutionError(`Unsupported token '${unsupported}' on chain '${chain.name}'`, unsupported, chain.name);
}
/**
 * Execute a prepared chain request and wait for confirmation.
 *
 * @throws If the request is a noop (no-op) request.
 * @returns The confirmed transaction hash.
 */
async function executeAndWait$2(adapter, request, chain) {
    if (request.type === 'noop') {
        throw createValidationFailedError('request', request, 'Unexpected noop request during Gateway operation');
    }
    const txHash = await request.execute();
    await adapter.waitForTransaction(txHash, { confirmations: 1 }, chain);
    return txHash;
}
/**
 * Safely convert a numeric string to `bigint`, throwing a
 * {@link KitError} with `GATEWAY_API_ERROR` when the value is not a
 * valid non-negative integer string.
 *
 * @param value - The string to convert (must match `/^\d+$/`).
 * @param field - Human-readable field name used in the error message.
 * @returns The parsed `bigint` value.
 * @throws KitError (3006 / GATEWAY_API_ERROR) when the string is not numeric.
 */
function safeBigInt(value, field) {
    if (!/^\d+$/.test(value)) {
        throw createValidationFailedError(field, value, 'must be a non-empty string of digits');
    }
    return BigInt(value);
}

/**
 * USDC ABI
 *
 * This ABI is used to interact with the USDC token on EVM networks.
 *
 * @see https://developers.circle.com/stablecoins/what-is-usdc
 */
const usdcAbi = [
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'owner',
                type: 'address',
            },
            {
                indexed: true,
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
        ],
        name: 'Approval',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'authorizer',
                type: 'address',
            },
            {
                indexed: true,
                internalType: 'bytes32',
                name: 'nonce',
                type: 'bytes32',
            },
        ],
        name: 'AuthorizationCanceled',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'authorizer',
                type: 'address',
            },
            {
                indexed: true,
                internalType: 'bytes32',
                name: 'nonce',
                type: 'bytes32',
            },
        ],
        name: 'AuthorizationUsed',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: '_account',
                type: 'address',
            },
        ],
        name: 'Blacklisted',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'newBlacklister',
                type: 'address',
            },
        ],
        name: 'BlacklisterChanged',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'burner',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
        ],
        name: 'Burn',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'newMasterMinter',
                type: 'address',
            },
        ],
        name: 'MasterMinterChanged',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'minter',
                type: 'address',
            },
            {
                indexed: true,
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
        ],
        name: 'Mint',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'minter',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'minterAllowedAmount',
                type: 'uint256',
            },
        ],
        name: 'MinterConfigured',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'oldMinter',
                type: 'address',
            },
        ],
        name: 'MinterRemoved',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: false,
                internalType: 'address',
                name: 'previousOwner',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'address',
                name: 'newOwner',
                type: 'address',
            },
        ],
        name: 'OwnershipTransferred',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [],
        name: 'Pause',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'newAddress',
                type: 'address',
            },
        ],
        name: 'PauserChanged',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'newRescuer',
                type: 'address',
            },
        ],
        name: 'RescuerChanged',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: 'from',
                type: 'address',
            },
            {
                indexed: true,
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
        ],
        name: 'Transfer',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: 'address',
                name: '_account',
                type: 'address',
            },
        ],
        name: 'UnBlacklisted',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [],
        name: 'Unpause',
        type: 'event',
    },
    {
        inputs: [],
        name: 'CANCEL_AUTHORIZATION_TYPEHASH',
        outputs: [
            {
                internalType: 'bytes32',
                name: '',
                type: 'bytes32',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'DOMAIN_SEPARATOR',
        outputs: [
            {
                internalType: 'bytes32',
                name: '',
                type: 'bytes32',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'PERMIT_TYPEHASH',
        outputs: [
            {
                internalType: 'bytes32',
                name: '',
                type: 'bytes32',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'RECEIVE_WITH_AUTHORIZATION_TYPEHASH',
        outputs: [
            {
                internalType: 'bytes32',
                name: '',
                type: 'bytes32',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'TRANSFER_WITH_AUTHORIZATION_TYPEHASH',
        outputs: [
            {
                internalType: 'bytes32',
                name: '',
                type: 'bytes32',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'owner',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
        ],
        name: 'allowance',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
        ],
        name: 'approve',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'authorizer',
                type: 'address',
            },
            {
                internalType: 'bytes32',
                name: 'nonce',
                type: 'bytes32',
            },
        ],
        name: 'authorizationState',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'account',
                type: 'address',
            },
        ],
        name: 'balanceOf',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '_account',
                type: 'address',
            },
        ],
        name: 'blacklist',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'blacklister',
        outputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'uint256',
                name: '_amount',
                type: 'uint256',
            },
        ],
        name: 'burn',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'authorizer',
                type: 'address',
            },
            {
                internalType: 'bytes32',
                name: 'nonce',
                type: 'bytes32',
            },
            {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8',
            },
            {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32',
            },
            {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32',
            },
        ],
        name: 'cancelAuthorization',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'minter',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'minterAllowedAmount',
                type: 'uint256',
            },
        ],
        name: 'configureMinter',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'currency',
        outputs: [
            {
                internalType: 'string',
                name: '',
                type: 'string',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'decimals',
        outputs: [
            {
                internalType: 'uint8',
                name: '',
                type: 'uint8',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'decrement',
                type: 'uint256',
            },
        ],
        name: 'decreaseAllowance',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'increment',
                type: 'uint256',
            },
        ],
        name: 'increaseAllowance',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'string',
                name: 'tokenName',
                type: 'string',
            },
            {
                internalType: 'string',
                name: 'tokenSymbol',
                type: 'string',
            },
            {
                internalType: 'string',
                name: 'tokenCurrency',
                type: 'string',
            },
            {
                internalType: 'uint8',
                name: 'tokenDecimals',
                type: 'uint8',
            },
            {
                internalType: 'address',
                name: 'newMasterMinter',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'newPauser',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'newBlacklister',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'newOwner',
                type: 'address',
            },
        ],
        name: 'initialize',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'string',
                name: 'newName',
                type: 'string',
            },
        ],
        name: 'initializeV2',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'lostAndFound',
                type: 'address',
            },
        ],
        name: 'initializeV2_1',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '_account',
                type: 'address',
            },
        ],
        name: 'isBlacklisted',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'account',
                type: 'address',
            },
        ],
        name: 'isMinter',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'masterMinter',
        outputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '_to',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: '_amount',
                type: 'uint256',
            },
        ],
        name: 'mint',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'minter',
                type: 'address',
            },
        ],
        name: 'minterAllowance',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'name',
        outputs: [
            {
                internalType: 'string',
                name: '',
                type: 'string',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'owner',
                type: 'address',
            },
        ],
        name: 'nonces',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'owner',
        outputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'pause',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'paused',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'pauser',
        outputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'owner',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
            {
                internalType: 'uint256',
                name: 'deadline',
                type: 'uint256',
            },
            {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8',
            },
            {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32',
            },
            {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32',
            },
        ],
        name: 'permit',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'from',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
            {
                internalType: 'uint256',
                name: 'validAfter',
                type: 'uint256',
            },
            {
                internalType: 'uint256',
                name: 'validBefore',
                type: 'uint256',
            },
            {
                internalType: 'bytes32',
                name: 'nonce',
                type: 'bytes32',
            },
            {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8',
            },
            {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32',
            },
            {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32',
            },
        ],
        name: 'receiveWithAuthorization',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'minter',
                type: 'address',
            },
        ],
        name: 'removeMinter',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'contract IERC20',
                name: 'tokenContract',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
        ],
        name: 'rescueERC20',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'rescuer',
        outputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'symbol',
        outputs: [
            {
                internalType: 'string',
                name: '',
                type: 'string',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'totalSupply',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
        ],
        name: 'transfer',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'from',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
        ],
        name: 'transferFrom',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'newOwner',
                type: 'address',
            },
        ],
        name: 'transferOwnership',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'from',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'value',
                type: 'uint256',
            },
            {
                internalType: 'uint256',
                name: 'validAfter',
                type: 'uint256',
            },
            {
                internalType: 'uint256',
                name: 'validBefore',
                type: 'uint256',
            },
            {
                internalType: 'bytes32',
                name: 'nonce',
                type: 'bytes32',
            },
            {
                internalType: 'uint8',
                name: 'v',
                type: 'uint8',
            },
            {
                internalType: 'bytes32',
                name: 'r',
                type: 'bytes32',
            },
            {
                internalType: 'bytes32',
                name: 's',
                type: 'bytes32',
            },
        ],
        name: 'transferWithAuthorization',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '_account',
                type: 'address',
            },
        ],
        name: 'unBlacklist',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'unpause',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '_newBlacklister',
                type: 'address',
            },
        ],
        name: 'updateBlacklister',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '_newMasterMinter',
                type: 'address',
            },
        ],
        name: 'updateMasterMinter',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '_newPauser',
                type: 'address',
            },
        ],
        name: 'updatePauser',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'newRescuer',
                type: 'address',
            },
        ],
        name: 'updateRescuer',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'version',
        outputs: [
            {
                internalType: 'string',
                name: '',
                type: 'string',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
];

/**
 * Zod schema for validating EVM adapter capabilities.
 *
 * This schema ensures that EVM adapter capabilities meet the requirements for the
 * OperationContext pattern by validating the addressContext property and ensuring
 * the supportedChains property contains only EVM-compatible chains.
 *
 * @remarks
 * This schema enforces that all supported chains are EVM type, making it specific
 * to EVM adapters (Ethers, Viem, etc.). For non-EVM adapters, a different validation
 * schema should be used.
 *
 * When used with the validate() function from @core/utils, this throws KitError
 * with INPUT_VALIDATION_FAILED code if validation fails, with details about which
 * properties failed.
 *
 * @example
 * ```typescript
 * import { AdapterCapabilitiesSchema } from '@core/adapter-evm/validation'
 * import { Ethereum, Base } from '@core/chains'
 *
 * // Valid user-controlled capabilities
 * const userCapabilities = {
 *   addressContext: 'user-controlled',
 *   supportedChains: [Ethereum, Base]
 * }
 *
 * // Valid developer-controlled capabilities
 * const devCapabilities = {
 *   addressContext: 'developer-controlled',
 *   supportedChains: [Ethereum]
 * }
 *
 * AdapterCapabilitiesSchema.parse(userCapabilities) // passes
 * AdapterCapabilitiesSchema.parse(devCapabilities) // passes
 * ```
 *
 * @example
 * ```typescript
 * // Invalid - non-EVM chain
 * const invalidCapabilities = {
 *   addressContext: 'user-controlled',
 *   supportedChains: [{ type: 'solana', name: 'Solana', chainId: 0 }]
 * }
 *
 * AdapterCapabilitiesSchema.parse(invalidCapabilities) // throws Zod validation error
 * ```
 */
zod.z
    .object({
    /**
     * Defines who controls the address used in operations.
     * Must be either 'user-controlled' or 'developer-controlled'.
     */
    addressContext: zod.z.enum(['user-controlled', 'developer-controlled'], {
        errorMap: () => ({
            message: "addressContext must be either 'user-controlled' or 'developer-controlled'. " +
                "Use 'user-controlled' for browser wallets, private keys, or hardware wallets. " +
                "Use 'developer-controlled' for enterprise custody solutions or multi-entity adapters.",
        }),
    }),
    /**
     * Array of supported chains. Must contain at least one EVM chain.
     * All chains must be valid EVM ChainDefinition objects.
     */
    supportedChains: zod.z
        .array(zod.z
        .object({
        type: zod.z.literal('evm'),
        chainId: zod.z.number(),
    })
        .passthrough(), // Allow additional ChainDefinition properties
    {
        errorMap: () => ({
            message: 'supportedChains must be an array. Provide an array of EVM ChainDefinition objects.',
        }),
    })
        .min(1, {
        message: 'supportedChains cannot be empty. Please specify at least one supported chain.',
    }),
})
    .strict();

/**
 * Zod schema for validating EIP-712 domain objects.
 *
 * `chainId` and `verifyingContract` are intentionally optional because this
 * schema is shared by the adapter's general-purpose `signTypedData` method,
 * which handles both:
 *
 * - **Permit / ERC-3009 signing** — domains include `chainId` and
 *   `verifyingContract` for on-chain replay protection.
 * - **Gateway burn-intent signing** — domains use only `name` + `version`;
 *   replay protection is embedded in the signed message body instead.
 *
 * Callers that require `chainId` / `verifyingContract` (e.g. permit flows)
 * enforce this at the action or build layer, not here.  See
 * {@link gatewayEip712DomainSchema} for the Gateway-specific variant.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { eip712DomainSchema } from '@core/adapter-evm/validation'
 *
 * const domain = {
 *   name: 'USDC',
 *   version: '2',
 *   chainId: 1,
 *   verifyingContract: '0xA0b86a33E6441e4d178bb0c14ce0E9Ce9c83bdd8'
 * }
 *
 * const result = eip712DomainSchema.safeParse(domain)
 * if (result.success) {
 *   console.log('Domain is valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */
const eip712DomainSchema = zod.z.object({
    name: zod.z
        .string({
        required_error: 'Domain name is required. Please provide the domain name.',
        invalid_type_error: 'Domain name must be a string.',
    })
        .min(1, 'Domain name cannot be empty.'),
    version: zod.z
        .string({
        required_error: 'Domain version is required. Please provide the domain version.',
        invalid_type_error: 'Domain version must be a string.',
    })
        .min(1, 'Domain version cannot be empty.'),
    chainId: zod.z
        .number({
        invalid_type_error: 'Chain ID must be a number.',
    })
        .int('Chain ID must be an integer.')
        .positive('Chain ID must be positive.')
        .optional(),
    verifyingContract: zod.z
        .string({
        invalid_type_error: 'Verifying contract address must be a string.',
    })
        .regex(/^0x[a-fA-F0-9]{40}$/, 'Verifying contract must be a valid Ethereum address.')
        .optional(),
    salt: zod.z
        .string()
        .regex(/^0x[a-fA-F0-9]+$/, 'Salt must be a valid hex string.')
        .optional(),
});
/**
 * Relaxed EIP-712 domain schema for Gateway burn-intent signing.
 *
 * Gateway's on-chain verifier only checks `name` and `version` in the domain
 * separator because replay-protection fields (`sourceDomain`, `sourceContract`,
 * `salt`) are embedded in the signed message body itself.
 *
 * **Do not use this schema for CCTP v2 permits or other EIP-712 signatures
 * that rely on the domain separator for replay-protection** — use
 * {@link eip712DomainSchema} instead.
 */
const gatewayEip712DomainSchema = zod.z.object({
    name: zod.z
        .string({
        required_error: 'Domain name is required. Please provide the domain name.',
        invalid_type_error: 'Domain name must be a string.',
    })
        .min(1, 'Domain name cannot be empty.'),
    version: zod.z
        .string({
        required_error: 'Domain version is required. Please provide the domain version.',
        invalid_type_error: 'Domain version must be a string.',
    })
        .min(1, 'Domain version cannot be empty.'),
});
/**
 * Zod schema for validating TypedData field definitions.
 *
 * This schema validates individual field definitions within EIP-712 type
 * definitions. Each field must have a name and a valid Solidity type.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { typedDataFieldSchema } from '@core/adapter-evm/validation'
 *
 * const field = {
 *   name: 'owner',
 *   type: 'address'
 * }
 *
 * const result = typedDataFieldSchema.safeParse(field)
 * if (result.success) {
 *   console.log('Field is valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */
const typedDataFieldSchema = zod.z.object({
    name: zod.z
        .string({
        required_error: 'Field name is required. Please provide the field name.',
        invalid_type_error: 'Field name must be a string.',
    })
        .min(1, 'Field name cannot be empty'),
    type: zod.z
        .string({
        required_error: 'Field type is required. Please provide the Solidity type.',
        invalid_type_error: 'Field type must be a string.',
    })
        .min(1, 'Field type cannot be empty'),
});
/**
 * Zod schema for validating complete EIP-712 TypedData structures.
 *
 * This schema validates the complete EIP-712 typed data structure including
 * domain, types, primaryType, and message. It ensures all components are
 * properly structured and the primaryType exists in the types definition.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { typedDataSchema } from '@core/adapter-evm/validation'
 *
 * const typedData = {
 *   domain: {
 *     name: 'USDC',
 *     version: '2',
 *     chainId: 1,
 *     verifyingContract: '0xA0b86a33E6441e4d178bb0c14ce0E9Ce9c83bdd8'
 *   },
 *   types: {
 *     Permit: [
 *       { name: 'owner', type: 'address' },
 *       { name: 'spender', type: 'address' },
 *       { name: 'value', type: 'uint256' },
 *       { name: 'nonce', type: 'uint256' },
 *       { name: 'deadline', type: 'uint256' }
 *     ]
 *   },
 *   primaryType: 'Permit',
 *   message: {
 *     owner: '0x1234567890123456789012345678901234567890',
 *     spender: '0x0987654321098765432109876543210987654321',
 *     value: 1000000,
 *     nonce: 0,
 *     deadline: 1640995200
 *   }
 * }
 *
 * const result = typedDataSchema.safeParse(typedData)
 * if (result.success) {
 *   console.log('TypedData is valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */
zod.z
    .object({
    domain: eip712DomainSchema,
    types: zod.z
        .record(zod.z.string().min(1, 'Type name cannot be empty.'), zod.z
        .array(typedDataFieldSchema, {
        required_error: 'Type definition is required. Please provide an array of field definitions.',
        invalid_type_error: 'Type definition must be an array of TypedDataField objects.',
    })
        .min(1, 'Type definition cannot be empty. Please provide at least one field.'))
        .refine((types) => Object.keys(types).length > 0, 'Types object cannot be empty. Please provide at least one type definition.'),
    primaryType: zod.z
        .string({
        required_error: 'Primary type is required. Please provide the primary type name.',
        invalid_type_error: 'Primary type must be a string.',
    })
        .min(1, 'Primary type cannot be empty.'),
    message: zod.z.record(zod.z.unknown(), {
        required_error: 'Message is required. Please provide the message object.',
        invalid_type_error: 'Message must be an object.',
    }),
})
    .refine((data) => data.primaryType in data.types, (data) => ({
    message: `Primary type "${data.primaryType}" must exist in the types definition. Available types: ${Object.keys(data.types).join(', ')}.`,
    path: ['primaryType'],
}));
/**
 * Relaxed typed-data schema for Gateway burn-intent signing.
 *
 * Identical to {@link typedDataSchema} except the domain uses
 * {@link gatewayEip712DomainSchema} (optional chainId / verifyingContract).
 */
zod.z
    .object({
    domain: gatewayEip712DomainSchema,
    types: zod.z
        .record(zod.z.string().min(1, 'Type name cannot be empty.'), zod.z
        .array(typedDataFieldSchema, {
        required_error: 'Type definition is required. Please provide an array of field definitions.',
        invalid_type_error: 'Type definition must be an array of TypedDataField objects.',
    })
        .min(1, 'Type definition cannot be empty. Please provide at least one field.'))
        .refine((types) => Object.keys(types).length > 0, 'Types object cannot be empty. Please provide at least one type definition.'),
    primaryType: zod.z
        .string({
        required_error: 'Primary type is required. Please provide the primary type name.',
        invalid_type_error: 'Primary type must be a string.',
    })
        .min(1, 'Primary type cannot be empty.'),
    message: zod.z.record(zod.z.unknown(), {
        required_error: 'Message is required. Please provide the message object.',
        invalid_type_error: 'Message must be an object.',
    }),
})
    .refine((data) => data.primaryType in data.types, (data) => ({
    message: `Primary type "${data.primaryType}" must exist in the types definition. Available types: ${Object.keys(data.types).join(', ')}.`,
    path: ['primaryType'],
}));
const abiParameterSchema = zod.z.object({
    name: zod.z.string(),
    type: zod.z.string().min(1, 'Parameter type cannot be empty'),
    internalType: zod.z.string().optional(),
    components: zod.z.lazy(() => zod.z.array(abiParameterSchema)).optional(), // For tuple types
});
/**
 * Schema for validating ABI entries (function definitions, events, etc).
 *
 * This schema validates individual ABI entries that describe contract functions,
 * constructors, events, and other contract interface elements.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { abiEntrySchema } from '@core/adapter-evm/validation'
 *
 * const functionAbi = {
 *   type: 'function',
 *   name: 'transfer',
 *   inputs: [
 *     { name: 'to', type: 'address' },
 *     { name: 'value', type: 'uint256' }
 *   ],
 *   outputs: [{ name: '', type: 'bool' }],
 *   stateMutability: 'nonpayable'
 * }
 *
 * const result = abiEntrySchema.safeParse(functionAbi)
 * ```
 */
const abiEntrySchema = zod.z.object({
    type: zod.z.enum([
        'function',
        'constructor',
        'event',
        'fallback',
        'receive',
        'error',
    ]),
    name: zod.z.string().optional(), // Not required for constructor, fallback, receive
    inputs: zod.z.array(abiParameterSchema).default([]),
    outputs: zod.z.array(abiParameterSchema).optional(),
    stateMutability: zod.z.enum(['pure', 'view', 'nonpayable', 'payable']).optional(),
    // Legacy fields for backwards compatibility
    constant: zod.z.boolean().optional(),
    payable: zod.z.boolean().optional(),
    anonymous: zod.z.boolean().optional(), // For events
});
/**
 * Schema for validating complete ABI arrays.
 *
 * This schema validates arrays of ABI entries, ensuring each entry is properly
 * structured for contract interaction.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { abiSchema } from '@core/adapter-evm/validation'
 *
 * const abi = [
 *   {
 *     type: 'function',
 *     name: 'balanceOf',
 *     inputs: [{ name: 'owner', type: 'address' }],
 *     outputs: [{ name: '', type: 'uint256' }],
 *     stateMutability: 'view'
 *   }
 * ]
 *
 * const result = abiSchema.safeParse(abi)
 * ```
 */
const abiSchema = zod.z
    .array(abiEntrySchema)
    .min(1, 'ABI must contain at least one entry');
/**
 * Schema for validating EVM adapter instances.
 *
 * This ensures all required properties and methods are present on an EVM adapter.
 * An EVM adapter must include:
 * - A chainType property set to `'evm'` or `'hybrid'`
 * - An actionRegistry with registerHandlers method and actionHandlers record
 * - A prepare method for creating chain requests
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { evmAdapterSchema } from '@core/evmAdapter'
 *
 * const validAdapter = {
 *   chainType: 'evm' as const,
 *   actionRegistry: {
 *     registerHandlers: (handlers: any) => {},
 *     actionHandlers: {
 *       'usdc.approve': async (params: any) => ({}),
 *     },
 *   },
 *   prepare: async (request: any) => ({}),
 * }
 *
 * const hybridAdapter = {
 *   ...validAdapter,
 *   chainType: 'hybrid' as const,
 * }
 *
 * console.log(evmAdapterSchema.safeParse(validAdapter).success) // true
 * console.log(evmAdapterSchema.safeParse(hybridAdapter).success) // true
 * ```
 */
const evmAdapterSchema = adapterSchema.extend({
    chainType: zod.z.union([zod.z.literal('evm'), zod.z.literal('hybrid')]),
    actionRegistry: zod.z.object({
        registerHandlers: zod.z.function().returns(zod.z.any()),
        actionHandlers: zod.z.map(zod.z.string(), zod.z.function().returns(zod.z.any())),
    }),
});
/**
 * Schema for validating EVM prepared chain request parameters.
 *
 * This schema validates the parameters needed to execute a contract call on an EVM-compatible chain.
 * It ensures proper formatting of addresses, ABI structure, and function parameters.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { evmPreparedChainRequestParamsSchema } from '@core/adapter-evm/validation'
 *
 * const params = {
 *   type: 'evm',
 *   abi: [{
 *     type: 'function',
 *     name: 'transfer',
 *     inputs: [
 *       { name: 'to', type: 'address' },
 *       { name: 'value', type: 'uint256' }
 *     ],
 *     outputs: [{ name: '', type: 'bool' }],
 *     stateMutability: 'nonpayable'
 *   }],
 *   address: '0x1234567890123456789012345678901234567890',
 *   functionName: 'transfer',
 *   args: ['0xabcdef...', '1000000']
 * }
 *
 * const result = evmPreparedChainRequestParamsSchema.safeParse(params)
 * ```
 */
zod.z.object({
    type: zod.z.literal('evm'),
    abi: abiSchema,
    address: evmAddressSchema,
    functionName: zod.z
        .string({
        required_error: 'Function name is required',
        invalid_type_error: 'Function name must be a string',
    })
        .min(1, 'Function name cannot be empty')
        .refine((name) => /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(name), 'Function name must be a valid identifier (letters, numbers, underscore, dollar sign, cannot start with number)'),
    args: zod.z.array(zod.z.unknown(), {
        required_error: 'Arguments array is required',
        invalid_type_error: 'Arguments must be an array',
    }),
});
/**
 * Zod schema for validating native token transfer parameters.
 *
 * This schema validates the parameters required for native token transfers
 * (e.g., ETH on Ethereum, MATIC on Polygon):
 * - Address must be a valid EVM address (42 characters starting with 0x)
 * - Value must be a positive bigint greater than 0
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { nativeTransferParamsSchema } from '@core/adapter-evm/validation'
 *
 * const params = {
 *   address: '0x1234567890123456789012345678901234567890',
 *   value: BigInt(1000000)
 * }
 *
 * const result = nativeTransferParamsSchema.safeParse(params)
 * if (result.success) {
 *   console.log('Native transfer params are valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */
zod.z.object({
    address: evmAddressSchema,
    value: zod.z
        .bigint({
        required_error: 'Value is required for native transfers',
        invalid_type_error: 'Value must be a bigint',
    })
        .refine((val) => val > BigInt(0), {
        message: 'Value must be greater than 0',
    }),
});
/**
 * Zod schema for validating Ethereum transaction hashes.
 *
 * This schema validates transaction hash strings to ensure they conform to the
 * standard Ethereum transaction hash format:
 * - Must be a non-empty string
 * - Must start with '0x'
 * - Must be exactly 66 characters long (0x + 64 hex characters)
 * - Must contain only valid hexadecimal characters (0-9, a-f, A-F)
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { transactionHashSchema } from '@core/adapter-evm/validation'
 *
 * const txHash = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 * const result = transactionHashSchema.safeParse(txHash)
 *
 * if (result.success) {
 *   console.log('Transaction hash is valid')
 * } else {
 *   console.error('Validation failed:', result.error.issues[0]?.message)
 * }
 * ```
 */
zod.z
    .string({
    required_error: 'Transaction hash is required and must be a string. Please provide a valid transaction hash.',
    invalid_type_error: 'Transaction hash is required and must be a string. Please provide a valid transaction hash.',
})
    .min(1, {
    message: 'Transaction hash cannot be empty. Please provide a valid transaction hash.',
})
    .refine((hash) => hash.startsWith('0x') && hash.length === 66, (hash) => ({
    message: `Transaction hash "${hash}" is not a valid format. Expected a 32-byte hex string prefixed with '0x' (66 characters total).`,
}))
    .refine((hash) => /^0x[0-9a-fA-F]{64}$/.test(hash), (hash) => ({
    message: `Transaction hash "${hash}" contains invalid characters. Only hexadecimal characters (0-9, a-f, A-F) are allowed after '0x'.`,
}));
/**
 * Zod schema for validating EVM private keys.
 *
 * This schema validates private key strings to ensure they are properly formatted:
 * - Accepts private keys with or without '0x' prefix
 * - Automatically normalizes by adding '0x' prefix if missing
 * - Validates that the key is exactly 64 hexadecimal characters (32 bytes)
 * - Ensures only valid hexadecimal characters (0-9, a-f, A-F) are used
 *
 * @remarks
 * This is a shared schema used by both ethers.v6 and viem.v2 adapters to ensure
 * consistent private key validation across all EVM adapters.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { evmPrivateKeySchema } from '@core/adapter-evm/validation'
 *
 * // Both formats are accepted and normalized
 * const keyWithPrefix = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 * const keyWithoutPrefix = '1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 *
 * const result1 = evmPrivateKeySchema.safeParse(keyWithPrefix)
 * const result2 = evmPrivateKeySchema.safeParse(keyWithoutPrefix)
 *
 * // Both succeed and produce the same normalized result with '0x' prefix
 * ```
 */
zod.z
    .string({
    required_error: 'Private key is required. Please provide a valid private key.',
    invalid_type_error: 'Private key must be a string. Please provide a valid private key.',
})
    .transform((val) => (val.startsWith('0x') ? val : `0x${val}`))
    .pipe(zod.z.string().regex(/^0x[0-9a-fA-F]{64}$/, {
    message: 'Private key must be a valid 64-character hex string. Please provide a valid private key with or without "0x" prefix.',
}));

// --- Signature Parsing Constants ---
const SIGNATURE_BYTE_LENGTH = 65; // Total bytes in an Ethereum signature
const HEX_CHARS_PER_BYTE = 2;
const SIGNATURE_HEX_LENGTH = SIGNATURE_BYTE_LENGTH * HEX_CHARS_PER_BYTE;
const R_HEX_LENGTH = 32 * HEX_CHARS_PER_BYTE; // 32 bytes for 'r'
const S_HEX_LENGTH = 32 * HEX_CHARS_PER_BYTE; // 32 bytes for 's'
// --- Recovery ID Validation Constants ---
/**
 * Legacy recovery IDs (pre-EIP-155 format):
 * - 0 or 1 (older clients) or 27, 28 (Ethereum before chain-id inclusion)
 */
const LEGACY_V_VALUES = new Set([0, 1, 27, 28]);
/**
 * Minimum v value indicating an EIP-155 style signature.
 * Calculated as 35 + (2 * chainId) + recoveryId (0 or 1).
 */
const MIN_EIP155_V = 35;
/**
 * parseSignature
 *
 * Parse a 65-byte ECDSA signature into its r, s, and v components, expressed in hex.
 *
 * Ethereum signatures are structured as:
 *   signature = r (32 bytes) || s (32 bytes) || v (1 byte)
 *
 * - r, s: Big-endian hex values (32 bytes each)
 * - v: Recovery identifier, used by secp256k1 to reconstruct the signer’s public key
 *
 * @param signatureHex - Signature as a hex string, optionally prefixed with "0x".
 * @returns { r, s, v }
 *   - r: Hex string of the R component.
 *   - s: Hex string of the S component.
 *   - v: Numeric recovery ID.
 *
 * @throws Error if:
 *   - Input is not valid hex.
 *   - Incorrect length (must be exactly 65 bytes / 130 hex chars).
 *   - v is outside the supported range (Legacy or EIP-155 formula).
 *
 * Notes on EIP-155 overload:
 * EIP-155 repurposes the v field so that:
 *   v = 35 + (2 * chainId) + recoveryId(0 or 1)
 * Any v value >= 35 indicates the chain-id is encoded, preventing cross-chain replay.
 * r and s values remain unchanged.
 *
 * Example:
 * ```typescript
 * const rawSig = '0x6c1b...f02b'
 * try {
 *   const { r, s, v } = parseSignature(rawSig)
 *   console.log('R:', r)
 *   console.log('S:', s)
 *   console.log('Recovery ID (v):', v)
 * } catch (err) {
 *   console.error('Signature parse error:', err.message)
 * }
 * ```
 */
function parseSignature(signatureHex) {
    // 1) Remove optional '0x' prefix
    const hex = signatureHex.startsWith('0x')
        ? signatureHex.slice(2)
        : signatureHex;
    // 2) Validate hex format and length
    const VALID_HEX_REGEX = /^[0-9a-fA-F]+$/;
    if (!VALID_HEX_REGEX.test(hex)) {
        throw new Error('Signature must be a valid hex string (0-9, a-f, A-F).');
    }
    if (hex.length !== SIGNATURE_HEX_LENGTH) {
        throw new Error(`Invalid length: expected ${SIGNATURE_HEX_LENGTH.toString()} hex chars (65 bytes), got ${hex.length.toString()}`);
    }
    // 3) Extract components
    const r = `0x${hex.slice(0, R_HEX_LENGTH)}`;
    const s = `0x${hex.slice(R_HEX_LENGTH, R_HEX_LENGTH + S_HEX_LENGTH)}`;
    const vValue = parseInt(hex.slice(R_HEX_LENGTH + S_HEX_LENGTH), 16);
    // 4) Ensure v is within supported values
    const isLegacy = LEGACY_V_VALUES.has(vValue);
    const isEIP155 = vValue >= MIN_EIP155_V;
    if (!isLegacy && !isEIP155) {
        throw new Error(`Unsupported v value: ${vValue.toString()}. Must be one of [${[
            ...LEGACY_V_VALUES,
        ].join(', ')}] or >=${MIN_EIP155_V.toString()}`);
    }
    return { r: r, s: s, v: vValue };
}
/**
 * buildTypedData
 *
 * Create an EIP-712 compliant "TypedData" object, encapsulating:
 *  - Domain separator (application/contract identity, chain ID)
 *  - Explicit type definitions (field names and types)
 *  - Primary type name identifying the root object
 *  - Message payload matching the defined schema
 *
 * This enforces structured, non-ambiguous signing, and guards against signature replay.
 *
 * @typeParam Types - Map of type names to arrays of { name, type } definitions.
 * @typeParam Msg - Object whose shape matches the primaryType fields.
 *
 * @param domain - EIP712Domain, e.g. { name, version, chainId, verifyingContract }.
 * @param types - Type definitions, e.g.:
 *   {
 *     Mail: [ { name: 'from', type: 'string' }, { name: 'contents', type: 'string' } ],
 *   }
 * @param primaryType - Root key in types, e.g. 'Mail'.
 * @param message - The actual values, e.g. { from: 'Alice', contents: 'Hello' }.
 *
 * @returns TypedData object ready for use with signing libraries.
 *
 * Example:
 * ```typescript
 * const typedData = buildTypedData(
 *   { name: 'MyDApp', version: '1', chainId: 1, verifyingContract: '0xabc...' },
 *   { Message: [{ name: 'text', type: 'string' }] },
 *   'Message',
 *   { text: 'Hello, EIP-712!' }
 * )
 * // Pass typedData to ethers.js signer._signTypedData(domain, types, message)
 * ```
 */
function buildTypedData(domain, types, primaryType, message) {
    return { domain, types, primaryType, message };
}

/**
 * Compute default deadline for permit signatures.
 *
 * Returns a timestamp 1 hour (3600 seconds) from the current time,
 * converted to Unix timestamp format as a bigint. This is commonly
 * used as the default expiration time for EIP-2612 permit signatures.
 *
 * @returns Unix timestamp (in seconds) 1 hour from now as a bigint
 *
 * @example
 * ```typescript
 * import { computeDefaultDeadline } from '@core/adapter-evm'
 *
 * const deadline = computeDefaultDeadline()
 * console.log(`Permit expires at: ${deadline}`)
 * // Output: Permit expires at: 1640998800
 * ```
 */
function computeDefaultDeadline() {
    return BigInt(Math.floor(Date.now() / 1000) + 3600);
}

/**
 * EIP-2612 permit type definition.
 * Defines the structure for permit signatures according to EIP-2612 specification.
 *
 * @see {@link https://eips.ethereum.org/EIPS/eip-2612 | EIP-2612 Specification}
 */
const EIP2612_TYPES = {
    Permit: [
        { name: 'owner', type: 'address' },
        { name: 'spender', type: 'address' },
        { name: 'value', type: 'uint256' },
        { name: 'nonce', type: 'uint256' },
        { name: 'deadline', type: 'uint256' },
    ],
};

/**
 * Build EIP-2612 typed data for permit signing.
 *
 * This function creates the complete EIP-712 typed data structure required
 * for EIP-2612 permit signatures, including automatic nonce fetching using
 * the adapter's built-in nonce fetching capability.
 *
 * **Address Formatting**: All addresses are automatically formatted with proper
 * EIP-55 checksumming using the `convertAddress` utility, ensuring compatibility
 * with strict validation libraries like viem.
 *
 * **Nonce Handling**: The nonce can be provided explicitly or will be fetched
 * automatically using the adapter's `fetchEIP2612Nonce` method, which queries
 * the token contract's `nonces(owner)` function.
 *
 * **Deadline Calculation**: If no deadline is provided, it defaults to 1 hour
 * from the current time (computed using `computeDefaultDeadline`).
 *
 * @param meta - Domain metadata for the token contract
 * @param adapter - Adapter instance with nonce-fetching capability
 * @param opts - EIP-2612 permit options including owner, spender, value
 * @returns Complete EIP-712 typed data ready for signing
 *
 * @example
 * ```typescript
 * import { buildEIP2612TypedData } from '@core/adapter-evm'
 *
 * const typedData = await buildEIP2612TypedData(
 *   {
 *     name: 'USD Coin',
 *     version: '2',
 *     chainId: 1,
 *     verifyingContract: '0xa0b86a33e6441e4d178bb0c14ce0e9ce9c83bdd8'
 *   },
 *   adapter,
 *   {
 *     owner: '0x742d35cc6639c0532fbe9002b3a2265ca4c878f8e',
 *     spender: '0x1234567890123456789012345678901234567890',
 *     value: 1000000n
 *   }
 * )
 *
 * const signature = await adapter.signTypedData(typedData)
 * ```
 */
async function buildEIP2612TypedData(meta, adapter, opts, ctx) {
    // Format addresses to ensure proper EIP-55 checksumming
    const formattedOwner = convertAddress(opts.owner, 'evm');
    const formattedSpender = convertAddress(opts.spender, 'evm');
    const formattedContract = convertAddress(meta.verifyingContract, 'evm');
    // Fetch nonce if not provided - adapter handles the contract interaction
    const nonce = opts.nonce ??
        (await adapter.fetchEIP2612Nonce(formattedContract, formattedOwner, ctx));
    /*
     * Calculate deadline if not provided (1 hour from now).
     * EIP-2612 deadline is a uint256 in the permit struct, so we use bigint for full compatibility
     * with on-chain values and to avoid overflow/precision issues with large timestamps.
     * Most real-world deadlines are within JS safe integer range, but using bigint is safest.
     */
    const now = BigInt(Math.floor(Date.now() / 1000));
    const deadline = opts.deadline !== undefined
        ? BigInt(opts.deadline)
        : computeDefaultDeadline();
    if (deadline <= now) {
        throw new Error(`EIP-2612 deadline must be in the future (got ${deadline.toString()}, now ${now.toString()})`);
    }
    // Build the message with properly formatted addresses
    const message = {
        owner: formattedOwner,
        spender: formattedSpender,
        value: opts.value,
        nonce,
        deadline,
    };
    // Return complete typed data structure with formatted contract address
    return buildTypedData({ ...meta, verifyingContract: formattedContract }, EIP2612_TYPES, 'Permit', message);
}

/**
 * ERC-3009 ReceiveWithAuthorization type definition.
 * Defines the structure for authorization signatures according to ERC-3009.
 *
 * @see {@link https://eips.ethereum.org/EIPS/eip-3009 | ERC-3009 Specification}
 */
const ERC3009_TYPES = {
    ReceiveWithAuthorization: [
        { name: 'from', type: 'address' },
        { name: 'to', type: 'address' },
        { name: 'value', type: 'uint256' },
        { name: 'validAfter', type: 'uint256' },
        { name: 'validBefore', type: 'uint256' },
        { name: 'nonce', type: 'bytes32' },
    ],
};

/**
 * Generate a random bytes32 hex string for use as an ERC-3009 nonce.
 *
 * Uses `crypto.getRandomValues` (available in both browser and Node.js >= 19).
 */
function generateRandomNonce() {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    const hex = Array.from(bytes)
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    return `0x${hex}`;
}
/**
 * Build ERC-3009 typed data for ReceiveWithAuthorization signing.
 *
 * This function creates the complete EIP-712 typed data structure required
 * for ERC-3009 `receiveWithAuthorization` signatures, used by the
 * `depositWithAuthorization` flow on the Gateway Wallet contract.
 *
 * **Address Formatting**: All addresses are automatically formatted with proper
 * EIP-55 checksumming using the `convertAddress` utility.
 *
 * **Nonce Handling**: Unlike EIP-2612, the nonce is a random `bytes32` value
 * (not a sequential counter). A cryptographically random nonce is generated
 * automatically if not provided.
 *
 * **Validity Window**: `validAfter` defaults to `0` (immediately valid).
 * `validBefore` defaults to 1 hour from now (same as EIP-2612 deadline default).
 *
 * @param meta - Domain metadata for the USDC token contract.
 * @param opts - ERC-3009 authorization options including from, to, value.
 * @returns Complete EIP-712 typed data ready for signing.
 *
 * @example
 * ```typescript
 * import { buildERC3009TypedData } from '@core/adapter-evm'
 *
 * const typedData = buildERC3009TypedData(
 *   {
 *     name: 'USD Coin',
 *     version: '2',
 *     chainId: 1,
 *     verifyingContract: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
 *   },
 *   {
 *     from: '0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38',
 *     to: '0x0077777d7EBA4688BDeF3E311b846F25870A19B9',
 *     value: 1000000n
 *   }
 * )
 *
 * const signature = await adapter.signTypedData(typedData)
 * ```
 */
function buildERC3009TypedData(meta, opts) {
    if (meta['chainId'] == null) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'ERC-3009 authorization requires chainId in the EIP-712 domain for replay protection.',
        });
    }
    if (meta['verifyingContract'] == null) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'ERC-3009 authorization requires verifyingContract in the EIP-712 domain.',
        });
    }
    const formattedFrom = convertAddress(opts.from, 'evm');
    const formattedTo = convertAddress(opts.to, 'evm');
    const formattedContract = convertAddress(meta.verifyingContract, 'evm');
    const validAfter = opts.validAfter ?? 0n;
    const validBefore = opts.validBefore ?? computeDefaultDeadline();
    const nonce = opts.nonce ?? generateRandomNonce();
    const now = BigInt(Math.floor(Date.now() / 1000));
    if (validBefore <= now) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `ERC-3009 validBefore must be in the future (got ${validBefore.toString()}, now ${now.toString()})`,
            cause: {
                trace: { validBefore: validBefore.toString(), now: now.toString() },
            },
        });
    }
    if (validAfter >= validBefore) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `ERC-3009 validAfter must be less than validBefore (got validAfter=${validAfter.toString()}, validBefore=${validBefore.toString()})`,
            cause: {
                trace: {
                    validAfter: validAfter.toString(),
                    validBefore: validBefore.toString(),
                },
            },
        });
    }
    const message = {
        from: formattedFrom,
        to: formattedTo,
        value: opts.value,
        validAfter,
        validBefore,
        nonce,
    };
    return buildTypedData({ ...meta, verifyingContract: formattedContract }, ERC3009_TYPES, 'ReceiveWithAuthorization', message);
}

const assertEvmAdapterSymbol = Symbol('assertEvmAdapter');
/**
 * Asserts that the provided parameters match the EvmAdapter interface.
 * The validation includes:
 * - A valid adapter with prepare and execute methods
 * - A valid chain definition with required properties.
 *
 * @param params - The parameters to validate
 * @throws KitError with INPUT_VALIDATION_FAILED code if validation fails, with details about which properties failed
 *
 * @example
 * ```typescript
 * import { assertEvmAdapter } from '@core/evmAdapter'
 *
 * // Prepare EVM adapter
 * const adapter = {
 *   chainType: 'evm',
 *   actionRegistry: {
 *     registerHandlers: (handlers: any) => {},
 *     actionHandlers: {
 *       'usdc.approve': async (params: any) => ({})
 *     }
 *   },
 *   prepare: async (request: any) => ({}),
 *   },
 * }
 *
 * // This will throw KitError if validation fails
 * assertEvmAdapter(adapter)
 *
 * // If we get here, adapter is guaranteed to be valid
 * console.log('EVM adapter is valid')
 * ```
 */
function assertEvmAdapter(params) {
    validateWithStateTracking(params, evmAdapterSchema, 'EVM adapter', assertEvmAdapterSymbol);
}

const USDC_EIP712_DOMAIN_VERSION = '2';
function createDepositWithRevokeError(depositError, revokeError) {
    const base = depositError instanceof KitError
        ? {
            code: depositError.code,
            name: depositError.name,
            type: depositError.type,
            recoverability: depositError.recoverability,
        }
        : {
            ...OnchainError.TRANSACTION_REVERTED,
            recoverability: 'FATAL',
        };
    return new KitError({
        ...base,
        message: `Deposit failed: ${getErrorMessage(depositError)}. Allowance revocation also failed: ${revokeError.message}`,
        cause: {
            trace: { depositError, revokeError },
        },
    });
}
async function fetchUsdcDomainName(adapter, operationContext) {
    const prepared = await adapter.prepareAction('usdc.name', {}, operationContext);
    const result = await prepared.execute();
    if (typeof result !== 'string' || result.length === 0) {
        throw new KitError({
            ...RpcError.INVALID_RESPONSE,
            recoverability: 'RETRYABLE',
            message: `Failed to fetch USDC domain name: expected non-empty string, got ${typeof result}`,
            cause: { trace: { resultType: typeof result } },
        });
    }
    return result;
}
async function buildUsdcDomainMeta(adapter, chain, operationContext) {
    const name = await fetchUsdcDomainName(adapter, operationContext);
    return {
        name,
        version: USDC_EIP712_DOMAIN_VERSION,
        chainId: chain.chainId,
        verifyingContract: chain.usdcAddress,
    };
}
async function executeAndWait$1(adapter, request, chain) {
    if (request.type === 'noop') {
        throw createValidationFailedError('request', request, 'Unexpected noop request during Gateway operation');
    }
    const txHash = await request.execute();
    await adapter.waitForTransaction(txHash, { confirmations: 1 }, chain);
    return txHash;
}
async function revokeAllowanceBestEffort(adapter, chain, gatewayWalletAddress, tokenAddress, operationContext) {
    try {
        const revokeRequest = await adapter.prepare({
            type: 'evm',
            abi: usdcAbi,
            address: tokenAddress,
            functionName: 'approve',
            args: [gatewayWalletAddress, 0n],
        }, operationContext);
        const txHash = await revokeRequest.execute();
        await adapter.waitForTransaction(txHash, { confirmations: 1 }, chain);
        return undefined;
    }
    catch (revokeError) {
        return revokeError instanceof Error
            ? revokeError
            : new Error(getErrorMessage(revokeError));
    }
}
async function depositWithApprove(params) {
    const { adapter, chain, amount, token, depositAccount, operationContext } = params;
    const gatewayWalletAddress = chain.gateway.contracts.v1.wallet;
    const approveRequest = await adapter.prepareAction('usdc.increaseAllowance', {
        amount,
        delegate: gatewayWalletAddress,
        chain,
    }, operationContext);
    await executeAndWait$1(adapter, approveRequest, chain);
    const isForAnother = depositAccount !== undefined;
    try {
        const depositRequest = await adapter.prepareAction(isForAnother ? 'gateway.v1.depositFor' : 'gateway.v1.deposit', {
            token,
            value: amount,
            ...(isForAnother ? { depositor: depositAccount } : {}),
            chain,
        }, operationContext);
        return await executeAndWait$1(adapter, depositRequest, chain);
    }
    catch (depositError) {
        const revokeError = await revokeAllowanceBestEffort(adapter, chain, gatewayWalletAddress, token, operationContext);
        if (revokeError) {
            throw createDepositWithRevokeError(depositError, revokeError);
        }
        throw depositError;
    }
}
async function depositWithPermit(params) {
    const { adapter, chain, amount, token, operationContext, signerAddress } = params;
    const evmChain = chain;
    assertEvmAdapter(adapter);
    const gatewayWalletAddress = chain.gateway.contracts.v1
        .wallet;
    const domainMeta = await buildUsdcDomainMeta(adapter, evmChain, operationContext);
    const typedData = await buildEIP2612TypedData(domainMeta, adapter, {
        owner: signerAddress,
        spender: gatewayWalletAddress,
        value: amount,
    }, operationContext);
    const signatureHex = await adapter.signTypedData(typedData, operationContext);
    const { v, r, s } = parseSignature(signatureHex);
    const depositRequest = await adapter.prepareAction('gateway.v1.depositWithPermit', {
        token,
        owner: signerAddress,
        value: amount,
        deadline: typedData.message.deadline,
        v,
        r,
        s,
        chain,
    }, operationContext);
    return executeAndWait$1(adapter, depositRequest, chain);
}
async function depositWithAuthorization(params) {
    const { adapter, chain, amount, token, operationContext, signerAddress } = params;
    const evmChain = chain;
    assertEvmAdapter(adapter);
    const gatewayWalletAddress = chain.gateway.contracts.v1
        .wallet;
    const domainMeta = await buildUsdcDomainMeta(adapter, evmChain, operationContext);
    const typedData = buildERC3009TypedData(domainMeta, {
        from: signerAddress,
        to: gatewayWalletAddress,
        value: amount,
    });
    const signatureHex = await adapter.signTypedData(typedData, operationContext);
    const { v, r, s } = parseSignature(signatureHex);
    const depositRequest = await adapter.prepareAction('gateway.v1.depositWithAuthorization', {
        token,
        from: signerAddress,
        value: amount,
        validAfter: typedData.message.validAfter,
        validBefore: typedData.message.validBefore,
        nonce: typedData.message.nonce,
        v,
        r,
        s,
        chain,
    }, operationContext);
    return executeAndWait$1(adapter, depositRequest, chain);
}
/**
 * Perform a full EVM Gateway deposit with the specified allowance strategy.
 *
 * Handles all EVM-specific flows: approve + deposit (with best-effort
 * revoke on failure), EIP-2612 permit + deposit, and EIP-3009
 * authorization + deposit.
 *
 * @param params - Deposit parameters including adapter, chain, amount,
 *   token address, strategy, and signer address.
 * @returns The confirmed deposit transaction hash.
 * @throws {KitError} If the strategy is unsupported or a transaction fails.
 *
 * @example
 * ```typescript
 * import { performEvmDeposit } from '@core/adapter-evm'
 *
 * const txHash = await performEvmDeposit({
 *   adapter,
 *   chain,
 *   amount: 1_000_000n,
 *   token: chain.usdcAddress,
 *   allowanceStrategy: 'permit',
 *   operationContext: { chain },
 *   signerAddress: '0x...',
 * })
 * ```
 */
async function performEvmDeposit(params) {
    const { allowanceStrategy, depositAccount } = params;
    if (depositAccount !== undefined &&
        (depositAccount === '' ||
            depositAccount === '0x0000000000000000000000000000000000000000')) {
        throw createValidationFailedError('depositAccount', depositAccount, 'must be a non-empty, non-zero address when provided');
    }
    switch (allowanceStrategy) {
        case 'approve':
            return depositWithApprove(params);
        case 'permit':
            return depositWithPermit(params);
        case 'authorize':
            return depositWithAuthorization(params);
        default: {
            const _exhaustive = allowanceStrategy;
            throw createValidationFailedError('allowanceStrategy', allowanceStrategy, `unsupported strategy: ${String(_exhaustive)}`);
        }
    }
}

const TRANSFER_SPEC_TYPES = [
    { name: 'version', type: 'uint32' },
    { name: 'sourceDomain', type: 'uint32' },
    { name: 'destinationDomain', type: 'uint32' },
    { name: 'sourceContract', type: 'bytes32' },
    { name: 'destinationContract', type: 'bytes32' },
    { name: 'sourceToken', type: 'bytes32' },
    { name: 'destinationToken', type: 'bytes32' },
    { name: 'sourceDepositor', type: 'bytes32' },
    { name: 'destinationRecipient', type: 'bytes32' },
    { name: 'sourceSigner', type: 'bytes32' },
    { name: 'destinationCaller', type: 'bytes32' },
    { name: 'value', type: 'uint256' },
    { name: 'salt', type: 'bytes32' },
    { name: 'hookData', type: 'bytes' },
];
const BURN_INTENT_TYPES = [
    { name: 'maxBlockHeight', type: 'uint256' },
    { name: 'maxFee', type: 'uint256' },
    { name: 'spec', type: 'TransferSpec' },
];
const BURN_INTENT_SET_TYPES = [
    { name: 'intents', type: 'BurnIntent[]' },
];
const EIP712_DOMAIN_TYPES = [
    { name: 'name', type: 'string' },
    { name: 'version', type: 'string' },
];
const GATEWAY_EIP712_DOMAIN = {
    name: 'GatewayWallet',
    version: '1',
};
function validateBurnIntentStructure(intent, label) {
    const value = intent;
    if (value === undefined ||
        value === null ||
        typeof value !== 'object' ||
        !('spec' in value) ||
        value.spec === undefined ||
        value.spec === null ||
        typeof value.spec !== 'object') {
        throw createValidationFailedError(label, intent, 'must be a valid BurnIntent with a spec object');
    }
}
function evmSigningData(burnIntent) {
    if (Array.isArray(burnIntent)) {
        if (burnIntent.length === 0) {
            throw createValidationFailedError('burnIntent', [], 'array must not be empty');
        }
        for (let i = 0; i < burnIntent.length; i++) {
            validateBurnIntentStructure(burnIntent[i], `burnIntent[${String(i)}]`);
        }
        return {
            types: {
                EIP712Domain: EIP712_DOMAIN_TYPES,
                TransferSpec: TRANSFER_SPEC_TYPES,
                BurnIntent: BURN_INTENT_TYPES,
                BurnIntentSet: BURN_INTENT_SET_TYPES,
            },
            domain: GATEWAY_EIP712_DOMAIN,
            primaryType: 'BurnIntentSet',
            message: { intents: burnIntent },
        };
    }
    validateBurnIntentStructure(burnIntent, 'burnIntent');
    return {
        types: {
            EIP712Domain: EIP712_DOMAIN_TYPES,
            TransferSpec: TRANSFER_SPEC_TYPES,
            BurnIntent: BURN_INTENT_TYPES,
        },
        domain: GATEWAY_EIP712_DOMAIN,
        primaryType: 'BurnIntent',
        message: burnIntent,
    };
}

/**
 * Sign an EVM adapter group: batches all intents and produces a single
 * EIP-712 ECDSA signature.
 *
 * For a single-intent group, `primaryType` is `'BurnIntent'`.
 * For multi-intent groups, `primaryType` is `'BurnIntentSet'`.
 *
 * @param group - The adapter group containing the adapter, chain, and
 *   burn intents to sign.
 * @returns A signed set with the intents and the ECDSA signature.
 *
 * @example
 * ```typescript
 * import { signEvmIntentGroup } from '@core/adapter-evm'
 *
 * const signedSet = await signEvmIntentGroup({
 *   adapter: evmAdapter,
 *   chain: ethereumChain,
 *   intents: [burnIntent1, burnIntent2],
 *   address: '0x...',
 * })
 * console.log(signedSet.signature)
 * ```
 */
async function signEvmIntentGroup(group) {
    const { adapter, intents: groupIntents, chain, address } = group;
    const operationContext = address === undefined ? { chain } : { chain, address };
    const firstIntent = groupIntents[0];
    const typedData = groupIntents.length === 1 && firstIntent
        ? evmSigningData(firstIntent)
        : evmSigningData(groupIntents);
    const signRequest = await adapter.prepareAction('gateway.v1.signBurnIntents', { typedData, chain }, operationContext);
    const sig = await signRequest.execute();
    return {
        intents: groupIntents,
        signature: sig,
    };
}

/**
 * Add an EVM intent into the batched EVM group map.
 *
 * On EVM, all intents for the same adapter are batched into a single
 * group so that they can be signed in one EIP-712 `BurnIntentSet`
 * operation.
 *
 * @param intent - The burn intent to group.
 * @param alloc - The allocation that resolved to this intent.
 * @param evmGroups - Mutable map of adapter → EVM group.
 *
 * @example
 * ```typescript
 * import { groupEvmIntents } from '@core/adapter-evm'
 *
 * const groups = new Map()
 * groupEvmIntents(intent, alloc, groups)
 * ```
 */
function groupEvmIntents(intent, alloc, evmGroups) {
    const existing = evmGroups.get(alloc.adapter);
    if (existing) {
        existing.intents.push(intent);
    }
    else {
        evmGroups.set(alloc.adapter, {
            adapter: alloc.adapter,
            chain: alloc.chain,
            intents: [intent],
            address: alloc.sourceSigner,
        });
    }
}

/**
 * SPL Token program ID (standard, non-2022).
 *
 * @remarks
 * Address: TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA
 */
const TOKEN_PROGRAM_ID = new web3_js.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
/**
 * SPL Associated Token Account program ID.
 *
 * @remarks
 * Address: ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL
 */
const ASSOCIATED_TOKEN_PROGRAM_ID = new web3_js.PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');
/**
 * Derive the Associated Token Account address for a given mint and owner.
 *
 * Equivalent to \@solana/spl-token's `getAssociatedTokenAddressSync`.
 *
 * @param mint - The token mint public key.
 * @param owner - The wallet owner public key.
 * @param allowOwnerOffCurve - Allow the owner to be off the ed25519 curve
 *   (e.g. PDA owners). Defaults to `false`.
 * @param programId - The token program owning the account.
 *   Defaults to the standard SPL Token program.
 * @param associatedTokenProgramId - The ATA program.
 *   Defaults to the standard ATA program.
 * @returns The derived ATA public key.
 *
 * @throws KitError with code 1004 (INPUT_INVALID_ADDRESS) when owner is off the ed25519 curve and allowOwnerOffCurve is false.
 *
 * @example
 * ```typescript
 * import { getAssociatedTokenAddressSync } from '@core/adapter-solana'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const ata = getAssociatedTokenAddressSync(
 *   new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'),
 *   new PublicKey('DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'),
 * )
 * ```
 */
const getAssociatedTokenAddressSync = (mint, owner, allowOwnerOffCurve = false, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID) => {
    if (!allowOwnerOffCurve && !web3_js.PublicKey.isOnCurve(owner.toBuffer())) {
        throw new KitError({
            ...InputError.INVALID_ADDRESS,
            recoverability: 'FATAL',
            message: `Owner ${owner.toBase58()} is off the ed25519 curve`,
            cause: {
                trace: {
                    reason: 'Owner is off the ed25519 curve',
                    owner: owner.toBase58(),
                },
            },
        });
    }
    const [address] = web3_js.PublicKey.findProgramAddressSync([owner.toBuffer(), programId.toBuffer(), mint.toBuffer()], associatedTokenProgramId);
    return address;
};
/**
 * SPL Token-2022 (Token Extensions) program ID.
 *
 * @remarks
 * Address: TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb
 */
new web3_js.PublicKey('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb');

function toPublicKey(address, label) {
    try {
        return new web3_js.PublicKey(address);
    }
    catch (error) {
        throw createInvalidAddressError(address, 'Solana', `valid base58-encoded public key for ${label} (${getErrorMessage(error)})`);
    }
}
/**
 * Derive the Associated Token Account (ATA) for a given wallet and
 * SPL token mint on Solana.
 *
 * Callers are responsible for checking the destination chain type
 * before invoking this function — it always derives an ATA and will
 * throw a {@link KitError} if either address is not a valid Solana
 * public key.
 *
 * @param walletAddress - The recipient wallet address (base58).
 * @param tokenMintAddress - The SPL token mint address (base58).
 * @param programId - The token program owning the mint. Defaults to
 *   the standard SPL Token program. Pass `TOKEN_2022_PROGRAM_ID` for
 *   Token-2022 mints.
 * @returns The derived ATA address as a base58 string.
 * @throws {KitError} If either address is not a valid Solana public key.
 *
 * @example
 * ```typescript
 * import { resolveRecipientAta } from '@core/adapter-solana'
 *
 * const ata = resolveRecipientAta(walletAddress, usdcMintAddress)
 * ```
 */
function resolveRecipientAta(walletAddress, tokenMintAddress, programId = TOKEN_PROGRAM_ID) {
    const tokenMint = toPublicKey(tokenMintAddress, 'tokenMintAddress');
    const wallet = toPublicKey(walletAddress, 'walletAddress');
    const ata = getAssociatedTokenAddressSync(tokenMint, wallet, false, programId);
    return ata.toBase58();
}

/**
 * Return Circle's fee recipient wallet address for Solana.
 *
 * @returns The Solana fee recipient address.
 *
 * @example
 * ```typescript
 * import { getSolanaFeeRecipient } from '@core/adapter-solana'
 *
 * const feeAddress = getSolanaFeeRecipient()
 * ```
 */
function getSolanaFeeRecipient() {
    return CIRCLE_FEE_RECIPIENT_SOLANA;
}

Buffer.from('gateway_minter');
Buffer.from('gateway_minter_custody');
Buffer.from('used_transfer_spec_hash');

async function executeAndWait(adapter, request, chain) {
    if (request.type === 'noop') {
        throw createValidationFailedError('request', request, 'Unexpected noop request during Gateway operation');
    }
    const txHash = await request.execute();
    await adapter.waitForTransaction(txHash, { confirmations: 1 }, chain);
    return txHash;
}
/**
 * Perform a Solana Gateway deposit.
 *
 * Solana deposits do not require a separate approval step. The function
 * prepares and executes a single deposit (or depositFor) instruction
 * via the adapter's action registry.
 *
 * @param params - Deposit parameters including adapter, chain, amount,
 *   token address, and optional depositAccount for depositFor.
 * @returns The confirmed deposit transaction hash.
 * @throws {KitError} If the transaction fails.
 *
 * @example
 * ```typescript
 * import { performSolanaDeposit } from '@core/adapter-solana'
 *
 * const txHash = await performSolanaDeposit({
 *   adapter,
 *   chain,
 *   amount: 1_000_000n,
 *   token: chain.usdcAddress,
 *   operationContext: { chain },
 * })
 * ```
 */
async function performSolanaDeposit(params) {
    const { adapter, chain, amount, token, depositAccount, operationContext } = params;
    if (depositAccount !== undefined && depositAccount === '') {
        throw createValidationFailedError('depositAccount', depositAccount, 'must be a non-empty address when provided');
    }
    const isForAnother = depositAccount !== undefined;
    const depositRequest = await adapter.prepareAction(isForAnother ? 'gateway.v1.depositFor' : 'gateway.v1.deposit', {
        token,
        value: amount,
        ...(isForAnother ? { depositor: depositAccount } : {}),
        chain,
    }, operationContext);
    return executeAndWait(adapter, depositRequest, chain);
}

const BURN_INTENT_MAGIC = 0x070afbc2;
const TRANSFER_SPEC_MAGIC = 0xca85def7;
const SOLANA_SIGNING_DOMAIN = new Uint8Array([
    0xff, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]);
function writeUint256BE(buffer, value, offset) {
    const buf = Buffer.alloc(32);
    const mask64 = 0xffffffffffffffffn;
    buf.writeBigUInt64BE((value >> 192n) & mask64, 0);
    buf.writeBigUInt64BE((value >> 128n) & mask64, 8);
    buf.writeBigUInt64BE((value >> 64n) & mask64, 16);
    buf.writeBigUInt64BE(value & mask64, 24);
    buf.copy(buffer, offset);
    return 32;
}
function writeBytes32(buffer, hex, offset) {
    const bytes = Buffer.from(hex.slice(2), 'hex');
    if (bytes.length !== 32) {
        throw createValidationFailedError('bytes32', hex, `Expected 32 bytes (66-char hex), got ${String(bytes.length)} bytes`);
    }
    bytes.copy(buffer, offset);
    return 32;
}
/**
 * Encode a {@link BurnIntent} into the Solana binary signing format,
 * prefixed with the 16-byte `SOLANA_SIGNING_DOMAIN`.
 *
 * Binary layout (after the domain prefix):
 * ```
 * [4 bytes]  BURN_INTENT_MAGIC  (0x070afbc2)
 * [32 bytes] maxBlockHeight     (uint256 big-endian)
 * [32 bytes] maxFee             (uint256 big-endian)
 * [4 bytes]  transferSpecLength (uint32 big-endian)
 * [4 bytes]  TRANSFER_SPEC_MAGIC (0xca85def7)
 * [4 bytes]  version            (uint32 big-endian)
 * [4 bytes]  sourceDomain       (uint32 big-endian)
 * [4 bytes]  destinationDomain  (uint32 big-endian)
 * [32 bytes each] 10 address fields (bytes32)
 * [32 bytes] value              (uint256 big-endian)
 * [32 bytes] salt               (bytes32)
 * [4 bytes]  hookDataLength     (uint32 big-endian)
 * [N bytes]  hookData           (raw bytes)
 * ```
 *
 * @param intent - A single burn intent to encode (addresses in bytes32 hex).
 * @returns Domain-prefixed binary payload ready for ed25519 signing.
 *
 * @example
 * ```typescript
 * import { encodeBurnIntentForSolana } from '@core/adapter-solana'
 *
 * const payload = encodeBurnIntentForSolana(burnIntent)
 * const signature = await solanaWallet.signMessage(payload)
 * ```
 */
function encodeBurnIntentForSolana(intent) {
    const value = intent;
    if (value === undefined ||
        value === null ||
        typeof value !== 'object' ||
        !('spec' in value) ||
        value.spec === undefined ||
        value.spec === null ||
        typeof value.spec !== 'object') {
        throw createValidationFailedError('burnIntent', intent, 'must be a valid BurnIntent with a spec object');
    }
    const { spec } = intent;
    const hookData = Buffer.from((spec.hookData || '0x').slice(2), 'hex');
    const transferSpecLength = 4 + 4 + 4 + 4 + 10 * 32 + 4 + hookData.length;
    const intentSize = 4 + 32 + 32 + 4 + transferSpecLength;
    const totalSize = SOLANA_SIGNING_DOMAIN.length + intentSize;
    const buffer = Buffer.alloc(totalSize);
    let offset = 0;
    Buffer.from(SOLANA_SIGNING_DOMAIN).copy(buffer, offset);
    offset += SOLANA_SIGNING_DOMAIN.length;
    offset = buffer.writeUInt32BE(BURN_INTENT_MAGIC, offset);
    offset += writeUint256BE(buffer, intent.maxBlockHeight, offset);
    offset += writeUint256BE(buffer, intent.maxFee, offset);
    offset = buffer.writeUInt32BE(transferSpecLength, offset);
    offset = buffer.writeUInt32BE(TRANSFER_SPEC_MAGIC, offset);
    offset = buffer.writeUInt32BE(spec.version, offset);
    offset = buffer.writeUInt32BE(spec.sourceDomain, offset);
    offset = buffer.writeUInt32BE(spec.destinationDomain, offset);
    offset += writeBytes32(buffer, spec.sourceContract, offset);
    offset += writeBytes32(buffer, spec.destinationContract, offset);
    offset += writeBytes32(buffer, spec.sourceToken, offset);
    offset += writeBytes32(buffer, spec.destinationToken, offset);
    offset += writeBytes32(buffer, spec.sourceDepositor, offset);
    offset += writeBytes32(buffer, spec.destinationRecipient, offset);
    offset += writeBytes32(buffer, spec.sourceSigner, offset);
    offset += writeBytes32(buffer, spec.destinationCaller, offset);
    offset += writeUint256BE(buffer, spec.value, offset);
    offset += writeBytes32(buffer, spec.salt, offset);
    offset = buffer.writeUInt32BE(hookData.length, offset);
    if (hookData.length > 0) {
        hookData.copy(buffer, offset);
    }
    return buffer;
}

/**
 * Sign a Solana adapter group: signs each intent individually
 * using domain-separated binary encoding.
 *
 * Unlike EVM batched signing, Solana signs one intent at a time
 * because each intent is a separate off-chain message.
 *
 * @param group - The adapter group containing the adapter, chain, and
 *   burn intents to sign.
 * @returns An array of signed sets, one per intent.
 *
 * @example
 * ```typescript
 * import { signSolanaIntentGroup } from '@core/adapter-solana'
 *
 * const signedSets = await signSolanaIntentGroup({
 *   adapter: solanaAdapter,
 *   chain: solanaChain,
 *   intents: [burnIntent],
 *   address: 'YubQzu18...',
 * })
 * ```
 */
async function signSolanaIntentGroup(group) {
    const { adapter, intents: groupIntents, chain, address } = group;
    const operationContext = address === undefined ? { chain } : { chain, address };
    return Promise.all(groupIntents.map(async (intent) => {
        const prefixed = encodeBurnIntentForSolana(intent);
        const signRequest = await adapter.prepareAction('gateway.v1.signBurnIntents', { typedData: prefixed, chain }, operationContext);
        const sig = await signRequest.execute();
        return { intents: [intent], signature: sig };
    }));
}

/**
 * Create a single-intent Solana group from a burn intent.
 *
 * On Solana, each intent is signed individually as a separate
 * off-chain message.
 *
 * @param intent - The burn intent to wrap.
 * @param alloc - The allocation that resolved to this intent.
 * @returns A group with exactly one intent.
 *
 * @example
 * ```typescript
 * import { groupSolanaIntents } from '@core/adapter-solana'
 *
 * const group = groupSolanaIntents(intent, alloc)
 * ```
 */
function groupSolanaIntents(intent, alloc) {
    return {
        adapter: alloc.adapter,
        chain: alloc.chain,
        intents: [intent],
        address: alloc.sourceSigner,
    };
}

/**
 * Zod schema for the numeric parameters of customBurn.
 * Matches existing error messages used in tests.
 */
zod.z.object({
    amount: zod.z
        .bigint({ required_error: 'amount is required for customBurn' })
        .refine((v) => v > 0n, 'amount must be greater than zero'),
    maxFee: zod.z
        .bigint({ required_error: 'maxFee is required for customBurn' })
        .refine((v) => v >= 0n, 'maxFee cannot be negative'),
    minFinalityThreshold: zod.z
        .number({
        required_error: 'minFinalityThreshold is required for customBurn',
        invalid_type_error: 'minFinalityThreshold is required for customBurn',
    })
        .refine((v) => Number.isFinite(v), 'minFinalityThreshold is required for customBurn')
        .refine((v) => v >= 0, 'minFinalityThreshold cannot be negative'),
    protocolFee: zod.z
        .bigint()
        .optional()
        .refine((v) => v === undefined || v >= 0n, 'protocolFee cannot be negative'),
});
// Chain params are validated via explicit checks below to preserve exact error messages
/**
 * Zod schema for the address parameters of customBurn.
 * Enforces presence; format is verified by PublicKey conversion below.
 */
zod.z.object({
    mintRecipient: zod.z
        .string({ required_error: 'mintRecipient is required for customBurn' })
        .min(1, 'mintRecipient is required for customBurn'),
    feeRecipient: zod.z.string().optional(),
    destinationCaller: zod.z.string().optional(),
});

/**
 * @packageDocumentation
 * @module SolanaValidationSchemas
 *
 * Shared validation schemas for Solana adapter parameters.
 *
 * This module provides transport-agnostic validation schemas that can be
 * used by both @solana/web3.js and @solana/kit adapter implementations.
 */
/**
 * Schema for validating private keys in multiple supported formats.
 *
 * Supports Base58, Base64, and JSON array formats for maximum compatibility
 * with different private key sources and developer preferences.
 *
 * @example
 * ```typescript
 * import { privateKeySchema } from '@core/adapter-solana'
 *
 * // Valid formats:
 * privateKeySchema.parse('5KkQMKuKpKU...') // Base58
 * privateKeySchema.parse('[1,2,3,...]')     // JSON array string
 * privateKeySchema.parse('base64string==')   // Base64
 * ```
 */
const privateKeySchema = zod.z
    .string({
    required_error: 'Private key is required. Please provide a valid private key (Base58, Base64, or JSON array format).',
    invalid_type_error: 'Private key must be a string. Please provide a valid private key (Base58, Base64, or JSON array format).',
})
    .min(10, {
    message: 'Private key is too short. Please provide a valid private key.',
})
    .max(1000, {
    message: 'Private key is too long. Please provide a valid private key.',
});
/**
 * Schema for validating Solana chain identifiers.
 *
 * Accepts multiple formats for developer convenience:
 * - String literals ('Solana', 'Solana_Devnet')
 * - Blockchain enum values (Blockchain.Solana, Blockchain.Solana_Devnet)
 * - ChainDefinition objects with type 'solana'
 *
 * @example
 * ```typescript
 * import { solanaChainIdentifierSchema } from '@core/adapter-solana'
 * import { Blockchain, Solana } from '@core/chains'
 *
 * // Valid formats:
 * solanaChainIdentifierSchema.parse('Solana')              // String literal
 * solanaChainIdentifierSchema.parse(Blockchain.Solana)     // Enum value
 * solanaChainIdentifierSchema.parse(Solana)                // ChainDefinition
 * ```
 */
const solanaChainIdentifierSchema = zod.z.union([
    zod.z.literal('Solana'),
    zod.z.literal('Solana_Devnet'),
    zod.z
        .nativeEnum(Blockchain)
        .refine((val) => val === Blockchain.Solana || val === Blockchain.Solana_Devnet, 'Must be a Solana blockchain enum value (Blockchain.Solana or Blockchain.Solana_Devnet)'),
    zod.z
        .object({
        type: zod.z.literal('solana'),
        chain: zod.z.nativeEnum(Blockchain),
        name: zod.z.string(),
    })
        .passthrough(), // Allow additional properties for full ChainDefinition
]);
/**
 * Schema for validating Solana wallet provider objects.
 *
 * Ensures the provider has all required methods for wallet operations
 * including connection, signing, and optional message signing capabilities.
 *
 * @example
 * ```typescript
 * import { solanaWalletProviderSchema } from '@core/adapter-solana'
 *
 * // Validates wallet providers like Phantom, Solflare, etc.
 * const provider = window.solana
 * solanaWalletProviderSchema.parse(provider)
 * ```
 */
const solanaWalletProviderSchema = zod.z
    .object({
    connect: zod.z.function().returns(zod.z.promise(zod.z.object({
        publicKey: zod.z.object({
            toString: zod.z.function().returns(zod.z.string()),
        }),
    }))),
    disconnect: zod.z.function().returns(zod.z.promise(zod.z.void())),
    isConnected: zod.z.boolean(),
    publicKey: zod.z.union([
        zod.z.object({
            toString: zod.z.function().returns(zod.z.string()),
        }),
        zod.z.null(),
    ]),
    signTransaction: zod.z.function().returns(zod.z.promise(zod.z.unknown())),
    signAllTransactions: zod.z
        .function()
        .returns(zod.z.promise(zod.z.array(zod.z.unknown())))
        .optional(),
    signMessage: zod.z
        .function()
        .returns(zod.z.promise(zod.z.object({
        signature: zod.z.instanceof(Uint8Array),
    })))
        .optional(),
})
    .passthrough(); // Allow additional provider-specific properties
/**
 * Schema for validating RPC URL strings.
 *
 * Ensures the URL is properly formatted and can be used for
 * Solana RPC connections.
 *
 * @example
 * ```typescript
 * import { rpcUrlSchema } from '@core/adapter-solana'
 *
 * // Valid URLs:
 * rpcUrlSchema.parse('https://api.mainnet-beta.solana.com')
 * rpcUrlSchema.parse('https://api.devnet.solana.com')
 * rpcUrlSchema.parse('https://rpc.helius.xyz/?api-key=...')
 * ```
 */
zod.z
    .string({
    invalid_type_error: 'RPC URL must be a string',
})
    .url({
    message: 'RPC URL must be a valid URL',
});
/**
 * Schema for validating connection configuration options.
 *
 * Provides flexible validation for connection options that work
 * with both @solana/web3.js and @solana/kit adapters.
 *
 * @example
 * ```typescript
 * import { connectionOptionsSchema } from '@core/adapter-solana'
 *
 * const options = {
 *   commitment: 'confirmed',
 *   timeout: 30000,
 *   maxRetries: 3
 * }
 * connectionOptionsSchema.parse(options)
 * ```
 */
zod.z.record(zod.z.unknown()).optional();
/**
 * Base schema for validating adapter creation parameters.
 *
 * Contains common fields used by all Solana adapter factory methods.
 * Extended by transport-specific schemas in individual adapter packages.
 */
zod.z.object({
    privateKey: privateKeySchema.optional(),
    chain: solanaChainIdentifierSchema,
    provider: solanaWalletProviderSchema.optional(),
});
/**
 * Schema for validating private key adapter creation parameters.
 *
 * Used by factory methods that create adapters from private keys
 * across both @solana/web3.js and @solana/kit implementations.
 *
 * @example
 * ```typescript
 * import { privateKeyAdapterParamsSchema } from '@core/adapter-solana'
 *
 * const params = {
 *   privateKey: 'your-base58-key',
 *   chain: 'Solana'
 * }
 * privateKeyAdapterParamsSchema.parse(params)
 * ```
 */
zod.z.object({
    privateKey: privateKeySchema,
    chain: solanaChainIdentifierSchema,
});
/**
 * Schema for validating provider-based adapter creation parameters.
 *
 * Used by factory methods that create adapters from wallet providers
 * across both @solana/web3.js and @solana/kit implementations.
 *
 * @example
 * ```typescript
 * import { providerAdapterParamsSchema } from '@core/adapter-solana'
 *
 * const params = {
 *   provider: window.solana,
 *   chain: 'Solana'
 * }
 * providerAdapterParamsSchema.parse(params)
 * ```
 */
zod.z.object({
    provider: solanaWalletProviderSchema,
    chain: solanaChainIdentifierSchema,
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function parseAmountSafe$1(amount) {
    try {
        return parseUnits(amount, USDC_DECIMALS$1);
    }
    catch (parseError) {
        throw createInvalidAmountError(amount, getErrorMessage(parseError));
    }
}
async function validateDepositBalance(adapter, chain, amountBigInt, operationContext, token = 'USDC') {
    const tokenAddress = getTokenAddress(chain, token);
    await validateBalanceForTransaction({
        adapter,
        amount: amountBigInt.toString(),
        token,
        tokenAddress,
        operationContext,
    });
}
function buildResult(params, txHash, chain, signerAddress) {
    const depositedTo = 'depositAccount' in params ? params.depositAccount : signerAddress;
    return {
        amount: params.amount,
        token: params.token,
        depositedTo,
        depositedBy: signerAddress,
        chain: chain.chain,
        txHash,
        explorerUrl: buildExplorerUrl(chain, txHash),
    };
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Deposit USDC into a Gateway account on a specific chain.
 *
 * Supports three EVM allowance strategies (`approve`, `permit`, `authorize`)
 * and Solana (no separate approval needed).
 *
 * For the `approve` strategy the flow is: increaseAllowance → deposit.
 * If the deposit step fails, a best-effort `approve(gateway, 0)` is issued
 * to revoke the dangling allowance before re-throwing.
 *
 * @param params - Resolved deposit parameters from the kit layer.
 * @returns The deposit confirmation including tx hash and explorer URL.
 * @throws If the chain is unsupported or the transaction fails.
 */
async function deposit(params) {
    const chain = resolveChainIdentifier(params.from.chain);
    assertGatewayV1(chain);
    const valueBigInt = parseAmountSafe$1(params.amount);
    const operationContext = extractOperationContext(params.from);
    const signerAddress = await resolveSignerAddress(params.from, chain);
    const resolvedContext = { ...operationContext, address: signerAddress };
    await validateDepositBalance(params.from.adapter, chain, valueBigInt, resolvedContext, params.token);
    await validateNativeBalanceForTransaction({
        adapter: params.from.adapter,
        operationContext: { ...resolvedContext, chain },
    });
    const tokenAddress = getTokenAddress(chain, params.token);
    const strategy = params.allowanceStrategy ?? 'authorize';
    let txHash;
    if (chain.type === 'solana') {
        txHash = await performSolanaDeposit({
            adapter: params.from.adapter,
            chain,
            amount: valueBigInt,
            token: tokenAddress,
            operationContext: resolvedContext,
        });
    }
    else {
        txHash = await performEvmDeposit({
            adapter: params.from.adapter,
            chain,
            amount: valueBigInt,
            token: tokenAddress,
            allowanceStrategy: strategy,
            operationContext: resolvedContext,
            signerAddress,
        });
    }
    return buildResult(params, txHash, chain, signerAddress);
}
/**
 * Deposit USDC into another Gateway account (not the caller's).
 *
 * Only the `approve` allowance strategy is supported for depositFor.
 * Solana deposits do not require a separate approval step.
 *
 * @param params - Resolved depositFor parameters from the kit layer.
 * @returns The deposit confirmation including tx hash and explorer URL.
 * @throws If the chain is unsupported or the transaction fails.
 */
async function depositFor(params) {
    const chain = resolveChainIdentifier(params.from.chain);
    assertGatewayV1(chain);
    assertValidAddress(params.depositAccount, chain, 'depositAccount');
    const valueBigInt = parseAmountSafe$1(params.amount);
    const operationContext = extractOperationContext(params.from);
    const signerAddress = await resolveSignerAddress(params.from, chain);
    const resolvedContext = { ...operationContext, address: signerAddress };
    await validateDepositBalance(params.from.adapter, chain, valueBigInt, resolvedContext, params.token);
    await validateNativeBalanceForTransaction({
        adapter: params.from.adapter,
        operationContext: { ...resolvedContext, chain },
    });
    const tokenAddress = getTokenAddress(chain, params.token);
    let txHash;
    if (chain.type === 'solana') {
        txHash = await performSolanaDeposit({
            adapter: params.from.adapter,
            chain,
            amount: valueBigInt,
            token: tokenAddress,
            depositAccount: params.depositAccount,
            operationContext: resolvedContext,
        });
    }
    else {
        txHash = await performEvmDeposit({
            adapter: params.from.adapter,
            chain,
            amount: valueBigInt,
            token: tokenAddress,
            allowanceStrategy: 'approve',
            depositAccount: params.depositAccount,
            operationContext: resolvedContext,
            signerAddress,
        });
    }
    return buildResult(params, txHash, chain, signerAddress);
}

/**
 * Validates that a value is a valid hex string.
 *
 * @param value - The value to validate
 * @param fieldName - Name of the field for error messages
 * @throws KitError if the value is not a valid hex string
 *
 * @example
 * ```typescript
 * validateHex('0xabcd', 'data') // passes
 * validateHex('invalid', 'data') // throws KitError
 * ```
 */
function validateHex(value, fieldName) {
    if (typeof value !== 'string') {
        throw createValidationFailedError(fieldName, value, 'must be a string');
    }
    if (!/^0x[0-9a-fA-F]+$/.test(value)) {
        throw createValidationFailedError(fieldName, value, 'must be a valid hex string (0x-prefixed)');
    }
}
/**
 * Checks whether a string is a valid EVM address (0x + 40 hex chars).
 *
 * @param value - The string to check
 * @returns `true` if the value is a valid EVM address
 */
function isEvmAddress(value) {
    return /^0x[0-9a-fA-F]{40}$/.test(value);
}
/**
 * Checks whether a string is a valid Solana base58 address (decodes to 32 bytes).
 *
 * @param value - The string to check
 * @returns `true` if the value is a valid Solana address
 */
function isSolanaAddress(value) {
    if (isEvmAddress(value) || value.startsWith('0x')) {
        return false;
    }
    try {
        convertAddress(value, 'bytes32');
        return true;
    }
    catch {
        return false;
    }
}
/**
 * Validates that a value is a valid address (EVM hex or Solana base58).
 *
 * Supports:
 * - EVM addresses: 0x-prefixed, 40 hex characters (20 bytes)
 * - Solana addresses: base58-encoded, decodes to 32 bytes
 *
 * @param value - The value to validate
 * @param fieldName - Name of the field for error messages
 * @throws KitError if the value is not a valid address
 *
 * @example
 * ```typescript
 * // EVM address
 * validateAddress('0x1234567890abcdef1234567890abcdef12345678', 'wallet') // passes
 *
 * // Solana address
 * validateAddress('GATEwdfmYNELfp5wDmmR6noSr2vHnAfBPMm2PvCzX5vu', 'wallet') // passes
 *
 * // Invalid
 * validateAddress('0x123', 'wallet') // throws KitError
 * ```
 */
function validateAddress(value, fieldName) {
    if (typeof value !== 'string') {
        throw createValidationFailedError(fieldName, value, 'must be a string');
    }
    if (!isEvmAddress(value) && !isSolanaAddress(value)) {
        throw createValidationFailedError(fieldName, value, 'must be a valid address (EVM 0x-prefixed 40 hex chars, or Solana base58)');
    }
}
/**
 * Validates that a value is a non-negative integer.
 *
 * @param value - The value to validate
 * @param fieldName - Name of the field for error messages
 * @throws KitError if the value is not a non-negative integer
 *
 * @example
 * ```typescript
 * validateDomain(0, 'sourceDomain') // passes
 * validateDomain(-1, 'sourceDomain') // throws KitError
 * validateDomain(1.5, 'sourceDomain') // throws KitError
 * ```
 */
function validateDomain(value, fieldName) {
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) {
        throw createValidationFailedError(fieldName, value, 'must be a non-negative integer');
    }
}
/**
 * Validates that a value is a positive bigint.
 *
 * @param value - The value to validate
 * @param fieldName - Name of the field for error messages
 * @throws KitError if the value is not a positive bigint
 *
 * @example
 * ```typescript
 * validatePositiveBigInt(1000000n, 'value') // passes
 * validatePositiveBigInt(0n, 'value') // throws KitError
 * validatePositiveBigInt(-1n, 'value') // throws KitError
 * ```
 */
function validatePositiveBigInt(value, fieldName) {
    if (typeof value !== 'bigint') {
        throw createValidationFailedError(fieldName, value, 'must be a bigint');
    }
    if (value <= 0n) {
        throw createValidationFailedError(fieldName, value, 'must be positive');
    }
}
/**
 * Validates that a value is a non-negative bigint (\>= 0).
 *
 * @param value - The value to validate
 * @param fieldName - Name of the field for error messages
 * @throws KitError if the value is not a non-negative bigint
 *
 * @example
 * ```typescript
 * validateNonNegativeBigInt(0n, 'maxFee') // passes
 * validateNonNegativeBigInt(1000000n, 'maxFee') // passes
 * validateNonNegativeBigInt(-1n, 'maxFee') // throws KitError
 * ```
 */
function validateNonNegativeBigInt(value, fieldName) {
    if (typeof value !== 'bigint' || value < 0n) {
        throw createValidationFailedError(fieldName, value, 'must be a non-negative bigint');
    }
}
/**
 * Generates a random 32-byte salt as a hex string.
 *
 * Uses the Web Crypto API (available in browsers and Node.js 15+).
 * Throws if no secure random source is available.
 *
 * @returns A random 32-byte hex string (0x-prefixed)
 *
 * @example
 * ```typescript
 * const salt = generateRandomSalt()
 * console.log(salt) // '0x7f3a2b1c...' (64 hex characters)
 * ```
 */
function generateRandomSalt() {
    const bytes = new Uint8Array(32);
    if (typeof globalThis.crypto?.getRandomValues !== 'function') {
        throw createValidationFailedError('crypto.getRandomValues', undefined, 'A secure random source is required for salt generation but crypto.getRandomValues is not available');
    }
    globalThis.crypto.getRandomValues(bytes);
    return `0x${Buffer.from(bytes).toString('hex')}`;
}

/**
 * Finds a chain definition by its Gateway domain ID.
 *
 * Returns `undefined` when no matching chain exists for the given
 * domain/network combination (e.g. the API returned a domain that the
 * SDK does not yet recognise). Callers should skip unknown entries
 * rather than crashing.
 *
 * @param domain - The Gateway domain ID to search for.
 * @param isTestnet - Whether to search for testnet or mainnet chains.
 * @returns The matching chain definition, or `undefined` if none found.
 *
 * @example
 * ```typescript
 * import { findChainByDomain } from '@circle-fin/provider-gateway-v1/utils'
 *
 * const chain = findChainByDomain(0, false) // Ethereum mainnet
 * const unknown = findChainByDomain(9999, false) // undefined
 * ```
 */
function findChainByDomain(domain, isTestnet) {
    return Object.values(Chains).find((c) => c.gateway?.domain === domain && c.isTestnet === isTestnet);
}

function normalizeChainsToArray(chains) {
    if (!chains)
        return undefined;
    return Array.isArray(chains) ? chains : [chains];
}
function resolveChainForAdapter(chains, adapter) {
    if (chains && chains.length > 0 && chains[0]) {
        return resolveChainIdentifier(chains[0]);
    }
    if (adapter.capabilities?.supportedChains?.[0]) {
        return adapter.capabilities.supportedChains[0];
    }
    return undefined;
}
async function normalizeAdapterSource(source) {
    const chains = normalizeChainsToArray(source.chains);
    const chainDef = resolveChainForAdapter(chains, source.adapter);
    if (!chainDef) {
        throw createValidationFailedError('source', source, 'no chains specified and adapter has no supported chains');
    }
    const isDeveloperControlled = source.adapter.capabilities?.addressContext === 'developer-controlled';
    let address;
    if (isDeveloperControlled) {
        if (!source.address) {
            throw createValidationFailedError('address', undefined, 'Address is required for developer-controlled adapters. ' +
                'Please provide: { adapter, chains, address: "0x..." }');
        }
        address = source.address;
    }
    else {
        if (source.address != null) {
            throw createValidationFailedError('address', source.address, 'Address should not be provided for user-controlled adapters. ' +
                'The address is automatically resolved from the connected wallet');
        }
        address = await source.adapter.getAddress(chainDef);
    }
    return chains ? { account: address, chains } : { account: address };
}
function normalizeAddressOnlySource(addressValue, chains) {
    return chains ? { account: addressValue, chains } : { account: addressValue };
}
async function normalizeSingleSource(source) {
    if (source.adapter != null) {
        return normalizeAdapterSource(source);
    }
    if (source.address != null) {
        return normalizeAddressOnlySource(source.address, normalizeChainsToArray(source.chains));
    }
    throw createValidationFailedError('source', source, 'must have either adapter or address');
}
async function normalizeSources(sources) {
    const sourceArray = Array.isArray(sources) ? sources : [sources];
    return Promise.all(sourceArray.map(normalizeSingleSource));
}

/**
 * Resolve the Gateway API base URL for the given network.
 *
 * @param isTestnet - `true` for the testnet Gateway API, `false` for mainnet.
 * @returns The base URL string (no trailing slash).
 */
function getGatewayApiBaseUrl(isTestnet) {
    return isTestnet ? GATEWAY_API_TESTNET_BASE_URL : GATEWAY_API_BASE_URL;
}

// ---------------------------------------------------------------------------
// Zod schemas
// ---------------------------------------------------------------------------
const gatewayDomainSchema = zod.z.object({
    chain: zod.z.string(),
    network: zod.z.string(),
    domain: zod.z.number(),
    processedHeight: zod.z.string().regex(/^\d+$/, 'processedHeight must be numeric'),
    burnIntentExpirationHeight: zod.z
        .string()
        .regex(/^\d+$/, 'burnIntentExpirationHeight must be numeric'),
    walletContract: zod.z
        .object({
        address: zod.z.string(),
        supportedTokens: zod.z.array(zod.z.string()),
    })
        .optional(),
    minterContract: zod.z
        .object({
        address: zod.z.string(),
        supportedTokens: zod.z.array(zod.z.string()),
    })
        .optional(),
});
const gatewayInfoSchema = zod.z.object({
    version: zod.z.number(),
    domains: zod.z.array(gatewayDomainSchema),
});
// ---------------------------------------------------------------------------
// Assertion (type guard for pollApiGet)
// ---------------------------------------------------------------------------
/**
 * Validate and narrow unknown data to a Gateway info response.
 *
 * @param data - Raw response from GET /v1/info.
 * @returns Type guard `true` when data matches the expected schema.
 * @throws KitError when the response shape is invalid.
 */
function assertGatewayInfoResponse(data) {
    if (typeof data === 'object' &&
        data !== null &&
        'success' in data &&
        data.success === false) {
        const message = 'message' in data &&
            typeof data.message === 'string'
            ? data.message
            : 'Unknown Gateway API failure';
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            recoverability: 'FATAL',
            message: `Gateway API error: ${message}`,
        });
    }
    const result = gatewayInfoSchema.safeParse(data);
    if (!result.success) {
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            message: `Invalid Gateway info response: ${result.error.message}`,
            recoverability: 'FATAL',
        });
    }
    return true;
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Fetch Gateway info from the `/v1/info` endpoint.
 *
 * @param isTestnet - Whether to query the testnet or mainnet API.
 * @returns Parsed Gateway info including per-domain processed heights.
 * @throws KitError on HTTP failure or invalid response.
 *
 * @example
 * ```typescript
 * const info = await fetchGatewayInfo(true)
 * console.log(info.domains.map(d => `${d.chain}: ${d.processedHeight}`))
 * ```
 */
async function fetchGatewayInfo(isTestnet) {
    const apiBaseUrl = getGatewayApiBaseUrl(isTestnet);
    const url = `${apiBaseUrl}/v1/info`;
    try {
        return await pollApiGet(url, assertGatewayInfoResponse);
    }
    catch (error) {
        if (error instanceof KitError) {
            throw error;
        }
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            recoverability: 'RETRYABLE',
            message: 'Failed to fetch Gateway info',
            cause: { trace: { rawError: error } },
        });
    }
}
/**
 * Get the processed block height for a specific Gateway domain.
 *
 * Calls `/v1/info` and extracts the `processedHeight` for the given
 * domain number. This represents the last block Gateway has indexed
 * and considers finalized.
 *
 * @param isTestnet - Whether to query the testnet or mainnet API.
 * @param domain - The Gateway domain number (e.g. 0 = Ethereum, 6 = Base).
 * @returns The processed height as a bigint.
 * @throws KitError when the domain is not found in the response.
 *
 * @example
 * ```typescript
 * const height = await getProcessedHeight(true, 6) // Base Sepolia
 * console.log(`Gateway processed up to block ${height}`)
 * ```
 */
async function getProcessedHeight(isTestnet, domain) {
    // No caching in v1 — /v1/info is cheap and delegate status checks
    // are infrequent. Revisit if rate-limit or latency issues appear.
    const info = await fetchGatewayInfo(isTestnet);
    const entry = info.domains.find((d) => d.domain === domain);
    if (!entry) {
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            recoverability: 'FATAL',
            message: `Gateway domain ${String(domain)} not found in /v1/info response`,
            cause: {
                trace: {
                    domain,
                    availableDomains: info.domains.map((d) => d.domain),
                },
            },
        });
    }
    return BigInt(entry.processedHeight);
}

/**
 * Extract the response body attached by `makeApiRequest` to HTTP error objects.
 *
 * @internal
 */
function getResponseBody(error) {
    if (typeof error === 'object' && error !== null) {
        return error.responseBody;
    }
    return undefined;
}
/**
 * Extract the `message` field from a Gateway API error response body.
 *
 * @internal
 */
function getApiMessage(body) {
    if (typeof body === 'object' &&
        body !== null &&
        'message' in body &&
        typeof body.message === 'string') {
        return body.message;
    }
    return undefined;
}
const INSUFFICIENT_BALANCE_RE = /Insufficient balance for depositor (\S+): available ([\d.]+), required ([\d.]+)/;
/**
 * Look up the source chain name for a depositor address from spend allocations.
 *
 * @internal
 */
function findSourceChainForDepositor(depositor, allocations) {
    if (!depositor || !allocations || allocations.length === 0)
        return 'Gateway';
    const match = allocations.find((a) => a.sourceDepositor.toLowerCase() === depositor.toLowerCase());
    return match?.chain.name ?? 'Gateway';
}
/**
 * Ensure a Gateway API error is always surfaced as a KitError.
 *
 * - If `error` is already a KitError it is re-thrown unchanged.
 * - Detects "Insufficient balance" responses and throws a
 *   typed `BALANCE_INSUFFICIENT_TOKEN` error with depositor,
 *   available, and required amounts in the trace. When
 *   `allocations` are provided the error includes the actual
 *   source chain name instead of the generic "Gateway".
 * - Otherwise the error is wrapped in a KitError with
 *   `NetworkError.GATEWAY_API_ERROR`.
 *
 * @param error - The caught error value.
 * @param allocations - Optional spend allocations used to resolve
 *   depositor addresses to source chain names.
 * @returns never — always throws.
 * @internal
 */
function throwGatewayApiError(error, allocations) {
    if (error instanceof KitError) {
        throw error;
    }
    const message = error instanceof Error ? error.message : 'Unknown Gateway API failure';
    const responseBody = getResponseBody(error);
    const apiMessage = getApiMessage(responseBody);
    if (apiMessage) {
        const matches = [
            ...apiMessage.matchAll(new RegExp(INSUFFICIENT_BALANCE_RE.source, 'g')),
        ];
        if (matches.length > 0) {
            const shortfalls = matches.map((m) => ({
                depositor: m[1] ?? '',
                available: m[2] ?? '',
                required: m[3] ?? '',
                chain: findSourceChainForDepositor(m[1], allocations),
            }));
            if (shortfalls.length === 1) {
                const [s] = shortfalls;
                if (s) {
                    throw new KitError({
                        ...BalanceError.INSUFFICIENT_TOKEN,
                        recoverability: 'FATAL',
                        message: `Insufficient USDC balance on ${s.chain}. ` +
                            `Available: ${s.available} USDC, required: ${s.required} USDC`,
                        cause: {
                            trace: {
                                depositor: s.depositor,
                                available: s.available,
                                required: s.required,
                                rawMessage: apiMessage,
                                chain: s.chain,
                                token: 'USDC',
                            },
                        },
                    });
                }
            }
            const chainList = shortfalls.map((s) => s.chain).join(', ');
            const summary = shortfalls
                .map((s) => `${s.chain}: available ${s.available} USDC, required ${s.required} USDC`)
                .join('; ');
            throw new KitError({
                ...BalanceError.INSUFFICIENT_TOKEN,
                recoverability: 'FATAL',
                message: `Insufficient USDC balance on ${chainList}. ${summary}`,
                cause: {
                    trace: {
                        shortfalls,
                        rawMessage: apiMessage,
                        chain: chainList,
                        token: 'USDC',
                    },
                },
            });
        }
    }
    const detail = apiMessage ??
        (responseBody == null ? undefined : JSON.stringify(responseBody));
    const fullMessage = detail
        ? `Gateway API error: ${message} — ${detail}`
        : `Gateway API error: ${message}`;
    throw new KitError({
        ...NetworkError.GATEWAY_API_ERROR,
        recoverability: 'FATAL',
        message: fullMessage,
        cause: { trace: { originalError: message, responseBody } },
    });
}

/** Zod schemas and inferred types for Gateway v1 estimate and transfer API responses. */
const numericStringSchema = zod.z
    .string()
    .regex(/^\d+$/, 'Expected a non-negative integer string');
const burnIntentResponseSchema = zod.z.object({
    maxBlockHeight: numericStringSchema,
    maxFee: numericStringSchema,
    spec: zod.z.object({
        version: zod.z.number(),
        sourceDomain: zod.z.number(),
        destinationDomain: zod.z.number(),
        sourceContract: zod.z.string(),
        destinationContract: zod.z.string(),
        sourceToken: zod.z.string(),
        destinationToken: zod.z.string(),
        sourceDepositor: zod.z.string(),
        destinationRecipient: zod.z.string(),
        sourceSigner: zod.z.string(),
        destinationCaller: zod.z.string(),
        value: zod.z.string(),
        salt: zod.z.string(),
        hookData: zod.z.string().optional(),
    }),
});
/** Schema for the fee summary returned by estimate and transfer endpoints. */
const feeSummarySchema = zod.z.object({
    total: zod.z.string(),
    token: zod.z.string(),
    perIntent: zod.z.array(zod.z.record(zod.z.unknown())),
    forwardingFee: zod.z.string().optional(),
});
const estimateEntrySchema = zod.z.object({
    burnIntentSet: zod.z
        .object({
        intents: zod.z.array(burnIntentResponseSchema),
    })
        .optional(),
    burnIntent: burnIntentResponseSchema.optional(),
});
/** Schema for the normal POST /v1/estimate response (array of entries). */
const gatewayEstimateResponseSchema = zod.z.array(estimateEntrySchema);
/**
 * Schema for the POST /v1/estimate?enableForwarder=true response.
 * The API wraps the normal array in `{ body, fees }`.
 */
const gatewayForwarderEstimateResponseSchema = zod.z.object({
    body: zod.z.array(estimateEntrySchema),
    fees: feeSummarySchema,
});
/** Schema for POST /v1/transfer response (attestation + signature). */
const gatewayTransferResponseSchema = zod.z.object({
    attestation: zod.z.string().optional(),
    signature: zod.z.string().optional(),
    transferId: zod.z.string().optional(),
    fees: feeSummarySchema.optional(),
    expirationBlock: numericStringSchema.optional(),
});
/** Schema for the burn-intent summary returned inside GET /v1/transfer/{id}. */
const burnIntentSummarySchema = zod.z.object({
    transferSpecHash: zod.z.string(),
    maxBlockHeight: zod.z.string(),
    maxFee: zod.z.string(),
});
/** Schema for GET /v1/transfer/{id} response (transfer details). */
const gatewayTransferDetailsSchema = zod.z.object({
    destinationDomain: zod.z.number().optional(),
    status: zod.z.enum(['pending', 'confirmed', 'finalized', 'failed', 'expired']),
    burnIntents: zod.z.array(burnIntentSummarySchema).optional(),
    transactionHash: zod.z.string().optional(),
    forwardingDetails: zod.z
        .object({
        forwardingEnabled: zod.z.boolean(),
        failureReason: zod.z.string().optional(),
    })
        .optional(),
    fees: feeSummarySchema.optional(),
    attestation: zod.z
        .object({
        payload: zod.z.string(),
        signature: zod.z.string(),
        expirationBlock: zod.z.string(),
    })
        .optional(),
});

const RETRYABLE_PATTERN = /rate limit|too many requests|timeout|timed out|server error|service unavailable|internal error/i;
function classifyGatewayApiError(message) {
    if (RETRYABLE_PATTERN.test(message)) {
        return {
            errorBase: NetworkError.GATEWAY_API_ERROR,
            recoverability: 'RETRYABLE',
        };
    }
    return { errorBase: InputError.VALIDATION_FAILED, recoverability: 'FATAL' };
}
function throwGatewayApiErrorIfPresent(data) {
    const errorResponse = data;
    if (errorResponse.success === false && errorResponse.message) {
        const { errorBase, recoverability } = classifyGatewayApiError(errorResponse.message);
        throw new KitError({
            ...errorBase,
            message: `Gateway API error: ${errorResponse.message}`,
            recoverability,
        });
    }
}
/**
 * Validate and narrow unknown data to Gateway estimate API response shape.
 *
 * @param data - Raw response from POST /v1/estimate.
 * @returns Type guard true when data is a valid GatewayEstimateResponse.
 * @throws KitError When API returns success: false or schema validation fails.
 */
function assertGatewayEstimateResponse(data) {
    throwGatewayApiErrorIfPresent(data);
    const result = gatewayEstimateResponseSchema.safeParse(data);
    if (!result.success) {
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            message: `Invalid Gateway estimate response: ${result.error.message}`,
            recoverability: 'RETRYABLE',
        });
    }
    return true;
}
/**
 * Validate and narrow unknown data to Gateway forwarder estimate response.
 *
 * When `enableForwarder=true`, the API returns `{ body: [...], fees: {...} }`
 * instead of a plain array.
 *
 * @param data - Raw response from POST /v1/estimate?enableForwarder=true.
 * @returns Type guard true when data is a valid GatewayForwarderEstimateResponse.
 * @throws KitError When API returns success: false or schema validation fails.
 */
function assertGatewayForwarderEstimateResponse(data) {
    throwGatewayApiErrorIfPresent(data);
    const result = gatewayForwarderEstimateResponseSchema.safeParse(data);
    if (!result.success) {
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            message: `Invalid Gateway forwarder estimate response: ${result.error.message}`,
            recoverability: 'RETRYABLE',
        });
    }
    return true;
}
/**
 * Validate and narrow unknown data to Gateway transfer API response shape.
 *
 * @param data - Raw response from POST /v1/transfer.
 * @returns Type guard true when data is a valid GatewayTransferResponse.
 * @throws KitError When API returns success: false or schema validation fails.
 */
function assertGatewayTransferResponse(data) {
    throwGatewayApiErrorIfPresent(data);
    const result = gatewayTransferResponseSchema.safeParse(data);
    if (!result.success) {
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            message: `Invalid Gateway transfer response: ${result.error.message}`,
            recoverability: 'RETRYABLE',
        });
    }
    return true;
}
/**
 * Validate and narrow unknown data to Gateway transfer details response shape.
 *
 * @param data - Raw response from GET /v1/transfer/{id}.
 * @returns Type guard true when data is a valid GatewayTransferDetails.
 * @throws KitError When schema validation fails.
 */
function assertGatewayTransferDetails(data) {
    throwGatewayApiErrorIfPresent(data);
    const result = gatewayTransferDetailsSchema.safeParse(data);
    if (!result.success) {
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            message: `Invalid Gateway transfer details response: ${result.error.message}`,
            recoverability: 'RETRYABLE',
        });
    }
    return true;
}

/** Normalize `from` param to an array of sources. */
function normalizeFromParam(fromParam) {
    if (Array.isArray(fromParam))
        return fromParam;
    if (fromParam)
        return [fromParam];
    return [];
}
/** Resolve the chain to use for address resolution from a source. */
function getChainForAddressFromSource(source) {
    const firstOrOnly = Array.isArray(source.allocations)
        ? source.allocations[0]
        : source.allocations;
    return firstOrOnly?.chain;
}
/** Append normalized allocations for a single source into the result array. */
function pushNormalizedAllocationsForSource(source, depositor, signerAddress, result) {
    const allocs = Array.isArray(source.allocations)
        ? source.allocations
        : [source.allocations];
    for (const alloc of allocs) {
        if (!alloc)
            continue;
        const chain = resolveChainIdentifier(alloc.chain);
        assertGatewayV1(chain);
        result.push({
            adapter: source.adapter,
            chain: chain,
            amount: parseUnits(alloc.amount, USDC_DECIMALS$1),
            sourceDepositor: depositor,
            sourceSigner: signerAddress,
        });
    }
}
function throwNetworkMismatch(expected, actual) {
    throw createNetworkMismatchError(expected, actual);
}
/**
 * Ensure all allocations and the destination chain share the same network (mainnet or testnet).
 *
 * @param allocations - Normalized allocations from spend sources.
 * @param destChain - The destination chain definition.
 * @throws When any allocation or destination mixes mainnet and testnet.
 */
function assertNetworkCompatibility(allocations, destChain) {
    const first = allocations[0];
    if (!first || allocations.length === 0)
        return;
    const firstTestnet = first.chain.isTestnet;
    for (let i = 1; i < allocations.length; i++) {
        const alloc = allocations[i];
        if (alloc && alloc.chain.isTestnet !== firstTestnet) {
            throwNetworkMismatch(first.chain, alloc.chain);
        }
    }
    if (destChain.isTestnet !== firstTestnet) {
        throwNetworkMismatch(first.chain, destChain);
    }
}
/**
 * Resolve spend params into a list of normalized allocations (adapter, chain, amount, signer).
 *
 * @typeParam TFromAdapterCapabilities - Source adapter capabilities.
 * @typeParam TToAdapterCapabilities - Destination adapter capabilities.
 * @param params - Spend parameters containing `from` (single source or array).
 * @returns Promise of normalized allocations for intent building.
 */
async function normalizeAllocations(params) {
    const sources = normalizeFromParam(params.from);
    const nested = await Promise.all(sources.map(async (source) => {
        if (!source)
            return [];
        const chainForAddress = getChainForAddressFromSource(source);
        if (!chainForAddress)
            return [];
        const chain = resolveChainIdentifier(chainForAddress);
        const adapterCtx = {
            adapter: source.adapter,
            chain,
            ...('address' in source && source.address
                ? { address: source.address }
                : {}),
        };
        const signerAddress = await resolveSignerAddress(adapterCtx, chain);
        const depositor = source.sourceAccount ?? signerAddress;
        const allocs = [];
        pushNormalizedAllocationsForSource(source, depositor, signerAddress, allocs);
        return allocs;
    }));
    return nested.flat();
}
/**
 * Resolve an auto-allocation result into three buckets of normalized allocations.
 *
 * @param autoAllocResult - The result from computeAutoAllocation.
 * @param sources - The original spend sources (used to resolve signers via sourceIndex).
 * @returns Promise of normalized allocations grouped by intent type.
 */
async function normalizeAutoAllocations(autoAllocResult, sources) {
    // Cache resolved signers by sourceIndex to avoid redundant RPC calls.
    // Keyed by sourceIndex alone because each source maps to a single adapter
    // and ecosystem — an EVM adapter returns the same address for all EVM chains.
    // If multi-ecosystem sources are introduced, this cache key must include chain.
    const signerCache = new Map();
    async function resolveSigner(sourceIndex, chain) {
        const cached = signerCache.get(sourceIndex);
        if (cached)
            return cached;
        const promise = (async () => {
            const source = sources[sourceIndex];
            if (!source) {
                throw createValidationFailedError('sourceIndex', sourceIndex, `Source not found at index ${String(sourceIndex)}`);
            }
            const adapterCtx = {
                adapter: source.adapter,
                chain,
                ...('address' in source && source.address
                    ? { address: source.address }
                    : {}),
            };
            const signerAddress = await resolveSignerAddress(adapterCtx, chain);
            const depositor = source.sourceAccount ?? signerAddress;
            return { signerAddress, depositor };
        })();
        signerCache.set(sourceIndex, promise);
        return promise;
    }
    async function normalizeBucket(taggedAllocs) {
        const normalized = await Promise.all(taggedAllocs.map(async (alloc) => {
            const chain = resolveChainIdentifier(alloc.chain);
            assertGatewayV1(chain);
            const source = sources[alloc.sourceIndex];
            if (!source) {
                throw createValidationFailedError('sourceIndex', alloc.sourceIndex, `Source not found at index ${String(alloc.sourceIndex)}`);
            }
            const { signerAddress, depositor } = await resolveSigner(alloc.sourceIndex, chain);
            return {
                adapter: source.adapter,
                chain,
                amount: parseUnits(alloc.amount, USDC_DECIMALS$1),
                sourceDepositor: depositor,
                sourceSigner: signerAddress,
            };
        }));
        return normalized;
    }
    const [user, devFee, circleFee] = await Promise.all([
        normalizeBucket(autoAllocResult.allocations),
        normalizeBucket(autoAllocResult.developerFeeAllocations),
        normalizeBucket(autoAllocResult.circleFeeAllocations),
    ]);
    return { user, devFee, circleFee };
}
/**
 * Group intents by adapter and chain for signing (Solana one-per-intent, EVM batched by adapter).
 *
 * @param intents - Burn intents from estimate response.
 * @param allocations - Normalized allocations used to map domain → adapter/chain.
 * @returns Array of groups, each with adapter, chain, and intents to sign.
 */
function groupIntentsByAdapter(intents, allocations) {
    const evmGroups = new Map();
    const solanaGroups = [];
    for (const intent of intents) {
        const alloc = allocations.find((a) => a.chain.gateway.domain === intent.spec.sourceDomain);
        if (!alloc) {
            throw createValidationFailedError('intent.spec.sourceDomain', intent.spec.sourceDomain, `No allocation found for sourceDomain ${String(intent.spec.sourceDomain)}; ` +
                'estimate response contains an intent that does not match any allocation');
        }
        if (alloc.chain.type === 'solana') {
            solanaGroups.push(groupSolanaIntents(intent, alloc));
        }
        else {
            groupEvmIntents(intent, alloc, evmGroups);
        }
    }
    return [...evmGroups.values(), ...solanaGroups];
}

/**
 * Converts an address (EVM hex or Solana base58) to bytes32 hex format.
 *
 * @param address - The address in native chain format
 * @returns The address in bytes32 hex format
 */
function toBytes32(address) {
    return convertAddress(address, 'bytes32');
}
/**
 * Creates a structured burn intent object for Gateway cross-chain transfers.
 *
 * This function builds a complete burn intent with all required fields,
 * applying sensible defaults where optional parameters are not provided.
 * Address fields are converted to bytes32 hex format during creation.
 *
 * The resulting object can be used with:
 * - `evmSigningData` for EIP-712 signing (EVM sources)
 * - `encodeBurnIntentForSolana` for binary encoding (Solana sources)
 *
 * @param params - Parameters for creating the burn intent
 * @returns A complete BurnIntent object with addresses in bytes32 format
 * @throws KitError if required parameters are missing or invalid
 *
 * @example
 * ```typescript
 * // EVM source
 * const evmIntent = createBurnIntent({
 *   sourceDomain: 0,        // Ethereum
 *   destinationDomain: 6,   // Base
 *   sourceContract: '0x0077777d7EBA4688BDeF3E311b846F25870A19B9',
 *   destinationContract: '0x0022222ABE238Cc2C7Bb1f21003F0a260052475B',
 *   sourceToken: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
 *   destinationToken: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
 *   sourceDepositor: '0xYourAddress...',
 *   value: 1_000_000n,
 * })
 *
 * // Solana source
 * const solanaIntent = createBurnIntent({
 *   sourceDomain: 5,        // Solana
 *   destinationDomain: 6,   // Base
 *   sourceContract: 'GATEwdfmYNELfp5wDmmR6noSr2vHnAfBPMm2PvCzX5vu',
 *   destinationContract: '0x0022222ABE238Cc2C7Bb1f21003F0a260052475B',
 *   sourceToken: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
 *   destinationToken: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
 *   sourceDepositor: 'YourSolanaPublicKey...',
 *   value: 1_000_000n,
 * })
 * ```
 */
function createBurnIntent(params) {
    // Validate required parameters
    validateDomain(params.sourceDomain, 'sourceDomain');
    validateDomain(params.destinationDomain, 'destinationDomain');
    validateAddress(params.sourceContract, 'sourceContract');
    validateAddress(params.destinationContract, 'destinationContract');
    validateAddress(params.sourceToken, 'sourceToken');
    validateAddress(params.destinationToken, 'destinationToken');
    validateAddress(params.sourceDepositor, 'sourceDepositor');
    validatePositiveBigInt(params.value, 'value');
    // Validate optional address parameters if provided
    if (params.destinationRecipient !== undefined) {
        validateAddress(params.destinationRecipient, 'destinationRecipient');
    }
    if (params.sourceSigner !== undefined) {
        validateAddress(params.sourceSigner, 'sourceSigner');
    }
    if (params.destinationCaller !== undefined) {
        validateAddress(params.destinationCaller, 'destinationCaller');
    }
    if (params.hookData !== undefined) {
        validateHex(params.hookData, 'hookData');
    }
    // Validate optional bigint parameters if provided
    if (params.maxFee !== undefined) {
        validateNonNegativeBigInt(params.maxFee, 'maxFee');
    }
    if (params.maxBlockHeight !== undefined) {
        validateNonNegativeBigInt(params.maxBlockHeight, 'maxBlockHeight');
    }
    // Determine if the source chain is Solana (base58 addresses)
    const isSolanaSource = detectFormat(params.sourceContract) === 'solana';
    // Default maxBlockHeight: max uint64 for Solana, max uint256 for EVM
    const defaultMaxBlockHeight = isSolanaSource ? MAX_UINT64 : MAX_UINT256;
    // Convert all addresses to bytes32 hex format at creation time.
    // This normalization ensures the BurnIntent works with both
    // evmSigningData (EIP-712) and encodeBurnIntentForSolana (binary).
    const destinationCallerBytes32 = params.destinationCaller
        ? toBytes32(params.destinationCaller)
        : ZERO_BYTES32;
    return {
        maxBlockHeight: params.maxBlockHeight ?? defaultMaxBlockHeight,
        maxFee: params.maxFee ?? DEFAULT_MAX_FEE,
        spec: {
            version: 1,
            sourceDomain: params.sourceDomain,
            destinationDomain: params.destinationDomain,
            sourceContract: toBytes32(params.sourceContract),
            destinationContract: toBytes32(params.destinationContract),
            sourceToken: toBytes32(params.sourceToken),
            destinationToken: toBytes32(params.destinationToken),
            sourceDepositor: toBytes32(params.sourceDepositor),
            destinationRecipient: toBytes32(params.destinationRecipient ?? params.sourceDepositor),
            sourceSigner: toBytes32(params.sourceSigner ?? params.sourceDepositor),
            destinationCaller: destinationCallerBytes32,
            value: params.value,
            salt: generateRandomSalt(),
            hookData: params.hookData ?? '0x',
        },
    };
}

const DEPRIORITIZED_FEE_CHAINS = new Set([
    Blockchain.Ethereum,
    Blockchain.Ethereum_Sepolia,
]);
function bigintMin(a, b) {
    return a < b ? a : b;
}
function sortByAmountDesc(a, b) {
    if (b.amount > a.amount)
        return 1;
    if (b.amount < a.amount)
        return -1;
    return 0;
}
/**
 * Allocate a fee total across sources, preferring non-Ethereum chains.
 *
 * Non-Ethereum sources are drained first (largest amount first), then
 * Ethereum sources are used only if needed. This avoids incurring
 * Ethereum gas fees for dev/Circle fee burn intents when cheaper
 * chains are available.
 *
 * Each allocation is keyed by its original array index so that multiple
 * allocations on the same chain are tracked independently.
 *
 * @param allocations - Per-chain amounts (chain name + bigint amount).
 * @param feeTotal - Total fee to allocate in atomic units.
 * @returns Map keyed by allocation index to userValue and feeValue.
 *
 * @example
 * ```typescript
 * const map = allocateFeeAcrossSources(
 *   [{ chain: 'Ethereum', amount: 100n }, { chain: 'Base', amount: 50n }],
 *   40n
 * )
 * expect(map.get(1)).toEqual({ userValue: 10n, feeValue: 40n })
 * expect(map.get(0)).toEqual({ userValue: 100n, feeValue: 0n })
 * ```
 */
function allocateFeeAcrossSources(allocations, feeTotal) {
    const indexed = allocations.map((alloc, idx) => ({ ...alloc, idx }));
    const preferred = indexed.filter((a) => !DEPRIORITIZED_FEE_CHAINS.has(a.chain));
    const deprioritized = indexed.filter((a) => DEPRIORITIZED_FEE_CHAINS.has(a.chain));
    preferred.sort(sortByAmountDesc);
    deprioritized.sort(sortByAmountDesc);
    const sorted = [...preferred, ...deprioritized];
    let feeRemaining = feeTotal;
    const result = new Map();
    for (const alloc of sorted) {
        if (feeRemaining <= 0n)
            break;
        const feeFromThis = bigintMin(feeRemaining, alloc.amount);
        result.set(alloc.idx, {
            userValue: alloc.amount - feeFromThis,
            feeValue: feeFromThis,
        });
        feeRemaining -= feeFromThis;
    }
    for (const alloc of indexed) {
        if (!result.has(alloc.idx)) {
            result.set(alloc.idx, { userValue: alloc.amount, feeValue: 0n });
        }
    }
    return result;
}
/**
 * Compute the proportional share of totalPortion for one source (sourceContribution / feeTotal).
 *
 * @param totalPortion - The total to split (e.g. dev share).
 * @param sourceContribution - This source's contribution to the fee.
 * @param feeTotal - Total fee across all sources.
 * @returns Proportional share in atomic units (rounded down).
 *
 * @example
 * ```typescript
 * expect(splitProportional(100n, 50n, 100n)).toBe(50n)
 * ```
 */
function splitProportional(totalPortion, sourceContribution, feeTotal) {
    if (feeTotal === 0n)
        return 0n;
    return (totalPortion * sourceContribution) / feeTotal;
}
/**
 * Split a fee total into Circle's share (by basis points) and the remainder (dev share).
 *
 * Uses the standard BPS divisor of 10 000.  `circleBps` is always a whole
 * number, so no scaling is needed.
 *
 * @param feeTotal - Total fee in atomic units.
 * @param circleBps - Circle's share in basis points (e.g. 1000 = 10%).
 * @returns Object with circleShare and devShare in atomic units.
 *
 * @example
 * ```typescript
 * const { circleShare, devShare } = splitFeeByBps(1_000_000n, 1000)
 * // circleShare 100_000n (10%), devShare 900_000n (90%)
 * ```
 */
function splitFeeByBps(feeTotal, circleBps) {
    if (!Number.isInteger(circleBps) || circleBps < 0 || circleBps > 10000) {
        throw createValidationFailedError('circleBps', circleBps, `circleBps must be an integer between 0 and 10000, got ${String(circleBps)}`);
    }
    const circleShare = feeTotal > 0n ? (feeTotal * BigInt(circleBps)) / 10000n : 0n;
    const devShare = feeTotal > 0n ? feeTotal - circleShare : 0n;
    return { circleShare, devShare };
}

/** Resolve recipient to ATA for Solana; pass-through for EVM. */
function toSolanaRecipient(walletAddress, destChain, token) {
    if (destChain.type !== 'solana')
        return walletAddress;
    const tokenMintAddress = getTokenAddress(destChain, token);
    return resolveRecipientAta(walletAddress, tokenMintAddress);
}
/** Build a single burn intent from a normalized allocation and destination. */
function createBurnIntentFromAlloc(alloc, destChain, token, destinationRecipient, value) {
    return createBurnIntent({
        sourceDomain: alloc.chain.gateway.domain,
        destinationDomain: destChain.gateway.domain,
        sourceContract: alloc.chain.gateway.contracts.v1.wallet,
        destinationContract: destChain.gateway.contracts.v1.minter,
        sourceToken: getTokenAddress(alloc.chain, token),
        destinationToken: getTokenAddress(destChain, token),
        sourceDepositor: alloc.sourceDepositor,
        sourceSigner: alloc.sourceSigner,
        destinationRecipient,
        value,
    });
}
/** Allocate fee total across sources (largest first); returns map of userValue and feeValue per allocation index. */
function getFeeMap(allocsForFee, feeTotal) {
    if (feeTotal <= 0n) {
        return new Map();
    }
    return allocateFeeAcrossSources(allocsForFee, feeTotal);
}
/** Append one user burn intent when userValue is positive. */
function pushUserBurnIntentIfPositive(alloc, destChain, token, resolvedRecipient, userValue, intents) {
    if (userValue <= 0n)
        return;
    intents.push(createBurnIntentFromAlloc(alloc, destChain, token, resolvedRecipient, userValue));
}
/** Circle fee recipient address for the destination chain (EVM vs Solana). */
function getCircleFeeRecipientAddress(destChain) {
    return destChain.gateway.domain === SOLANA_GATEWAY_DOMAIN
        ? getSolanaFeeRecipient()
        : CIRCLE_FEE_RECIPIENT_EVM;
}
/** Append dev and Circle fee intents for one allocation when fee is present. */
function pushCustomFeeIntentsForAlloc(alloc, feeEntry, ctx, intents) {
    if (!feeEntry || feeEntry.feeValue <= 0n || !ctx.resolvedFeeRecipient) {
        return;
    }
    const devFromThis = splitProportional(ctx.devShare, feeEntry.feeValue, ctx.feeTotal);
    const circleFromThis = feeEntry.feeValue - devFromThis;
    if (devFromThis > 0n) {
        intents.push(createBurnIntentFromAlloc(alloc, ctx.destChain, ctx.token, ctx.resolvedFeeRecipient, devFromThis));
    }
    if (circleFromThis > 0n) {
        const circleAddress = getCircleFeeRecipientAddress(ctx.destChain);
        const circleFeeRecipient = toSolanaRecipient(circleAddress, ctx.destChain, ctx.token);
        intents.push(createBurnIntentFromAlloc(alloc, ctx.destChain, ctx.token, circleFeeRecipient, circleFromThis));
    }
}
/**
 * Build the list of burn intents for a spend (user + optional custom fee split).
 *
 * Resolves recipient (ATA for Solana), allocates fee across sources, and creates
 * intents for user value and for dev/Circle fee portions per allocation.
 *
 * @param allocations - Normalized allocations from spend params.
 * @param destChain - Destination chain with Gateway v1 config.
 * @param recipientAddress - Final recipient (wallet or ATA).
 * @param token - Token (e.g. USDC).
 * @param customFee - Optional custom fee value and recipient.
 * @param circleBps - Circle share of fee in basis points (default 1000 = 10%).
 * @returns Promise of burn intents ready for estimate API.
 *
 * @example
 * ```typescript
 * import { buildBurnIntents } from './buildBurnIntents'
 * const intents = buildBurnIntents(allocations, destChain, recipient, 'USDC', customFee)
 * ```
 */
function buildBurnIntents(allocations, destChain, recipientAddress, token, customFee, circleBps = 1000) {
    const intents = [];
    const resolvedRecipient = toSolanaRecipient(recipientAddress, destChain, token);
    const resolvedFeeRecipient = customFee
        ? toSolanaRecipient(customFee.recipientAddress, destChain, token)
        : undefined;
    const feeTotal = customFee ? parseUnits(customFee.value, USDC_DECIMALS$1) : 0n;
    const allocsForFee = allocations.map((a) => ({
        chain: a.chain.name,
        amount: a.amount,
    }));
    const feeMap = getFeeMap(allocsForFee, feeTotal);
    const { devShare } = splitFeeByBps(feeTotal, circleBps);
    for (const [i, alloc] of allocations.entries()) {
        const feeEntry = feeMap.get(i);
        const userValue = feeEntry ? feeEntry.userValue : alloc.amount;
        pushUserBurnIntentIfPositive(alloc, destChain, token, resolvedRecipient, userValue, intents);
        pushCustomFeeIntentsForAlloc(alloc, feeEntry, {
            destChain,
            token,
            feeTotal,
            devShare,
            resolvedFeeRecipient,
        }, intents);
    }
    return intents;
}
/**
 * Build the list of burn intents for an auto-allocated spend.
 *
 * Maps the pre-computed user, dev fee, and Circle fee allocations
 * 1:1 to their respective burn intents.
 *
 * @param allocations - Normalized auto-allocations grouped by intent type.
 * @param destChain - Destination chain with Gateway v1 config.
 * @param recipientAddress - Final recipient (wallet or ATA).
 * @param token - Token (e.g. USDC).
 * @param customFee - Optional custom fee value and recipient.
 * @returns Promise of burn intents ready for estimate API.
 *
 * @internal
 */
function buildAutoAllocatedBurnIntents(allocations, destChain, recipientAddress, token, customFee) {
    const intents = [];
    const resolvedUserRecipient = toSolanaRecipient(recipientAddress, destChain, token);
    const resolvedDevFeeRecipient = customFee
        ? toSolanaRecipient(customFee.recipientAddress, destChain, token)
        : undefined;
    const circleAddress = getCircleFeeRecipientAddress(destChain);
    const resolvedCircleFeeRecipient = toSolanaRecipient(circleAddress, destChain, token);
    for (const alloc of allocations.user) {
        if (alloc.amount <= 0n)
            continue;
        intents.push(createBurnIntentFromAlloc(alloc, destChain, token, resolvedUserRecipient, alloc.amount));
    }
    if (resolvedDevFeeRecipient) {
        for (const alloc of allocations.devFee) {
            if (alloc.amount <= 0n)
                continue;
            intents.push(createBurnIntentFromAlloc(alloc, destChain, token, resolvedDevFeeRecipient, alloc.amount));
        }
    }
    for (const alloc of allocations.circleFee) {
        if (alloc.amount <= 0n)
            continue;
        intents.push(createBurnIntentFromAlloc(alloc, destChain, token, resolvedCircleFeeRecipient, alloc.amount));
    }
    return intents;
}

/**
 * Create a structured error for amount operation failures.
 *
 * @remarks
 * Returns a `KitError` with `INPUT_INVALID_AMOUNT` code (1002).
 * The error trace contains the reason and context for debugging.
 *
 * @param reason - The specific error reason.
 * @param message - Human-readable error description.
 * @param context - Additional context about the error (optional).
 * @param cause - The underlying error, if any (optional).
 * @returns A KitError with INPUT type and FATAL recoverability.
 *
 * @example
 * ```typescript
 * throw createAmountError(
 *   'DECIMAL_MISMATCH',
 *   'Cannot add amounts with different decimals',
 *   { leftDecimals: 6, rightDecimals: 18 }
 * )
 * ```
 *
 * @example
 * ```typescript
 * throw createAmountError(
 *   'PARSE_ERROR',
 *   'Amount.parse: input contains non-numeric characters',
 *   { input: '12.34.56' }
 * )
 * ```
 */
function createAmountError(reason, message, context, cause) {
    const trace = { reason };
    if (context !== undefined) {
        trace.context = context;
    }
    return new KitError({
        ...InputError.INVALID_AMOUNT,
        recoverability: 'FATAL',
        message,
        cause: { trace },
    });
}

/**
 * Internal helpers for the Amount system.
 *
 * @remarks
 * This module contains utilities shared across Amount operations but not
 * intended for public consumption. These helpers handle:
 *
 * - Scale factor caching for efficient decimal conversions
 * - Input validation for decimal precision
 * - Decimal consistency checks between Amount operands
 *
 * The scale cache prevents repeated BigInt exponentiation operations,
 * which can be costly for high-decimal tokens like ETH (18 decimals).
 *
 * @internal
 * @packageDocumentation
 */
// ============================================================================
// Constants
// ============================================================================
/**
 * Maximum supported decimal precision.
 *
 * @remarks
 * Set to 77 because `10n ** 77n` is the largest power of 10 that fits within
 * a 256-bit unsigned integer (`2n ** 256n - 1n`), which is the standard word
 * size for EVM smart contracts. This is well beyond any practical token
 * decimal requirement (ETH uses 18, most stablecoins 6).
 */
const MAX_DECIMALS = 77;
/**
 * Cache for scale multipliers to avoid repeated BigInt exponentiation.
 *
 * @remarks
 * Maps decimal count → 10^decimals. Populated lazily on first access
 * for each decimal value. Thread-safe in single-threaded JS environments.
 */
const scaleCache = new Map();
// ============================================================================
// Scale Helpers
// ============================================================================
/**
 * Get the scale multiplier for a given number of decimals.
 *
 * @param decimals - The decimal precision (0 to MAX_DECIMALS).
 * @returns The scale factor (10^decimals).
 * @throws KitError If decimals is out of valid range.
 *
 * @remarks
 * Results are cached to avoid repeated BigInt exponentiation. The cache
 * is bounded by MAX_DECIMALS, so memory usage is predictable.
 *
 * @example
 * ```typescript
 * getScale(6)  // 1_000_000n
 * getScale(18) // 1_000_000_000_000_000_000n
 * ```
 */
function getScale(decimals) {
    // Validate range before cache lookup
    if (decimals < 0 || decimals > MAX_DECIMALS) {
        throw createAmountError('INVALID_DECIMALS', `Decimals must be between 0 and ${String(MAX_DECIMALS)}, got ${String(decimals)}`, { decimals });
    }
    // Check cache first
    let scale = scaleCache.get(decimals);
    if (scale === undefined) {
        // Compute and cache for future use
        scale = 10n ** BigInt(decimals);
        scaleCache.set(decimals, scale);
    }
    return scale;
}
// ============================================================================
// Validation Helpers
// ============================================================================
/**
 * Validate that decimals are within acceptable range.
 *
 * @param decimals - The decimal value to validate.
 * @param context - The calling function name for error messages.
 * @throws KitError If decimals is not a valid integer in range.
 *
 * @remarks
 * Ensures decimals is:
 * - An integer (not a float)
 * - Non-negative
 * - At most MAX_DECIMALS
 *
 * @example
 * ```typescript
 * validateDecimals(6, 'Amt.of')     // OK
 * validateDecimals(-1, 'Amt.parse') // throws INVALID_DECIMALS
 * validateDecimals(1.5, 'Amt.of')   // throws INVALID_DECIMALS
 * ```
 */
function validateDecimals(decimals, context) {
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > MAX_DECIMALS) {
        throw createAmountError('INVALID_DECIMALS', `${context}: decimals must be an integer between 0 and ${String(MAX_DECIMALS)}, got ${String(decimals)}`, { decimals, context });
    }
}
/**
 * Assert that two amounts have the same decimal precision.
 *
 * @param a - The first Amount.
 * @param b - The second Amount.
 * @param operation - The operation name for error messages.
 * @throws KitError If decimals differ.
 *
 * @remarks
 * Operations like add/sub/compare require matching decimals to ensure
 * meaningful results. This function provides a consistent error message
 * format across all such operations.
 *
 * @example
 * ```typescript
 * const usdc = { raw: 1_000_000n, decimals: 6 }
 * const eth = { raw: 1n, decimals: 18 }
 *
 * assertSameDecimals(usdc, usdc, 'Amt.add') // OK
 * assertSameDecimals(usdc, eth, 'Amt.add')  // throws DECIMAL_MISMATCH
 * ```
 */
function assertSameDecimals(a, b, operation) {
    if (a.decimals !== b.decimals) {
        throw createAmountError('DECIMAL_MISMATCH', `${operation}: cannot operate on amounts with different decimals ` +
            `(${String(a.decimals)} vs ${String(b.decimals)})`, { aDecimals: a.decimals, bDecimals: b.decimals, operation });
    }
}
/**
 * Assert that a config's decimals matches an Amount's decimals when both are provided.
 *
 * @param inputDecimals - The decimal precision of the input Amount.
 * @param configDecimals - The decimal precision specified in config (may be undefined).
 * @param context - The calling function name for error messages.
 * @throws KitError If both are defined and don't match.
 *
 * @remarks
 * Used by Amount.from to validate that when an Amount-like input is provided
 * with explicit config, the decimals are consistent.
 *
 * @example
 * ```typescript
 * assertDecimalConfig(6, 6, 'Amount.from')   // OK - matches
 * assertDecimalConfig(6, undefined, 'Amount.from') // OK - no config
 * assertDecimalConfig(6, 18, 'Amount.from')  // throws DECIMAL_MISMATCH
 * ```
 */
function assertDecimalConfig(inputDecimals, configDecimals, context) {
    if (configDecimals !== undefined && configDecimals !== inputDecimals) {
        throw createAmountError('DECIMAL_MISMATCH', `${context}: Amount has ${String(inputDecimals)} decimals but ` +
            `config specifies ${String(configDecimals)}`, { inputDecimals, configDecimals });
    }
}

/**
 * Parse a human-readable string or number into raw amount data.
 *
 * @param input - The input to parse (e.g., "100.50", ".5", "1000", or 100.5).
 * @param options - Parse options including decimals.
 * @param ctx - Context for error messages.
 * @returns Parsed amount data with raw bigint and decimals.
 * @throws KitError If input is invalid or parsing fails.
 *
 * @example
 * ```typescript
 * parse('100.50', { decimals: 6 }, 'test')
 * // { raw: 100_500_000n, decimals: 6 }
 *
 * parse('1', { decimals: 6 }, 'test')
 * // { raw: 1_000_000n, decimals: 6 }
 *
 * // Inputs starting with decimal point are supported
 * parse('.5', { decimals: 6 }, 'test')
 * // { raw: 500_000n, decimals: 6 }
 * ```
 */
function parse(input, options, ctx) {
    // Validate decimals first
    validateDecimals(options.decimals, ctx);
    const { decimals, allowNegative = false } = options;
    // Convert number to string (warning: potential precision loss)
    const str = typeof input === 'number' ? input.toString() : input;
    // Basic validation - must be non-empty string
    if (typeof str !== 'string' || str.trim() === '') {
        throw createAmountError('PARSE_ERROR', `${ctx}: input must be a non-empty string or number`, { input });
    }
    // Normalize: trim whitespace
    let normalized = str.trim();
    // Handle negative sign
    const isNegative = normalized.startsWith('-');
    if (isNegative) {
        if (!allowNegative) {
            throw createAmountError('NEGATIVE_NOT_ALLOWED', `${ctx}: negative values not allowed`, { input });
        }
        normalized = normalized.slice(1);
    }
    // Normalize leading zeros (but preserve "0" and "0.xxx")
    if (normalized.length > 1 &&
        normalized.startsWith('0') &&
        normalized[1] !== '.') {
        normalized = normalized.replace(/^0+/, '') || '0';
    }
    // Split into integer and decimal parts
    const parts = normalized.split('.');
    if (parts.length > 2) {
        throw createAmountError('PARSE_ERROR', `${ctx}: invalid number format (multiple decimal points)`, { input });
    }
    let integerPart = parts[0] ?? '';
    const decimalPart = parts[1] ?? '';
    // Handle inputs starting with decimal point (e.g., ".5" → "0.5")
    if (integerPart === '' && decimalPart !== '') {
        integerPart = '0';
    }
    // Validate parts contain only digits
    if (!/^\d+$/.test(integerPart) ||
        (decimalPart && !/^\d+$/.test(decimalPart))) {
        throw createAmountError('PARSE_ERROR', `${ctx}: input contains non-numeric characters`, { input });
    }
    // Truncate decimal part to allowed precision and pad if needed
    const truncatedDecimal = decimalPart.slice(0, decimals).padEnd(decimals, '0');
    // Combine and convert to bigint
    const rawString = integerPart + truncatedDecimal;
    let raw = BigInt(rawString);
    // Apply negative sign if present
    if (isNegative) {
        raw = -raw;
    }
    return { raw, decimals };
}

/**
 * Compare two amount values.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns -1 if a is less than b, 0 if equal, 1 if a is greater than b.
 * @throws KitError If decimals don't match.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 500_000n, decimals: 6 }
 * compare(a, b, 'test') // 1 (a > b)
 * ```
 */
function compare(a, b, ctx) {
    assertSameDecimals(a, b, ctx);
    if (a.raw < b.raw)
        return -1;
    if (a.raw > b.raw)
        return 1;
    return 0;
}
/**
 * Check if two amounts are equal.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if raw values are equal.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * eq(a, a, 'test') // true
 * ```
 */
function eq(a, b, ctx) {
    return compare(a, b, ctx) === 0;
}
/**
 * Check if a is less than b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is less than b.
 *
 * @example
 * ```typescript
 * const a = { raw: 500_000n, decimals: 6 }
 * const b = { raw: 1_000_000n, decimals: 6 }
 * lt(a, b, 'test') // true
 * ```
 */
function lt(a, b, ctx) {
    return compare(a, b, ctx) === -1;
}
/**
 * Check if a is less than or equal to b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is less than or equal to b.
 *
 * @example
 * ```typescript
 * const a = { raw: 500_000n, decimals: 6 }
 * lte(a, a, 'test') // true
 * ```
 */
function lte(a, b, ctx) {
    return compare(a, b, ctx) <= 0;
}
/**
 * Check if a is greater than b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is greater than b.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 500_000n, decimals: 6 }
 * gt(a, b, 'test') // true
 * ```
 */
function gt(a, b, ctx) {
    return compare(a, b, ctx) === 1;
}
/**
 * Check if a is greater than or equal to b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is greater than or equal to b.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * gte(a, a, 'test') // true
 * ```
 */
function gte(a, b, ctx) {
    return compare(a, b, ctx) >= 0;
}

/**
 * Math operations for Amount values.
 *
 * @remarks
 * This module provides arithmetic operations that operate on AmountFields.
 * Binary operations (add, sub) require matching decimal precision.
 * Scalar operations (mul, div) use fixed-point math for number multipliers.
 *
 * @packageDocumentation
 */
/**
 * Fixed-point precision for number multiplication/division.
 * Using 10^18 provides sufficient precision for most token operations.
 */
const PRECISION = 10n ** 18n;
/**
 * Add two amount values.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns The sum with preserved decimals.
 * @throws KitError If decimals don't match.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 500_000n, decimals: 6 }
 * add(a, b, 'test') // { raw: 1_500_000n, decimals: 6 }
 * ```
 */
function add(a, b, ctx) {
    assertSameDecimals(a, b, ctx);
    return {
        raw: a.raw + b.raw,
        decimals: a.decimals,
    };
}
/**
 * Subtract one amount from another.
 *
 * @param a - The amount to subtract from.
 * @param b - The amount to subtract.
 * @param ctx - Context for error messages.
 * @returns The difference with preserved decimals.
 * @throws KitError If decimals don't match.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 300_000n, decimals: 6 }
 * sub(a, b, 'test') // { raw: 700_000n, decimals: 6 }
 * ```
 */
function sub(a, b, ctx) {
    assertSameDecimals(a, b, ctx);
    return {
        raw: a.raw - b.raw,
        decimals: a.decimals,
    };
}
/**
 * Multiply an amount by a scalar.
 *
 * @param amount - The amount to multiply.
 * @param multiplier - The scalar (bigint for exact, number for approximate).
 * @returns The product with preserved decimals.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * mul(a, 2n)   // { raw: 2_000_000n, decimals: 6 }
 * mul(a, 0.5) // { raw: 500_000n, decimals: 6 }
 * ```
 */
function mul(amount, multiplier) {
    let raw;
    if (typeof multiplier === 'bigint') {
        // Exact multiplication for bigint
        raw = amount.raw * multiplier;
    }
    else {
        // Fixed-point math for number multipliers.
        // Note: Precision is limited to ~15-17 significant digits (JavaScript Number limit).
        // For exact precision with large or high-precision multipliers, use bigint instead.
        // Use Math.round for better precision (avoids systematic bias from truncation).
        const multiplierBigInt = BigInt(Math.round(multiplier * Number(PRECISION)));
        raw = (amount.raw * multiplierBigInt) / PRECISION;
    }
    return {
        raw,
        decimals: amount.decimals,
    };
}
/**
 * Divide an amount by a scalar.
 *
 * @param amount - The amount to divide.
 * @param divisor - The scalar divisor (bigint or number).
 * @param ctx - Context for error messages.
 * @returns The quotient (truncated) with preserved decimals.
 * @throws KitError If divisor is zero.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * div(a, 2n, 'test')   // { raw: 500_000n, decimals: 6 }
 * div(a, 2.5, 'test') // { raw: 400_000n, decimals: 6 }
 * ```
 */
function div(amount, divisor, ctx) {
    let raw;
    if (typeof divisor === 'bigint') {
        if (divisor === 0n) {
            throw createAmountError('INVALID_INPUT', `${ctx}: division by zero`);
        }
        raw = amount.raw / divisor;
    }
    else {
        if (divisor === 0) {
            throw createAmountError('INVALID_INPUT', `${ctx}: division by zero`);
        }
        // Fixed-point math for number divisors
        // Use Math.round for better precision (avoids systematic bias from truncation).
        const divisorBigInt = BigInt(Math.round(divisor * Number(PRECISION)));
        raw = (amount.raw * PRECISION) / divisorBigInt;
    }
    return {
        raw,
        decimals: amount.decimals,
    };
}
/**
 * Get the absolute value of an amount.
 *
 * @param amount - The amount.
 * @returns The absolute value with preserved decimals.
 *
 * @example
 * ```typescript
 * const a = { raw: -1_000_000n, decimals: 6 }
 * abs(a) // { raw: 1_000_000n, decimals: 6 }
 * ```
 */
function abs(amount) {
    return {
        raw: amount.raw < 0n ? -amount.raw : amount.raw,
        decimals: amount.decimals,
    };
}
/**
 * Negate an amount.
 *
 * @param amount - The amount.
 * @returns The negated value with preserved decimals.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * neg(a) // { raw: -1_000_000n, decimals: 6 }
 * ```
 */
function neg(amount) {
    return {
        raw: -amount.raw,
        decimals: amount.decimals,
    };
}

/**
 * Remove trailing zeros from a decimal string, keeping at least minDigits.
 *
 * @param str - The decimal string to trim.
 * @param minDigits - Minimum digits to keep.
 * @returns The trimmed string.
 */
function trimTrailingZeros(str, minDigits) {
    let end = str.length;
    while (end > minDigits && str[end - 1] === '0') {
        end--;
    }
    return str.slice(0, end);
}
/**
 * Format an amount as a human-readable string.
 *
 * @param amount - The amount to format.
 * @param options - Formatting options.
 * @returns A human-readable string (e.g., "1,000.50").
 *
 * @example
 * ```typescript
 * const a = { raw: 1_500_000n, decimals: 6 }
 * formatted(a)                              // "1.5"
 * formatted(a, { minimumFractionDigits: 2 }) // "1.50"
 * formatted(a, { useGrouping: false })      // "1.5"
 * ```
 */
function formatted(amount, options = {}) {
    const { locale = 'en-US', minimumFractionDigits = 0, maximumFractionDigits = amount.decimals, useGrouping = true, } = options;
    // Validate that minimumFractionDigits does not exceed maximumFractionDigits
    if (minimumFractionDigits > maximumFractionDigits) {
        throw new RangeError(`minimumFractionDigits (${String(minimumFractionDigits)}) cannot be ` +
            `greater than maximumFractionDigits (${String(maximumFractionDigits)})`);
    }
    // Get scale for splitting integer and decimal parts
    const scale = getScale(amount.decimals);
    // Handle negative values
    const isNegative = amount.raw < 0n;
    const absRaw = isNegative ? -amount.raw : amount.raw;
    // Split into integer and decimal parts using bigint division
    const integerPart = absRaw / scale;
    const decimalPart = absRaw % scale;
    // Format integer with locale grouping
    const formattedInteger = useGrouping
        ? integerPart.toLocaleString(locale)
        : integerPart.toString();
    // Format decimal part
    let formattedDecimal = '';
    if (maximumFractionDigits > 0) {
        // Pad decimal part to full precision
        const fullDecimal = decimalPart.toString().padStart(amount.decimals, '0');
        // Truncate to max digits
        let trimmed = fullDecimal.slice(0, maximumFractionDigits);
        // Trim trailing zeros (but keep minimumFractionDigits)
        if (minimumFractionDigits < trimmed.length) {
            trimmed = trimTrailingZeros(trimmed, minimumFractionDigits);
        }
        // Add decimal point if there's content
        if (trimmed.length > 0) {
            formattedDecimal = '.' + trimmed;
        }
    }
    // Note: The branch for maximumFractionDigits <= 0 && minimumFractionDigits > 0
    // is unreachable due to validation at the start of the function.
    return (isNegative ? '-' : '') + formattedInteger + formattedDecimal;
}
/**
 * Convert an amount to a human-readable string.
 *
 * @param amount - The amount to convert.
 * @returns A formatted string like "1.5".
 *
 * @remarks
 * This is equivalent to calling `formatted()` with default options.
 * For display with a token symbol, combine with the token registry:
 * ```typescript
 * `${amount.toString()} ${token.symbol}`
 * ```
 *
 * @example
 * ```typescript
 * const a = { raw: 1_500_000n, decimals: 6 }
 * toString(a) // "1.5"
 * ```
 */
function toString(amount) {
    return formatted(amount);
}
/**
 * Convert an amount to a JSON-serializable object.
 *
 * @param amount - The amount to convert.
 * @returns An object with raw (as string), decimals, and formatted value.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_500_000n, decimals: 6 }
 * toJSON(a)
 * // { raw: "1500000", decimals: 6, formatted: "1.5" }
 * ```
 */
function toJSON(amount) {
    return {
        raw: amount.raw.toString(),
        decimals: amount.decimals,
        formatted: formatted(amount),
    };
}

/**
 * Conversion operations for Amount values.
 *
 * @remarks
 * This module provides conversion functions for changing decimal precision.
 *
 * @packageDocumentation
 */
/**
 * Convert an amount to a different decimal precision.
 *
 * @param amount - The amount to convert.
 * @param newDecimals - The target decimal precision.
 * @param ctx - Context for error messages.
 * @returns Converted amount data with adjusted raw value and new decimals.
 * @throws KitError If newDecimals is invalid.
 *
 * @example
 * ```typescript
 * // Increase precision (6 → 18)
 * const usdc = { raw: 1_000_000n, decimals: 6 }
 * toDecimals(usdc, 18, 'test')
 * // { raw: 1_000_000_000_000_000_000n, decimals: 18 }
 *
 * // Decrease precision (18 → 6)
 * const eth = { raw: 1_000_000_000_000_000_000n, decimals: 18 }
 * toDecimals(eth, 6, 'test')
 * // { raw: 1_000_000n, decimals: 6 }
 * ```
 */
function toDecimals(amount, newDecimals, ctx) {
    validateDecimals(newDecimals, ctx);
    // Same precision - return copy with same values
    if (amount.decimals === newDecimals) {
        return {
            raw: amount.raw,
            decimals: amount.decimals,
        };
    }
    let raw;
    if (newDecimals > amount.decimals) {
        // Increasing precision - multiply by scale difference
        const scaleDiff = getScale(newDecimals - amount.decimals);
        raw = amount.raw * scaleDiff;
    }
    else {
        // Decreasing precision - divide by scale difference (truncates)
        const scaleDiff = getScale(amount.decimals - newDecimals);
        raw = amount.raw / scaleDiff;
    }
    return {
        raw,
        decimals: newDecimals,
    };
}

// ============================================================================
// Amount Class
// ============================================================================
/**
 * An immutable token amount with fluent API methods.
 *
 * @remarks
 * The `Amount` class provides a type-safe, ergonomic way to work with token
 * amounts. It combines the raw bigint value with decimal precision and
 * provides chainable methods for:
 *
 * - **Math operations**: add, sub, mul, div, abs, neg
 * - **Comparisons**: eq, lt, lte, gt, gte, cmp, min, max
 * - **Predicates**: isZero, isPositive, isNegative
 * - **Formatting**: formatted, toString, toJSON
 * - **Conversion**: toDecimals
 *
 * All operations return new Amount instances - the class is immutable.
 *
 * Token identity (symbol) is intentionally excluded. Source token metadata
 * from the token registry for display purposes.
 */
class Amount {
    /** The raw value in smallest units (e.g., wei for ETH, micro-units for USDC). */
    raw;
    /** Number of decimal places for this token. */
    decimals;
    // ==========================================================================
    // Constructor (private - use static factories)
    // ==========================================================================
    constructor(raw, decimals) {
        this.raw = raw;
        this.decimals = decimals;
        Object.freeze(this);
    }
    // ==========================================================================
    // Static Factory Methods
    // ==========================================================================
    /**
     * Create an Amount from a raw bigint value.
     *
     * @param raw - The raw value in smallest units.
     * @param config - Configuration with decimals.
     * @returns A new immutable Amount instance.
     * @throws KitError If raw is not a bigint or decimals is invalid.
     *
     * @example
     * ```typescript
     * // Get decimals from token registry
     * const amount = Amount.of(1_000_000n, { decimals: 6 })
     * ```
     */
    static of(raw, config) {
        validateDecimals(config.decimals, 'Amount.of');
        if (typeof raw !== 'bigint') {
            throw createAmountError('INVALID_INPUT', `Amount.of: expected bigint, got ${typeof raw}`, { input: raw });
        }
        return new Amount(raw, config.decimals);
    }
    /**
     * Parse a human-readable string or number into an Amount.
     *
     * @param input - The input to parse (e.g., "100.50" or 100.5).
     * @param options - Parse options including decimals.
     * @returns A new immutable Amount instance.
     * @throws KitError If input is invalid or parsing fails.
     *
     * @example
     * ```typescript
     * const amount = Amount.parse('100.50', { decimals: 6 })
     * ```
     */
    static parse(input, options) {
        const result = parse(input, options, 'Amount.parse');
        return new Amount(result.raw, result.decimals);
    }
    /**
     * Convert any AmountLike value to an Amount.
     *
     * @param input - The input (bigint, string, number, or existing Amount).
     * @param config - Configuration (required for non-Amount inputs).
     * @returns A new immutable Amount instance.
     * @throws KitError If conversion fails or config is missing.
     *
     * @remarks
     * When providing a `number` input, very large or small values may be
     * converted to exponential notation (e.g., `1e21`), which is not supported.
     * For such values, provide a `string` representation instead.
     *
     * @example
     * ```typescript
     * Amount.from(1_000_000n, { decimals: 6 })  // from bigint
     * Amount.from('1.00', { decimals: 6 })      // from string
     * Amount.from(existingAmount)               // pass-through
     * ```
     */
    static from(input, config) {
        // Already an Amount instance - return directly
        if (input instanceof Amount) {
            assertDecimalConfig(input.decimals, config?.decimals, 'Amount.from');
            return input;
        }
        // Plain Amount-like object (e.g., from JSON deserialization)
        if (Amount.isAmount(input)) {
            assertDecimalConfig(input.decimals, config?.decimals, 'Amount.from');
            return new Amount(input.raw, input.decimals);
        }
        // Config is required for non-Amount inputs
        if (config === undefined) {
            throw createAmountError('INVALID_INPUT', 'Amount.from: config with decimals is required for non-Amount inputs', { input });
        }
        // Route to appropriate factory
        if (typeof input === 'bigint') {
            return Amount.of(input, config);
        }
        return Amount.parse(input, config);
    }
    /**
     * Create a zero Amount with the given configuration.
     *
     * @param config - Configuration with decimals.
     * @returns A zero Amount instance.
     *
     * @example
     * ```typescript
     * const zero = Amount.zero({ decimals: 6 })
     * ```
     */
    static zero(config) {
        return Amount.of(0n, config);
    }
    /**
     * Check if a value is an Amount-like object.
     *
     * @param value - The value to check.
     * @returns True if the value has Amount shape (raw: bigint, decimals: number).
     *
     * @example
     * ```typescript
     * Amount.isAmount({ raw: 1000000n, decimals: 6 }) // true
     * Amount.isAmount({ value: 100 })                 // false
     * ```
     */
    static isAmount(value) {
        return (typeof value === 'object' &&
            value !== null &&
            'raw' in value &&
            typeof value.raw === 'bigint' &&
            'decimals' in value &&
            typeof value.decimals === 'number');
    }
    /**
     * Sum an array of Amounts.
     *
     * @param amounts - The amounts to sum (must have same decimals).
     * @returns A new Amount with the total sum.
     * @throws KitError If amounts array is empty or decimals don't match.
     *
     * @example
     * ```typescript
     * const fee1 = Amount.parse('0.10', { decimals: 6 })
     * const fee2 = Amount.parse('0.25', { decimals: 6 })
     * const fee3 = Amount.parse('0.15', { decimals: 6 })
     *
     * const total = Amount.sum([fee1, fee2, fee3])
     * total.toString() // "0.5"
     * ```
     */
    static sum(amounts) {
        // Extract first element with proper type narrowing
        const first = amounts[0];
        if (first === undefined) {
            throw createAmountError('INVALID_INPUT', 'Amount.sum: cannot sum an empty array');
        }
        // Single element - return directly (preserves immutability semantics)
        if (amounts.length === 1) {
            return first;
        }
        // Sum remaining amounts using reduce, validating decimal consistency
        const totalRaw = amounts.slice(1).reduce((sum, amount, index) => {
            if (amount.decimals !== first.decimals) {
                throw createAmountError('DECIMAL_MISMATCH', `Amount.sum: all amounts must have the same decimals ` +
                    `(expected ${String(first.decimals)}, got ${String(amount.decimals)} at index ${String(index + 1)})`, { expectedDecimals: first.decimals, actualDecimals: amount.decimals });
            }
            return sum + amount.raw;
        }, first.raw);
        return new Amount(totalRaw, first.decimals);
    }
    /**
     * Deserialize an Amount from a JSON object.
     *
     * @param json - The JSON object (e.g., from `JSON.parse()`).
     * @returns A new Amount instance.
     * @throws KitError If the JSON structure is invalid.
     *
     * @example
     * ```typescript
     * const json = JSON.parse('{"raw":"1500000","decimals":6}')
     * const amount = Amount.fromJSON(json)
     * ```
     */
    static fromJSON(json) {
        // Runtime validation since input may come from JSON.parse()
        if (typeof json !== 'object' ||
            json === null ||
            !('raw' in json) ||
            typeof json.raw !== 'string' ||
            !('decimals' in json) ||
            typeof json.decimals !== 'number') {
            throw createAmountError('INVALID_INPUT', 'Amount.fromJSON: invalid JSON structure', { json });
        }
        const { raw, decimals } = json;
        return Amount.of(BigInt(raw), { decimals });
    }
    // ==========================================================================
    // Comparison Methods
    // ==========================================================================
    /**
     * Compare this Amount with another.
     *
     * @param other - The Amount to compare with.
     * @returns -1 if this is less than other, 0 if equal, 1 if this is greater.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * const b = Amount.parse('2.0', { decimals: 6 })
     * a.compare(b) // -1
     * ```
     */
    compare(other) {
        return compare(this, other, 'Amount.compare');
    }
    /**
     * Check if this Amount equals another.
     *
     * @param other - The Amount to compare with.
     * @returns True if the raw values are equal.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * const b = Amount.parse('1.5', { decimals: 6 })
     * a.eq(b) // true
     * ```
     */
    eq(other) {
        return eq(this, other, 'Amount.eq');
    }
    /**
     * Check if this Amount is less than another.
     *
     * @param other - The Amount to compare with.
     * @returns True if this.raw is less than other.raw.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.0', { decimals: 6 })
     * const b = Amount.parse('2.0', { decimals: 6 })
     * a.lt(b) // true
     * ```
     */
    lt(other) {
        return lt(this, other, 'Amount.lt');
    }
    /**
     * Check if this Amount is less than or equal to another.
     *
     * @param other - The Amount to compare with.
     * @returns True if this.raw is less than or equal to other.raw.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * const b = Amount.parse('1.5', { decimals: 6 })
     * a.lte(b) // true
     * ```
     */
    lte(other) {
        return lte(this, other, 'Amount.lte');
    }
    /**
     * Check if this Amount is greater than another.
     *
     * @param other - The Amount to compare with.
     * @returns True if this.raw is greater than other.raw.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('2.0', { decimals: 6 })
     * const b = Amount.parse('1.0', { decimals: 6 })
     * a.gt(b) // true
     * ```
     */
    gt(other) {
        return gt(this, other, 'Amount.gt');
    }
    /**
     * Check if this Amount is greater than or equal to another.
     *
     * @param other - The Amount to compare with.
     * @returns True if this.raw is greater than or equal to other.raw.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('2.0', { decimals: 6 })
     * const b = Amount.parse('2.0', { decimals: 6 })
     * a.gte(b) // true
     * ```
     */
    gte(other) {
        return gte(this, other, 'Amount.gte');
    }
    /**
     * Return the minimum of this Amount and another.
     *
     * @param other - The Amount to compare with.
     * @returns The smaller of the two amounts.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.0', { decimals: 6 })
     * const b = Amount.parse('2.0', { decimals: 6 })
     * a.min(b).toString() // "1"
     * ```
     */
    min(other) {
        return this.lt(other) ? this : other;
    }
    /**
     * Return the maximum of this Amount and another.
     *
     * @param other - The Amount to compare with.
     * @returns The larger of the two amounts.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.0', { decimals: 6 })
     * const b = Amount.parse('2.0', { decimals: 6 })
     * a.max(b).toString() // "2"
     * ```
     */
    max(other) {
        return this.gt(other) ? this : other;
    }
    // ==========================================================================
    // Math Methods
    // ==========================================================================
    /**
     * Add another Amount to this one.
     *
     * @param other - The Amount to add.
     * @returns A new Amount with the sum.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * const b = Amount.parse('0.5', { decimals: 6 })
     * a.add(b).toString() // "2"
     * ```
     */
    add(other) {
        const result = add(this, other, 'Amount.add');
        return new Amount(result.raw, result.decimals);
    }
    /**
     * Subtract another Amount from this one.
     *
     * @param other - The Amount to subtract.
     * @returns A new Amount with the difference.
     * @throws KitError If amounts have different decimals.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('2.0', { decimals: 6 })
     * const b = Amount.parse('0.5', { decimals: 6 })
     * a.sub(b).toString() // "1.5"
     * ```
     */
    sub(other) {
        const result = sub(this, other, 'Amount.sub');
        return new Amount(result.raw, result.decimals);
    }
    /**
     * Multiply this Amount by a scalar.
     *
     * @param multiplier - The scalar to multiply by (bigint or integer number).
     * @returns A new Amount with the product.
     *
     * @remarks
     * When using a `number` as a multiplier, precision is limited by standard
     * JavaScript floating-point capabilities (~15-17 significant digits). For
     * high-precision calculations, provide the multiplier as a `bigint`.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * a.mul(2n).toString() // "3"
     * a.mul(3).toString()  // "4.5"
     * ```
     */
    mul(multiplier) {
        const result = mul(this, multiplier);
        return new Amount(result.raw, result.decimals);
    }
    /**
     * Divide this Amount by a scalar.
     *
     * @param divisor - The scalar to divide by (bigint or integer number).
     * @returns A new Amount with the quotient (integer division).
     * @throws KitError If divisor is zero.
     *
     * @remarks
     * When using a `number` as a divisor, precision is limited by standard
     * JavaScript floating-point capabilities (~15-17 significant digits). For
     * high-precision calculations, provide the divisor as a `bigint`.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('6.0', { decimals: 6 })
     * a.div(2n).toString() // "3"
     * a.div(4).toString()  // "1.5"
     * ```
     */
    div(divisor) {
        const result = div(this, divisor, 'Amount.div');
        return new Amount(result.raw, result.decimals);
    }
    /**
     * Get the absolute value of this Amount.
     *
     * @returns A new Amount with the absolute value.
     *
     * @example
     * ```typescript
     * const a = Amount.of(-1_500_000n, { decimals: 6 })
     * a.abs().toString() // "1.5"
     * ```
     */
    abs() {
        const result = abs(this);
        return new Amount(result.raw, result.decimals);
    }
    /**
     * Negate this Amount.
     *
     * @returns A new Amount with the negated value.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * a.neg().raw // -1_500_000n
     * ```
     */
    neg() {
        const result = neg(this);
        return new Amount(result.raw, result.decimals);
    }
    // ==========================================================================
    // Predicate Methods
    // ==========================================================================
    /**
     * Check if this Amount is zero.
     *
     * @returns True if the raw value is 0n.
     *
     * @example
     * ```typescript
     * Amount.zero({ decimals: 6 }).isZero() // true
     * Amount.parse('0.001', { decimals: 6 }).isZero() // false
     * ```
     */
    isZero() {
        return this.raw === 0n;
    }
    /**
     * Check if this Amount is positive.
     *
     * @returns True if the raw value is greater than 0n.
     *
     * @example
     * ```typescript
     * Amount.parse('1.0', { decimals: 6 }).isPositive() // true
     * Amount.zero({ decimals: 6 }).isPositive() // false
     * ```
     */
    isPositive() {
        return this.raw > 0n;
    }
    /**
     * Check if this Amount is negative.
     *
     * @returns True if the raw value is less than 0n.
     *
     * @example
     * ```typescript
     * Amount.of(-1_000_000n, { decimals: 6 }).isNegative() // true
     * Amount.parse('1.0', { decimals: 6 }).isNegative() // false
     * ```
     */
    isNegative() {
        return this.raw < 0n;
    }
    // ==========================================================================
    // Conversion Methods
    // ==========================================================================
    /**
     * Convert this Amount to a different decimal precision.
     *
     * @param newDecimals - The target number of decimal places.
     * @returns A new Amount with adjusted precision (or this if same precision).
     * @throws KitError If newDecimals is invalid.
     *
     * @example
     * ```typescript
     * // Scale up: 6 decimals → 18 decimals
     * const usdc = Amount.parse('1.5', { decimals: 6 })
     * const scaled = usdc.toDecimals(18)
     * scaled.raw // 1_500_000_000_000_000_000n
     *
     * // Scale down: 18 decimals → 6 decimals (truncates)
     * const eth = Amount.of(1_500_000_000_000_000_000n, { decimals: 18 })
     * eth.toDecimals(6).raw // 1_500_000n
     * ```
     */
    toDecimals(newDecimals) {
        // Same precision - return this for immutability
        if (this.decimals === newDecimals) {
            return this;
        }
        const result = toDecimals(this, newDecimals, 'Amount.toDecimals');
        return new Amount(result.raw, result.decimals);
    }
    // ==========================================================================
    // Formatting Methods
    // ==========================================================================
    /**
     * Format this Amount as a human-readable string.
     *
     * @param options - Formatting options (locale, fraction digits, grouping).
     * @returns A formatted string (e.g., "1,000.50").
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1000.5', { decimals: 6 })
     * a.formatted()                              // "1,000.5"
     * a.formatted({ minimumFractionDigits: 2 }) // "1,000.50"
     * a.formatted({ useGrouping: false })       // "1000.5"
     * ```
     */
    formatted(options = {}) {
        return formatted(this, options);
    }
    /**
     * Convert to a human-readable string.
     *
     * @returns A formatted string like "1.5".
     *
     * @remarks
     * For display with a token symbol, combine with the token registry:
     * ```typescript
     * `${amount.toString()} ${token.symbol}`
     * ```
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * a.toString() // "1.5"
     * ```
     */
    toString() {
        return toString(this);
    }
    /**
     * Convert to a JSON-serializable object.
     *
     * @returns An object with raw (as string), decimals, and formatted value.
     *
     * @example
     * ```typescript
     * const a = Amount.parse('1.5', { decimals: 6 })
     * a.toJSON()
     * // { raw: "1500000", decimals: 6, formatted: "1.5" }
     * ```
     */
    toJSON() {
        return toJSON(this);
    }
}

/**
 * Transfer speed options for cross-chain operations.
 *
 * Defines the available speed modes for CCTPv2 transfers, affecting
 * both transfer time and potential fee implications.
 */
var TransferSpeed;
(function (TransferSpeed) {
    /** Fast burn mode - reduces transfer time but may have different fee implications */
    TransferSpeed["FAST"] = "FAST";
    /** Standard burn mode - normal transfer time with standard fees */
    TransferSpeed["SLOW"] = "SLOW";
})(TransferSpeed || (TransferSpeed = {}));

/**
 * Factory to validate a numeric string with strict dot-decimal notation.
 * Only accepts dot (.) as the decimal separator. Thousand separators are not allowed.
 *
 * This enforces an unambiguous format for SDK inputs. Internationalization concerns
 * (comma vs dot decimal separators) should be handled in the UI layer before passing
 * values to the SDK.
 *
 * Accepts the following formats:
 * - Whole numbers: "1", "100", "1000"
 * - Leading zero decimals: "0.1", "0.5", "0.001"
 * - Shorthand decimals: ".1", ".5", ".001"
 * - Standard decimals: "1.23", "100.50"
 *
 * Does NOT accept:
 * - Comma decimal separator: "1,5" (use "1.5" instead)
 * - Thousand separators: "1,000.50" or "1.000,50" (use "1000.50" instead)
 * - Multiple decimal points: "1.2.3"
 * - Negative numbers: "-100"
 * - Non-numeric characters: "abc", "100a"
 *
 * Behavior differences controlled by options:
 * - allowZero: when false, value must be strictly greater than 0; when true, non-negative.
 * - regexMessage: error message when the basic numeric format fails.
 * - maxDecimals: maximum number of decimal places allowed (e.g., 6 for USDC).
 */
const createDecimalStringValidator = (options) => (schema) => {
    // Capitalize first letter of attribute name for error messages
    const capitalizedAttributeName = options.attributeName.charAt(0).toUpperCase() +
        options.attributeName.slice(1);
    return schema
        .regex(/^-?(?:\d+(?:\.\d+)?|\.\d+)$/, options.regexMessage)
        .superRefine((val, ctx) => {
        const amount = Number.parseFloat(val);
        if (Number.isNaN(amount)) {
            ctx.addIssue({
                code: zod.z.ZodIssueCode.custom,
                message: options.regexMessage,
            });
            return;
        }
        // Check decimal precision if maxDecimals is specified
        if (options.maxDecimals !== undefined) {
            const decimalPart = val.split('.')[1];
            if (decimalPart && decimalPart.length > options.maxDecimals) {
                ctx.addIssue({
                    code: zod.z.ZodIssueCode.custom,
                    message: `Maximum supported decimal places: ${options.maxDecimals.toString()}`,
                });
                return;
            }
        }
        if (options.allowZero && amount < 0) {
            ctx.addIssue({
                code: zod.z.ZodIssueCode.custom,
                message: `${capitalizedAttributeName} must be non-negative`,
            });
        }
        else if (!options.allowZero && amount <= 0) {
            ctx.addIssue({
                code: zod.z.ZodIssueCode.custom,
                message: `${capitalizedAttributeName} must be greater than 0`,
            });
        }
    });
};
/**
 * Schema for validating chain definitions.
 * This ensures the basic structure of a chain definition is valid.
 * A chain definition must include at minimum a name and type.
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { chainDefinitionSchema } from '@core/provider'
 *
 * const validChain = {
 *   name: 'Ethereum',
 *   type: 'evm'
 * }
 *
 * const result = chainDefinitionSchema.safeParse(validChain)
 * console.log(result.success) // true
 * ```
 */
const chainDefinitionSchema = zod.z.object({
    name: zod.z.string().min(1, 'Chain name is required'),
    type: zod.z.string().min(1, 'Chain type is required'),
});
/**
 * Schema for validating wallet contexts.
 * This ensures all required fields are present and properly typed.
 * A wallet context must include:
 * - A valid adapter with prepare and execute methods
 * - A valid Ethereum address
 * - A valid chain definition with required properties
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { walletContextSchema } from '@core/provider'
 *
 * const validContext = {
 *   adapter: {
 *     prepare: () => Promise.resolve({}),
 *     waitForTransaction: () => Promise.resolve({})
 *   },
 *   address: '0x1234567890123456789012345678901234567890',
 *   chain: {
 *     name: 'Ethereum',
 *     type: 'evm',
 *     isTestnet: false
 *   }
 * }
 *
 * const result = walletContextSchema.safeParse(validContext)
 * console.log(result.success) // true
 * ```
 */
const walletContextSchema = zod.z.object({
    adapter: zod.z.object({
        prepare: zod.z.function().returns(zod.z.any()),
        waitForTransaction: zod.z.function().returns(zod.z.any()),
    }),
    address: zod.z.string().min(1),
    chain: zod.z.object({
        name: zod.z.string(),
        type: zod.z.string(),
        isTestnet: zod.z.boolean(),
    }),
});
/**
 * Schema for validating destination wallet contexts.
 * Extends walletContextSchema with optional useForwarder flag.
 *
 * @throws KitError if validation fails
 */
const destinationContextSchema = walletContextSchema.extend({
    useForwarder: zod.z.boolean().optional(),
    recipientAddress: zod.z.string().optional(),
});
/**
 * Schema for validating forwarder-only destination contexts.
 * Used when useForwarder is true and no adapter is provided.
 * Requires chain definition and recipientAddress.
 *
 * Validates that recipientAddress format is correct for the destination chain
 * (EVM hex address or Solana base58 address).
 *
 * @throws KitError if validation fails
 */
const forwarderOnlyDestinationSchema = zod.z
    .object({
    chain: chainDefinitionSchema.extend({
        isTestnet: zod.z.boolean(),
    }),
    recipientAddress: zod.z
        .string()
        .min(1, 'Recipient address is required for forwarder-only destination'),
    useForwarder: zod.z.literal(true),
})
    .superRefine((data, ctx) => {
    // Pass chain name as string - isValidAddressForChain will use name-based matching
    if (!isValidAddressForChain(data.recipientAddress, data.chain.name)) {
        ctx.addIssue({
            code: zod.z.ZodIssueCode.custom,
            message: `Invalid recipient address format for chain ${data.chain.name}`,
            path: ['recipientAddress'],
        });
    }
});
/**
 * Schema for validating any destination - either with adapter or forwarder-only.
 */
const bridgeDestinationSchema = zod.z.union([
    destinationContextSchema,
    forwarderOnlyDestinationSchema,
]);
/**
 * Schema for validating a custom fee configuration.
 * Validates the simplified CustomFee interface which includes:
 * - An optional fee amount as string
 * - An optional fee recipient as string address
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { customFeeSchema } from '@core/provider'
 *
 * const validConfig = {
 *   value: '1000000',
 *   recipientAddress: '0x1234567890123456789012345678901234567890'
 * }
 *
 * const result = customFeeSchema.safeParse(validConfig)
 * console.log(result.success) // true
 * ```
 */
const customFeeSchema = zod.z
    .object({
    /**
     * The fee to charge for the transfer as string.
     * Must be a non-negative value using dot (.) as decimal separator,
     * with no thousand separators or comma decimals.
     */
    value: createDecimalStringValidator({
        allowZero: true,
        regexMessage: 'Value must be a non-negative numeric string with dot (.) as decimal separator, with no thousand separators or comma decimals.',
        attributeName: 'value',
    })(zod.z.string()).optional(),
    /**
     * The fee recipient address.
     * Must be a valid address string.
     */
    recipientAddress: zod.z
        .string()
        .trim()
        .min(1, 'Fee recipient must be a non-empty string')
        .optional(),
})
    .strict();
/**
 * Schema for validating bridge parameters.
 * This ensures all required fields are present and properly typed.
 * A bridge must include:
 * - A valid amount (non-empty numeric string \> 0)
 * - Valid source and destination wallet contexts
 * - USDC as the token
 * - Optional config with transfer speed and max fee settings
 *
 * @throws KitError if validation fails
 *
 * @example
 * ```typescript
 * import { bridgeParamsSchema } from '@core/provider'
 *
 * const validBridge = {
 *   amount: '100.50',
 *   source: {
 *     adapter: sourceAdapter,
 *     address: '0xSourceAddress',
 *     chain: sourceChain
 *   },
 *   destination: {
 *     adapter: destAdapter,
 *     address: '0xDestAddress',
 *     chain: destChain
 *   },
 *   token: 'USDC',
 *   config: {
 *     transferSpeed: 'FAST',
 *     maxFee: '1.5', // Must use dot as decimal separator
 *     customFee: {
 *       value: '0.5', // Must use dot as decimal separator
 *       recipientAddress: '0x1234567890123456789012345678901234567890'
 *     }
 *   }
 * }
 *
 * const result = bridgeParamsSchema.safeParse(validBridge)
 * console.log(result.success) // true
 * ```
 */
zod.z.object({
    amount: zod.z
        .string()
        .min(1, 'Required')
        .pipe(createDecimalStringValidator({
        allowZero: false,
        regexMessage: AMOUNT_FORMAT_ERROR_MESSAGE,
        attributeName: 'amount',
        maxDecimals: 6,
    })(zod.z.string())),
    source: walletContextSchema,
    destination: bridgeDestinationSchema,
    token: zod.z.literal('USDC'),
    config: zod.z.object({
        transferSpeed: zod.z.nativeEnum(TransferSpeed).optional(),
        maxFee: zod.z
            .string()
            .pipe(createDecimalStringValidator({
            allowZero: true,
            regexMessage: MAX_FEE_FORMAT_ERROR_MESSAGE,
            attributeName: 'maxFee',
            maxDecimals: 6,
        })(zod.z.string()))
            .optional(),
        customFee: customFeeSchema.optional(),
    }),
});

// ---------------------------------------------------------------------------
// Shared
// ---------------------------------------------------------------------------
/**
 * Zod schema for Gateway API error response (4xx responses).
 * Live API returns \{ success: false, message: string \} (verified
 * against gateway-api-testnet). Docs show \{ code, message \} but
 * actual response uses success/message.
 *
 * @example
 * ```typescript
 * {
 *   success: false,
 *   message: 'Invalid request: token: Invalid literal value, expected "USDC"'
 * }
 * ```
 */
const gatewayErrorResponseSchema = zod.z.object({
    success: zod.z.literal(false),
    message: zod.z.string(),
});
// ---------------------------------------------------------------------------
// Confirmed balances (/v1/balances)
// ---------------------------------------------------------------------------
/**
 * Zod schema for a single balance entry in the Gateway API
 * confirmed-balances response.
 *
 * @example
 * ```typescript
 * {
 *   domain: 0,
 *   depositor: '0x1234567890123456789012345678901234567890',
 *   balance: '10.500000'
 * }
 * ```
 */
const balanceEntrySchema = zod.z.object({
    domain: zod.z.number(),
    depositor: zod.z.string(),
    balance: zod.z.string(),
});
/**
 * Zod schema for the Gateway confirmed-balances API response
 * (POST /v1/balances).
 *
 * @example
 * ```typescript
 * {
 *   token: 'USDC',
 *   balances: [
 *     { domain: 0, depositor: '0x1234…', balance: '10.500000' }
 *   ]
 * }
 * ```
 */
const gatewayBalancesResponseSchema = zod.z.object({
    token: zod.z.enum(SUPPORTED_TOKENS),
    balances: zod.z.array(balanceEntrySchema),
});
// ---------------------------------------------------------------------------
// Pending deposits (/v1/deposits)
// ---------------------------------------------------------------------------
/** Zod schema for a single pending deposit entry in the Gateway API response. */
const gatewayDepositEntrySchema = zod.z.object({
    depositor: zod.z.string(),
    domain: zod.z.number(),
    transactionHash: zod.z.string(),
    amount: zod.z.string().pipe(createDecimalStringValidator({
        allowZero: true,
        regexMessage: 'amount must be a non-negative integer string',
        attributeName: 'amount',
        maxDecimals: 0,
    })(zod.z.string())),
    status: zod.z.string(),
    blockHeight: zod.z.string(),
    blockHash: zod.z.string(),
    blockTimestamp: zod.z.string(),
});
/**
 * Zod schema for the Gateway pending-deposits API response
 * (POST /v1/deposits — token + deposits array).
 */
const gatewayDepositsResponseSchema = zod.z.object({
    token: zod.z.string(),
    deposits: zod.z.array(gatewayDepositEntrySchema),
});
/**
 * Union of error and success response schemas for the
 * confirmed-balances API. Order matters: error shape is tried first so
 * \{ success: false, message \} is validated as an API error.
 */
const gatewayBalancesResponseUnionSchema = zod.z.union([
    gatewayErrorResponseSchema,
    gatewayBalancesResponseSchema,
]);
/**
 * Union of error and success response schemas for the
 * pending-deposits API. Order matters: error shape is tried first so
 * \{ success: false, message \} is validated as an API error.
 */
const gatewayDepositsResponseUnionSchema = zod.z.union([
    gatewayErrorResponseSchema,
    gatewayDepositsResponseSchema,
]);

// ---------------------------------------------------------------------------
// Confirmed balances
// ---------------------------------------------------------------------------
/**
 * Validate and type-narrow the Gateway confirmed-balances API response.
 *
 * Parse against the union of error and success schemas, then reject
 * the API error shape by throwing.
 *
 * @param obj - Raw value from the Gateway POST /v1/balances response.
 * @returns True when obj is a valid GatewayBalancesResponse.
 * @throws KitError With descriptive message if the structure is
 *   invalid or the API returned an error body.
 *
 * @example
 * ```typescript
 * const data = await response.json()
 * if (assertGatewayBalancesResponse(data)) {
 *   console.log(data.token, data.balances)
 * }
 * ```
 */
const assertGatewayBalancesResponse = (obj) => {
    const parsed = parseOrThrow(obj, gatewayBalancesResponseUnionSchema, 'Gateway balances response');
    if ('success' in parsed && !parsed.success) {
        throwGatewayApiError(new Error(parsed.message));
    }
    return true;
};
// ---------------------------------------------------------------------------
// Pending deposits
// ---------------------------------------------------------------------------
/**
 * Validate and type-narrow the Gateway pending-deposits API response.
 *
 * Parse against the union of error and success schemas, then reject
 * the API error shape by throwing.
 *
 * @param obj - Raw value from the Gateway POST /v1/deposits response.
 * @returns True when obj is a valid GatewayDepositsResponse.
 * @throws KitError When the API returns an error body
 *   (success: false with message), or when the response fails Zod
 *   validation.
 *
 * @example
 * ```typescript
 * const raw = await response.json()
 * if (assertGatewayDepositsResponse(raw)) {
 *   console.log(raw.deposits.length)
 * }
 * ```
 */
const assertGatewayDepositsResponse = (obj) => {
    const parsed = parseOrThrow(obj, gatewayDepositsResponseUnionSchema, 'Gateway pending deposits response');
    if ('success' in parsed && !parsed.success) {
        throwGatewayApiError(new Error(parsed.message));
    }
    return true;
};

/**
 * Map pre-normalized sources into Gateway API source entries.
 *
 * Each source's `account` becomes a `depositor`. When `chains` are
 * specified the chain is resolved to its Gateway domain; otherwise a
 * single domain-less entry is produced so the API returns data for all
 * domains.
 *
 * @param normalizedSources - Pre-normalized source list.
 * @returns Flat array of Gateway API source entries.
 * @throws KitError When a chain has no Gateway domain.
 */
function resolveGatewayApiSources(normalizedSources) {
    return normalizedSources.flatMap((source) => {
        if (!source.chains || source.chains.length === 0) {
            return [{ depositor: source.account }];
        }
        return source.chains.map((chainId) => {
            const chain = resolveChainIdentifier(chainId);
            const domain = chain.gateway?.domain;
            if (domain === undefined) {
                throw createInvalidChainError(chain.name, 'does not support Gateway (no Gateway domain configured)');
            }
            return { depositor: source.account, domain };
        });
    });
}
// ---------------------------------------------------------------------------
// Confirmed balances
// ---------------------------------------------------------------------------
/**
 * Transform the raw Gateway API response into a flat list of confirmed
 * deposits.
 *
 * Entries whose Gateway domain cannot be mapped to a known chain are
 * silently skipped. This is intentional — the API may return domains
 * for chains the SDK does not yet support, and dropping them avoids
 * breaking consumers when new chains are added server-side.
 *
 * @param response - Raw API response from POST /v1/balances.
 * @param isTestnet - Whether the request targeted testnet chains.
 * @returns Flat list of confirmed balance entries (unknown domains omitted).
 *
 * @example
 * ```typescript
 * const response = {
 *   token: 'USDC',
 *   balances: [
 *     { domain: 0, depositor: '0x123', balance: '10.500000' },
 *     { domain: 6, depositor: '0x123', balance: '5.250000' }
 *   ]
 * }
 *
 * const result = transformToConfirmedDeposits(response, false)
 * // result.balances[0].chain === 'Ethereum'
 * ```
 */
function transformToConfirmedDeposits(response, isTestnet) {
    const balances = [];
    for (const balance of response.balances) {
        const chain = findChainByDomain(balance.domain, isTestnet);
        if (!chain)
            continue;
        balances.push({
            chain: chain.chain,
            depositor: balance.depositor,
            balance: balance.balance,
        });
    }
    return {
        token: response.token,
        balances,
    };
}
// ---------------------------------------------------------------------------
// Pending deposits
// ---------------------------------------------------------------------------
/**
 * Resolve the Gateway API pending-deposits response into
 * {@link GetPendingDepositsResult}.
 *
 * Entries whose Gateway domain cannot be mapped to a known chain are
 * silently skipped (same rationale as {@link transformToConfirmedDeposits}).
 *
 * @param response - Validated Gateway API response.
 * @param isTestnet - Whether the response is from testnet (for chain
 *   lookup).
 * @returns Token and list of {@link PendingDeposit} (unknown domains omitted).
 *
 * @example
 * ```typescript
 * const result = resolvePendingDepositsResult(response, false)
 * // result.deposits[0].chain === 'Ethereum'
 * ```
 */
function resolvePendingDepositsResult(response, isTestnet) {
    const deposits = [];
    for (const d of response.deposits) {
        const chain = findChainByDomain(d.domain, isTestnet);
        if (!chain)
            continue;
        deposits.push({
            depositor: d.depositor,
            chain: chain.chain,
            transactionHash: d.transactionHash,
            amount: Amount.of(safeBigInt(String(d.amount), 'deposit.amount'), {
                decimals: USDC_DECIMALS$1,
            }).formatted({
                minimumFractionDigits: USDC_DECIMALS$1,
                maximumFractionDigits: USDC_DECIMALS$1,
                useGrouping: false,
            }),
            status: d.status,
            blockHeight: d.blockHeight,
            blockHash: d.blockHash,
            blockTimestamp: d.blockTimestamp,
        });
    }
    return {
        token: response.token,
        deposits,
    };
}

/**
 * Default configuration for Gateway API balance calls.
 *
 * @internal
 */
const DEFAULT_BALANCES_CONFIG = {
    timeout: 2_000, // 2 seconds per request
    maxRetries: 10, // 10 retry attempts
    retryDelay: 200, // 200ms between retries
    headers: {
        'Content-Type': 'application/json',
    },
};
/**
 * Fetches confirmed USDC balances across multiple chains for multiple
 * depositor addresses. Accepts a pre-built Gateway request body so the
 * caller can share it with other queries (e.g. pending).
 *
 * @param requestBody - Pre-built Gateway API request body.
 * @param isTestnet - Whether to target the testnet API.
 * @param config - Optional custom retry configuration.
 * @returns Promise resolving to flat list of confirmed balances.
 * @throws KitError When API request fails after retries.
 * @throws KitError When response validation fails.
 *
 * @example
 * ```typescript
 * const sources = resolveGatewayApiSources(normalizedSources)
 * const result = await getConfirmedDeposits({ token: 'USDC', sources }, false)
 * ```
 */
async function getConfirmedDeposits(requestBody, isTestnet, config) {
    const apiBaseUrl = getGatewayApiBaseUrl(isTestnet);
    const effectiveConfig = {
        ...DEFAULT_BALANCES_CONFIG,
        ...config,
    };
    const url = `${apiBaseUrl}/v1/balances`;
    let rawResponse;
    try {
        rawResponse = await pollApiPost(url, requestBody, assertGatewayBalancesResponse, effectiveConfig);
    }
    catch (error) {
        throwGatewayApiError(error);
    }
    return transformToConfirmedDeposits(rawResponse, isTestnet);
}

/**
 * Fetches pending USDC deposits using a pre-built Gateway request body.
 * Called by the parent balance flow (e.g. getBalances) after building
 * the shared request body.
 *
 * @param requestBody - Pre-built Gateway API request body.
 * @param isTestnet - Whether to use testnet API (caller-provided).
 * @param config - Optional retry configuration.
 * @returns Promise resolving to {@link GetPendingDepositsResult} (token + deposits list).
 * @throws \{KitError\} When the API returns an error shape, or when
 *   the response fails validation. Entries with unrecognised domains
 *   are silently skipped.
 *
 * @example
 * ```typescript
 * const sources = resolveGatewayApiSources(normalizedSources)
 * const result = await getPendingDeposits({ token: 'USDC', sources }, false)
 * // result.token, result.deposits
 * ```
 */
async function getPendingDeposits(requestBody, isTestnet = false, config) {
    const apiBaseUrl = getGatewayApiBaseUrl(isTestnet);
    const effectiveConfig = {
        ...DEFAULT_BALANCES_CONFIG,
        ...config,
    };
    const url = `${apiBaseUrl}/v1/deposits`;
    let rawResponse;
    try {
        rawResponse = await pollApiPost(url, requestBody, assertGatewayDepositsResponse, effectiveConfig);
    }
    catch (error) {
        throwGatewayApiError(error);
    }
    return resolvePendingDepositsResult(rawResponse, isTestnet);
}

/** Reusable zero amount to avoid repeated allocations. */
const ZERO = Amount.of(0n, { decimals: USDC_DECIMALS$1 });
/**
 * Fetch combined confirmed and pending balances for one or more accounts.
 *
 * Sources are normalized once upfront and shared between the confirmed
 * and pending API calls to avoid redundant async adapter resolution.
 *
 * @param params - Balance query parameters. Provide either an adapter
 *   (address resolved automatically) or a raw account address.
 *   Optionally narrow by chain(s). Set `includePending: true` to
 *   include pending balances and transaction details in the result.
 * @param config - Optional custom retry configuration.
 * @returns Promise resolving to totalConfirmedBalance, optional
 *   totalPendingBalance, and per-depositor per-chain breakdown.
 * @throws KitError When chains do not support Gateway.
 * @throws KitError When an API request fails after retries.
 * @throws KitError When response validation fails.
 *
 * @example
 * ```typescript
 * // Confirmed only
 * const result = await getBalances({
 *   token: 'USDC',
 *   sources: { account: '0x1234…' },
 * })
 *
 * // With pending
 * const result = await getBalances({
 *   token: 'USDC',
 *   sources: { account: '0x1234…', chains: ['Ethereum'] },
 *   includePending: true,
 * })
 * ```
 */
async function getBalances(params, config) {
    const normalizedSources = await normalizeSources(params.sources);
    // Derive network type from the first source's chain. Safe because the kit
    // layer enforces assertSameNetwork before reaching the provider, preventing
    // mixed mainnet/testnet sources.
    const firstChainId = normalizedSources[0]?.chains?.[0];
    const isTestnet = firstChainId
        ? resolveChainIdentifier(firstChainId).isTestnet
        : params.networkType === 'testnet';
    const requestBody = {
        token: params.token,
        sources: resolveGatewayApiSources(normalizedSources),
    };
    const [confirmedResult, pendingDeposits] = await Promise.all([
        getConfirmedDeposits(requestBody, isTestnet, config),
        params.includePending
            ? getPendingDeposits(requestBody, isTestnet, config).then((r) => r.deposits)
            : [],
    ]);
    return mergeResults(confirmedResult.token, confirmedResult.balances, pendingDeposits, params.includePending ?? false);
}
function emptyAccumulator() {
    return { confirmed: ZERO, pending: ZERO, pendingTxs: [] };
}
/**
 * Return the chain-level map for a depositor, creating it when absent.
 *
 * @param map - Top-level depositor map.
 * @param depositor - Depositor address.
 * @returns The chain-level map for this depositor.
 * @internal
 */
function getOrCreateChainMap(map, depositor) {
    let chainMap = map.get(depositor);
    if (!chainMap) {
        chainMap = new Map();
        map.set(depositor, chainMap);
    }
    return chainMap;
}
/**
 * Merge confirmed balance entries and pending deposits into a single
 * GetBalancesResult with per-depositor, per-chain breakdown.
 *
 * @param token - The queried token.
 * @param confirmedEntries - Flat confirmed balance entries from the API.
 * @param pendingDeposits - Pending deposit entries (empty when not
 *   requested).
 * @param includePending - Whether pending data was requested.
 * @returns Aggregated GetBalancesResult.
 * @internal
 */
function mergeResults(token, confirmedEntries, pendingDeposits, includePending) {
    const depositorMap = buildDepositorMap(confirmedEntries, pendingDeposits);
    let totalConfirmed = ZERO;
    let totalPending = ZERO;
    const breakdown = [];
    for (const [depositor, chainMap] of depositorMap) {
        const { confirmed, pending } = sumChainAccumulators(chainMap);
        totalConfirmed = totalConfirmed.add(confirmed);
        totalPending = totalPending.add(pending);
        breakdown.push(buildDepositorEntry(depositor, confirmed, pending, chainMap, includePending));
    }
    const result = {
        token,
        totalConfirmedBalance: formatAmount(totalConfirmed),
        breakdown,
    };
    if (includePending) {
        result.totalPendingBalance = formatAmount(totalPending);
    }
    return result;
}
/**
 * Index confirmed and pending data into a two-level
 * `depositor → chain → ChainAccumulator` map.
 * @internal
 */
function buildDepositorMap(confirmedEntries, pendingDeposits) {
    const map = new Map();
    // Seed each (depositor, chain) slot with confirmed data, accumulating
    // if the API returns duplicate (depositor, chain) entries.
    for (const entry of confirmedEntries) {
        const chainMap = getOrCreateChainMap(map, entry.depositor);
        const parsedBalance = Amount.parse(entry.balance, {
            decimals: USDC_DECIMALS$1,
        });
        const existing = chainMap.get(entry.chain);
        if (existing) {
            existing.confirmed = existing.confirmed.add(parsedBalance);
        }
        else {
            chainMap.set(entry.chain, {
                confirmed: parsedBalance,
                pending: ZERO,
                pendingTxs: [],
            });
        }
    }
    // Layer pending deposits on top. A deposit may reference a chain that has
    // no confirmed entry yet (e.g. first-ever deposit still in flight), so we
    // fall back to an empty accumulator.
    for (const deposit of pendingDeposits) {
        const chainMap = getOrCreateChainMap(map, deposit.depositor);
        const acc = chainMap.get(deposit.chain) ?? emptyAccumulator();
        acc.pending = acc.pending.add(Amount.parse(deposit.amount, { decimals: USDC_DECIMALS$1 }));
        acc.pendingTxs.push(deposit);
        chainMap.set(deposit.chain, acc);
    }
    return map;
}
/**
 * Sum confirmed and pending amounts across all chains for a single depositor.
 * @internal
 */
function sumChainAccumulators(chainMap) {
    let confirmed = ZERO;
    let pending = ZERO;
    for (const acc of chainMap.values()) {
        confirmed = confirmed.add(acc.confirmed);
        pending = pending.add(acc.pending);
    }
    return { confirmed, pending };
}
/**
 * Build the per-depositor breakdown entry from pre-computed totals and
 * chain-level accumulators.
 *
 * @param depositor - Depositor address.
 * @param totalConfirmed - Pre-summed confirmed total for this depositor.
 * @param totalPending - Pre-summed pending total for this depositor.
 * @param chainMap - Chain-level accumulators for this depositor.
 * @param includePending - Whether to include pending data.
 * @returns Formatted depositor breakdown.
 * @internal
 */
function buildDepositorEntry(depositor, totalConfirmed, totalPending, chainMap, includePending) {
    const breakdown = Array.from(chainMap.entries()).map(([chain, acc]) => buildChainEntry(chain, acc, includePending));
    const result = {
        depositor,
        totalConfirmed: formatAmount(totalConfirmed),
        breakdown,
    };
    if (includePending) {
        result.totalPending = formatAmount(totalPending);
    }
    return result;
}
/**
 * Format a single chain's accumulator into a {@link ChainBalanceBreakdown}.
 * @internal
 */
function buildChainEntry(chain, acc, includePending) {
    const entry = {
        chain,
        confirmedBalance: formatAmount(acc.confirmed),
    };
    if (includePending) {
        entry.pendingBalance = formatAmount(acc.pending);
        entry.pendingTransactions = acc.pendingTxs.map((tx) => ({
            transactionHash: tx.transactionHash,
            amount: tx.amount,
            blockTimestamp: tx.blockTimestamp,
        }));
    }
    return entry;
}
/**
 * Format an Amount as a USDC decimal string with 6 fractional digits.
 *
 * @param amount - The Amount to format.
 * @returns Formatted decimal string (e.g. `"10.500000"`).
 * @internal
 */
function formatAmount(amount) {
    return amount.formatted({
        minimumFractionDigits: USDC_DECIMALS$1,
        maximumFractionDigits: USDC_DECIMALS$1,
        useGrouping: false,
    });
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const ETHEREUM_CHAINS = new Set([
    Blockchain.Ethereum,
    Blockchain.Ethereum_Sepolia,
]);
const USDC_DECIMALS = 6;
/**
 * Gateway gas fees per source chain in USDC atomic units.
 * Mainnet and testnet counterparts share the same gas fee.
 *
 * @see {@link https://developers.circle.com/gateway/references/fees}
 */
const GAS_FEE_BY_CHAIN = new Map([
    [Blockchain.Arc_Testnet, parseUnits('0.001', USDC_DECIMALS)],
    [Blockchain.Arbitrum, parseUnits('0.01', USDC_DECIMALS)],
    [Blockchain.Arbitrum_Sepolia, parseUnits('0.01', USDC_DECIMALS)],
    [Blockchain.Avalanche, parseUnits('0.02', USDC_DECIMALS)],
    [Blockchain.Avalanche_Fuji, parseUnits('0.02', USDC_DECIMALS)],
    [Blockchain.Base, parseUnits('0.01', USDC_DECIMALS)],
    [Blockchain.Base_Sepolia, parseUnits('0.01', USDC_DECIMALS)],
    [Blockchain.Ethereum, parseUnits('2', USDC_DECIMALS)],
    [Blockchain.Ethereum_Sepolia, parseUnits('2', USDC_DECIMALS)],
    [Blockchain.HyperEVM, parseUnits('0.05', USDC_DECIMALS)],
    [Blockchain.HyperEVM_Testnet, parseUnits('0.05', USDC_DECIMALS)],
    [Blockchain.Optimism, parseUnits('0.0015', USDC_DECIMALS)],
    [Blockchain.Optimism_Sepolia, parseUnits('0.0015', USDC_DECIMALS)],
    [Blockchain.Polygon, parseUnits('0.0015', USDC_DECIMALS)],
    [Blockchain.Polygon_Amoy_Testnet, parseUnits('0.0015', USDC_DECIMALS)],
    [Blockchain.Sei, parseUnits('0.001', USDC_DECIMALS)],
    [Blockchain.Sei_Testnet, parseUnits('0.001', USDC_DECIMALS)],
    [Blockchain.Solana, parseUnits('0.15', USDC_DECIMALS)],
    [Blockchain.Solana_Devnet, parseUnits('0.15', USDC_DECIMALS)],
    [Blockchain.Sonic, parseUnits('0.01', USDC_DECIMALS)],
    [Blockchain.Sonic_Testnet, parseUnits('0.01', USDC_DECIMALS)],
    [Blockchain.Unichain, parseUnits('0.001', USDC_DECIMALS)],
    [Blockchain.Unichain_Sepolia, parseUnits('0.001', USDC_DECIMALS)],
    [Blockchain.World_Chain, parseUnits('0.01', USDC_DECIMALS)],
    [Blockchain.World_Chain_Sepolia, parseUnits('0.01', USDC_DECIMALS)],
]);
/**
 * Forwarding service fee (USDC atomic units).
 * $0.20 flat fee charged on all destination chains.
 *
 * @see {@link https://developers.circle.com/gateway/references/forwarding-service}
 */
const FORWARDER_SERVICE_FEE = parseUnits('0.2', USDC_DECIMALS);
/**
 * Transfer fee divisor for the 0.5 bps cross-chain rate.
 *
 * `effectiveBalance = (balance - fixedFees) * DIVISOR / (DIVISOR + SCALED_BPS)`
 *
 * This avoids floating-point: 0.5 bps = 5 / 100_000, so
 * `(balance - fixedFees) / 1.00005` becomes
 * `(balance - fixedFees) * 100_000 / 100_005`.
 */
const TRANSFER_BPS_DIVISOR = 100000n;
const TRANSFER_FEE_SCALED_BPS = 5n;
const CIRCLE_BPS_DIVISOR = 10000n;
/**
 * Build the three-tier ordered list of chain slots:
 *   Tier 1: same-chain (destination chain) — cheapest, no cross-chain fee
 *   Tier 2: non-Ethereum chains, sorted by balance descending
 *   Tier 3: Ethereum chains — most expensive gas, used last
 */
function buildOrderedSlots(chainBalances, destinationChain) {
    const sameChain = [];
    const nonEthereum = [];
    const ethereum = [];
    for (const { chain, confirmedBalance, sourceIndex } of chainBalances) {
        const slot = {
            chain,
            remaining: parseUnits(confirmedBalance, USDC_DECIMALS),
            isSameChain: chain === destinationChain,
            isEthereum: ETHEREUM_CHAINS.has(chain),
            sourceIndex,
        };
        if (slot.isSameChain) {
            sameChain.push(slot);
        }
        else if (slot.isEthereum) {
            ethereum.push(slot);
        }
        else {
            nonEthereum.push(slot);
        }
    }
    // Within each tier, sort by balance descending (greedy: largest first)
    const byBalanceDesc = (a, b) => {
        if (a.remaining > b.remaining)
            return -1;
        if (a.remaining < b.remaining)
            return 1;
        return 0;
    };
    nonEthereum.sort(byBalanceDesc);
    ethereum.sort(byBalanceDesc);
    // Tier 1 → Tier 2 → Tier 3
    return [...sameChain, ...nonEthereum, ...ethereum];
}
const DEFAULT_GAS_FEE = parseUnits('0.1', USDC_DECIMALS);
/**
 * Return the estimated Gateway gas fee for a chain in USDC atomic units.
 * Falls back to a conservative 0.1 USDC for unlisted chains.
 *
 * @param chain - The source blockchain.
 * @returns Gas fee in USDC atomic units.
 */
function getGasFee(chain) {
    return GAS_FEE_BY_CHAIN.get(chain) ?? DEFAULT_GAS_FEE;
}
/**
 * Return the estimated forwarder fee for the destination chain
 * (service fee + destination gas fee).
 *
 * @param destinationChain - The mint destination chain.
 * @returns Forwarder fee in USDC atomic units.
 */
function getForwarderFee(destinationChain) {
    const destGas = getGasFee(destinationChain);
    return FORWARDER_SERVICE_FEE + destGas;
}
/**
 * Estimate the fixed fees (gas + forwarder) and compute the maximum
 * amount that can be drawn from this chain for a single intent,
 * accounting for the 0.5 bps transfer fee if cross-chain.
 */
function computeMaxDrawable(slot, forwarderFeeRemaining) {
    const gasFee = getGasFee(slot.chain);
    let fixedFees = gasFee;
    let forwarderFeeUsed = 0n;
    if (forwarderFeeRemaining > 0n) {
        fixedFees += forwarderFeeRemaining;
        forwarderFeeUsed = forwarderFeeRemaining;
    }
    if (slot.remaining <= fixedFees) {
        return { drawable: 0n, gasFee, forwarderFeeUsed: 0n };
    }
    const afterFixed = slot.remaining - fixedFees;
    // Transfer fee applies per intent for cross-chain transfers.
    // effective = afterFixed * DIVISOR / (DIVISOR + scaledBps)
    const drawable = slot.isSameChain
        ? afterFixed
        : (afterFixed * TRANSFER_BPS_DIVISOR) /
            (TRANSFER_BPS_DIVISOR + TRANSFER_FEE_SCALED_BPS);
    return { drawable, gasFee, forwarderFeeUsed };
}
/**
 * Run one greedy allocation pass over the ordered chain slots.
 *
 * Walks the slots in order (same-chain → non-ETH → ETH), takes as
 * much as possible from each chain (up to remaining balance minus gas
 * buffer), and returns the allocations for this pass.
 *
 * Mutates `slot.remaining` so the next pass sees reduced balances.
 */
function greedyAllocate(slots, amount, destinationChain, useForwarder) {
    const result = [];
    let remaining = amount;
    let forwarderFeeRemaining = useForwarder
        ? getForwarderFee(destinationChain)
        : 0n;
    if (remaining <= 0n)
        return result;
    for (const slot of slots) {
        if (remaining <= 0n)
            break;
        const { drawable, gasFee, forwarderFeeUsed } = computeMaxDrawable(slot, forwarderFeeRemaining);
        if (drawable <= 0n)
            continue;
        // Greedy: take as much as we can from this chain
        const take = remaining < drawable ? remaining : drawable; // NOSONAR: This is a false positive — Math.min() only accepts number, not bigint, so the ternary is the correct pattern here.
        // If cross-chain, we must also deduct the transfer fee (0.5 bps)
        const transferFee = slot.isSameChain
            ? 0n
            : (take * TRANSFER_FEE_SCALED_BPS) / TRANSFER_BPS_DIVISOR;
        result.push({
            chain: slot.chain,
            amount: formatUnits(take.toString(), USDC_DECIMALS),
            sourceIndex: slot.sourceIndex,
        });
        // Consume from this chain's pool (the take + gas + transfer fee + forwarder)
        slot.remaining -= take + gasFee + transferFee + forwarderFeeUsed;
        remaining -= take;
        forwarderFeeRemaining -= forwarderFeeUsed;
    }
    return result;
}
/** @internal Exported for unit testing only. */
function assertFullyAllocated(allocations, requestedAmount, amountIn) {
    const allocated = allocations.reduce((sum, a) => sum + parseUnits(a.amount, USDC_DECIMALS), 0n);
    if (allocated < requestedAmount) {
        throw new KitError({
            ...BalanceError.INSUFFICIENT_TOKEN,
            recoverability: 'FATAL',
            message: `Insufficient balance to cover ${amountIn} USDC.`,
        });
    }
    if (allocated > requestedAmount) {
        throw createValidationFailedError('amount', amountIn, `over-allocation detected: allocated more than the requested ${amountIn} USDC`);
    }
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Compute per-chain allocations for the user transfer, developer fee,
 * and Circle fee using a phased greedy strategy.
 *
 * **Chain ordering (three tiers, applied to every phase):**
 *   1. Same chain as destination — cheapest (no cross-chain fee)
 *   2. Non-Ethereum chains — sorted by balance descending
 *   3. Ethereum — highest gas, used only if needed
 *
 * **Phase 1 — User transfer:**
 *   Allocate `amountIn` across the three tiers.
 *
 * **Phase 2 — Developer fee:**
 *   Allocate `devShare` of `customFee.value` across remaining balances.
 *
 * **Phase 3 — Circle fee:**
 *   Allocate `circleShare` across whatever remains.
 *
 * Each phase mutates the shared per-chain balance pool so subsequent
 * phases see the reduced capacities.
 *
 * @param ctx - All inputs needed for allocation.
 * @returns Per-chain splits for transfer, developer fee, and Circle fee.
 * @throws KitError with `INSUFFICIENT_TOKEN` when balances cannot
 *   cover the requested amounts.
 *
 * @internal
 *
 * @example
 * ```typescript
 * const result = computeAutoAllocation({
 *   amountIn: '100',
 *   destinationChain: Blockchain.Base,
 *   chainBalances: [
 *     { chain: Blockchain.Base, confirmedBalance: '80' },
 *     { chain: Blockchain.Avalanche, confirmedBalance: '50' },
 *   ],
 *   useForwarder: false,
 * })
 * ```
 */
function computeAutoAllocation(ctx) {
    // -----------------------------------------------------------------------
    // 1. Build the ordered chain slots (same-chain → non-ETH → ETH)
    //    This mutable array is shared across all three phases.
    // -----------------------------------------------------------------------
    const slots = buildOrderedSlots(ctx.chainBalances, ctx.destinationChain);
    // -----------------------------------------------------------------------
    // 2. Compute fee splits (only when customFee is present)
    // -----------------------------------------------------------------------
    const circleBps = BigInt(ctx.circleBps ?? 1000);
    let devFeeAmount = 0n;
    let circleFeeAmount = 0n;
    if (ctx.customFee) {
        const totalFee = parseUnits(ctx.customFee.value, USDC_DECIMALS);
        circleFeeAmount = (totalFee * circleBps) / CIRCLE_BPS_DIVISOR;
        devFeeAmount = totalFee - circleFeeAmount;
    }
    // -----------------------------------------------------------------------
    // 3. Phase 1 — Allocate user transfer amount
    //    Goes through: same-chain first → non-ETH desc → ETH last.
    //    Each chain only gets gas buffer for this one intent deducted.
    //    After this pass, slot.remaining reflects consumed capacity.
    // -----------------------------------------------------------------------
    const transferAmount = parseUnits(ctx.amountIn, USDC_DECIMALS);
    const allocations = greedyAllocate(slots, transferAmount, ctx.destinationChain, ctx.useForwarder);
    assertFullyAllocated(allocations, transferAmount, ctx.amountIn);
    // -----------------------------------------------------------------------
    // 4. Phase 2 — Allocate developer fee
    //    Same three-tier ordering over the SAME slots (reduced balances).
    //    Same-chain first here too — if the destination chain still has
    //    capacity, use it (same-chain fee intent = cheapest gas).
    // -----------------------------------------------------------------------
    const developerFeeAllocations = greedyAllocate(slots, devFeeAmount, ctx.destinationChain, false);
    if (devFeeAmount > 0n) {
        assertFullyAllocated(developerFeeAllocations, devFeeAmount, formatUnits(devFeeAmount.toString(), USDC_DECIMALS));
    }
    // -----------------------------------------------------------------------
    // 5. Phase 3 — Allocate Circle fee
    //    Again same ordering, same shared reduced balances.
    //    Same-chain first for the same reason.
    // -----------------------------------------------------------------------
    const circleFeeAllocations = greedyAllocate(slots, circleFeeAmount, ctx.destinationChain, false);
    if (circleFeeAmount > 0n) {
        assertFullyAllocated(circleFeeAllocations, circleFeeAmount, formatUnits(circleFeeAmount.toString(), USDC_DECIMALS));
    }
    return {
        allocations,
        developerFeeAllocations,
        circleFeeAllocations,
    };
}

/** Serialize a transfer spec to a plain object for the API. */
function serializeTransferSpec(spec) {
    const result = {
        version: spec.version,
        sourceDomain: spec.sourceDomain,
        destinationDomain: spec.destinationDomain,
        sourceContract: spec.sourceContract,
        destinationContract: spec.destinationContract,
        sourceToken: spec.sourceToken,
        destinationToken: spec.destinationToken,
        sourceDepositor: spec.sourceDepositor,
        destinationRecipient: spec.destinationRecipient,
        sourceSigner: spec.sourceSigner,
        destinationCaller: spec.destinationCaller,
        value: spec.value.toString(),
        salt: spec.salt,
    };
    if (spec.hookData && spec.hookData !== '0x') {
        result['hookData'] = spec.hookData;
    }
    return result;
}
/**
 * Build the request body for the Gateway v1 estimate endpoint.
 *
 * EVM intents are sent as one batch; Solana intents as one payload per intent.
 *
 * @param intents - Burn intents to estimate.
 * @returns Array of request payloads for POST /v1/estimate.
 */
function buildEstimateRequestBody(intents) {
    const evmIntents = intents.filter((i) => i.spec.sourceDomain !== SOLANA_GATEWAY_DOMAIN);
    const solanaIntents = intents.filter((i) => i.spec.sourceDomain === SOLANA_GATEWAY_DOMAIN);
    const body = [];
    if (evmIntents.length > 0) {
        body.push({
            intents: evmIntents.map((i) => ({
                spec: serializeTransferSpec(i.spec),
            })),
        });
    }
    for (const intent of solanaIntents) {
        body.push({
            spec: serializeTransferSpec(intent.spec),
        });
    }
    return body;
}
/** Serialize a single burn intent (maxBlockHeight, maxFee, spec) for the API. */
function serializeBurnIntent(intent) {
    return {
        maxBlockHeight: intent.maxBlockHeight.toString(),
        maxFee: intent.maxFee.toString(),
        spec: serializeTransferSpec(intent.spec),
    };
}
/**
 * Build the request body for the Gateway v1 transfer endpoint.
 *
 * Single-intent sets become one burnIntent + signature; multi-intent sets become burnIntentSet + signature.
 *
 * @param signedSets - Signed intent sets (intents + signature per signer).
 * @returns Array of transfer payloads for POST /v1/transfer.
 */
function buildTransferRequestBody(signedSets) {
    return signedSets.map((set) => {
        const firstIntent = set.intents[0];
        if (set.intents.length === 1 && firstIntent) {
            return {
                burnIntent: serializeBurnIntent(firstIntent),
                signature: set.signature,
            };
        }
        return {
            burnIntentSet: {
                intents: set.intents.map(serializeBurnIntent),
            },
            signature: set.signature,
        };
    });
}

// Standard BPS divisor is 10 000. We multiply by 10 (→ 100 000) so that
// a sub-integer rate like 0.5 bps can be scaled to an integer (0.5 × 10 = 5)
// and divided without losing precision.  See transferFeeBps below.
const BPS_DIVISOR = 100000n;
/**
 * Resolve the canonical {@link Blockchain} enum value for a CCTP domain
 * by looking up the allocation whose chain matches the given domain.
 *
 * Unlike `findChainNameByDomain` (which returns the display `name`),
 * this returns `chain.chain` — the enum identifier expected by
 * {@link FeeAllocation}.
 */
function findBlockchainByDomain(domain, allocations) {
    const alloc = allocations.find((a) => a.chain.gateway.domain === domain);
    return (alloc?.chain.chain ?? 'Unknown');
}
/**
 * Normalize any address/salt format to lowercase bytes32 hex.
 *
 * Original intents store all addresses as bytes32 hex after creation.
 * The Gateway estimate API returns addresses in their native format
 * (20-byte EVM hex or Solana base58). Salts may be short hex (e.g. "0x00").
 * This normalizes both so full spec comparison works regardless of format.
 *
 * @throws KitError (VALIDATION_FAILED) if a hex string exceeds 32 bytes
 *   (64 hex chars), indicating a malformed input rather than a format difference.
 */
function toBytes32Lower(address) {
    if (/^0x[0-9a-fA-F]+$/.test(address)) {
        const hexBody = address.slice(2);
        if (hexBody.length > 64) {
            throw createValidationFailedError('address', address, `Value exceeds 32 bytes (${String(hexBody.length / 2)} bytes)`);
        }
        return ('0x' + hexBody.padStart(64, '0')).toLowerCase();
    }
    return convertAddress(address, 'bytes32').toLowerCase();
}
/**
 * Verify that an estimated spec fully matches the original intent spec.
 *
 * All fields are compared: numeric domains, value, salt (bytes32, case-insensitive),
 * and all address fields normalized to lowercase bytes32 hex to handle the format
 * difference between originals (bytes32) and API response (native EVM/Solana).
 *
 * @throws Error if any field does not match, with a descriptive message.
 */
function assertSpecMatches(estimated, original, index) {
    const s = original.spec;
    const mismatches = [];
    if (estimated.version !== s.version)
        mismatches.push(`version: expected ${String(s.version)}, got ${String(estimated.version)}`);
    if (estimated.sourceDomain !== s.sourceDomain)
        mismatches.push(`sourceDomain: expected ${String(s.sourceDomain)}, got ${String(estimated.sourceDomain)}`);
    if (estimated.destinationDomain !== s.destinationDomain)
        mismatches.push(`destinationDomain: expected ${String(s.destinationDomain)}, got ${String(estimated.destinationDomain)}`);
    if (estimated.value !== s.value.toString())
        mismatches.push(`value: expected ${s.value.toString()}, got ${estimated.value}`);
    if (toBytes32Lower(estimated.salt) !== toBytes32Lower(s.salt))
        mismatches.push(`salt: expected ${s.salt}, got ${estimated.salt}`);
    if (toBytes32Lower(estimated.sourceContract) !==
        toBytes32Lower(s.sourceContract))
        mismatches.push(`sourceContract: expected ${s.sourceContract}, got ${estimated.sourceContract}`);
    if (toBytes32Lower(estimated.destinationContract) !==
        toBytes32Lower(s.destinationContract))
        mismatches.push(`destinationContract: expected ${s.destinationContract}, got ${estimated.destinationContract}`);
    if (toBytes32Lower(estimated.sourceToken) !== toBytes32Lower(s.sourceToken))
        mismatches.push(`sourceToken: expected ${s.sourceToken}, got ${estimated.sourceToken}`);
    if (toBytes32Lower(estimated.destinationToken) !==
        toBytes32Lower(s.destinationToken))
        mismatches.push(`destinationToken: expected ${s.destinationToken}, got ${estimated.destinationToken}`);
    if (toBytes32Lower(estimated.sourceDepositor) !==
        toBytes32Lower(s.sourceDepositor))
        mismatches.push(`sourceDepositor: expected ${s.sourceDepositor}, got ${estimated.sourceDepositor}`);
    if (toBytes32Lower(estimated.destinationRecipient) !==
        toBytes32Lower(s.destinationRecipient))
        mismatches.push(`destinationRecipient: expected ${s.destinationRecipient}, got ${estimated.destinationRecipient}`);
    if (toBytes32Lower(estimated.sourceSigner) !== toBytes32Lower(s.sourceSigner))
        mismatches.push(`sourceSigner: expected ${s.sourceSigner}, got ${estimated.sourceSigner}`);
    if (toBytes32Lower(estimated.destinationCaller) !==
        toBytes32Lower(s.destinationCaller))
        mismatches.push(`destinationCaller: expected ${s.destinationCaller}, got ${estimated.destinationCaller}`);
    if (mismatches.length > 0) {
        throw createValidationFailedError(`estimateResponse.intents[${index.toString()}]`, { index, mismatches }, `intent does not match original: ${mismatches.join('; ')}`);
    }
}
/**
 * Apply maxFee and maxBlockHeight from the estimate API response to the
 * original intents, matching by a composite `sourceDomain:salt` key.
 *
 * The estimate API may return intents in a different order than submitted
 * (e.g. mixed Solana + EVM requests). This function flattens the response
 * (burnIntentSet batches and individual burnIntent entries), matches each
 * estimated intent to its original by the composite domain+salt key, verifies
 * the full spec, then copies the estimated maxFee / maxBlockHeight onto each
 * original. When multiple intents share the same salt (across different source
 * domains), the domain component of the key disambiguates them.
 *
 * All address fields are normalized to bytes32 hex before comparison to handle
 * the format difference: originals use bytes32, the API returns native format
 * (20-byte EVM hex or Solana base58).
 *
 * @param response - Raw Gateway estimate API response (array of burnIntent/burnIntentSet).
 * @param originalIntents - Intents that were sent to the estimate API.
 * @returns Intents with maxBlockHeight and maxFee replaced by the API values.
 * @throws Error when the count does not match or an intent cannot be matched.
 *
 * @example
 * ```typescript
 * const estimated = parseEstimateResponse(apiResponse, intents)
 * const fees = computeEstimateFees(estimated, allocations, customFee)
 * ```
 */
function parseEstimateResponse(response, originalIntents) {
    const estimatedIntents = [];
    for (const entry of response) {
        if (entry.burnIntentSet) {
            for (const intent of entry.burnIntentSet.intents) {
                estimatedIntents.push(intent);
            }
        }
        else if (entry.burnIntent) {
            estimatedIntents.push(entry.burnIntent);
        }
    }
    if (estimatedIntents.length !== originalIntents.length) {
        throw createValidationFailedError('estimateResponse', {
            expected: originalIntents.length,
            received: estimatedIntents.length,
        }, `intent count does not match submitted intents`);
    }
    const domainSaltToIntents = new Map();
    for (const e of estimatedIntents) {
        const key = `${String(e.spec.sourceDomain)}:${toBytes32Lower(e.spec.salt)}`;
        const list = domainSaltToIntents.get(key) ?? [];
        list.push(e);
        domainSaltToIntents.set(key, list);
    }
    const nextIndexByKey = new Map();
    return originalIntents.map((original, i) => {
        const key = `${String(original.spec.sourceDomain)}:${toBytes32Lower(original.spec.salt)}`;
        const list = domainSaltToIntents.get(key);
        const nextIdx = nextIndexByKey.get(key) ?? 0;
        const estimated = list?.[nextIdx];
        if (estimated === undefined) {
            throw createValidationFailedError(`estimateResponse[${i.toString()}]`, { sourceDomain: original.spec.sourceDomain, salt: original.spec.salt }, `no matching intent for domain+salt`);
        }
        nextIndexByKey.set(key, nextIdx + 1);
        assertSpecMatches(estimated.spec, original, i);
        return {
            ...original,
            maxBlockHeight: safeBigInt(String(estimated.maxBlockHeight), 'maxBlockHeight'),
            maxFee: safeBigInt(String(estimated.maxFee), 'maxFee'),
        };
    });
}
/**
 * Decompose each intent's `maxFee` into a transfer fee and a gas fee,
 * then aggregate both by source chain.
 *
 * The Gateway API returns a `fees.perIntent` array with `baseFee` and
 * `transferFee` fields, but the schema treats those entries as opaque
 * (`z.record(z.unknown())`). Rather than parsing and trusting that
 * untyped structure, the split is re-derived locally:
 *
 *   `transferFee = value * GATEWAY_TRANSFER_FEE_SCALED_BPS / BPS_DIVISOR`
 *   `gasFee      = maxFee - transferFee`
 *
 * This is accurate as long as the API applies the same 0.5 bps rate
 * with identical BigInt truncation semantics. If the API's fee
 * calculation ever diverges (different rate, different rounding), the
 * individual fee buckets will be inaccurate — though the total
 * `maxFee` (which comes directly from the API) remains correct.
 *
 * @param estimatedIntents - Intents with `maxFee` populated by
 *   {@link parseEstimateResponse}.
 * @param allocations - Normalised allocations used to resolve chain
 *   names from source domains.
 * @returns Per-chain and total transfer/gas fee breakdowns.
 */
function aggregateFeesByIntent(estimatedIntents, allocations) {
    const transferFeeBps = GATEWAY_TRANSFER_FEE_SCALED_BPS;
    const transferFeeByChain = new Map();
    const gasFeeByChain = new Map();
    let totalTransferFee = 0n;
    let totalGasFee = 0n;
    for (const intent of estimatedIntents) {
        const { maxFee, spec } = intent;
        if (maxFee === 0n)
            continue;
        const chainName = findBlockchainByDomain(spec.sourceDomain, allocations);
        const value = typeof spec.value === 'bigint'
            ? spec.value
            : safeBigInt(String(spec.value), 'spec.value');
        const isSameChain = spec.sourceDomain === spec.destinationDomain;
        const transferFee = isSameChain
            ? 0n
            : (value * transferFeeBps) / BPS_DIVISOR;
        const gasFee = maxFee > transferFee ? maxFee - transferFee : 0n;
        if (transferFee > 0n) {
            totalTransferFee += transferFee;
            transferFeeByChain.set(chainName, (transferFeeByChain.get(chainName) ?? 0n) + transferFee);
        }
        if (gasFee > 0n) {
            totalGasFee += gasFee;
            gasFeeByChain.set(chainName, (gasFeeByChain.get(chainName) ?? 0n) + gasFee);
        }
    }
    return {
        transferFeeByChain,
        gasFeeByChain,
        totalTransferFee,
        totalGasFee,
    };
}
/** Convert chain→amount map to FeeEntry allocations (chain + formatted amount). */
function mapToAllocationsEntry(byChain) {
    return [...byChain.entries()].map(([chain, amt]) => ({
        chain,
        amount: formatUnits(amt.toString(), USDC_DECIMALS$1),
    }));
}
/**
 * Build the fees array for an estimate result (provider, gasFee, optional kit).
 *
 * Derives transfer and gas fees from estimated intents and adds a kit fee entry
 * when custom fee is configured.
 *
 * @param estimatedIntents - Intents with maxFee from parseEstimateResponse.
 * @param allocations - Normalized allocations (for chain names).
 * @param customFee - Optional custom fee value and recipient.
 * @returns Array of {@link FeeEntry} for the estimate result.
 */
function computeEstimateFees(estimatedIntents, allocations, customFee) {
    const fees = [];
    const { transferFeeByChain, gasFeeByChain, totalTransferFee, totalGasFee } = aggregateFeesByIntent(estimatedIntents, allocations);
    if (totalTransferFee > 0n) {
        fees.push({
            type: 'provider',
            token: 'USDC',
            amount: formatUnits(totalTransferFee.toString(), USDC_DECIMALS$1),
            allocations: mapToAllocationsEntry(transferFeeByChain),
        });
    }
    if (totalGasFee > 0n) {
        fees.push({
            type: 'gasFee',
            token: 'USDC',
            amount: formatUnits(totalGasFee.toString(), USDC_DECIMALS$1),
            allocations: mapToAllocationsEntry(gasFeeByChain),
        });
    }
    if (customFee) {
        const firstSourceChain = allocations[0]?.chain;
        fees.push({
            type: 'kit',
            token: 'USDC',
            amount: customFee.value,
            allocations: firstSourceChain
                ? [
                    {
                        chain: firstSourceChain.chain,
                        amount: customFee.value,
                    },
                ]
                : [],
            recipientAddress: customFee.recipientAddress,
        });
    }
    return fees;
}

/**
 * Sign each adapter group: Solana one intent per signature, EVM batch per adapter.
 *
 * @param adapterGroups - Groups from groupIntentsByAdapter.
 * @returns Promise of signed sets (intents + signature) for buildTransferRequestBody.
 *
 * @example
 * ```typescript
 * const groups = groupIntentsByAdapter(estimatedIntents, allocations)
 * const signedSets = await signIntentGroups(groups)
 * const body = buildTransferRequestBody(signedSets)
 * ```
 */
async function signIntentGroups(adapterGroups) {
    const nested = await Promise.all(adapterGroups.map(async (group) => {
        if (group.chain.type === 'solana') {
            return signSolanaIntentGroup(group);
        }
        return [await signEvmIntentGroup(group)];
    }));
    return nested.flat();
}

/**
 * Dispatch a spend step event through the provider's action dispatcher.
 *
 * Constructs a {@link GatewayEventPayload} with the step data and dispatches
 * it to any registered event listeners. Returns early when no dispatcher is
 * registered.
 *
 * @param dispatcher - The action dispatcher (may be null if no listeners registered).
 * @param stepName - The fully-qualified step name (e.g. `'gateway.spend.step.mint'`).
 * @param chain - Chain identifier relevant to the operation.
 * @param step - The completed spend step data.
 */
function dispatchSpendStepEvent(dispatcher, stepName, chain, step) {
    if (!dispatcher) {
        return;
    }
    dispatcher.dispatch(stepName, {
        protocol: 'gateway',
        version: 'v1',
        tags: { opName: 'spend', chain },
        data: step,
    });
}

/**
 * Create a KitError for a mint failure that occurred after the transfer
 * was already committed (funds locked).
 *
 * The returned error is RESUMABLE so callers can retry the mint via
 * `config.retry` using the attestation and signature from `error.cause.trace`.
 *
 * @param cause - The underlying error that caused the mint to fail.
 * @param attestation - The attestation hex string from the Gateway API.
 * @param signature - The attestation signature hex string from the Gateway API.
 * @returns A KitError with TRANSACTION_REVERTED code and RESUMABLE recoverability.
 */
function createMintFailedError(cause, attestation, signature) {
    const causeMsg = cause instanceof Error ? cause.message : String(cause);
    return new KitError({
        ...OnchainError.TRANSACTION_REVERTED,
        recoverability: 'RESUMABLE',
        message: `Mint failure: Use the attestation and signature in 'error.cause.trace' to reattempt via 'config.retry'. ` +
            `Cause: ${causeMsg}`,
        cause: {
            trace: {
                attestation,
                signature,
                cause,
            },
        },
    });
}
/**
 * Type guard for forwarder-only destinations (no adapter).
 *
 * @internal
 */
function isForwarderOnly(dest) {
    return (dest.useForwarder === true &&
        !('adapter' in dest) &&
        'recipientAddress' in dest);
}
/** Whether the destination requests forwarding (with or without adapter). */
function isForwarderEnabled(dest) {
    return dest.useForwarder === true;
}
/**
 * Validate that the forwarder route is supported for both destination and
 * (optionally) source chains based on the Gateway `forwarderSupported` flag.
 *
 * @param destChain - Resolved destination chain with Gateway v1 config.
 * @param allocations - Optional source allocations for source-side validation.
 * @throws KitError (VALIDATION_FAILED) when any chain in the route lacks
 *   forwarder support for its role.
 */
function assertForwarderRouteSupport(destChain, allocations) {
    if (!destChain.gateway.forwarderSupported.destination) {
        throw createValidationFailedError('to.chain', destChain.name, 'does not support the Forwarding Service as a destination');
    }
    if (allocations) {
        for (const alloc of allocations) {
            if (!alloc.chain.gateway.forwarderSupported.source) {
                throw createValidationFailedError('from.chain', alloc.chain.name, 'does not support the Forwarding Service as a source');
            }
        }
    }
}
const FORWARDER_POLL_INTERVAL_MS = 5_000;
const FORWARDER_POLL_TIMEOUT_MS = 300_000;
/**
 * Poll the Gateway Forwarding Service transfer endpoint until the
 * transfer reaches a terminal state (`confirmed` or `finalized`).
 *
 * Issue `GET /v1/transfer/{transferId}` every
 * {@link FORWARDER_POLL_INTERVAL_MS | 5 s} and inspect the response
 * status. Polling stops on a terminal status or after
 * {@link FORWARDER_POLL_TIMEOUT_MS | 5 min}, whichever comes first.
 *
 * **Postconditions (on success):**
 * - The returned {@link GatewayTransferDetails} has `status` equal to
 *   `'confirmed'` or `'finalized'` and a non-empty `transactionHash`.
 *
 * **Side effects:**
 * - Send one or more HTTP GET requests to the Gateway API.
 * - Block the calling async context for up to 5 minutes.
 *
 * @param apiBaseUrl - Base URL of the Gateway Forwarding Service
 *   (no trailing slash).
 * @param transferId - Opaque transfer identifier returned by the
 *   initial `POST /v1/transfer` call.
 * @returns The full transfer status response including fees and
 *   destination transaction hash.
 * @throws KitError `TRANSACTION_REVERTED` (RETRYABLE) when the
 *   transfer completes but the response omits a transaction hash.
 * @throws KitError `TRANSACTION_REVERTED` (FATAL) when the
 *   transfer status is `failed` (includes the failure reason).
 * @throws KitError `TRANSACTION_REVERTED` (FATAL) when the transfer
 *   attestation expires before forwarding completes.
 * @throws KitError `NETWORK_TIMEOUT` (RETRYABLE) when polling
 *   exceeds the 5-minute timeout without reaching a terminal status.
 * @throws KitError Propagated from {@link pollApiGet} if the HTTP
 *   request itself fails or returns a non-OK response.
 */
async function pollForwarderCompletion(apiBaseUrl, transferId) {
    const startTime = Date.now();
    while (Date.now() - startTime < FORWARDER_POLL_TIMEOUT_MS) {
        let status;
        try {
            status = await pollApiGet(`${apiBaseUrl}/v1/transfer/${transferId}`, assertGatewayTransferDetails);
        }
        catch (error) {
            throwGatewayApiError(error);
        }
        if (status.status === 'confirmed' || status.status === 'finalized') {
            if (!status.transactionHash) {
                throw new KitError({
                    ...OnchainError.TRANSACTION_REVERTED,
                    recoverability: 'RETRYABLE',
                    message: 'Forwarder transfer completed but no transaction hash returned.',
                });
            }
            return status;
        }
        if (status.status === 'failed') {
            const reason = status.forwardingDetails?.failureReason ?? 'unknown reason';
            throw new KitError({
                ...OnchainError.TRANSACTION_REVERTED,
                recoverability: 'FATAL',
                message: `Forwarder transfer failed: ${reason}`,
            });
        }
        if (status.status === 'expired') {
            throw new KitError({
                ...OnchainError.TRANSACTION_REVERTED,
                recoverability: 'FATAL',
                message: 'Transfer attestation expired before forwarding completed.',
            });
        }
        await new Promise((resolve) => setTimeout(resolve, FORWARDER_POLL_INTERVAL_MS));
    }
    throw new KitError({
        ...NetworkError.TIMEOUT,
        recoverability: 'RETRYABLE',
        message: 'Forwarder polling timed out waiting for transfer completion.',
        cause: { trace: { transferId } },
    });
}
/** Validate recipient and customFee.recipientAddress when present. */
function assertSpendAddresses(params, destChain) {
    if (params.to.recipientAddress) {
        assertValidAddress(params.to.recipientAddress, destChain, 'recipientAddress');
    }
    const customFeeRecipient = params.config?.customFee?.recipientAddress;
    if (customFeeRecipient) {
        assertValidAddress(customFeeRecipient, destChain, 'customFee.recipientAddress');
    }
}
/**
 * Execute the normal (non-retry) spend path: build burn intents,
 * sign them via each source adapter, then submit the transfer to the
 * Gateway API to obtain an attestation and signature.
 *
 * **Orchestration steps (in order):**
 * 1. Normalise allocations and assert network/forwarder compatibility.
 * 2. Build burn intents from the normalised allocations.
 * 3. `POST /v1/estimate` — obtain fee estimates for each intent.
 * 4. Group intents by source adapter and sign each group
 *    (EVM: EIP-712 batch signature; Solana: per-intent Ed25519).
 * 5. `POST /v1/transfer` — submit signed intents; receive the
 *    attestation, signature, and optional `transferId`.
 *
 * Each completed step is pushed onto the mutable `steps` array and
 * dispatched as a spend-step event through `dispatcher`.
 *
 * **Preconditions:**
 * - `params.from` is non-nullish (enforced by the call-site).
 * - Every source allocation chain and the destination chain must
 *   share the same network environment (testnet / mainnet).
 * - When `useForwarder` is `true`, both source and destination
 *   chains must declare forwarder support.
 *
 * **Postconditions (on success):**
 * - The returned `attestation` and `attestationSignature` are
 *   non-empty hex strings ready for on-chain mint.
 * - `allocationResults` contains the formatted breakdown per source
 *   chain, and `fees` contains estimated fee entries.
 *
 * **Side effects:**
 * - Send HTTP POST requests to the Gateway estimate and transfer
 *   endpoints.
 * - Invoke adapter signing operations (may trigger wallet pop-ups or
 *   hardware-signer interaction).
 * - Mutate the caller-owned `steps` array with step descriptors.
 * - Emit spend-step events via `dispatcher`.
 *
 * @param params - Spend parameters with a guaranteed non-null `from`.
 * @param destChain - Resolved destination chain with Gateway v1
 *   contract addresses.
 * @param recipientAddress - Resolved recipient address on the
 *   destination chain.
 * @param useForwarder - Whether the Forwarding Service path is active.
 * @param dispatcher - Optional action dispatcher for spend-step events.
 * @param steps - Mutable array that receives a descriptor for each
 *   completed step (buildBurnIntents, signBurnIntents, fetchAttestation).
 * @returns Attestation payload, allocation breakdown, and fee details.
 * @throws KitError `VALIDATION_FAILED` when network environments are
 *   mixed or a chain lacks forwarder support.
 * @throws KitError `GATEWAY_API_ERROR` when the estimate or transfer
 *   API call fails (propagated via {@link throwGatewayApiError}).
 * @throws KitError `TRANSACTION_REVERTED` (RETRYABLE) when the
 *   non-forwarder transfer response is missing attestation or signature.
 * @throws KitError Propagated from adapter signing if the user rejects
 *   or the signer is unavailable.
 */
async function resolveAllocationsAndIntents(params, destChain, recipientAddress, useForwarder) {
    if (params.amountIn) {
        const rawSources = Array.isArray(params.from) ? params.from : [params.from];
        const sourcesArray = rawSources.filter((s) => s != null);
        const networkType = destChain.isTestnet ? 'testnet' : 'mainnet';
        const balanceResults = await Promise.all(sourcesArray.map(async (source) => {
            const querySource = {
                adapter: source.adapter,
            };
            if (source.sourceAccount)
                querySource['account'] = source.sourceAccount;
            if ('address' in source && source.address) {
                querySource['address'] = source.address;
            }
            return getBalances({
                token: params.token,
                sources: querySource,
                networkType,
            });
        }));
        const chainBalances = [];
        for (let i = 0; i < balanceResults.length; i++) {
            const breakdowns = balanceResults[i]?.breakdown[0]?.breakdown ?? [];
            for (const b of breakdowns) {
                chainBalances.push({
                    chain: b.chain,
                    confirmedBalance: b.confirmedBalance,
                    sourceIndex: i,
                });
            }
        }
        const customFeeConfig = params.config?.customFee;
        const autoAllocResult = computeAutoAllocation({
            amountIn: params.amountIn,
            destinationChain: destChain.chain,
            chainBalances,
            useForwarder,
            ...(customFeeConfig ? { customFee: customFeeConfig } : {}),
        });
        const normalizedAutoAllocations = await normalizeAutoAllocations(autoAllocResult, sourcesArray);
        const intents = buildAutoAllocatedBurnIntents(normalizedAutoAllocations, destChain, recipientAddress, params.token, params.config?.customFee);
        const allocations = [
            ...normalizedAutoAllocations.user,
            ...normalizedAutoAllocations.devFee,
            ...normalizedAutoAllocations.circleFee,
        ];
        return { allocations, intents };
    }
    const allocations = await normalizeAllocations(params);
    const intents = buildBurnIntents(allocations, destChain, recipientAddress, params.token, params.config?.customFee);
    return { allocations, intents };
}
/**
 * Call the Gateway estimate API, handling the forwarder vs standard path.
 *
 * @param apiBaseUrl - Gateway API base URL (no trailing slash).
 * @param estimateBody - Serialised estimate request body.
 * @param useForwarder - Whether the Forwarding Service path is active.
 * @param allocations - Normalised allocations (forwarded to error handler).
 * @returns Estimate entries and optional forwarding fee.
 */
async function fetchEstimate(apiBaseUrl, estimateBody, useForwarder, allocations) {
    if (useForwarder) {
        let fwdResponse;
        try {
            fwdResponse = await pollApiPost(`${apiBaseUrl}/v1/estimate?enableForwarder=true`, estimateBody, assertGatewayForwarderEstimateResponse);
        }
        catch (error) {
            throwGatewayApiError(error, allocations);
        }
        return {
            entries: fwdResponse.body,
            forwardingFee: fwdResponse.fees.forwardingFee,
        };
    }
    let entries;
    try {
        entries = await pollApiPost(`${apiBaseUrl}/v1/estimate`, estimateBody, assertGatewayEstimateResponse);
    }
    catch (error) {
        throwGatewayApiError(error, allocations);
    }
    return { entries, forwardingFee: undefined };
}
/**
 * Validate allocations, call the estimate API, and return estimated intents.
 *
 * Shared pipeline used by both the normal spend path and the estimate-only
 * path. Handles forwarder route validation, network compatibility, and the
 * estimate API call.
 *
 * @param params - Spend parameters.
 * @param destChain - Resolved destination chain with Gateway v1 config.
 * @param recipientAddress - Resolved recipient address.
 * @param useForwarder - Whether the Forwarding Service path is active.
 * @returns Allocations, estimated intents, and optional forwarding fee.
 */
async function resolveValidatedIntents(params, destChain, recipientAddress, useForwarder) {
    if (useForwarder) {
        assertForwarderRouteSupport(destChain);
    }
    const { allocations, intents } = await resolveAllocationsAndIntents(params, destChain, recipientAddress, useForwarder);
    assertNetworkCompatibility(allocations, destChain);
    if (useForwarder) {
        assertForwarderRouteSupport(destChain, allocations);
    }
    const apiBaseUrl = getGatewayApiBaseUrl(destChain.isTestnet);
    const estimateBody = buildEstimateRequestBody(intents);
    const { entries, forwardingFee } = await fetchEstimate(apiBaseUrl, estimateBody, useForwarder, allocations);
    const estimatedIntents = parseEstimateResponse(entries, intents);
    return { allocations, estimatedIntents, forwardingFee };
}
/**
 * Push a spend step onto the mutable array and dispatch it as an event.
 *
 * @param steps - Mutable array that accumulates step descriptors.
 * @param dispatcher - Optional action dispatcher for spend-step events.
 * @param stepName - Fully-qualified step event name.
 * @param chainName - Chain identifier for the event payload.
 * @param step - The completed spend step data.
 */
function pushStep(steps, dispatcher, stepName, chainName, step) {
    steps.push(step);
    dispatchSpendStepEvent(dispatcher, stepName, chainName, step);
}
/**
 * Extract the attestation and signature from the transfer response,
 * validating presence for non-forwarder transfers.
 */
function extractAttestation(transferResponse, useForwarder) {
    if (useForwarder) {
        return {
            attestation: transferResponse.attestation ?? '',
            attestationSignature: transferResponse.signature ?? '',
        };
    }
    if (!transferResponse.attestation || !transferResponse.signature) {
        throw new KitError({
            ...NetworkError.GATEWAY_API_ERROR,
            recoverability: 'FATAL',
            message: 'Gateway transfer response missing attestation or signature.',
        });
    }
    return {
        attestation: transferResponse.attestation,
        attestationSignature: transferResponse.signature,
    };
}
async function runSpendNormalPath(params, destChain, useForwarder, dispatcher, steps) {
    const chainName = destChain.name;
    const recipientAddress = await resolveRecipientAddress(params.to);
    const { allocations, estimatedIntents, forwardingFee: estimateFwdFee, } = await resolveValidatedIntents(params, destChain, recipientAddress, useForwarder);
    pushStep(steps, dispatcher, 'gateway.spend.step.buildBurnIntents', chainName, {
        name: 'buildBurnIntents',
        state: 'success',
        data: {
            intentCount: estimatedIntents.length,
            allocations: allocations.map((a) => ({
                chain: a.chain.name,
                amount: formatUnits(a.amount.toString(), USDC_DECIMALS$1),
            })),
            intents: estimatedIntents.map((i) => ({
                sourceDomain: i.spec.sourceDomain,
                destinationDomain: i.spec.destinationDomain,
                value: formatUnits(i.spec.value.toString(), USDC_DECIMALS$1),
                maxFee: formatUnits(i.maxFee.toString(), USDC_DECIMALS$1),
            })),
        },
    });
    const adapterGroups = groupIntentsByAdapter(estimatedIntents, allocations);
    const signedSets = await signIntentGroups(adapterGroups);
    pushStep(steps, dispatcher, 'gateway.spend.step.signBurnIntents', chainName, {
        name: 'signBurnIntents',
        state: 'success',
        data: {
            signedSetCount: signedSets.length,
            signatures: signedSets.map((s) => ({
                intentCount: s.intents.length,
                signature: s.signature,
            })),
        },
    });
    const transferBody = buildTransferRequestBody(signedSets);
    const transferApiBaseUrl = getGatewayApiBaseUrl(destChain.isTestnet);
    const forwarderParam = useForwarder ? '?enableForwarder=true' : '';
    let transferResponse;
    try {
        transferResponse = await pollApiPost(`${transferApiBaseUrl}/v1/transfer${forwarderParam}`, transferBody, assertGatewayTransferResponse);
    }
    catch (error) {
        throwGatewayApiError(error, allocations);
    }
    const forwardingFee = estimateFwdFee ?? transferResponse.fees?.forwardingFee;
    pushStep(steps, dispatcher, 'gateway.spend.step.fetchAttestation', chainName, {
        name: 'fetchAttestation',
        state: 'success',
        data: {
            forwardingEnabled: useForwarder,
            ...(!useForwarder && {
                attestation: transferResponse.attestation,
                signature: transferResponse.signature,
            }),
            ...(transferResponse.transferId && {
                transferId: transferResponse.transferId,
            }),
        },
    });
    const allocationResults = allocations.map((a) => ({
        amount: formatUnits(a.amount.toString(), USDC_DECIMALS$1),
        chain: a.chain.chain,
        sourceAccount: a.sourceDepositor,
    }));
    const fees = computeEstimateFees(estimatedIntents, allocations, params.config?.customFee);
    const { attestation, attestationSignature } = extractAttestation(transferResponse, useForwarder);
    return {
        recipientAddress,
        attestation,
        attestationSignature,
        transferId: transferResponse.transferId,
        expirationBlock: transferResponse.expirationBlock,
        allocationResults,
        fees,
        forwardingFee,
    };
}
const HEX_PATTERN = /^0x[0-9a-fA-F]+$/;
async function resolveRecipientAddress(dest) {
    if (isForwarderOnly(dest)) {
        return dest.recipientAddress;
    }
    if (dest.recipientAddress) {
        return dest.recipientAddress;
    }
    const adapterCtx = ('address' in dest && dest.address !== undefined
        ? { adapter: dest.adapter, chain: dest.chain, address: dest.address }
        : { adapter: dest.adapter, chain: dest.chain });
    return resolveSignerAddress(adapterCtx, dest.chain);
}
function validateRetryConfig(retryConfig) {
    if (!retryConfig ||
        !HEX_PATTERN.test(retryConfig.attestation) ||
        !HEX_PATTERN.test(retryConfig.signature)) {
        throw createValidationFailedError('config.retry', retryConfig, 'attestation and signature must be non-empty hex strings (0x-prefixed)');
    }
}
function appendForwarderFee(fees, forwardingFee) {
    if (!forwardingFee)
        return fees;
    const entry = {
        type: 'forwarder',
        token: 'USDC',
        amount: forwardingFee,
    };
    return [...(fees ?? []), entry];
}
function updateFeesWithActual(fees, completionStatus) {
    const actual = completionStatus.fees?.forwardingFee;
    if (!actual || !fees)
        return fees;
    return fees.map((f) => f.type === 'forwarder' ? { ...f, amount: actual } : f);
}
async function resolveDestinationTxHash(params, destChain, forwarder, transferId, attestation, attestationSignature, fees) {
    if (forwarder && transferId) {
        const apiBaseUrl = getGatewayApiBaseUrl(destChain.isTestnet);
        const completionStatus = await pollForwarderCompletion(apiBaseUrl, transferId);
        if (!completionStatus.transactionHash) {
            throw new KitError({
                ...OnchainError.TRANSACTION_REVERTED,
                recoverability: 'RESUMABLE',
                message: 'Forwarder completed but did not return a transaction hash.',
            });
        }
        return {
            txHash: completionStatus.transactionHash,
            fees: updateFeesWithActual(fees, completionStatus),
        };
    }
    if (forwarder) {
        throw createValidationFailedError('to', params.to, 'Forwarder was enabled but the transfer API did not return a transferId');
    }
    if (isForwarderOnly(params.to)) {
        throw createValidationFailedError('to', params.to, 'Destination has no adapter; cannot perform user-signed mint');
    }
    const dest = params.to;
    const destAdapterCtx = ('address' in dest && dest.address !== undefined
        ? { adapter: dest.adapter, chain: destChain, address: dest.address }
        : {
            adapter: dest.adapter,
            chain: destChain,
        });
    const destOperationContext = extractOperationContext(destAdapterCtx);
    const mintRequest = await dest.adapter.prepareAction('gateway.v1.gatewayMint', {
        attestation: attestation,
        signature: attestationSignature,
        chain: destChain,
    }, destOperationContext);
    try {
        return {
            txHash: await executeAndWait$2(dest.adapter, mintRequest, destChain),
            fees,
        };
    }
    catch (err) {
        throw createMintFailedError(err, attestation, attestationSignature);
    }
}
function buildSpendResult(recipientAddress, destChain, txHash, allocationResults, fees, transferId, expirationBlock) {
    const result = {
        recipientAddress,
        destinationChain: destChain.chain,
        txHash,
        explorerUrl: buildExplorerUrl(destChain, txHash),
    };
    if (allocationResults !== undefined && allocationResults.length > 0) {
        result.allocations = allocationResults;
    }
    if (fees !== undefined) {
        result.fees = fees;
    }
    if (transferId) {
        result.transferId = transferId;
    }
    if (expirationBlock) {
        result.expirationBlock = expirationBlock;
    }
    return result;
}
/**
 * Resolve the spend context for the retry path (attestation-only mint).
 */
async function resolveRetryContext(params) {
    const retryConfig = params.config?.retry;
    validateRetryConfig(retryConfig);
    return {
        recipientAddress: await resolveRecipientAddress(params.to),
        attestation: retryConfig.attestation,
        attestationSignature: retryConfig.signature,
        transferId: undefined,
        expirationBlock: undefined,
        allocationResults: undefined,
        fees: undefined,
        forwardingFee: undefined,
    };
}
/**
 * Execute the mint step, recording success/error as a spend step.
 */
async function executeMintStep(opts) {
    const { params, destChain, forwarder, transferId, attestation, attestationSignature, fees, steps, dispatcher, } = opts;
    try {
        const mintResult = await resolveDestinationTxHash(params, destChain, forwarder, transferId, attestation, attestationSignature, fees);
        pushStep(steps, dispatcher, 'gateway.spend.step.mint', destChain.name, {
            name: 'mint',
            state: 'success',
            txHash: mintResult.txHash,
            explorerUrl: buildExplorerUrl(destChain, mintResult.txHash),
        });
        return mintResult;
    }
    catch (err) {
        pushStep(steps, dispatcher, 'gateway.spend.step.mint', destChain.name, {
            name: 'mint',
            state: 'error',
            errorMessage: err instanceof Error ? err.message : String(err),
            error: err,
        });
        throw err;
    }
}
/**
 * Execute a Gateway spend (mint): move USDC from source chain(s) to the destination chain.
 *
 * When `config.retry` is provided, skips estimate/sign/transfer and mints using the
 * supplied attestation and signature. Otherwise runs the full flow and mints on success.
 *
 * Step events are dispatched through the optional `dispatcher` as each phase completes:
 * `buildBurnIntents` → `signBurnIntents` → `transfer` → `mint` (normal path) or
 * `mint` only (retry path).
 *
 * @typeParam TFromAdapterCapabilities - Capabilities of the source adapter(s).
 * @typeParam TToAdapterCapabilities - Capabilities of the destination adapter.
 * @param params - Spend parameters: source(s), destination, token, optional custom fee and retry.
 * @param dispatcher - Optional action dispatcher for emitting spend step events.
 * @returns The spend result (allocations, recipient, destination chain, tx hash, explorer URL, steps).
 * @throws Error When `from` is missing and retry is not used.
 * @throws KitError (TRANSACTION_REVERTED, RESUMABLE) When the destination mint transaction fails.
 *   The attestation and signature are available in `error.cause.trace` for retry.
 *
 * @example
 * ```typescript
 * import { spend } from '@circle-fin/provider-gateway-v1'
 * const result = await spend({
 *   from: { adapter: evmAdapter, chain: 'Ethereum', allocations: [{ chain: 'Ethereum', amount: '100' }] },
 *   to: { adapter: baseAdapter, chain: 'Base' },
 *   token: 'USDC',
 * })
 * console.log(result.txHash, result.explorerUrl)
 * ```
 */
async function spend(params, dispatcher) {
    const destChain = resolveChainIdentifier(params.to.chain);
    assertGatewayV1(destChain);
    assertSpendAddresses(params, destChain);
    const forwarder = isForwarderEnabled(params.to);
    const steps = [];
    const context = params.config?.retry
        ? await resolveRetryContext(params)
        : await resolveNormalContext(params, destChain, forwarder, dispatcher, steps);
    const fees = appendForwarderFee(context.fees, context.forwardingFee);
    const mintResult = await executeMintStep({
        params,
        destChain,
        forwarder,
        transferId: context.transferId,
        attestation: context.attestation,
        attestationSignature: context.attestationSignature,
        fees,
        steps,
        dispatcher,
    });
    const result = buildSpendResult(context.recipientAddress, destChain, mintResult.txHash, context.allocationResults, mintResult.fees, context.transferId, context.expirationBlock);
    result.steps = steps;
    return result;
}
/**
 * Resolve the spend context via the normal (non-retry) path.
 * Validates `from`, then delegates to `runSpendNormalPath`.
 */
async function resolveNormalContext(params, destChain, forwarder, dispatcher, steps) {
    if (!params.from) {
        throw createValidationFailedError('from', params.from, 'Source (from) is required when config.retry is not provided.');
    }
    return runSpendNormalPath({ ...params, from: params.from }, destChain, forwarder, dispatcher, steps);
}
/**
 * Estimate fees for a Gateway spend without executing it.
 *
 * Returns provider (transfer) fees, gas fees, and optional kit (custom) fee
 * with per-chain breakdown when applicable.
 *
 * @typeParam TFromAdapterCapabilities - Capabilities of the source adapter(s).
 * @typeParam TToAdapterCapabilities - Capabilities of the destination adapter.
 * @param params - Same shape as spend (from, to, token, optional config.customFee).
 * @returns Object with a `fees` array of {@link FeeEntry} (provider, gasFee, kit).
 *
 * @example
 * ```typescript
 * import { estimateSpend } from '@circle-fin/provider-gateway-v1'
 * const { fees } = await estimateSpend({
 *   from: { adapter, chain: 'Ethereum', allocations: [{ chain: 'Ethereum', amount: '100' }] },
 *   to: { adapter: baseAdapter, chain: 'Base' },
 *   token: 'USDC',
 * })
 * fees.forEach((f) => console.log(f.type, f.amount, f.allocations))
 * ```
 */
async function estimateSpend(params) {
    const destChain = resolveChainIdentifier(params.to.chain);
    assertGatewayV1(destChain);
    assertSpendAddresses(params, destChain);
    const forwarder = isForwarderEnabled(params.to);
    const recipientAddress = await resolveRecipientAddress(params.to);
    const { allocations, estimatedIntents, forwardingFee } = await resolveValidatedIntents(params, destChain, recipientAddress, forwarder);
    const fees = computeEstimateFees(estimatedIntents, allocations, params.config?.customFee);
    if (forwardingFee) {
        fees.push({
            type: 'forwarder',
            token: 'USDC',
            amount: forwardingFee,
        });
    }
    return { fees };
}

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------
// Heuristic: detect RPC errors caused by requesting a block the node hasn't
// seen yet. Relies on substring matching because RPC providers surface these
// as unstructured error messages (no standard code). Patterns cover geth,
// erigon, nethermind, and common provider wrappers. If a provider returns a
// novel wording, the error falls through and is re-thrown (safe direction).
function isBlockRangeError(error) {
    if (!(error instanceof Error))
        return false;
    const msg = error.message.toLowerCase();
    return (msg.includes('block not found') ||
        msg.includes('header not found') ||
        msg.includes('unknown block') ||
        msg.includes('requested block number') ||
        msg.includes('minimum context slot has not been reached'));
}
async function updateDelegate(params, action, state) {
    const { from, delegateAddress } = params;
    const { adapter } = from;
    const chain = resolveChainIdentifier(from.chain);
    assertGatewayV1(chain);
    const operationContext = extractOperationContext(from);
    const signerAddress = await resolveSignerAddress(from, chain);
    const tokenAddress = getTokenAddress(chain, params.token);
    assertValidAddress(delegateAddress, chain, 'delegate');
    assertNotSelfDelegation(chain, signerAddress, delegateAddress, action);
    await validateNativeBalanceForTransaction({
        adapter,
        operationContext: { ...operationContext, chain, address: signerAddress },
    });
    const request = await adapter.prepareAction(action, { token: tokenAddress, delegate: delegateAddress, chain }, operationContext);
    const txHash = await executeAndWait$2(adapter, request, chain);
    return {
        account: signerAddress,
        delegateAddress,
        chain: chain.chain,
        state,
        txHash,
        explorerUrl: buildExplorerUrl(chain, txHash),
    };
}
function assertNotSelfDelegation(chain, signerAddress, delegateAddress, action) {
    const normalizedSigner = chain.type === 'evm' ? signerAddress.toLowerCase() : signerAddress;
    const normalizedDelegate = chain.type === 'evm' ? delegateAddress.toLowerCase() : delegateAddress;
    if (normalizedSigner === normalizedDelegate) {
        const reason = action === 'gateway.v1.removeDelegate'
            ? 'cannot remove self as delegate: address must differ from signer'
            : 'cannot add self as delegate: address must differ from signer';
        throw createValidationFailedError('delegate', delegateAddress, reason);
    }
}
// ---------------------------------------------------------------------------
// addDelegate
// ---------------------------------------------------------------------------
/**
 * Grant spending rights to another address on the owner's Gateway account.
 *
 * Calls `addDelegate(token, delegate)` on the Gateway Wallet contract (EVM)
 * or the `add_delegate` instruction (Solana).
 *
 * @param params - The owner's adapter context (`from`), delegate address, and token.
 * @returns Promise resolving to the delegate update result.
 * @throws KitError on self-delegation or if the chain is unsupported.
 *
 * @example
 * ```typescript
 * import { addDelegate } from '@circle-fin/provider-gateway-v1'
 * import type { UpdateDelegateParams } from '@circle-fin/provider-gateway-v1'
 *
 * declare const params: UpdateDelegateParams
 * const result = await addDelegate(params)
 * // result.state === 'added'
 * ```
 */
async function addDelegate(params) {
    return updateDelegate(params, 'gateway.v1.addDelegate', 'added');
}
// ---------------------------------------------------------------------------
// removeDelegate
// ---------------------------------------------------------------------------
/**
 * Revoke spending rights from a delegate on the owner's Gateway account.
 *
 * Calls `removeDelegate(token, delegate)` on the Gateway Wallet contract (EVM)
 * or the `remove_delegate` instruction (Solana).
 *
 * @param params - The owner's adapter context (`from`), delegate address, and token.
 * @returns Promise resolving to the delegate update result.
 * @throws KitError on self-delegation or if the chain is unsupported.
 *
 * @example
 * ```typescript
 * import { removeDelegate } from '@circle-fin/provider-gateway-v1'
 * import type { UpdateDelegateParams } from '@circle-fin/provider-gateway-v1'
 *
 * declare const params: UpdateDelegateParams
 * const result = await removeDelegate(params)
 * // result.state === 'removed'
 * ```
 */
async function removeDelegate(params) {
    return updateDelegate(params, 'gateway.v1.removeDelegate', 'removed');
}
// ---------------------------------------------------------------------------
// getDelegateStatus
// ---------------------------------------------------------------------------
/**
 * Check the finality-aware status of a delegate on a Gateway account.
 *
 * Uses a two-step optimization:
 * 1. Read `isAuthorizedForBalance` at the latest block (cheap, no HTTP).
 *    If `false`, return `'none'` immediately.
 * 2. Only when the latest read is `true`, fetch Gateway's `processedHeight`
 *    via `/v1/info` and re-read at that block. If the re-read returns `true`,
 *    the delegate is `'ready'` (finalized); otherwise it is `'pending'`.
 *
 * @param params - The adapter context (`from`), delegate address, and token.
 * @returns Promise resolving to `'none'`, `'pending'`, or `'ready'`.
 * @throws KitError if the chain is unsupported or `/v1/info` fails.
 *
 * @remarks
 * If the Gateway `/v1/info` endpoint is unreachable or returns an error,
 * the function throws rather than degrading to `'pending'`. This is
 * intentional: a transient Gateway outage means the finality state is
 * unknown, and silently returning `'pending'` could mask an infrastructure
 * issue. Callers should handle the error and retry as appropriate.
 *
 * @example
 * ```typescript
 * import { getDelegateStatus } from '@circle-fin/provider-gateway-v1'
 * import type { GetDelegateStatusParams } from '@circle-fin/provider-gateway-v1'
 *
 * declare const params: GetDelegateStatusParams
 * const status = await getDelegateStatus(params)
 * if (status === 'ready') { // safe to spend }
 * ```
 */
async function getDelegateStatus(params) {
    const { from, delegateAddress } = params;
    const { adapter } = from;
    const chain = resolveChainIdentifier(from.chain);
    assertGatewayV1(chain);
    assertValidAddress(delegateAddress, chain, 'delegateAddress');
    const operationContext = extractOperationContext(from);
    const signerAddress = await resolveSignerAddress(from, chain);
    const tokenAddress = getTokenAddress(chain, params.token);
    const baseActionParams = {
        token: tokenAddress,
        depositor: signerAddress,
        delegate: delegateAddress,
        chain,
    };
    // Step 1: Quick check at latest block (no HTTP call)
    const latestRequest = await adapter.prepareAction('gateway.v1.isDelegate', baseActionParams, operationContext);
    const latestResult = await latestRequest.execute();
    if (String(latestResult).toLowerCase() !== 'true') {
        return 'none';
    }
    // Step 2: On-chain says true — verify Gateway has finalized it
    if (chain.type === 'solana') {
        // Solana uses confirmed vs finalized commitment as a proxy for
        // Gateway finality. This is conservative — can only over-report
        // 'pending', never falsely report 'ready'.
        const finalizedRequest = await adapter.prepareAction('gateway.v1.isDelegate', { ...baseActionParams, commitment: 'finalized' }, operationContext);
        let finalizedResult;
        try {
            finalizedResult = await finalizedRequest.execute();
        }
        catch (error) {
            if (isBlockRangeError(error)) {
                return 'pending';
            }
            throw error;
        }
        return String(finalizedResult).toLowerCase() === 'true'
            ? 'ready'
            : 'pending';
    }
    // EVM: use processedHeight from /v1/info
    const processedHeight = await getProcessedHeight(chain.isTestnet, chain.gateway.domain);
    const finalizedRequest = await adapter.prepareAction('gateway.v1.isDelegate', { ...baseActionParams, blockNumber: processedHeight }, operationContext);
    // If the RPC node lags Gateway's indexer view, the historical read at
    // processedHeight may throw a block-range error. This is safe to treat
    // as 'pending' because processedHeight comes from Gateway's /v1/info
    // and represents what Gateway has finalized — if the RPC node hasn't
    // seen that block yet, the delegate is not yet usable for spend.
    // Re-throw structural errors to avoid masking real bugs.
    let finalizedResult;
    try {
        finalizedResult = await finalizedRequest.execute();
    }
    catch (error) {
        if (isBlockRangeError(error)) {
            return 'pending';
        }
        throw error;
    }
    return String(finalizedResult).toLowerCase() === 'true' ? 'ready' : 'pending';
}

function parseAmountSafe(amount) {
    try {
        return parseUnits(amount, USDC_DECIMALS$1);
    }
    catch (parseError) {
        throw createInvalidAmountError(amount, getErrorMessage(parseError));
    }
}
// ---------------------------------------------------------------------------
// initiateRemoveFund
// ---------------------------------------------------------------------------
/**
 * Start a delayed fund removal from a Gateway account.
 *
 * Dispatches `initiateWithdrawal` via the adapter action registry. A
 * mandatory withdrawal delay must elapse before {@link removeFund} can
 * complete the removal.
 *
 * @param params - The account owner's adapter context (`from`), amount, and token.
 * @returns Promise resolving to the initiation details including the
 *   `withdrawalBlock` at which {@link removeFund} may be called.
 * @throws If the chain does not support Gateway v1 or the transaction fails.
 */
async function initiateRemoveFund(params) {
    const { from, amount } = params;
    const { adapter } = from;
    const chain = resolveChainIdentifier(from.chain);
    assertGatewayV1(chain);
    const operationContext = extractOperationContext(from);
    const signerAddress = await resolveSignerAddress(from, chain);
    const tokenAddress = getTokenAddress(chain, params.token);
    const value = parseAmountSafe(amount);
    await validateNativeBalanceForTransaction({
        adapter,
        operationContext: { ...operationContext, chain, address: signerAddress },
    });
    const request = await adapter.prepareAction('gateway.v1.initiateWithdrawal', { token: tokenAddress, value, chain }, operationContext);
    let txHash;
    try {
        txHash = await executeAndWait$2(adapter, request, chain);
    }
    catch (error) {
        throw parseBlockchainError(error, {
            chain: chain.chain,
            token: params.token,
        });
    }
    // Fetch the post-transaction state in parallel — both reads are independent.
    const readParams = { token: tokenAddress, depositor: signerAddress, chain };
    const [withdrawingRaw, withdrawalBlockRaw] = await Promise.all([
        adapter
            .prepareAction('gateway.v1.withdrawingBalance', readParams, operationContext)
            .then(async (req) => req.execute()),
        adapter
            .prepareAction('gateway.v1.withdrawalBlock', readParams, operationContext)
            .then(async (req) => req.execute()),
    ]);
    const withdrawingValue = safeBigInt(String(withdrawingRaw), 'withdrawingBalance');
    const withdrawalBlockValue = safeBigInt(String(withdrawalBlockRaw), 'withdrawalBlock');
    return {
        amount,
        token: params.token,
        account: signerAddress,
        chain: chain.chain,
        withdrawingBalance: formatUnits(withdrawingValue.toString(), USDC_DECIMALS$1),
        withdrawalBlock: Number(withdrawalBlockValue),
        txHash,
        explorerUrl: buildExplorerUrl(chain, txHash),
    };
}
// ---------------------------------------------------------------------------
// removeFund
// ---------------------------------------------------------------------------
/**
 * Complete a fund removal after the withdrawal delay has elapsed.
 *
 * Dispatches `withdraw` via the adapter action registry. The full pending
 * withdrawal balance is returned to the caller — no `amount` is required.
 *
 * @param params - The account owner's adapter context (`from`) and token.
 * @returns Promise resolving to the removal details including the final
 *   removed `amount` and txHash.
 * @throws If the chain does not support Gateway v1 or the transaction fails.
 *
 * @see initiateRemoveFund to start the process.
 */
async function removeFund(params) {
    const { from } = params;
    const { adapter } = from;
    const chain = resolveChainIdentifier(from.chain);
    assertGatewayV1(chain);
    const operationContext = extractOperationContext(from);
    const signerAddress = await resolveSignerAddress(from, chain);
    const tokenAddress = getTokenAddress(chain, params.token);
    await validateNativeBalanceForTransaction({
        adapter,
        operationContext: { ...operationContext, chain, address: signerAddress },
    });
    // Read the pending balance before withdrawing — the contract resets it to 0
    // after withdraw() executes, so this is the only way to capture the amount.
    const withdrawingBalanceReq = await adapter.prepareAction('gateway.v1.withdrawingBalance', { token: tokenAddress, depositor: signerAddress, chain }, operationContext);
    const withdrawingRaw = await withdrawingBalanceReq.execute();
    const withdrawingValue = safeBigInt(String(withdrawingRaw), 'withdrawingBalance');
    if (withdrawingValue === 0n) {
        throw new KitError({
            ...BalanceError.INSUFFICIENT_TOKEN,
            recoverability: 'FATAL',
            message: 'No pending withdrawal to complete. Call initiateRemoveFund first to start a fund removal.',
        });
    }
    const withdrawingBalance = formatUnits(withdrawingValue.toString(), USDC_DECIMALS$1);
    const request = await adapter.prepareAction('gateway.v1.withdraw', { token: tokenAddress, chain }, operationContext);
    let txHash;
    try {
        txHash = await executeAndWait$2(adapter, request, chain);
    }
    catch (error) {
        throw parseBlockchainError(error, {
            chain: chain.chain,
            token: params.token,
        });
    }
    return {
        amount: withdrawingBalance,
        token: params.token,
        account: signerAddress,
        chain: chain.chain,
        txHash,
        explorerUrl: buildExplorerUrl(chain, txHash),
    };
}

const SUPPORTED_CHAINS = Object.values(Chains).filter((chain) => isGatewayV1Supported(chain));
/**
 * Return all chains supported by the provider for the given token.
 *
 * Uses static chain definitions filtered by {@link isGatewayV1Supported}.
 * No network calls are made.
 *
 * @param token - Optional token filter. Only tokens listed in
 *   {@link SUPPORTED_TOKENS} are accepted; any other value returns an
 *   empty array.
 * @returns Array of supported chain definitions.
 */
function getSupportedChains(token) {
    if (token !== undefined && !SUPPORTED_TOKENS.includes(token)) {
        return [];
    }
    return SUPPORTED_CHAINS;
}

function buildPayload(opName, chain, data) {
    return { protocol: 'gateway', version: 'v1', tags: { opName, chain }, data };
}
function dispatchEvent(dispatcher, opName, stage, chain, data) {
    if (!dispatcher) {
        return;
    }
    const key = `gateway.${opName}.${stage}`;
    dispatcher.dispatch(key, buildPayload(opName, chain, data));
}
/**
 * Dispatch a gateway started event through the provider's action dispatcher.
 *
 * @param dispatcher - The action dispatcher (may be null if no listeners registered).
 * @param opName - The operation name (e.g. 'deposit', 'spend').
 * @param chain - Chain identifier relevant to the operation.
 * @param data - The operation input params.
 */
function dispatchGatewayStartedEvent(dispatcher, opName, chain, data) {
    dispatchEvent(dispatcher, opName, 'started', chain, data);
}
/**
 * Dispatch a gateway succeeded event through the provider's action dispatcher.
 *
 * @param dispatcher - The action dispatcher (may be null if no listeners registered).
 * @param opName - The operation name (e.g. 'deposit', 'spend').
 * @param chain - Chain identifier relevant to the operation.
 * @param data - The operation result data.
 */
function dispatchGatewaySucceededEvent(dispatcher, opName, chain, data) {
    dispatchEvent(dispatcher, opName, 'succeeded', chain, data);
}
/**
 * Dispatch a gateway failed event through the provider's action dispatcher.
 *
 * @param dispatcher - The action dispatcher (may be null if no listeners registered).
 * @param opName - The operation name (e.g. 'deposit', 'spend').
 * @param chain - Chain identifier relevant to the operation.
 * @param error - The error that caused the failure.
 */
function dispatchGatewayFailedEvent(dispatcher, opName, chain, error) {
    dispatchEvent(dispatcher, opName, 'failed', chain, extractErrorInfo(error));
}

// ---------------------------------------------------------------------------
// Factory
// ---------------------------------------------------------------------------
/**
 * Creates a Gateway v1 provider instance (functional implementation).
 *
 * Returns a plain object that implements {@link IGatewayProvider} by
 * delegating to the standalone functions in `operations/`.
 *
 * @returns An {@link IGatewayProvider} instance.
 *
 * @example
 * ```typescript
 * import { createGatewayV1Provider } from '@circle-fin/provider-gateway-v1'
 *
 * const provider = createGatewayV1Provider()
 * const chains = provider.getSupportedChains()
 * ```
 */
function createGatewayV1Provider() {
    /**
     * Execute an operation with started/succeeded/failed event dispatch.
     */
    async function withEvents(opName, chain, startedData, params, fn) {
        dispatchGatewayStartedEvent(provider.actionDispatcher, opName, chain, startedData);
        try {
            const result = await fn(params);
            dispatchGatewaySucceededEvent(provider.actionDispatcher, opName, chain, result);
            return result;
        }
        catch (error) {
            dispatchGatewayFailedEvent(provider.actionDispatcher, opName, chain, error);
            throw error;
        }
    }
    const provider = {
        name: GATEWAY_V1_PROVIDER_NAME,
        actionDispatcher: null,
        registerDispatcher(dispatcher) {
            provider.actionDispatcher = dispatcher;
        },
        deposit: async (params) => withEvents('deposit', extractChainInfo(params.from.chain).name, { amount: params.amount, token: params.token ?? 'USDC' }, params, deposit),
        depositFor: async (params) => withEvents('depositFor', extractChainInfo(params.from.chain).name, {
            amount: params.amount,
            token: params.token ?? 'USDC',
            depositAccount: params.depositAccount,
        }, params, depositFor),
        spend: async (params) => {
            const destChainName = extractChainInfo(params.to.chain).name;
            return withEvents('spend', destChainName, {
                destinationChain: destChainName,
                token: params.token ?? 'USDC',
            }, params, async (p) => spend(p, provider.actionDispatcher));
        },
        estimateSpend: async (params) => {
            const destChainName = extractChainInfo(params.to.chain).name;
            return withEvents('estimateSpend', destChainName, {
                destinationChain: destChainName,
                token: params.token ?? 'USDC',
            }, params, estimateSpend);
        },
        getBalances: async (params) => withEvents('getBalances', 'aggregate', { token: params.token ?? 'USDC' }, params, getBalances),
        addDelegate: async (params) => withEvents('addDelegate', extractChainInfo(params.from.chain).name, { delegateAddress: params.delegateAddress }, params, addDelegate),
        removeDelegate: async (params) => withEvents('removeDelegate', extractChainInfo(params.from.chain).name, { delegateAddress: params.delegateAddress }, params, removeDelegate),
        initiateRemoveFund: async (params) => withEvents('initiateRemoveFund', extractChainInfo(params.from.chain).name, { amount: params.amount, token: params.token ?? 'USDC' }, params, initiateRemoveFund),
        removeFund: async (params) => withEvents('removeFund', extractChainInfo(params.from.chain).name, { token: params.token ?? 'USDC' }, params, removeFund),
        // getDelegateStatus and getSupportedChains are intentionally not wrapped
        // in withEvents. getSupportedChains is synchronous. getDelegateStatus is a
        // lightweight read that consumers treat as a utility check, unlike
        // getBalances which involves API polling and benefits from lifecycle events.
        getDelegateStatus,
        getSupportedChains,
    };
    return provider;
}

exports.GATEWAY_V1_PROVIDER_NAME = GATEWAY_V1_PROVIDER_NAME;
exports.addDelegate = addDelegate;
exports.createGatewayV1Provider = createGatewayV1Provider;
exports.deposit = deposit;
exports.depositFor = depositFor;
exports.estimateSpend = estimateSpend;
exports.getBalances = getBalances;
exports.getDelegateStatus = getDelegateStatus;
exports.getSupportedChains = getSupportedChains;
exports.initiateRemoveFund = initiateRemoveFund;
exports.removeDelegate = removeDelegate;
exports.removeFund = removeFund;
exports.spend = spend;
//# sourceMappingURL=index.cjs.map
